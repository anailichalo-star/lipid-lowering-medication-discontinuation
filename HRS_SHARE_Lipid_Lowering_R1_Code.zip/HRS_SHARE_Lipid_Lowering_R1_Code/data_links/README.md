# Local study inputs

See [DATA_INPUT_MANIFEST.csv](../DATA_INPUT_MANIFEST.csv).
Place authorized source files in the listed paths on your local computer.
