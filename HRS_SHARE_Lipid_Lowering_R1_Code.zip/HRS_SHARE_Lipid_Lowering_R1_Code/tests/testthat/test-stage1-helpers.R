helper_path <- file.path(getOption("tte.project_root", getwd()), "R", "_stage1_helpers.R")
source(helper_path, encoding = "UTF-8")

testthat::test_that("labelled cleaned CSV headers recover canonical variable names", {
  input <- c(
    "hhidpn (个人标识符)",
    "rxhchol (是否服用高胆固醇类药物)",
    "plain_name"
  )
  testthat::expect_equal(
    tte_clean_variable_name(input),
    c("hhidpn", "rxhchol", "plain_name")
  )
})

testthat::test_that("mortgage files are not misclassified as mortality files", {
  role <- tte_classify_file_role("wave3/wave_3_mortgage_grid.dta")
  testthat::expect_equal(role, "raw_data")
})

testthat::test_that("true death and weight files are classified correctly", {
  testthat::expect_equal(
    tte_classify_file_role("Raw_data/h_elsa_eol_a2.dta"),
    "death_exit"
  )
  testthat::expect_equal(
    tte_classify_file_role("Wave 9/sharew9_gv_weights.dta"),
    "survey_weight"
  )
})

testthat::test_that("alias splitting is exact and case insensitive", {
  testthat::expect_equal(
    tte_split_aliases("rxhchol|trhchol|RXHCHOL"),
    c("rxhchol", "trhchol")
  )
})
