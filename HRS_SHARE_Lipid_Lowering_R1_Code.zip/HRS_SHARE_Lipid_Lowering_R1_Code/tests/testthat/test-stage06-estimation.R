testthat::test_that("cluster covariance and standardized effects are finite", {
  helper_path <- file.path(getOption("tte.project_root", Sys.getenv("TTE_PROJECT_ROOT", unset = normalizePath(".", winslash = "/", mustWork = FALSE))), "R", "_stage06_helpers.R")
  source(helper_path, encoding = "UTF-8", local = TRUE)
  set.seed(20260908)
  n <- 500L
  synthetic <- data.frame(
    person_id = rep(seq_len(n / 2L), each = 2L),
    treatment = stats::rbinom(n, 1, 0.30),
    sequence = factor(rep(c("trial_1", "trial_2"), n / 2L)),
    followup_time_years = stats::runif(n, 2, 4),
    model_weight = stats::runif(n, 0.5, 1.5),
    survey_weight_scaled = stats::runif(n, 0.7, 1.3)
  )
  hazard <- exp(-2.8 + 0.25 * synthetic$treatment +
    0.15 * (synthetic$sequence == "trial_2"))
  synthetic$primary_event <- stats::rbinom(
    n, 1, 1 - exp(-hazard * synthetic$followup_time_years)
  )
  fit <- stats::glm(
    primary_event ~ treatment + sequence + offset(log(followup_time_years)),
    data = synthetic,
    family = stats::quasibinomial(link = "cloglog"),
    weights = model_weight
  )
  robust <- tte_cluster_vcov_glm(fit, synthetic$person_id)
  effect <- tte_standardized_cloglog_effects(
    fit, robust$vcov, synthetic, synthetic$survey_weight_scaled, 3
  )
  testthat::expect_true(all(is.finite(robust$vcov)))
  testthat::expect_equal(robust$vcov, t(robust$vcov), tolerance = 1e-10)
  testthat::expect_true(effect$risk_continue > 0 && effect$risk_continue < 1)
  testthat::expect_true(effect$risk_discontinue > 0 && effect$risk_discontinue < 1)
  testthat::expect_equal(
    effect$risk_difference,
    effect$risk_discontinue - effect$risk_continue,
    tolerance = 1e-12
  )
})

testthat::test_that("Rubin pooling is reproducible and preserves the null scale", {
  helper_path <- file.path(getOption("tte.project_root", Sys.getenv("TTE_PROJECT_ROOT", unset = normalizePath(".", winslash = "/", mustWork = FALSE))), "R", "_stage06_helpers.R")
  source(helper_path, encoding = "UTF-8", local = TRUE)
  pooled <- tte_pool_scalar(
    estimates = rep(log(1.2), 20),
    within_variances = rep(0.01, 20),
    df_complete = 300,
    null = 0
  )
  testthat::expect_equal(pooled$estimate, log(1.2), tolerance = 1e-12)
  testthat::expect_equal(pooled$between_variance, 0, tolerance = 1e-15)
  testthat::expect_true(pooled$lower < pooled$estimate)
  testthat::expect_true(pooled$upper > pooled$estimate)
  testthat::expect_true(pooled$p_value >= 0 && pooled$p_value <= 1)
})
