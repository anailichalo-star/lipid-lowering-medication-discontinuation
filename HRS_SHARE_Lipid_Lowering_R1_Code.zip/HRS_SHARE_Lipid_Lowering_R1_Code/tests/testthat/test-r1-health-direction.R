testthat::test_that("self-rated health deterioration uses the cleaned scale", {
  source(file.path(getOption("tte.project_root"), "R", "_stage1_helpers.R"), local = TRUE)
  testthat::expect_identical(tte_self_rated_health_worsened(c(5, 1, 3, 3, NA), c(4, 3, 3, NA, 2)),
                             c(1L, 0L, 0L, NA_integer_, NA_integer_))
  testthat::expect_error(tte_self_rated_health_worsened(6, 2))
})
