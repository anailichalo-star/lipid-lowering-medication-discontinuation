source(file.path(getOption("tte.project_root", getwd()), "R", "_trial_helpers.R"), encoding = "UTF-8")

testthat::test_that("binary composite preserves unknown outcomes", {
  result <- tte_any_binary(c(1, 0, NA, 0), c(NA, 0, 0, NA))
  testthat::expect_equal(result, c(1L, 0L, NA_integer_, NA_integer_))
})

testthat::test_that("date intervals use the prespecified bounds", {
  earlier <- as.Date(c("2010-01-01", "2010-01-01", "2010-01-01"))
  later <- as.Date(c("2011-01-01", "2012-01-01", "2015-01-02"))
  testthat::expect_equal(tte_valid_interval(later, earlier, 1, 4), c(TRUE, TRUE, FALSE))
})

testthat::test_that("snapshot choice uses the selected source", {
  result <- tte_choose_value(c(10, 20, 30), c(11, 21, 31), c(1L, 2L, NA_integer_))
  testthat::expect_equal(result, c(10, 21, NA_real_))
})

testthat::test_that("midpoint death date is bounded by the interval", {
  result <- tte_midpoint_date(as.Date("2010-01-01"), as.Date("2012-01-01"))
  testthat::expect_true(result > as.Date("2010-01-01"))
  testthat::expect_true(result < as.Date("2012-01-01"))
})

testthat::test_that("ELSA mortwave codes map only documented death intervals", {
  values <- c(11, 13, 21, 33, 42, 53, 61, 63, 0, -3, -5, NA, 99)
  expected <- c(1L, 1L, 2L, 3L, 4L, 5L, 6L, 6L, rep(NA_integer_, 5L))
  testthat::expect_equal(tte_elsa_mortwave_death_wave(values), expected)
})

testthat::test_that("ELSA mortality coverage excludes unlinked and unresolved records", {
  values <- c(0, 51, -3, -5, NA, 51)
  linked <- c(TRUE, TRUE, TRUE, TRUE, TRUE, FALSE)
  testthat::expect_equal(
    tte_elsa_mortwave_covered(values, linked),
    c(1L, 1L, 0L, 0L, 0L, 0L)
  )
})
