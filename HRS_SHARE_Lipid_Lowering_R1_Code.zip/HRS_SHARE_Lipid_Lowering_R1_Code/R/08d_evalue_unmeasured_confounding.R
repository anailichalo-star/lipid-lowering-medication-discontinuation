# Stage 08d: E-values for risk-ratio estimates. E-values quantify the minimum
# joint association an unmeasured confounder would need with exposure and
# outcome, conditional on measured covariates, to move an RR to the null.

options(stringsAsFactors = FALSE)
project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
if (!requireNamespace("data.table", quietly = TRUE)) {
  stop("Missing required package: data.table", call. = FALSE)
}
analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
output_root <- file.path(project_root, analysis_config$output_root)
output_dir <- file.path(output_root, "stage08d_evalues")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

input_manifest <- data.table::data.table(
  analysis_family = c(
    "primary", "component", "functional",
    "health_deterioration_restricted", "overlap_weight", "age_80plus"
  ),
  path = c(
    file.path(output_root, "stage06_primary_effects", "06_primary_effects_pooled.csv"),
    file.path(output_root, "stage07c_component_effects", "07c_component_effects_pooled.csv"),
    file.path(output_root, "stage07h_functional_effects", "07h_functional_effects_pooled.csv"),
    file.path(output_root, "stage07f_restricted_effects", "07f_restricted_effects_pooled.csv"),
    file.path(output_root, "stage08a_alternative_weights", "08a_effects_pooled.csv"),
    file.path(output_root, "stage08b_age_sensitivity", "08b_age_effects_pooled.csv")
  )
)
missing_inputs <- input_manifest[!file.exists(path)]
if (nrow(missing_inputs)) {
  stop("Missing E-value input: ", paste(missing_inputs$path, collapse = ", "), call. = FALSE)
}

evalue_rr <- function(rr) {
  rr <- suppressWarnings(as.numeric(rr))
  if (!is.finite(rr) || rr <= 0) return(NA_real_)
  strength <- if (rr < 1) 1 / rr else rr
  strength + sqrt(strength * (strength - 1))
}

evalue_ci_nearest_null <- function(lower, upper) {
  lower <- suppressWarnings(as.numeric(lower))
  upper <- suppressWarnings(as.numeric(upper))
  if (!is.finite(lower) || !is.finite(upper) || lower <= 0 || upper <= 0) {
    return(NA_real_)
  }
  if (lower <= 1 && upper >= 1) return(1)
  nearest <- if (lower > 1) lower else upper
  evalue_rr(nearest)
}

parts <- list()
for (i in seq_len(nrow(input_manifest))) {
  item <- input_manifest[i]
  table <- data.table::as.data.table(tte_read_csv_utf8(item$path))
  required <- c("cohort", "outcome", "measure", "estimate", "confidence_lower", "confidence_upper")
  missing <- setdiff(required, names(table))
  if (length(missing)) {
    stop(item$analysis_family, " table lacks: ", paste(missing, collapse = ", "), call. = FALSE)
  }
  rr <- table[measure == "risk_ratio"]
  if (!nrow(rr)) next
  rr[, analysis_family := item$analysis_family]
  if (!"outcome_label" %in% names(rr)) rr[, outcome_label := outcome]
  if (!"restriction" %in% names(rr)) rr[, restriction := ""]
  if (!"scheme" %in% names(rr)) rr[, scheme := ""]
  if (!"analysis" %in% names(rr)) rr[, analysis := ""]
  if (!"estimand" %in% names(rr)) rr[, estimand := "ATE"]
  parts[[item$analysis_family]] <- rr[, .(
    analysis_family, cohort, outcome, outcome_label,
    restriction, scheme, analysis, estimand,
    risk_ratio = suppressWarnings(as.numeric(estimate)),
    confidence_lower = suppressWarnings(as.numeric(confidence_lower)),
    confidence_upper = suppressWarnings(as.numeric(confidence_upper))
  )]
}
result <- data.table::rbindlist(parts, use.names = TRUE, fill = TRUE)
result[, evalue_point_estimate := vapply(risk_ratio, evalue_rr, numeric(1L))]
result[, evalue_confidence_limit := mapply(
  evalue_ci_nearest_null, confidence_lower, confidence_upper
)]
result[, confidence_interval_includes_null :=
  confidence_lower <= 1 & confidence_upper >= 1]
result[, interpretation := ifelse(
  confidence_interval_includes_null,
  "CI already includes the null; confidence-limit E-value equals 1",
  "E-value for the confidence limit nearest the null"
)]
data.table::setorder(result, analysis_family, cohort, outcome)
tte_write_csv(result, file.path(output_dir, "08d_evalues.csv"))

primary_result <- result[analysis_family == "primary"]
primary_lines <- vapply(seq_len(nrow(primary_result)), function(i) {
  row <- primary_result[i]
  paste0(
    row$cohort, ": RR=", sprintf("%.3f", row$risk_ratio),
    " (95% CI ", sprintf("%.3f", row$confidence_lower), " to ",
    sprintf("%.3f", row$confidence_upper),
    "); E-value point=", sprintf("%.2f", row$evalue_point_estimate),
    ", confidence limit=", sprintf("%.2f", row$evalue_confidence_limit), "."
  )
}, character(1L))
summary_lines <- c(
  "Stage 08d: E-value analysis for unmeasured confounding",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "E-values are calculated on the risk-ratio scale.",
  "They do not address exposure misclassification, selection bias, or multiple biases jointly.",
  "", "Primary outcome:", primary_lines
)
writeLines(summary_lines, file.path(output_dir, "08d_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "08d_session_info.txt"), useBytes = TRUE)
message(paste(summary_lines, collapse = "\n"))
message("Stage 08d completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
