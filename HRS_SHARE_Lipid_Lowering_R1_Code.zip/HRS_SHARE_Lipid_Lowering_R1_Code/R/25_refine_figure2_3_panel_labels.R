# Re-render Figures 2 and 3 from their frozen data with lowercase panel labels.
# The plotting expressions are taken from the frozen R publication script, while
# all output is directed to new files. No statistical model is rerun.

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
output_root <- file.path(project_root, "outputs_r")
figure_dir <- file.path(output_root, "scientific_reports", "refined_figure2_3")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

stopifnot(requireNamespace("data.table", quietly = TRUE), requireNamespace("ggplot2", quietly = TRUE))
library(data.table)
library(ggplot2)

read_output <- function(relative_path) {
  path <- file.path(output_root, relative_path)
  if (!file.exists(path)) stop("Missing frozen output: ", path)
  data.table::fread(path, encoding = "UTF-8")
}
blue <- "#0072B2"
orange <- "#D55E00"
gray <- "#5C5C5C"
font_family <- "Arial"
format_p_label <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  ifelse(!is.finite(p), "", ifelse(p < 0.001, "P<0.001", sprintf("P=%.3f", p)))
}
theme_jaha <- function(base_size = 10) {
  ggplot2::theme_classic(base_size = base_size, base_family = font_family) +
    ggplot2::theme(
      axis.title = ggplot2::element_text(size = 10, colour = "black"),
      axis.text = ggplot2::element_text(size = 9.5, colour = "black"),
      strip.background = ggplot2::element_blank(),
      strip.text = ggplot2::element_text(size = 10, face = "bold", colour = "black"),
      legend.title = ggplot2::element_blank(),
      legend.text = ggplot2::element_text(size = 9.5, colour = "black"),
      plot.tag = ggplot2::element_text(size = 12, face = "bold", colour = "black"),
      panel.grid.major.x = ggplot2::element_line(colour = "#E6E6E6", linewidth = 0.3),
      panel.grid.minor = ggplot2::element_blank(),
      plot.margin = ggplot2::margin(5.5, 8, 5.5, 5.5)
    )
}
open_device <- function(path, width, height, dpi = NULL) {
  extension <- tolower(tools::file_ext(path))
  if (extension == "pdf") {
    if (capabilities("cairo")) grDevices::cairo_pdf(path, width = width, height = height, family = font_family)
    else grDevices::pdf(path, width = width, height = height, family = "sans")
  } else if (extension == "tiff") {
    grDevices::tiff(path, width = width, height = height, units = "in", res = dpi,
                    compression = "lzw", type = if (capabilities("cairo")) "cairo" else "windows", bg = "white")
  } else if (extension == "png") {
    grDevices::png(path, width = width, height = height, units = "in", res = dpi,
                   type = if (capabilities("cairo")) "cairo" else "windows", bg = "white")
  } else stop("Unsupported format: ", extension)
}
save_drawing <- function(draw, stem, width, height, tiff_dpi) {
  for (format in c("pdf", "tiff", "png")) {
    path <- file.path(figure_dir, paste0(stem, ".", format))
    if (file.exists(path)) stop("Refusing to overwrite: ", path)
    open_device(path, width, height, if (format == "png") 300 else tiff_dpi)
    draw()
    grDevices::dev.off()
  }
}

all_effects <- data.table::rbindlist(list(
  read_output("stage06_primary_effects/06_primary_effects_pooled.csv"),
  read_output("stage07c_component_effects/07c_component_effects_pooled.csv"),
  read_output("stage07h_functional_effects/07h_functional_effects_pooled.csv")
), use.names = TRUE, fill = TRUE)
outcome_order <- c("primary_event", "strict_event", "death_component", "death_adl_decline")
short_outcome <- c(
  primary_event = "Broad CVD or death", strict_event = "MI, stroke, or death",
  death_component = "All-cause death", death_adl_decline = "Death or ADL decline"
)

source_file <- file.path(project_root, "R", "12_generate_jaha_tables_figures_results.R")
lines <- readLines(source_file, encoding = "UTF-8", warn = FALSE)
start <- grep("# Figure 2: absolute and relative", lines, fixed = TRUE)
stop <- grep("# Figure 4: sensitivity analyses", lines, fixed = TRUE)
if (length(start) != 1L || length(stop) != 1L || stop <= start) stop("Figure source boundaries changed")
plot_code <- paste(lines[start:(stop - 2L)], collapse = "\n")
plot_code <- gsub('tag = "A"', 'tag = "a"', plot_code, fixed = TRUE)
plot_code <- gsub('tag = "B"', 'tag = "b"', plot_code, fixed = TRUE)
plot_code <- gsub('"A  Broad CVD or death"', '"a  Broad CVD or death"', plot_code, fixed = TRUE)
plot_code <- gsub('"B  Death or ADL decline"', '"b  Death or ADL decline"', plot_code, fixed = TRUE)
plot_code <- gsub('"Figure2_cohort_specific_effects"', '"Figure2_cohort_specific_effects_submission"', plot_code, fixed = TRUE)
plot_code <- gsub('"Figure3_frailty_effect_modification"', '"Figure3_frailty_effect_modification_submission"', plot_code, fixed = TRUE)
eval(parse(text = plot_code), envir = environment())

expected <- file.path(figure_dir, paste0(rep(c(
  "Figure2_cohort_specific_effects_submission",
  "Figure3_frailty_effect_modification_submission"
), each = 3L), ".", rep(c("pdf", "tiff", "png"), 2L)))
if (!all(file.exists(expected))) stop("One or more updated figure files are missing")
cat("Lowercase-panel Figures 2 and 3 created in", figure_dir, "\n")
