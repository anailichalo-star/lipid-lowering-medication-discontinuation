# Stage 07j: estimate continuous pre-treatment frailty effect modification for
# the primary and functional outcomes. Categorical subgroup effects are not
# estimated because Stage 07i showed residual imbalance within every category.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8", local = TRUE
)
source(
  file.path(project_root, "R", "_stage06_helpers.R"),
  encoding = "UTF-8", local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2", "splines")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
interaction_config_path <- file.path(
  project_root, "config_r", "frailty_interaction_model.yml"
)
interaction_config <- tte_read_yaml_utf8(interaction_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_private <- file.path(
  project_root, analysis_config$output_root,
  "stage05_weighting", "private_do_not_share"
)
stage07g_private <- file.path(
  project_root, analysis_config$output_root,
  "stage07g_functional_weights", "private_do_not_share"
)
stage07i_dir <- file.path(
  project_root, analysis_config$output_root, "stage07i_frailty_audit"
)
output_dir <- file.path(
  project_root, analysis_config$output_root,
  "stage07j_frailty_interaction"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

fi_variable <- as.character(interaction_config$effect_modifier$variable)
fi_center <- as.numeric(interaction_config$effect_modifier$center)
fi_unit <- as.numeric(interaction_config$effect_modifier$unit)
target_years <- as.numeric(interaction_config$target_risk_years)
curve_lower <- as.numeric(interaction_config$effect_curve_grid$lower)
curve_upper <- as.numeric(interaction_config$effect_curve_grid$upper)
curve_increment <- as.numeric(interaction_config$effect_curve_grid$increment)
curve_grid <- seq(curve_lower, curve_upper, by = curve_increment)
reporting_points <- as.numeric(unlist(
  interaction_config$reporting_points, use.names = FALSE
))
reporting_points_on_grid <- vapply(
  reporting_points,
  function(point) any(abs(curve_grid - point) < 1e-8),
  logical(1L)
)
if (!length(curve_grid) || any(!is.finite(curve_grid)) ||
    !all(reporting_points_on_grid) ||
    !is.finite(fi_unit) || fi_unit <= 0) {
  stop("Invalid Stage 07j FI grid or scaling.", call. = FALSE)
}

outcome_manifest <- data.table::rbindlist(lapply(
  names(interaction_config$outcomes),
  function(outcome_name) {
    item <- interaction_config$outcomes[[outcome_name]]
    data.table::data.table(
      outcome = outcome_name,
      outcome_label = as.character(item$label),
      weight_source = as.character(item$weight_source)
    )
  }
))
cohorts <- c("HRS", "SHARE")

as_logical_value <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}

gate_path <- file.path(
  stage07i_dir, "07i_continuous_frailty_interaction_gate.csv"
)
if (!file.exists(gate_path)) {
  stop("Missing Stage 07i continuous-interaction gate.", call. = FALSE)
}
gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
required_gate <- c(
  "cohort", "outcome", "ready_for_continuous_frailty_interaction"
)
missing_gate <- setdiff(required_gate, names(gate))
if (length(missing_gate)) {
  stop(
    "Stage 07i gate lacks: ", paste(missing_gate, collapse = ", "),
    call. = FALSE
  )
}
ready_gate <- gate[
  cohort %in% cohorts & outcome %in% outcome_manifest$outcome &
    as_logical_value(ready_for_continuous_frailty_interaction)
]
expected_pairs <- data.table::CJ(
  cohort = cohorts, outcome = outcome_manifest$outcome, unique = TRUE
)
observed_pairs <- unique(ready_gate[, .(cohort, outcome)])
expected_pair_keys <- paste(expected_pairs$cohort, expected_pairs$outcome, sep = "\r")
observed_pair_keys <- paste(observed_pairs$cohort, observed_pairs$outcome, sep = "\r")
if (length(setdiff(expected_pair_keys, observed_pair_keys))) {
  stop("Not every prespecified cohort-outcome pair passed Stage 07i.", call. = FALSE)
}
if (nrow(observed_pairs) != nrow(expected_pairs)) {
  stop("Stage 07i ready-pair identity is invalid.", call. = FALSE)
}

interaction_parts <- list()
curve_parts <- list()
model_parts <- list()
join_parts <- list()

for (cohort_name in cohorts) {
  source_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  functional_path <- file.path(
    stage07g_private,
    paste0(tolower(cohort_name), "_functional_weights_PRIVATE.rds")
  )
  for (required_path in c(source_path, stage05_path, functional_path)) {
    if (!file.exists(required_path)) {
      stop("Missing Stage 07j input: ", required_path, call. = FALSE)
    }
  }

  source_trials <- data.table::as.data.table(readRDS(source_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  required_source <- c("person_id", "trial_id", "followup_time_years")
  missing_source <- setdiff(required_source, names(source_trials))
  if (length(missing_source)) {
    stop(
      cohort_name, " source trials lack: ",
      paste(missing_source, collapse = ", "), call. = FALSE
    )
  }
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate Stage 04 person-trial key.", call. = FALSE)
  }
  source_fields <- source_trials[, .(
    join_key,
    followup_time_years = suppressWarnings(as.numeric(followup_time_years))
  )]

  completed_list <- readRDS(stage05_path)
  functional_list <- readRDS(functional_path)
  if (!is.list(completed_list) || !is.list(functional_list) ||
      length(completed_list) != 20L || length(functional_list) != 20L) {
    stop(cohort_name, ": expected 20 completed datasets.", call. = FALSE)
  }

  adjustment_terms <- unlist(
    interaction_config$design_adjustment[[cohort_name]], use.names = FALSE
  )
  formula_text <- paste0(
    "outcome_value ~ treatment + splines::ns(", fi_variable,
    ", df = 3) + treatment:FI_per_0_10 + ",
    paste(adjustment_terms, collapse = " + "),
    " + offset(log(followup_time_years))"
  )
  outcome_formula <- stats::as.formula(formula_text)

  for (imputation_index in seq_along(completed_list)) {
    base_completed <- data.table::as.data.table(
      data.table::copy(completed_list[[imputation_index]])
    )
    functional <- data.table::as.data.table(
      data.table::copy(functional_list[[imputation_index]])
    )
    required_completed <- c(
      "person_id", "trial_id", "treatment", fi_variable,
      "primary_event", "outcome_observed", "total_weight",
      "survey_weight_scaled", "sequence"
    )
    if (cohort_name == "SHARE") {
      required_completed <- c(required_completed, "B_country")
    }
    missing_completed <- setdiff(required_completed, names(base_completed))
    if (length(missing_completed)) {
      stop(
        cohort_name, " Stage 05 lacks: ",
        paste(missing_completed, collapse = ", "), call. = FALSE
      )
    }
    required_functional <- c(
      "person_id", "trial_id", "outcome_value",
      "outcome_observed_specific", "total_weight_specific"
    )
    missing_functional <- setdiff(required_functional, names(functional))
    if (length(missing_functional)) {
      stop(
        cohort_name, " Stage 07g lacks: ",
        paste(missing_functional, collapse = ", "), call. = FALSE
      )
    }

    base_completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    functional[, join_key_check := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    completed_source_index <- match(
      base_completed$join_key, source_fields$join_key
    )
    functional_index <- match(
      base_completed$join_key, functional$join_key_check
    )
    exact_join <- !anyNA(completed_source_index) && !anyNA(functional_index) &&
      nrow(base_completed) == nrow(source_fields) &&
      nrow(base_completed) == nrow(functional)
    if (!exact_join || anyDuplicated(base_completed$join_key) ||
        anyDuplicated(functional$join_key_check)) {
      stop(
        cohort_name, ": person-trial join failed in imputation ",
        imputation_index, call. = FALSE
      )
    }

    base_completed[, followup_time_years :=
      source_fields$followup_time_years[completed_source_index]]
    base_completed[, treatment := suppressWarnings(
      as.integer(as.character(treatment))
    )]
    base_completed[, FI_per_0_10 :=
      (suppressWarnings(as.numeric(get(fi_variable))) - fi_center) / fi_unit]
    base_completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      base_completed[, B_country := droplevels(factor(B_country))]
    }
    if (anyNA(base_completed[[fi_variable]]) ||
        any(!is.finite(base_completed$FI_per_0_10)) ||
        any(base_completed[[fi_variable]] < 0) ||
        any(base_completed[[fi_variable]] > 1)) {
      stop(cohort_name, ": invalid imputed FI.", call. = FALSE)
    }

    for (outcome_index in seq_len(nrow(outcome_manifest))) {
      outcome_row <- outcome_manifest[outcome_index]
      outcome_name <- outcome_row$outcome
      completed <- data.table::copy(base_completed)
      if (outcome_row$weight_source == "stage05") {
        completed[, outcome_value := suppressWarnings(
          as.integer(primary_event)
        )]
        completed[, outcome_observed_specific := suppressWarnings(
          as.integer(outcome_observed)
        )]
        completed[, total_weight_specific := suppressWarnings(
          as.numeric(total_weight)
        )]
      } else if (outcome_row$weight_source == "stage07g") {
        completed[, outcome_value := suppressWarnings(as.integer(
          functional$outcome_value[functional_index]
        ))]
        completed[, outcome_observed_specific := suppressWarnings(as.integer(
          functional$outcome_observed_specific[functional_index]
        ))]
        completed[, total_weight_specific := suppressWarnings(as.numeric(
          functional$total_weight_specific[functional_index]
        ))]
      } else {
        stop("Unsupported weight source: ", outcome_row$weight_source, call. = FALSE)
      }

      if (!all(completed$outcome_observed_specific %in% c(0L, 1L)) ||
          any(is.na(completed$outcome_value) !=
                (completed$outcome_observed_specific == 0L))) {
        stop(
          cohort_name, "/", outcome_name,
          ": outcome observation mismatch.", call. = FALSE
        )
      }
      observed <- completed[
        outcome_observed_specific == 1L & !is.na(outcome_value) &
          is.finite(total_weight_specific) & total_weight_specific > 0
      ]
      if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
        stop(
          cohort_name, "/", outcome_name,
          ": both observed treatment arms are required.", call. = FALSE
        )
      }
      observed[, model_weight := total_weight_specific /
        mean(total_weight_specific)]

      warning_messages <- character()
      fit <- withCallingHandlers(
        stats::glm(
          formula = outcome_formula,
          data = observed,
          family = stats::quasibinomial(link = "cloglog"),
          weights = model_weight,
          na.action = stats::na.fail,
          control = stats::glm.control(maxit = 100, epsilon = 1e-9)
        ),
        warning = function(warning_condition) {
          warning_messages <<- c(
            warning_messages, conditionMessage(warning_condition)
          )
          invokeRestart("muffleWarning")
        }
      )
      if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
        stop(
          cohort_name, "/", outcome_name,
          ": interaction model failed in imputation ",
          imputation_index, call. = FALSE
        )
      }
      robust <- tte_cluster_vcov_glm(
        fit, as.character(observed$person_id)
      )
      interaction_candidates <- grep(
        "treatment:FI_per_0_10|FI_per_0_10:treatment",
        names(stats::coef(fit)), value = TRUE
      )
      if (length(interaction_candidates) != 1L) {
        stop("Could not identify exactly one FI interaction coefficient.", call. = FALSE)
      }
      interaction_name <- interaction_candidates[[1L]]
      key <- paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )
      interaction_parts[[key]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        outcome_label = outcome_row$outcome_label,
        imputation = imputation_index,
        interaction_term = interaction_name,
        log_cloglog_contrast_ratio_per_0_10_FI =
          unname(stats::coef(fit)[interaction_name]),
        variance_log_cloglog_contrast_ratio =
          unname(robust$vcov[interaction_name, interaction_name])
      )

      for (fi_level in curve_grid) {
        target_data <- data.table::copy(completed)
        target_data[, (fi_variable) := fi_level]
        target_data[, FI_per_0_10 := (fi_level - fi_center) / fi_unit]
        standardized <- tte_standardized_cloglog_effects(
          fit = fit,
          robust_vcov = robust$vcov,
          target_data = target_data,
          standardization_weight = target_data$survey_weight_scaled,
          target_years = target_years
        )
        variance_continue <- standardized$risk_covariance[1L, 1L]
        variance_discontinue <- standardized$risk_covariance[2L, 2L]
        curve_key <- paste(key, sprintf("%.2f", fi_level), sep = "_")
        curve_parts[[curve_key]] <- data.table::data.table(
          cohort = cohort_name,
          outcome = outcome_name,
          outcome_label = outcome_row$outcome_label,
          imputation = imputation_index,
          FI = fi_level,
          target_years = target_years,
          risk_continue = standardized$risk_continue,
          variance_logit_risk_continue = variance_continue /
            (standardized$risk_continue *
               (1 - standardized$risk_continue))^2,
          logit_risk_continue = tte_logit(standardized$risk_continue),
          risk_discontinue = standardized$risk_discontinue,
          variance_logit_risk_discontinue = variance_discontinue /
            (standardized$risk_discontinue *
               (1 - standardized$risk_discontinue))^2,
          logit_risk_discontinue = tte_logit(
            standardized$risk_discontinue
          ),
          risk_difference = standardized$risk_difference,
          variance_risk_difference =
            standardized$variance_risk_difference,
          log_risk_ratio = standardized$log_risk_ratio,
          variance_log_risk_ratio =
            standardized$variance_log_risk_ratio
        )
      }

      model_parts[[key]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        formula = formula_text,
        converged = isTRUE(fit$converged),
        iterations = fit$iter,
        coefficient_n = length(stats::coef(fit)),
        aliased_coefficient_n = sum(is.na(stats::coef(fit))),
        warning_n = length(unique(warning_messages)),
        warnings = paste(unique(warning_messages), collapse = " | "),
        outcome_observations = nrow(observed),
        unique_person_clusters = robust$clusters,
        events = sum(observed$outcome_value == 1L),
        cluster_CR1_correction = robust$correction
      )
      join_parts[[key]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        stage05_rows = nrow(base_completed),
        stage04_rows = nrow(source_fields),
        stage07g_rows = nrow(functional),
        exact_person_trial_join = exact_join
      )
    }
  }
}

interaction_by_imputation <- data.table::rbindlist(
  interaction_parts, use.names = TRUE, fill = TRUE
)
curve_by_imputation <- data.table::rbindlist(
  curve_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(
  join_parts, use.names = TRUE, fill = TRUE
)

interaction_pooled_parts <- list()
curve_pooled_parts <- list()
pooling_parts <- list()

for (cohort_name in cohorts) {
  for (outcome_name in outcome_manifest$outcome) {
    estimates <- interaction_by_imputation[
      cohort == cohort_name & outcome == outcome_name
    ]
    diagnostics <- model_diagnostics[
      cohort == cohort_name & outcome == outcome_name
    ]
    if (nrow(estimates) != 20L || nrow(diagnostics) != 20L) {
      stop(
        cohort_name, "/", outcome_name,
        ": expected 20 interaction estimates.", call. = FALSE
      )
    }
    df_complete <- min(diagnostics$unique_person_clusters) -
      max(diagnostics$coefficient_n)
    interaction_pool <- tte_pool_scalar(
      estimates$log_cloglog_contrast_ratio_per_0_10_FI,
      estimates$variance_log_cloglog_contrast_ratio,
      df_complete = df_complete, null = 0
    )
    label <- unique(estimates$outcome_label)
    interaction_pooled_parts[[paste(cohort_name, outcome_name, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        outcome_label = label,
        FI_unit = fi_unit,
        estimate_log_scale = interaction_pool$estimate,
        standard_error_log_scale = interaction_pool$standard_error,
        cloglog_contrast_ratio_per_0_10_FI = exp(interaction_pool$estimate),
        confidence_lower = exp(interaction_pool$lower),
        confidence_upper = exp(interaction_pool$upper),
        p_interaction = interaction_pool$p_value,
        degrees_freedom = interaction_pool$degrees_freedom,
        imputations = interaction_pool$imputations,
        interpretation = paste0(
          "ratio of cloglog-scale discontinuation contrasts per ",
          sprintf("%.2f", fi_unit), " higher FI"
        )
      )

    for (fi_level in curve_grid) {
      point <- curve_by_imputation[
        cohort == cohort_name & outcome == outcome_name &
          abs(FI - fi_level) < 1e-10
      ]
      if (nrow(point) != 20L) {
        stop("Expected 20 effect-curve estimates at each FI value.", call. = FALSE)
      }
      pools <- list(
        risk_continue = tte_pool_scalar(
          point$logit_risk_continue,
          point$variance_logit_risk_continue,
          df_complete = df_complete
        ),
        risk_discontinue = tte_pool_scalar(
          point$logit_risk_discontinue,
          point$variance_logit_risk_discontinue,
          df_complete = df_complete
        ),
        risk_difference = tte_pool_scalar(
          point$risk_difference,
          point$variance_risk_difference,
          df_complete = df_complete, null = 0
        ),
        risk_ratio = tte_pool_scalar(
          point$log_risk_ratio,
          point$variance_log_risk_ratio,
          df_complete = df_complete, null = 0
        )
      )
      transformers <- list(
        risk_continue = tte_expit,
        risk_discontinue = tte_expit,
        risk_difference = identity,
        risk_ratio = exp
      )
      for (measure_name in names(pools)) {
        pool <- pools[[measure_name]]
        transform <- transformers[[measure_name]]
        curve_pooled_parts[[paste(
          cohort_name, outcome_name, sprintf("%.2f", fi_level),
          measure_name, sep = "_"
        )]] <- data.table::data.table(
          cohort = cohort_name,
          outcome = outcome_name,
          outcome_label = label,
          FI = fi_level,
          target_years = target_years,
          measure = measure_name,
          estimate = transform(pool$estimate),
          confidence_lower = transform(pool$lower),
          confidence_upper = transform(pool$upper),
          p_value = if (measure_name %in%
            c("risk_difference", "risk_ratio")) pool$p_value else NA_real_,
          reporting_point = any(abs(reporting_points - fi_level) < 1e-8)
        )
        pooling_parts[[paste(
          cohort_name, outcome_name, sprintf("%.2f", fi_level),
          measure_name, sep = "_"
        )]] <- data.table::data.table(
          cohort = cohort_name,
          outcome = outcome_name,
          FI = fi_level,
          measure = measure_name,
          degrees_freedom = pool$degrees_freedom,
          within_variance = pool$within_variance,
          between_variance = pool$between_variance,
          total_variance = pool$total_variance,
          fraction_missing_information = pool$fraction_missing_information
        )
      }
    }
  }
}

interaction_pooled <- data.table::rbindlist(
  interaction_pooled_parts, use.names = TRUE, fill = TRUE
)
curve_pooled <- data.table::rbindlist(
  curve_pooled_parts, use.names = TRUE, fill = TRUE
)
pooling_diagnostics <- data.table::rbindlist(
  pooling_parts, use.names = TRUE, fill = TRUE
)
curve_pooled[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000, NA_real_
)]
curve_pooled[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000, NA_real_
)]
curve_pooled[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000, NA_real_
)]

model_summary <- model_diagnostics[, .(
  imputations = .N,
  all_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0L),
  any_warning = any(warning_n > 0L),
  observed_outcomes = unique(outcome_observations)[1L],
  unique_person_clusters = unique(unique_person_clusters)[1L],
  events = unique(events)[1L],
  minimum_CR1_correction = min(cluster_CR1_correction),
  maximum_CR1_correction = max(cluster_CR1_correction)
), by = .(cohort, outcome)]

data.table::setorder(interaction_by_imputation, cohort, outcome, imputation)
data.table::setorder(interaction_pooled, cohort, outcome)
data.table::setorder(curve_by_imputation, cohort, outcome, FI, imputation)
data.table::setorder(curve_pooled, cohort, outcome, FI, measure)
data.table::setorder(pooling_diagnostics, cohort, outcome, FI, measure)
data.table::setorder(model_diagnostics, cohort, outcome, imputation)
data.table::setorder(join_checks, cohort, outcome, imputation)

tte_write_csv(
  interaction_by_imputation,
  file.path(output_dir, "07j_interaction_by_imputation.csv")
)
tte_write_csv(
  interaction_pooled,
  file.path(output_dir, "07j_interaction_pooled.csv")
)
tte_write_csv(
  curve_by_imputation,
  file.path(output_dir, "07j_effect_curve_by_imputation.csv")
)
tte_write_csv(
  curve_pooled,
  file.path(output_dir, "07j_effect_curve_pooled.csv")
)
tte_write_csv(
  curve_pooled[reporting_point == TRUE],
  file.path(output_dir, "07j_effects_at_reporting_FI_values.csv")
)
tte_write_csv(
  pooling_diagnostics,
  file.path(output_dir, "07j_pooling_diagnostics.csv")
)
tte_write_csv(
  model_diagnostics,
  file.path(output_dir, "07j_model_diagnostics.csv")
)
tte_write_csv(
  model_summary,
  file.path(output_dir, "07j_model_summary.csv")
)
tte_write_csv(
  join_checks,
  file.path(output_dir, "07j_join_checks.csv")
)
writeLines(
  readLines(interaction_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07j_frozen_frailty_interaction_model.yml"),
  useBytes = TRUE
)
saveRDS(
  list(
    interaction_by_imputation = interaction_by_imputation,
    interaction_pooled = interaction_pooled,
    curve_by_imputation = curve_by_imputation,
    curve_pooled = curve_pooled,
    model_diagnostics = model_diagnostics,
    config = interaction_config
  ),
  file.path(private_dir, "stage07j_frailty_interaction_PRIVATE.rds"),
  version = 3L
)

rd_plot_data <- curve_pooled[measure == "risk_difference"]
rd_plot <- ggplot2::ggplot(
  rd_plot_data,
  ggplot2::aes(
    x = FI, y = estimate * 1000,
    ymin = confidence_lower * 1000,
    ymax = confidence_upper * 1000,
    colour = cohort, fill = cohort
  )
) +
  ggplot2::geom_hline(yintercept = 0, linetype = 2, colour = "grey45") +
  ggplot2::geom_ribbon(alpha = 0.14, colour = NA) +
  ggplot2::geom_line(linewidth = 0.8) +
  ggplot2::facet_wrap(~outcome_label, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52"
  )) +
  ggplot2::scale_fill_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52"
  )) +
  ggplot2::labs(
    x = "Pre-treatment frailty index",
    y = "3-year risk difference per 1,000",
    colour = "Cohort", fill = "Cohort",
    title = "Discontinuation effect across continuous frailty",
    subtitle = "Positive values indicate higher risk under observed discontinuation"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

rr_plot_data <- curve_pooled[measure == "risk_ratio"]
rr_plot <- ggplot2::ggplot(
  rr_plot_data,
  ggplot2::aes(
    x = FI, y = estimate,
    ymin = confidence_lower, ymax = confidence_upper,
    colour = cohort, fill = cohort
  )
) +
  ggplot2::geom_hline(yintercept = 1, linetype = 2, colour = "grey45") +
  ggplot2::geom_ribbon(alpha = 0.14, colour = NA) +
  ggplot2::geom_line(linewidth = 0.8) +
  ggplot2::facet_wrap(~outcome_label, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52"
  )) +
  ggplot2::scale_fill_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52"
  )) +
  ggplot2::labs(
    x = "Pre-treatment frailty index",
    y = "3-year risk ratio",
    colour = "Cohort", fill = "Cohort",
    title = "Relative effect across continuous frailty"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

ggplot2::ggsave(
  file.path(output_dir, "07j_frailty_risk_difference_curve.png"),
  rd_plot, width = 11, height = 6, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07j_frailty_risk_difference_curve.pdf"),
  rd_plot, width = 11, height = 6
)
ggplot2::ggsave(
  file.path(output_dir, "07j_frailty_risk_ratio_curve.png"),
  rr_plot, width = 11, height = 6, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07j_frailty_risk_ratio_curve.pdf"),
  rr_plot, width = 11, height = 6
)

interaction_lines <- vapply(seq_len(nrow(interaction_pooled)), function(i) {
  row <- interaction_pooled[i]
  paste0(
    row$cohort, "/", row$outcome,
    ": cloglog contrast ratio per 0.10 FI = ",
    sprintf("%.3f", row$cloglog_contrast_ratio_per_0_10_FI),
    " (95% CI ", sprintf("%.3f", row$confidence_lower),
    " to ", sprintf("%.3f", row$confidence_upper),
    "); P-interaction = ", sprintf("%.4f", row$p_interaction), "."
  )
}, character(1L))

summary_lines <- c(
  "Stage 07j: continuous frailty interaction estimation",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Target risk horizon: ", target_years, " years"),
  "Outcomes: broad cardiovascular disease/death and death/ADL decline.",
  "FI main effect: natural cubic spline with 3 degrees of freedom.",
  "Effect modification: one linear treatment-by-FI term per 0.10 higher FI.",
  "Inference: person-clustered CR1 sandwich within imputation, then Rubin pooling.",
  "",
  interaction_lines,
  "",
  "The P-interaction is the main heterogeneity test.",
  "The interaction ratio is on the cloglog scale and is not itself a risk ratio.",
  "Use the standardized RD and RR curves for clinical interpretation.",
  "No categorical frailty-specific causal effect was estimated because Stage 07i balance gates failed.",
  "Do not interpret the exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07j_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07j_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message(
  "Stage 07j completed: ",
  normalizePath(output_dir, winslash = "/", mustWork = TRUE)
)
