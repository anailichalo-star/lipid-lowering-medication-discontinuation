# Stage 07c: estimate three-year effects for strict MI/stroke/death and
# all-cause death using the outcome-specific weights from Stage 07b.
# No meta-analysis, subgroup analysis, or ADL analysis is performed here.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8",
  local = TRUE
)
source(
  file.path(project_root, "R", "_stage06_helpers.R"),
  encoding = "UTF-8",
  local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
effect_config_path <- file.path(
  project_root, "config_r", "secondary_outcome_effect_model.yml"
)
effect_config <- tte_read_yaml_utf8(effect_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_private <- file.path(
  project_root, analysis_config$output_root,
  "stage05_weighting", "private_do_not_share"
)
stage07b_dir <- file.path(
  project_root, analysis_config$output_root, "stage07b_outcome_weights"
)
stage07b_private <- file.path(stage07b_dir, "private_do_not_share")
output_dir <- file.path(
  project_root, analysis_config$output_root, "stage07c_component_effects"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
outcomes <- c("strict_event", "death_component")
target_years <- as.numeric(effect_config$target_risk_years)
confidence_level <- as.numeric(effect_config$confidence_level)
if (!isTRUE(all.equal(confidence_level, 0.95))) {
  stop("Stage 07c currently requires a 95% confidence level.", call. = FALSE)
}

as_logical_value <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}

gate_path <- file.path(stage07b_dir, "07b_weighting_gate.csv")
if (!file.exists(gate_path)) {
  stop("Missing Stage 07b gate file: ", gate_path, call. = FALSE)
}
gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
expected_pairs <- data.table::CJ(cohort = cohorts, outcome = outcomes, sorted = FALSE)
gate_pairs <- gate[cohort %in% cohorts & outcome %in% outcomes]
if (nrow(gate_pairs) != nrow(expected_pairs) ||
    anyDuplicated(paste(gate_pairs$cohort, gate_pairs$outcome)) ||
    !setequal(
      paste(gate_pairs$cohort, gate_pairs$outcome),
      paste(expected_pairs$cohort, expected_pairs$outcome)
    )) {
  stop("Stage 07b gate must contain exactly four cohort-outcome rows.", call. = FALSE)
}
if (!all(as_logical_value(gate_pairs$ready_for_secondary_effect_estimation))) {
  failed_pairs <- gate_pairs[
    !as_logical_value(ready_for_secondary_effect_estimation),
    paste(cohort, outcome, sep = "/")
  ]
  stop(
    "Stage 07c aborted because these pairs failed Stage 07b: ",
    paste(failed_pairs, collapse = ", "),
    call. = FALSE
  )
}

effect_parts <- list()
model_diagnostic_parts <- list()
sample_parts <- list()
join_check_parts <- list()

for (cohort_name in cohorts) {
  trial_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  imputation_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(trial_path)) {
    stop("Missing Stage 04f trial file: ", trial_path, call. = FALSE)
  }
  if (!file.exists(imputation_path)) {
    stop("Missing Stage 05 imputation file: ", imputation_path, call. = FALSE)
  }

  source_trials <- data.table::as.data.table(readRDS(trial_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  required_source <- c(
    "person_id", "trial_id", "followup_time_years",
    "L_interview_date", "followup_reference_date"
  )
  missing_source <- setdiff(required_source, names(source_trials))
  if (length(missing_source)) {
    stop(
      cohort_name, " source trials are missing: ",
      paste(missing_source, collapse = ", "),
      call. = FALSE
    )
  }
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate Stage 04f person-trial keys.", call. = FALSE)
  }
  source_fields <- source_trials[, .(
    join_key,
    followup_time_years = suppressWarnings(as.numeric(followup_time_years)),
    L_interview_date,
    followup_reference_date
  )]

  imputed_datasets <- readRDS(imputation_path)
  if (length(imputed_datasets) != 20L) {
    stop(cohort_name, ": Stage 05 must contain 20 imputations.", call. = FALSE)
  }

  for (outcome_name in outcomes) {
    specific_weight_path <- file.path(
      stage07b_private,
      paste0(
        tolower(cohort_name), "_", outcome_name,
        "_specific_weights_PRIVATE.rds"
      )
    )
    if (!file.exists(specific_weight_path)) {
      stop("Missing Stage 07b outcome-specific weights: ", specific_weight_path,
           call. = FALSE)
    }
    specific_weights <- readRDS(specific_weight_path)
    if (length(specific_weights) != length(imputed_datasets)) {
      stop(
        cohort_name, "/", outcome_name,
        ": imputation count differs between Stage 05 and Stage 07b.",
        call. = FALSE
      )
    }

    for (imputation_index in seq_along(imputed_datasets)) {
      completed <- data.table::as.data.table(
        data.table::copy(imputed_datasets[[imputation_index]])
      )
      completed[, join_key := paste(
        as.character(person_id), as.character(trial_id), sep = "\r"
      )]
      if (anyDuplicated(completed$join_key)) {
        stop(
          cohort_name, "/", outcome_name,
          ": duplicate Stage 05 key in imputation ", imputation_index,
          call. = FALSE
        )
      }

      compact <- data.table::as.data.table(specific_weights[[imputation_index]])
      if (!"join_key" %in% names(compact) || anyDuplicated(compact$join_key)) {
        stop(
          cohort_name, "/", outcome_name,
          ": invalid Stage 07b compact key in imputation ", imputation_index,
          call. = FALSE
        )
      }
      weight_index <- match(completed$join_key, compact$join_key)
      source_index <- match(completed$join_key, source_fields$join_key)
      if (anyNA(weight_index) || anyNA(source_index) ||
          nrow(compact) != nrow(completed)) {
        stop(
          cohort_name, "/", outcome_name,
          ": one-to-one join failed in imputation ", imputation_index,
          call. = FALSE
        )
      }

      completed[, outcome_value := compact$outcome_value[weight_index]]
      completed[, outcome_observed_specific :=
        compact$outcome_observed_specific[weight_index]]
      completed[, total_weight_specific :=
        compact$total_weight_specific[weight_index]]
      completed[, followup_time_years :=
        source_fields$followup_time_years[source_index]]
      completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
      completed[, sequence := droplevels(factor(sequence))]
      if (cohort_name == "SHARE") {
        completed[, B_country := droplevels(factor(B_country))]
      }

      if (anyNA(completed$treatment) ||
          !all(completed$treatment %in% c(0L, 1L))) {
        stop(
          cohort_name, "/", outcome_name,
          ": treatment is not binary in imputation ", imputation_index,
          call. = FALSE
        )
      }
      if (any(!is.finite(completed$followup_time_years)) ||
          any(completed$followup_time_years <= 0)) {
        stop(
          cohort_name, "/", outcome_name,
          ": invalid follow-up time in imputation ", imputation_index,
          call. = FALSE
        )
      }
      if (!all(completed$outcome_observed_specific %in% c(0L, 1L)) ||
          any(is.na(completed$outcome_value) !=
                (completed$outcome_observed_specific == 0L))) {
        stop(
          cohort_name, "/", outcome_name,
          ": outcome observation indicator is inconsistent in imputation ",
          imputation_index,
          call. = FALSE
        )
      }

      observed <- completed[
        outcome_observed_specific == 1L & !is.na(outcome_value) &
          is.finite(total_weight_specific) & total_weight_specific > 0
      ]
      if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
        stop(
          cohort_name, "/", outcome_name,
          ": both arms are required in imputation ", imputation_index,
          call. = FALSE
        )
      }
      observed[, model_weight :=
        total_weight_specific / mean(total_weight_specific)]

      adjustment_terms <- unlist(
        effect_config$design_adjustment[[cohort_name]], use.names = FALSE
      )
      formula_text <- paste0(
        "outcome_value ~ treatment + ",
        paste(adjustment_terms, collapse = " + "),
        " + offset(log(followup_time_years))"
      )
      outcome_formula <- stats::as.formula(formula_text)
      warning_messages <- character()
      fit <- withCallingHandlers(
        stats::glm(
          formula = outcome_formula,
          data = observed,
          family = stats::quasibinomial(link = "cloglog"),
          weights = model_weight,
          na.action = stats::na.fail,
          control = stats::glm.control(maxit = 100, epsilon = 1e-9)
        ),
        warning = function(warning_condition) {
          warning_messages <<- c(
            warning_messages, conditionMessage(warning_condition)
          )
          invokeRestart("muffleWarning")
        }
      )
      if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
        stop(
          cohort_name, "/", outcome_name,
          ": outcome model failed in imputation ", imputation_index,
          call. = FALSE
        )
      }

      robust <- tte_cluster_vcov_glm(
        fit, as.character(observed$person_id)
      )
      standardized <- tte_standardized_cloglog_effects(
        fit = fit,
        robust_vcov = robust$vcov,
        target_data = completed,
        standardization_weight = completed$survey_weight_scaled,
        target_years = target_years
      )

      variance_continue <- standardized$risk_covariance[1L, 1L]
      variance_discontinue <- standardized$risk_covariance[2L, 2L]
      variance_logit_continue <- variance_continue /
        (standardized$risk_continue * (1 - standardized$risk_continue))^2
      variance_logit_discontinue <- variance_discontinue /
        (standardized$risk_discontinue *
           (1 - standardized$risk_discontinue))^2

      effect_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        target_years = target_years,
        risk_continue = standardized$risk_continue,
        variance_risk_continue = variance_continue,
        logit_risk_continue = tte_logit(standardized$risk_continue),
        variance_logit_risk_continue = variance_logit_continue,
        risk_discontinue = standardized$risk_discontinue,
        variance_risk_discontinue = variance_discontinue,
        logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
        variance_logit_risk_discontinue = variance_logit_discontinue,
        risk_difference = standardized$risk_difference,
        variance_risk_difference = standardized$variance_risk_difference,
        log_risk_ratio = standardized$log_risk_ratio,
        variance_log_risk_ratio = standardized$variance_log_risk_ratio
      )

      model_diagnostic_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        formula = formula_text,
        converged = isTRUE(fit$converged),
        iterations = fit$iter,
        coefficient_n = length(stats::coef(fit)),
        aliased_coefficient_n = sum(is.na(stats::coef(fit))),
        warning_n = length(unique(warning_messages)),
        warnings = paste(unique(warning_messages), collapse = " | "),
        outcome_observations = nrow(observed),
        unique_person_clusters = robust$clusters,
        events = sum(observed$outcome_value == 1L),
        continue_observations = sum(observed$treatment == 0L),
        discontinue_observations = sum(observed$treatment == 1L),
        continue_events = sum(
          observed$outcome_value == 1L & observed$treatment == 0L
        ),
        discontinue_events = sum(
          observed$outcome_value == 1L & observed$treatment == 1L
        ),
        followup_minimum_years = min(observed$followup_time_years),
        followup_median_years = stats::median(observed$followup_time_years),
        followup_maximum_years = max(observed$followup_time_years),
        cluster_CR1_correction = robust$correction,
        full_survey_design_variance_available = FALSE
      )

      if (imputation_index == 1L) {
        sample_parts[[paste(cohort_name, outcome_name, sep = "_")]] <-
          completed[, .(
            eligible_person_trials = .N,
            unique_persons = data.table::uniqueN(person_id),
            outcome_observed_n = sum(outcome_observed_specific == 1L),
            outcome_observed_fraction = mean(
              outcome_observed_specific == 1L
            ),
            events = sum(outcome_value == 1L, na.rm = TRUE),
            followup_minimum_years = min(followup_time_years),
            followup_median_years = stats::median(followup_time_years),
            followup_maximum_years = max(followup_time_years)
          ), by = treatment][, `:=`(
            cohort = cohort_name,
            outcome = outcome_name,
            treatment_label = ifelse(
              treatment == 1L, "discontinue", "continue"
            )
          )]
      }

      join_check_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        stage05_person_trials = nrow(completed),
        stage07b_weight_rows = nrow(compact),
        matched_weight_rows = sum(!is.na(weight_index)),
        matched_source_rows = sum(!is.na(source_index)),
        duplicated_completed_keys = sum(duplicated(completed$join_key)),
        duplicated_compact_keys = sum(duplicated(compact$join_key))
      )
    }
  }
}

effects_by_imputation <- data.table::rbindlist(
  effect_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_diagnostic_parts, use.names = TRUE, fill = TRUE
)
sample_description <- data.table::rbindlist(
  sample_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(
  join_check_parts, use.names = TRUE, fill = TRUE
)

pooled_rows <- list()
pooling_rows <- list()
for (cohort_name in cohorts) {
  for (outcome_name in outcomes) {
    estimates <- effects_by_imputation[
      cohort == cohort_name & outcome == outcome_name
    ]
    diagnostics <- model_diagnostics[
      cohort == cohort_name & outcome == outcome_name
    ]
    if (nrow(estimates) != 20L || nrow(diagnostics) != 20L) {
      stop(
        cohort_name, "/", outcome_name,
        ": expected exactly 20 effect estimates and diagnostics.",
        call. = FALSE
      )
    }
    df_complete <- min(diagnostics$unique_person_clusters) -
      max(diagnostics$coefficient_n)

    pooled_continue <- tte_pool_scalar(
      estimates$logit_risk_continue,
      estimates$variance_logit_risk_continue,
      df_complete = df_complete
    )
    pooled_discontinue <- tte_pool_scalar(
      estimates$logit_risk_discontinue,
      estimates$variance_logit_risk_discontinue,
      df_complete = df_complete
    )
    pooled_difference <- tte_pool_scalar(
      estimates$risk_difference,
      estimates$variance_risk_difference,
      df_complete = df_complete,
      null = 0
    )
    pooled_ratio <- tte_pool_scalar(
      estimates$log_risk_ratio,
      estimates$variance_log_risk_ratio,
      df_complete = df_complete,
      null = 0
    )

    pooled_list <- list(
      risk_continue = pooled_continue,
      risk_discontinue = pooled_discontinue,
      risk_difference = pooled_difference,
      risk_ratio = pooled_ratio
    )
    transformers <- list(
      risk_continue = tte_expit,
      risk_discontinue = tte_expit,
      risk_difference = identity,
      risk_ratio = exp
    )
    null_values <- c(
      risk_continue = NA_real_, risk_discontinue = NA_real_,
      risk_difference = 0, risk_ratio = 1
    )

    for (measure_name in names(pooled_list)) {
      pooled <- pooled_list[[measure_name]]
      transform_value <- transformers[[measure_name]]
      pooled_rows[[paste(
        cohort_name, outcome_name, measure_name, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        outcome_label = effect_config$outcomes[[outcome_name]]$label,
        target_years = target_years,
        measure = measure_name,
        estimate = transform_value(pooled$estimate),
        confidence_lower = transform_value(pooled$lower),
        confidence_upper = transform_value(pooled$upper),
        null_value = null_values[[measure_name]],
        p_value = if (measure_name %in% c(
          "risk_difference", "risk_ratio"
        )) pooled$p_value else NA_real_,
        imputations = pooled$imputations,
        inference = "person-clustered CR1 sandwich; Rubin pooled",
        interpretation = if (measure_name == "risk_difference") {
          "discontinuation minus continuation"
        } else if (measure_name == "risk_ratio") {
          "discontinuation divided by continuation"
        } else {
          gsub("risk_", "standardized risk under ", measure_name)
        }
      )
      pooling_rows[[paste(
        cohort_name, outcome_name, measure_name, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        measure = measure_name,
        pooled_transformed_estimate = pooled$estimate,
        transformed_standard_error = pooled$standard_error,
        degrees_freedom = pooled$degrees_freedom,
        within_variance = pooled$within_variance,
        between_variance = pooled$between_variance,
        total_variance = pooled$total_variance,
        relative_increase_variance = pooled$relative_increase_variance,
        fraction_missing_information = pooled$fraction_missing_information,
        complete_data_degrees_freedom = df_complete
      )
    }
  }
}

pooled_effects <- data.table::rbindlist(
  pooled_rows, use.names = TRUE, fill = TRUE
)
pooling_diagnostics <- data.table::rbindlist(
  pooling_rows, use.names = TRUE, fill = TRUE
)
pooled_effects[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000,
  NA_real_
)]
pooled_effects[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000,
  NA_real_
)]
pooled_effects[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000,
  NA_real_
)]

model_summary <- model_diagnostics[, .(
  imputations = .N,
  all_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0L),
  any_warning = any(warning_n > 0L),
  observed_outcomes = unique(outcome_observations)[1L],
  unique_person_clusters = unique(unique_person_clusters)[1L],
  events = unique(events)[1L],
  min_iterations = min(iterations),
  max_iterations = max(iterations),
  minimum_CR1_correction = min(cluster_CR1_correction),
  maximum_CR1_correction = max(cluster_CR1_correction)
), by = .(cohort, outcome)]

data.table::setorder(effects_by_imputation, cohort, outcome, imputation)
data.table::setorder(pooled_effects, cohort, outcome, measure)
data.table::setorder(pooling_diagnostics, cohort, outcome, measure)
data.table::setorder(model_diagnostics, cohort, outcome, imputation)
data.table::setorder(model_summary, cohort, outcome)
data.table::setorder(sample_description, cohort, outcome, treatment)
data.table::setorder(join_checks, cohort, outcome, imputation)

tte_write_csv(
  effects_by_imputation,
  file.path(output_dir, "07c_component_effects_by_imputation.csv")
)
tte_write_csv(
  pooled_effects,
  file.path(output_dir, "07c_component_effects_pooled.csv")
)
tte_write_csv(
  pooling_diagnostics,
  file.path(output_dir, "07c_pooling_diagnostics.csv")
)
tte_write_csv(
  model_diagnostics,
  file.path(output_dir, "07c_model_diagnostics.csv")
)
tte_write_csv(
  model_summary,
  file.path(output_dir, "07c_model_summary.csv")
)
tte_write_csv(
  sample_description,
  file.path(output_dir, "07c_analysis_sample.csv")
)
tte_write_csv(
  join_checks,
  file.path(output_dir, "07c_join_checks.csv")
)
writeLines(
  readLines(effect_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07c_frozen_component_effect_model.yml"),
  useBytes = TRUE
)
saveRDS(
  list(
    effects_by_imputation = effects_by_imputation,
    pooled_effects = pooled_effects,
    pooling_diagnostics = pooling_diagnostics,
    model_diagnostics = model_diagnostics,
    config = effect_config
  ),
  file.path(private_dir, "stage07c_component_estimates_PRIVATE.rds"),
  version = 3L
)

risk_plot_data <- pooled_effects[
  measure %in% c("risk_continue", "risk_discontinue")
]
risk_plot_data[, treatment_strategy := factor(
  measure,
  levels = c("risk_continue", "risk_discontinue"),
  labels = c("Continue", "Discontinue")
)]
risk_plot <- ggplot2::ggplot(
  risk_plot_data,
  ggplot2::aes(
    x = treatment_strategy,
    y = estimate,
    ymin = confidence_lower,
    ymax = confidence_upper,
    colour = treatment_strategy
  )
) +
  ggplot2::geom_pointrange(linewidth = 0.5) +
  ggplot2::facet_grid(cohort ~ outcome_label) +
  ggplot2::scale_y_continuous(
    labels = function(x) paste0(round(100 * x, 1), "%")
  ) +
  ggplot2::scale_colour_manual(values = c(
    "Continue" = "#2463A8", "Discontinue" = "#C44E52"
  )) +
  ggplot2::labs(
    x = NULL,
    y = "Standardized 3-year risk (95% CI)",
    title = "Strict cardiovascular/death and all-cause mortality outcomes",
    subtitle = "Outcome-specific censoring weights; person-clustered inference"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "none")

difference_plot_data <- pooled_effects[measure == "risk_difference"]
difference_plot <- ggplot2::ggplot(
  difference_plot_data,
  ggplot2::aes(
    x = estimate * 1000,
    y = cohort,
    xmin = confidence_lower * 1000,
    xmax = confidence_upper * 1000,
    colour = outcome_label
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
  ggplot2::geom_errorbar(
    orientation = "y", width = 0.12, linewidth = 0.55,
    position = ggplot2::position_dodge(width = 0.45)
  ) +
  ggplot2::geom_point(
    size = 2.2,
    position = ggplot2::position_dodge(width = 0.45)
  ) +
  ggplot2::labs(
    x = "3-year risk difference per 1,000 (discontinue - continue)",
    y = NULL,
    colour = "Outcome",
    title = "Component outcome effects"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

ggplot2::ggsave(
  file.path(output_dir, "07c_standardized_risk_plot.png"),
  risk_plot, width = 10.5, height = 6.5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07c_standardized_risk_plot.pdf"),
  risk_plot, width = 10.5, height = 6.5
)
ggplot2::ggsave(
  file.path(output_dir, "07c_risk_difference_plot.png"),
  difference_plot, width = 9.5, height = 4.5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07c_risk_difference_plot.pdf"),
  difference_plot, width = 9.5, height = 4.5
)

effect_lines <- unlist(lapply(cohorts, function(cohort_name) {
  vapply(outcomes, function(outcome_name) {
    rd <- pooled_effects[
      cohort == cohort_name & outcome == outcome_name &
        measure == "risk_difference"
    ]
    rr <- pooled_effects[
      cohort == cohort_name & outcome == outcome_name &
        measure == "risk_ratio"
    ]
    paste0(
      cohort_name, "/", outcome_name,
      ": RD = ", sprintf("%.1f", rd$estimate_per_1000),
      " per 1,000 (95% CI ",
      sprintf("%.1f", rd$confidence_lower_per_1000), " to ",
      sprintf("%.1f", rd$confidence_upper_per_1000),
      "); RR = ", sprintf("%.3f", rr$estimate),
      " (95% CI ", sprintf("%.3f", rr$confidence_lower), " to ",
      sprintf("%.3f", rr$confidence_upper), ")."
    )
  }, character(1L))
}))

summary_lines <- c(
  "Stage 07c: component outcome effect estimation",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Target risk horizon: ", target_years, " years"),
  "All four cohort-outcome pairs passed the Stage 07b weighting gates.",
  "Outcome-specific censoring weights were used for every model.",
  "Model: complementary log-log marginal structural outcome model with log follow-up offset.",
  "Adjustment: sequence in HRS; sequence plus country in SHARE.",
  "Inference: person-clustered CR1 sandwich within each imputation, then Rubin pooling.",
  "No cross-cohort meta-analysis was performed.",
  "",
  effect_lines,
  "",
  "Positive RD and RR > 1 indicate higher risk under observed discontinuation.",
  "All-cause death does not distinguish cardiovascular from noncardiovascular death.",
  "Do not interpret exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07c_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07c_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message("Stage 07c completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))

