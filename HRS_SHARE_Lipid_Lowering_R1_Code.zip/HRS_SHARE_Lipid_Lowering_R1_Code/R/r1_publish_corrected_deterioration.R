# Run after r1_run_corrected_deterioration.R. Refresh Table 3 and Figure S3 in R1.
suppressPackageStartupMessages(library(data.table))
read_output <- function(path) fread(file.path("outputs_r", path), encoding = "UTF-8")
destination <- "outputs_r/revision_r1"
revision <- "revision_r1/deterioration_corrected"
gate_path <- "stage07e_restricted_weights/07e_weighting_gate.csv"
effect_path <- "stage07f_restricted_effects/07f_restricted_effects_pooled.csv"
keys <- c("cohort", "restriction", "outcome")

gate <- read_output(file.path(revision, gate_path))
gate_before <- read_output(gate_path)
gate_comparison <- merge(
  gate_before[, .(cohort, restriction, outcome, old_ready = ready_for_restricted_effect_estimation)],
  gate[, .(cohort, restriction, outcome, new_ready = ready_for_restricted_effect_estimation,
           maximum_absolute_primary_covariate_smd, maximum_absolute_change_variable_smd, total_events)],
  by = keys
)
stopifnot(nrow(gate_comparison) == nrow(gate), !anyDuplicated(gate_comparison, by = keys))
effects <- read_output(file.path(revision, effect_path))
stopifnot(fsetequal(unique(effects[, ..keys]), gate[ready_for_restricted_effect_estimation == TRUE, ..keys]))

original_table <- read_output("jaha_publication/tables/Table3_sensitivity_analyses.csv")
outcomes <- c(primary_event = "Broad CVD or death", death_component = "All-cause death")
restrictions <- c(exclude_severe_deterioration = "Exclude objective severe deterioration",
                  exclude_multiple_deterioration_markers = "Exclude 2 or more deterioration markers")
table_keys <- c("Cohort", "Outcome", "Analysis")
revised_table <- effects[outcome %in% names(outcomes) & measure %in% c("risk_ratio", "risk_difference")]
revised_table <- dcast(revised_table, cohort + restriction + outcome ~ measure,
                       value.var = c("estimate", "confidence_lower", "confidence_upper", "p_value"))
format_p <- function(x) ifelse(x < 0.001, "<0.001", sprintf("%.3f", x))
revised_table <- revised_table[, .(
  Cohort = cohort, Outcome = unname(outcomes[outcome]), Analysis = unname(restrictions[restriction]),
  `Risk difference per 1,000 (95% CI); P value` = sprintf(
    "%.1f (%.1f to %.1f); %s", 1000 * estimate_risk_difference, 1000 * confidence_lower_risk_difference,
    1000 * confidence_upper_risk_difference, format_p(p_value_risk_difference)),
  `Risk ratio (95% CI); P value` = sprintf(
    "%.3f (%.3f to %.3f); %s", estimate_risk_ratio, confidence_lower_risk_ratio,
    confidence_upper_risk_ratio, format_p(p_value_risk_ratio))
)]
stopifnot(!anyDuplicated(revised_table, by = table_keys))
table3 <- rbindlist(list(original_table[!Analysis %in% unname(restrictions)], revised_table))
setorder(table3, Cohort, Outcome)
fwrite(table3, file.path(destination, "Table3_sensitivity_analyses.csv"))
fwrite(gate_comparison, file.path(destination, "R1_deterioration_gate_comparison.csv"))

# Reuse the publication styling and drawing code for the existing Figure S3.
figure_env <- new.env()
figure_env$figure_dir <- figure_env$word_image_dir <- file.path(destination, "figures")
figure_env$reverse_causation <- rbindlist(list(
  read_output("stage06_primary_effects/06_primary_effects_pooled.csv")[, analysis := "Unrestricted"],
  read_output("stage07c_component_effects/07c_component_effects_pooled.csv")[, analysis := "Unrestricted"],
  copy(effects)[, analysis := "Restricted"]
), fill = TRUE)[measure == "risk_difference" & outcome %in% c("death_component", "primary_event", "strict_event")]
required <- c("green", "gray", "font_family", "format_p_value", "format_p_label", "theme_jaha_supplement",
              "open_device", "save_supplement_plot", "outcome_short", "figure_s3")
for (expr in parse("R/13_prepare_jaha_submission_files.R")) {
  is_assignment <- is.call(expr) && identical(expr[[1L]], quote(`<-`)) && is.symbol(expr[[2L]])
  if (is_assignment && as.character(expr[[2L]]) %in% required) {
    eval(expr, envir = figure_env)
  }
  if (is.call(expr) && identical(expr[[1L]], quote(`[`)) && identical(expr[[2L]], quote(reverse_causation))) {
    eval(expr, envir = figure_env)
  }
}
stopifnot(all(required %in% ls(figure_env)))
plot_data <- figure_env$reverse_causation
stopifnot(!anyDuplicated(plot_data, by = c("cohort", "outcome", "analysis")),
          all(plot_data$confidence_lower_per_1000 >= -50 & plot_data$confidence_upper_per_1000 <= 175))
# Give each cohort only the rows represented in its results.
figure <- figure_env$figure_s3 +
  ggplot2::facet_grid(cohort ~ outcome_panel, scales = "free_y", space = "free_y")
built <- ggplot2::ggplot_build(figure)
panel_cohorts <- as.character(built$layout$layout$cohort)
panel_rows <- lapply(built$layout$panel_params, function(panel) panel$y$get_limits())
for (cohort_name in unique(panel_cohorts)) {
  expected_rows <- levels(plot_data$analysis)[levels(plot_data$analysis) %in%
    plot_data[cohort == cohort_name, analysis]]
  stopifnot(all(vapply(panel_rows[panel_cohorts == cohort_name], identical, logical(1L), expected_rows)))
}
figure_env$save_supplement_plot(figure, "FigureS3_reverse_causation_sensitivity",
                                width = 7.2, height = 4.1, tiff_dpi = 600)

# Refresh the main sensitivity figure from the same eligible estimates as Table 3.
figure_env$sensitivity_source <- rbindlist(list(
  read_output("stage06_primary_effects/06_primary_effects_pooled.csv")[, Analysis := "Primary IPTW/IPCW"],
  read_output("stage08a_alternative_weights/08a_effects_pooled.csv")[scheme == "overlap_1_99"][, Analysis := "Overlap weighting"],
  read_output("stage08b_age_sensitivity/08b_age_effects_pooled.csv")[cohort == "HRS" & age_threshold == 80L][, Analysis := "Age 80 y or older"],
  copy(effects)[, Analysis := unname(restrictions[restriction])]
), fill = TRUE)
required <- c("blue", "orange", "theme_jaha", "save_drawing", "figure4_data", "figure4")
for (expr in parse("R/12_generate_jaha_tables_figures_results.R")) {
  is_assignment <- is.call(expr) && identical(expr[[1L]], quote(`<-`)) && is.symbol(expr[[2L]])
  if (is_assignment && as.character(expr[[2L]]) %in% required) eval(expr, envir = figure_env)
  if (is.call(expr) && identical(expr[[1L]], quote(`[`)) && identical(expr[[2L]], quote(figure4_data))) {
    eval(expr, envir = figure_env)
  }
}
stopifnot(all(required %in% ls(figure_env)))
primary_rows <- table3[Outcome == outcomes[["primary_event"]]]
figure_rows <- figure_env$figure4_data[, .(Cohort = as.character(cohort), Analysis)]
stopifnot(nrow(figure_rows) == nrow(primary_rows),
          fsetequal(figure_rows, primary_rows[, .(Cohort, Analysis)]),
          all(figure_env$figure4_data$lower_plot >= -40 & figure_env$figure4_data$upper_plot <= 220))
figure_env$save_drawing(function() print(figure_env$figure4), "Figure4_primary_outcome_sensitivity",
                        width = 7.2, height = 4.2, tiff_dpi = 600)
print(gate_comparison[old_ready != new_ready])
