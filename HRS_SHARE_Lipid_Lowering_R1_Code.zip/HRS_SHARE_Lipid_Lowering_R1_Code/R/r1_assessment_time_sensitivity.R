# R1 primary composite: compare fixed versus estimated log assessment time.
# Use frozen Stage 06 samples, weights, and standardization targets.

args <- commandArgs(trailingOnly = TRUE)
project_root <- if (length(args)) args[[1L]] else getwd()
source(file.path(project_root, "R", "_stage06_helpers.R"), local = TRUE)
root <- file.path(project_root, "outputs_r")
reference <- read.csv(file.path(root, "stage06_primary_effects", "06_primary_effects_pooled.csv"))
sample_reference <- read.csv(file.path(root, "stage06_primary_effects", "06_analysis_sample.csv"))

entry_key <- function(entries) paste(entries$person_id, entries$trial_id, sep = "\r")

fit_comparison <- function(entries, cohort, mode) {
  keep <- entries$outcome_observed == 1L & !is.na(entries$primary_event) &
    is.finite(entries$total_weight) & entries$total_weight > 0
  observed <- entries[keep, , drop = FALSE]
  observed$model_weight <- observed$total_weight / mean(observed$total_weight)
  adjustment <- c("treatment", "sequence", if (cohort == "SHARE") "B_country")
  time_term <- if (mode == "Fixed slope") {
    "offset(log(followup_time_years))"
  } else {
    "log(followup_time_years)"
  }
  formula <- reformulate(c(adjustment, time_term), response = "primary_event")
  fit <- glm(
    formula, data = observed, family = quasibinomial(link = "cloglog"),
    weights = model_weight, na.action = na.fail,
    control = glm.control(maxit = 100, epsilon = 1e-9)
  )
  if (!isTRUE(fit$converged) || anyNA(coef(fit))) {
    stop(cohort, ": time comparison failed to converge.", call. = FALSE)
  }
  robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
  contrast_at <- function(year) {
    effect <- tte_standardized_cloglog_effects(
      fit, robust$vcov, entries, entries$survey_weight_scaled, year
    )
    risks <- c(effect$risk_continue, effect$risk_discontinue)
    list(
      estimates = c(tte_logit(risks), effect$risk_difference, effect$log_risk_ratio),
      variances = c(
        diag(effect$risk_covariance) / (risks * (1 - risks))^2,
        effect$variance_risk_difference, effect$variance_log_risk_ratio
      )
    )
  }
  list(
    at_typical_time = contrast_at(2.25),
    at_three_years = contrast_at(3),
    df_complete = robust$clusters - robust$coefficients,
    time_slope = if (mode == "Fixed slope") {
      c(1, 0)
    } else {
      name <- "log(followup_time_years)"
      c(unname(coef(fit)[name]), robust$vcov[name, name])
    }
  )
}

pool_comparison <- function(fits, cohort, mode, year, key) {
  df <- min(vapply(fits, function(fit) fit$df_complete, numeric(1L)))
  measures <- c("risk_continue", "risk_discontinue", "risk_difference", "risk_ratio")
  transformations <- list(tte_expit, tte_expit, identity, exp)
  rows <- lapply(seq_along(measures), function(i) {
    estimates <- vapply(fits, function(fit) fit[[key]]$estimates[i], numeric(1L))
    variances <- vapply(fits, function(fit) fit[[key]]$variances[i], numeric(1L))
    pooled <- tte_pool_scalar(estimates, variances, df_complete = df)
    values <- transformations[[i]](c(pooled$estimate, pooled$lower, pooled$upper))
    data.frame(
      cohort = cohort, model = mode, years = year, measure = measures[i],
      estimate = values[1L], lower = values[2L], upper = values[3L]
    )
  })
  do.call(rbind, rows)
}

compare_cohort <- function(cohort) {
  stem <- tolower(cohort)
  trials <- as.data.frame(readRDS(file.path(
    root, "stage04_structural_followup", "private_do_not_share",
    paste0(stem, "_structural_validated_trials_PRIVATE.rds")
  )))
  weight <- as.numeric(trials$L_survey_weight_final)
  trials <- trials[is.finite(weight) & weight > 0, , drop = FALSE]
  trials_key <- entry_key(trials)
  stopifnot(!anyDuplicated(trials_key))

  completed <- readRDS(file.path(
    root, "stage05_weighting", "private_do_not_share",
    paste0(stem, "_weighted_imputations_PRIVATE.rds")
  ))
  stopifnot(length(completed) == 20L)
  for (i in seq_along(completed)) {
    entries <- as.data.frame(completed[[i]])
    index <- match(entry_key(entries), trials_key)
    stopifnot(length(index) == nrow(trials), !anyNA(index), !anyDuplicated(index))
    entries$followup_time_years <- trials$followup_time_years[index]
    entries$treatment <- as.integer(as.character(entries$treatment))
    entries$sequence <- factor(entries$sequence)
    if (cohort == "SHARE") entries$B_country <- factor(entries$B_country)
    expected <- sample_reference[sample_reference$cohort == cohort, ]
    stopifnot(
      all(is.finite(entries$followup_time_years) & entries$followup_time_years > 0),
      all(entries$treatment %in% 0:1),
      nrow(entries) == sum(expected$person_trials),
      sum(entries$outcome_observed == 1L & !is.na(entries$primary_event) &
            is.finite(entries$total_weight) & entries$total_weight > 0) == sum(expected$outcome_observed_n)
    )
    completed[[i]] <- entries
  }

  fixed <- lapply(completed, fit_comparison, cohort = cohort, mode = "Fixed slope")
  original <- pool_comparison(fixed, cohort, "Fixed slope", 3, "at_three_years")
  expected <- reference[reference$cohort == cohort, ]
  expected <- expected[match(original$measure, expected$measure), ]
  stopifnot(
    isTRUE(all.equal(original$estimate, expected$estimate, tolerance = 1e-9)),
    isTRUE(all.equal(original$lower, expected$confidence_lower, tolerance = 1e-9)),
    isTRUE(all.equal(original$upper, expected$confidence_upper, tolerance = 1e-9))
  )

  free <- lapply(completed, fit_comparison, cohort = cohort, mode = "Estimated slope")
  slopes <- t(vapply(free, function(fit) fit$time_slope, numeric(2L)))
  slope <- tte_pool_scalar(
    slopes[, 1L], slopes[, 2L],
    df_complete = min(vapply(free, function(fit) fit$df_complete, numeric(1L))),
    null = 1
  )
  list(
    contrasts = rbind(
      pool_comparison(fixed, cohort, "Fixed slope", 2.25, "at_typical_time"),
      pool_comparison(free, cohort, "Estimated slope", 2.25, "at_typical_time"),
      original,
      pool_comparison(free, cohort, "Estimated slope", 3, "at_three_years")
    ),
    slope = data.frame(
      cohort = cohort, estimate = slope$estimate, lower = slope$lower, upper = slope$upper,
      positive_imputations = sum(slopes[, 1L] > 0)
    )
  )
}

result <- lapply(c("HRS", "SHARE"), compare_cohort)
contrasts <- do.call(rbind, lapply(result, function(x) x$contrasts))
slopes <- do.call(rbind, lapply(result, function(x) x$slope))

rows <- vapply(seq_len(nrow(slopes)), function(i) {
  x <- slopes[i, ]
  sprintf("| %s | %.2f (%.2f to %.2f) | %d of 20 |", x$cohort, x$estimate, x$lower, x$upper, x$positive_imputations)
}, character(1L))
contrast_rows <- vapply(seq(1L, nrow(contrasts), by = 4L), function(i) {
  x <- contrasts[i + 0:3, ]
  sprintf(
    "| %s | %.2f | %s | %.1f%% | %.1f%% | %.1f (%.1f to %.1f) | %.3f (%.3f to %.3f) |",
    x$cohort[1L], x$years[1L], x$model[1L], x$estimate[1L] * 100, x$estimate[2L] * 100,
    x$estimate[3L] * 1000, x$lower[3L] * 1000, x$upper[3L] * 1000,
    x$estimate[4L], x$lower[4L], x$upper[4L]
  )
}, character(1L))

output_dir <- file.path(root, "revision_r1")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output <- file.path(output_dir, "R1_primary_composite_assessment_time_sensitivity.md")
writeLines(c(
  "# Sensitivity of the primary composite to assessment-time modeling", "",
  "| Cohort | Estimated log-time slope (95% CI) | Positive slopes across imputations |",
  "|---|---:|---:|",
  rows, "",
  "| Cohort | Prediction time, y | Log-time model | Continuation risk | Discontinuation risk | RD per 1,000 (95% CI) | RR (95% CI) |",
  "|---|---:|---|---:|---:|---:|---:|",
  contrast_rows, "",
  "Both models used the original outcome-observed sample, combined analysis weights and standardization to eligible entries. Person-clustered CR1 variances were pooled across 20 imputations. The original model fixed the log-time slope at 1. The alternative estimated one cohort-specific slope. The 2.25-year reference is the pooled assessment interval median to two decimals in both cohorts. The alternative tests the sensitivity to fixing the slope at 1, with other outcome ascertainment and variance assumptions retained."
), output, useBytes = TRUE)
message("Reproduced the Stage 06 3-year estimates and confidence intervals. Wrote ", output)
