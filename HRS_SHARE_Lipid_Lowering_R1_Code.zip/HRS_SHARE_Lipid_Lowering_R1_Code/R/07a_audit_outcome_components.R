# Stage 07a: audit outcome components before fitting sensitivity models.
# This stage produces only de-identified counts and feasibility checks.
# No treatment-effect model is fitted here.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8",
  local = TRUE
)

required_packages <- c("yaml", "data.table")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
input_dir <- file.path(
  project_root, config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_dir <- file.path(project_root, config$output_root, "stage05_weighting")
output_dir <- file.path(project_root, config$output_root, "stage07a_outcome_audit")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")

gate_path <- file.path(stage05_dir, "05_weighting_gate.csv")
if (!file.exists(gate_path)) {
  stop("Missing Stage 05 gate file: ", gate_path, call. = FALSE)
}
stage05_gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
ready_column <- intersect(
  c("ready_for_effect_estimation", "all_gates_pass"),
  names(stage05_gate)
)
if (length(ready_column) != 1L) {
  stop("Could not identify the Stage 05 final gate column.", call. = FALSE)
}
as_logical_gate <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}
gate_rows <- stage05_gate[cohort %in% cohorts]
if (!setequal(as.character(gate_rows$cohort), cohorts) ||
    anyDuplicated(as.character(gate_rows$cohort)) ||
    nrow(gate_rows) != length(cohorts) ||
    !all(as_logical_gate(gate_rows[[ready_column]]))) {
  stop("Stage 07a requires both HRS and SHARE to have passed Stage 05.", call. = FALSE)
}

to_binary <- function(x, variable_name, cohort_name) {
  value <- suppressWarnings(as.integer(as.character(x)))
  invalid <- !is.na(value) & !value %in% c(0L, 1L)
  if (any(invalid)) {
    stop(
      cohort_name, ": ", variable_name,
      " contains values outside 0/1/NA.",
      call. = FALSE
    )
  }
  value
}

outcome_definitions <- data.table::data.table(
  outcome = c(
    "primary_event",
    "strict_event",
    "death_component",
    "broad_nonfatal_survivor",
    "strict_nonfatal_survivor",
    "death_adl_decline"
  ),
  label = c(
    "Broad heart disease, stroke, or all-cause death",
    "Myocardial infarction, stroke, or all-cause death",
    "All-cause death within the common follow-up interval",
    "Broad nonfatal cardiovascular report among observed survivors",
    "Nonfatal myocardial infarction or stroke among observed survivors",
    "All-cause death or increase of at least one ADL difficulty"
  ),
  analysis_role = c(
    "completed_primary_model",
    "eligible_for_effect_model",
    "eligible_for_effect_model_if_observation_matches_primary",
    "descriptive_only_survivor_conditioned",
    "descriptive_only_survivor_conditioned",
    "requires_outcome_specific_censoring_weights"
  ),
  interpretation_limit = c(
    "Includes a broad self-reported heart-disease component",
    "Nonfatal diagnoses remain interval-censored and self-reported",
    "Alive status is confirmed by an observed F interview; otherwise missing unless death was recorded",
    "Conditions on survival and observed F interview; not a marginal causal effect",
    "Conditions on survival and observed F interview; not a marginal causal effect",
    "Requires a separate observation model because ADL can be missing at an otherwise observed interview"
  )
)

arm_count_parts <- list()
sequence_count_parts <- list()
composition_parts <- list()
check_parts <- list()
pattern_parts <- list()
cohort_data <- list()

for (cohort_name in cohorts) {
  input_path <- file.path(
    input_dir,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  if (!file.exists(input_path)) {
    stop("Missing Stage 04f trial file: ", input_path, call. = FALSE)
  }

  trials <- data.table::as.data.table(readRDS(input_path))
  required_columns <- c(
    "person_id", "trial_id", "sequence", "treatment",
    "L_survey_weight_final", "F_interview_observed",
    "death_in_interval", "primary_event", "strict_event",
    "nonfatal_broad", "nonfatal_strict", "death_adl_decline"
  )
  missing_columns <- setdiff(required_columns, names(trials))
  if (length(missing_columns)) {
    stop(
      cohort_name, " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }

  # Match the Stage 05 treatment-weight eligibility sample exactly.
  trials <- trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  trials[, analysis_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(trials$analysis_key)) {
    stop(cohort_name, ": person_id + trial_id is not unique.", call. = FALSE)
  }

  binary_columns <- c(
    "treatment", "F_interview_observed", "death_in_interval",
    "primary_event", "strict_event", "nonfatal_broad",
    "nonfatal_strict", "death_adl_decline"
  )
  for (variable_name in binary_columns) {
    data.table::set(
      trials,
      j = variable_name,
      value = to_binary(trials[[variable_name]], variable_name, cohort_name)
    )
  }
  if (anyNA(trials$treatment) || !all(trials$treatment %in% c(0L, 1L))) {
    stop(cohort_name, ": treatment must be fully observed and binary.", call. = FALSE)
  }
  trials[, treatment_label := ifelse(treatment == 1L, "discontinue", "continue")]

  # Death is considered observed only when death was recorded, or an F-wave
  # interview confirms survival to the interval endpoint. A missing F interview
  # without a death record is not automatically treated as survival.
  trials[, death_component := data.table::fcase(
    death_in_interval == 1L, 1L,
    death_in_interval == 0L & F_interview_observed == 1L, 0L,
    default = NA_integer_
  )]

  # These two outcomes deliberately condition on being alive and observed at F.
  # They are used only to describe which nonfatal diagnoses contribute to the
  # composite, not as marginal causal estimands.
  trials[, broad_nonfatal_survivor := data.table::fcase(
    death_in_interval == 0L & F_interview_observed == 1L & nonfatal_broad == 1L, 1L,
    death_in_interval == 0L & F_interview_observed == 1L & nonfatal_broad == 0L, 0L,
    default = NA_integer_
  )]
  trials[, strict_nonfatal_survivor := data.table::fcase(
    death_in_interval == 0L & F_interview_observed == 1L & nonfatal_strict == 1L, 1L,
    death_in_interval == 0L & F_interview_observed == 1L & nonfatal_strict == 0L, 0L,
    default = NA_integer_
  )]

  trials[, primary_event_component := data.table::fcase(
    is.na(primary_event), "primary_outcome_unobserved",
    primary_event == 0L, "no_primary_event",
    death_in_interval == 1L, "death",
    death_in_interval == 0L & nonfatal_strict == 1L,
      "nonfatal_myocardial_infarction_or_stroke",
    death_in_interval == 0L & nonfatal_broad == 1L,
      "other_or_not_strictly_identified_broad_heart_disease",
    default = "logic_unclassified"
  )]

  hard_checks <- data.table::data.table(
    cohort = cohort_name,
    check = c(
      "unique_person_trial_key",
      "strict_event_nested_in_primary_event",
      "all_recorded_deaths_in_primary_event",
      "all_recorded_deaths_in_strict_event",
      "all_recorded_deaths_in_death_adl_decline",
      "every_observed_primary_event_classified"
    ),
    n_violations = c(
      sum(duplicated(trials$analysis_key)),
      sum(trials$strict_event == 1L & trials$primary_event == 0L, na.rm = TRUE),
      sum(trials$death_in_interval == 1L &
            (is.na(trials$primary_event) | trials$primary_event != 1L)),
      sum(trials$death_in_interval == 1L &
            (is.na(trials$strict_event) | trials$strict_event != 1L)),
      sum(trials$death_in_interval == 1L &
            (is.na(trials$death_adl_decline) | trials$death_adl_decline != 1L)),
      sum(trials$primary_event == 1L &
            trials$primary_event_component == "logic_unclassified", na.rm = TRUE)
    )
  )
  hard_checks[, passed := n_violations == 0L]
  check_parts[[cohort_name]] <- hard_checks

  pattern_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    comparison = c(
      "strict_vs_primary_observation_pattern",
      "death_vs_primary_observation_pattern",
      "death_adl_vs_primary_observation_pattern"
    ),
    discordant_person_trials = c(
      sum(is.na(trials$strict_event) != is.na(trials$primary_event)),
      sum(is.na(trials$death_component) != is.na(trials$primary_event)),
      sum(is.na(trials$death_adl_decline) != is.na(trials$primary_event))
    ),
    identical_observation_pattern = c(
      all(is.na(trials$strict_event) == is.na(trials$primary_event)),
      all(is.na(trials$death_component) == is.na(trials$primary_event)),
      all(is.na(trials$death_adl_decline) == is.na(trials$primary_event))
    )
  )

  outcome_names <- outcome_definitions$outcome
  arm_count_parts[[cohort_name]] <- data.table::rbindlist(
    lapply(outcome_names, function(outcome_name) {
      trials[, .(
        eligible_person_trials = .N,
        unique_persons = data.table::uniqueN(person_id),
        outcome_observed_person_trials = sum(!is.na(get(outcome_name))),
        outcome_observed_fraction = mean(!is.na(get(outcome_name))),
        events = sum(get(outcome_name) == 1L, na.rm = TRUE),
        non_events = sum(get(outcome_name) == 0L, na.rm = TRUE)
      ), by = .(treatment, treatment_label)][
        , `:=`(cohort = cohort_name, outcome = outcome_name)
      ]
    }),
    use.names = TRUE,
    fill = TRUE
  )

  sequence_count_parts[[cohort_name]] <- data.table::rbindlist(
    lapply(outcome_names, function(outcome_name) {
      trials[, .(
        eligible_person_trials = .N,
        unique_persons = data.table::uniqueN(person_id),
        outcome_observed_person_trials = sum(!is.na(get(outcome_name))),
        outcome_observed_fraction = mean(!is.na(get(outcome_name))),
        events = sum(get(outcome_name) == 1L, na.rm = TRUE)
      ), by = .(sequence, treatment, treatment_label)][
        , `:=`(cohort = cohort_name, outcome = outcome_name)
      ]
    }),
    use.names = TRUE,
    fill = TRUE
  )

  composition <- trials[, .(
    person_trials = .N,
    unique_persons = data.table::uniqueN(person_id)
  ), by = .(
    treatment, treatment_label,
    component = primary_event_component
  )]
  composition[, cohort := cohort_name]
  event_components <- c(
    "death",
    "nonfatal_myocardial_infarction_or_stroke",
    "other_or_not_strictly_identified_broad_heart_disease"
  )
  composition[, primary_event_component := component %in% event_components]
  composition[, primary_event_total := sum(
    person_trials[primary_event_component]
  ), by = .(cohort, treatment)]
  composition[, fraction_of_primary_events := ifelse(
    primary_event_component & primary_event_total > 0,
    person_trials / primary_event_total,
    NA_real_
  )]
  composition_parts[[cohort_name]] <- composition

  cohort_data[[cohort_name]] <- trials
}

hard_checks <- data.table::rbindlist(check_parts, use.names = TRUE, fill = TRUE)
if (any(!hard_checks$passed)) {
  failed <- hard_checks[passed == FALSE]
  stop(
    "Stage 07a hard consistency check failed: ",
    paste(paste(failed$cohort, failed$check, sep = "/"), collapse = ", "),
    call. = FALSE
  )
}

observation_patterns <- data.table::rbindlist(
  pattern_parts, use.names = TRUE, fill = TRUE
)
arm_counts <- data.table::rbindlist(
  arm_count_parts, use.names = TRUE, fill = TRUE
)
sequence_counts <- data.table::rbindlist(
  sequence_count_parts, use.names = TRUE, fill = TRUE
)
composition <- data.table::rbindlist(
  composition_parts, use.names = TRUE, fill = TRUE
)

data.table::setcolorder(
  arm_counts,
  c(
    "cohort", "outcome", "treatment", "treatment_label",
    "eligible_person_trials", "unique_persons",
    "outcome_observed_person_trials", "outcome_observed_fraction",
    "events", "non_events"
  )
)
data.table::setcolorder(
  sequence_counts,
  c(
    "cohort", "sequence", "outcome", "treatment", "treatment_label",
    "eligible_person_trials", "unique_persons",
    "outcome_observed_person_trials", "outcome_observed_fraction", "events"
  )
)

feasibility <- arm_counts[, .(
  both_arms_present = data.table::uniqueN(treatment) == 2L,
  smaller_arm_observed_person_trials = min(outcome_observed_person_trials),
  smaller_arm_events = min(events),
  total_events = sum(events),
  minimum_arm_observation_fraction = min(outcome_observed_fraction)
), by = .(cohort, outcome)]
feasibility <- merge(
  feasibility,
  outcome_definitions[, .(outcome, analysis_role)],
  by = "outcome",
  all.x = TRUE,
  sort = FALSE
)
feasibility[, pass_smaller_arm_n :=
  smaller_arm_observed_person_trials >=
    as.numeric(config$data_gates$minimum_smaller_arm_person_trials)]
feasibility[, pass_smaller_arm_events :=
  smaller_arm_events >=
    as.numeric(config$data_gates$minimum_smaller_arm_primary_events)]
feasibility[, pass_total_events :=
  total_events >= as.numeric(config$data_gates$minimum_total_primary_events)]
feasibility[, passes_unweighted_event_gate :=
  both_arms_present & pass_smaller_arm_n & pass_smaller_arm_events & pass_total_events]

death_pattern <- observation_patterns[
  comparison == "death_vs_primary_observation_pattern",
  .(cohort, death_observation_matches_primary = identical_observation_pattern)
]
feasibility <- merge(feasibility, death_pattern, by = "cohort", all.x = TRUE, sort = FALSE)
feasibility[, can_reuse_stage05_total_weight := data.table::fcase(
  outcome %in% c("primary_event", "strict_event"), TRUE,
  outcome == "death_component", death_observation_matches_primary,
  default = FALSE
)]
feasibility[, recommendation := data.table::fcase(
  outcome == "primary_event", "already_completed_in_stage06",
  outcome %in% c("broad_nonfatal_survivor", "strict_nonfatal_survivor"),
    "report_counts_only_due_to_survivor_conditioning",
  outcome == "death_adl_decline" & passes_unweighted_event_gate,
    "rebuild_outcome_specific_censoring_weights_before_model",
  outcome == "death_adl_decline" & !passes_unweighted_event_gate,
    "descriptive_only_event_gate_failed",
  passes_unweighted_event_gate & can_reuse_stage05_total_weight,
    "eligible_for_stage07b_effect_model",
  passes_unweighted_event_gate & !can_reuse_stage05_total_weight,
    "requires_new_censoring_weights_before_effect_model",
  default = "descriptive_only_event_gate_failed"
)]
feasibility[, death_observation_matches_primary := NULL]

data.table::setorder(arm_counts, cohort, outcome, treatment)
data.table::setorder(sequence_counts, cohort, sequence, outcome, treatment)
data.table::setorder(composition, cohort, treatment, component)
data.table::setorder(feasibility, cohort, outcome)
data.table::setorder(hard_checks, cohort, check)
data.table::setorder(observation_patterns, cohort, comparison)

tte_write_csv(outcome_definitions, file.path(output_dir, "07a_outcome_definitions.csv"))
tte_write_csv(arm_counts, file.path(output_dir, "07a_arm_outcome_counts.csv"))
tte_write_csv(
  sequence_counts,
  file.path(output_dir, "07a_sequence_arm_outcome_counts.csv")
)
tte_write_csv(
  composition,
  file.path(output_dir, "07a_primary_event_composition.csv")
)
tte_write_csv(feasibility, file.path(output_dir, "07a_outcome_feasibility.csv"))
tte_write_csv(hard_checks, file.path(output_dir, "07a_consistency_checks.csv"))
tte_write_csv(
  observation_patterns,
  file.path(output_dir, "07a_observation_pattern_checks.csv")
)

composition_summary <- composition[
  primary_event_component == TRUE,
  .(
    event_component_text = paste0(
      component, "=", person_trials, " (",
      sprintf("%.1f", 100 * fraction_of_primary_events), "%)",
      collapse = "; "
    )
  ),
  by = .(cohort, treatment_label)
]
feasibility_summary <- feasibility[
  outcome %in% c("strict_event", "death_component", "death_adl_decline"),
  .(
    line = paste0(
      outcome, ": smaller-arm events=", smaller_arm_events,
      ", total events=", total_events,
      ", recommendation=", recommendation
    )
  ),
  by = cohort
]

summary_lines <- c(
  "Stage 07a: outcome-component feasibility audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "No treatment-effect model was fitted in this stage.",
  "Death was not assigned as absent solely because a follow-up interview was missing.",
  "Nonfatal component counts among survivors are descriptive and are not marginal causal effects.",
  "",
  unlist(lapply(cohorts, function(cohort_name) {
    c(
      paste0(cohort_name, " primary-event composition:"),
      paste0(
        "  ",
        composition_summary[cohort == cohort_name, treatment_label], ": ",
        composition_summary[cohort == cohort_name, event_component_text]
      ),
      paste0(
        "  ",
        feasibility_summary[cohort == cohort_name, line]
      )
    )
  })),
  "",
  "Proceed only with outcomes marked eligible_for_stage07b_effect_model.",
  "ADL models require outcome-specific censoring weights and are deferred."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07a_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07a_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message("Stage 07a completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
