# Stage 04f: remove country-wave person-trials without a uniformly administered
# regular health follow-up. This design-stage filter is frozen before any effect
# estimate is fitted. No imputation, weighting, or treatment-effect model occurs.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "data.table"))

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
input_dir <- file.path(
  project_root, config$output_root,
  "stage04_fi_exposure_validation", "private_do_not_share"
)
output_dir <- file.path(project_root, config$output_root, "stage04_structural_followup")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

rule_path <- file.path(
  project_root, "config_r", "share_regular_health_followup.csv"
)
rules <- data.table::fread(rule_path, encoding = "UTF-8")
required_rule_columns <- c(
  "F_wave", "availability_policy", "allowed_country_codes",
  "rationale", "official_source"
)
if (!all(required_rule_columns %in% names(rules))) {
  stop("SHARE follow-up rule table is incomplete.", call. = FALSE)
}
if (anyDuplicated(rules$F_wave)) {
  stop("SHARE follow-up rule table has duplicate F_wave rows.", call. = FALSE)
}
if (!all(rules$availability_policy %in% c("restricted", "exclude_all", "all"))) {
  stop("Unknown availability_policy in SHARE follow-up rule table.", call. = FALSE)
}

parse_codes <- function(value) {
  value <- trimws(as.character(value))
  if (!nzchar(value) || value == "ALL") return(integer())
  suppressWarnings(as.integer(strsplit(value, "|", fixed = TRUE)[[1L]]))
}

evaluate_share_rule <- function(f_wave, country_code) {
  rule <- rules[F_wave == as.integer(f_wave)]
  if (nrow(rule) != 1L) {
    stop("No unique structural follow-up rule for SHARE F_wave ", f_wave, call. = FALSE)
  }
  policy <- rule$availability_policy[[1L]]
  eligible <- if (policy == "all") {
    TRUE
  } else if (policy == "exclude_all") {
    FALSE
  } else {
    as.integer(country_code) %in% parse_codes(rule$allowed_country_codes[[1L]])
  }
  list(
    eligible = eligible,
    policy = policy,
    rationale = rule$rationale[[1L]],
    official_source = rule$official_source[[1L]]
  )
}

flow_parts <- list()
excluded_parts <- list()
arm_parts <- list()
sequence_parts <- list()
fi_parts <- list()
country_sequence_parts <- list()
expanded_rule_parts <- list()

for (cohort_name in c("HRS", "SHARE")) {
  input_path <- file.path(
    input_dir, paste0(tolower(cohort_name), "_fi_validated_trials_PRIVATE.rds")
  )
  if (!file.exists(input_path)) stop("Missing Stage 04e input: ", input_path, call. = FALSE)
  trials <- data.table::as.data.table(readRDS(input_path))
  initial_n <- nrow(trials)

  if (cohort_name == "HRS") {
    trials[, `:=`(
      structural_followup_eligible = TRUE,
      structural_followup_policy = "not_applicable",
      structural_followup_reason = "HRS is not subject to SHARE country-wave routing.",
      structural_followup_source = NA_character_
    )]
  } else {
    required_columns <- c("F_wave", "B_country", "sequence")
    missing_columns <- setdiff(required_columns, names(trials))
    if (length(missing_columns)) {
      stop("SHARE is missing: ", paste(missing_columns, collapse = ", "), call. = FALSE)
    }
    if (anyNA(trials$F_wave) || anyNA(trials$B_country)) {
      stop("SHARE contains missing F_wave or B_country before structural filtering.", call. = FALSE)
    }
    unexpected_waves <- setdiff(unique(as.integer(trials$F_wave)), rules$F_wave)
    if (length(unexpected_waves)) {
      stop(
        "SHARE has F waves absent from the frozen rule table: ",
        paste(unexpected_waves, collapse = ", "), call. = FALSE
      )
    }

    evaluated <- lapply(seq_len(nrow(trials)), function(index) {
      evaluate_share_rule(trials$F_wave[[index]], trials$B_country[[index]])
    })
    trials[, structural_followup_eligible := vapply(
      evaluated, function(value) isTRUE(value$eligible), logical(1L)
    )]
    trials[, structural_followup_policy := vapply(
      evaluated, function(value) value$policy, character(1L)
    )]
    trials[, structural_followup_reason := vapply(
      evaluated, function(value) value$rationale, character(1L)
    )]
    trials[, structural_followup_source := vapply(
      evaluated, function(value) value$official_source, character(1L)
    )]

    expanded_rule_parts[[cohort_name]] <- unique(trials[, .(
      F_wave,
      country_code = as.integer(B_country),
      structural_followup_eligible,
      structural_followup_policy,
      structural_followup_reason,
      structural_followup_source
    )])[order(F_wave, country_code)]
  }

  excluded <- trials[structural_followup_eligible == FALSE]
  retained <- trials[structural_followup_eligible == TRUE]
  if (cohort_name == "SHARE" && any(retained$F_wave == 7L)) {
    stop("Wave 7 remained after structural follow-up filtering.", call. = FALSE)
  }
  if (!setequal(unique(retained$treatment), c(0L, 1L))) {
    stop(cohort_name, " lost one treatment arm after structural filtering.", call. = FALSE)
  }

  output_path <- file.path(
    private_dir,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  saveRDS(retained, output_path, version = 3L)

  flow_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    input_person_trials = initial_n,
    structurally_excluded_person_trials = nrow(excluded),
    retained_person_trials = nrow(retained),
    retained_unique_persons = data.table::uniqueN(retained$person_id)
  )
  if (nrow(excluded)) {
    excluded_parts[[cohort_name]] <- excluded[, .(
      excluded_person_trials = .N,
      continue_trials = sum(treatment == 0L),
      discontinue_trials = sum(treatment == 1L),
      outcomes_observed = sum(!is.na(primary_event)),
      primary_events = sum(primary_event == 1L, na.rm = TRUE)
    ), by = .(
      cohort, sequence, F_wave, B_country,
      structural_followup_policy, structural_followup_reason,
      structural_followup_source
    )]
  }
  arm_parts[[cohort_name]] <- retained[, .(
    person_trials = .N,
    unique_persons = data.table::uniqueN(person_id),
    outcomes_observed = sum(!is.na(primary_event)),
    primary_events = sum(primary_event == 1L, na.rm = TRUE),
    strict_events = sum(strict_event == 1L, na.rm = TRUE),
    death_adl_events = sum(death_adl_decline == 1L, na.rm = TRUE)
  ), by = .(cohort, treatment)]
  sequence_parts[[cohort_name]] <- retained[, .(
    person_trials = .N,
    unique_persons = data.table::uniqueN(person_id),
    continue_trials = sum(treatment == 0L),
    discontinue_trials = sum(treatment == 1L),
    outcomes_observed = sum(!is.na(primary_event)),
    outcome_observation_fraction = mean(!is.na(primary_event)),
    primary_events = sum(primary_event == 1L, na.rm = TRUE)
  ), by = .(cohort, sequence, E_wave, L_wave, F_wave)]
  fi_parts[[cohort_name]] <- retained[, .(
    person_trials = .N,
    outcomes_observed = sum(!is.na(primary_event)),
    primary_events = sum(primary_event == 1L, na.rm = TRUE)
  ), by = .(cohort, FI_group, treatment)]
  country_sequence_parts[[cohort_name]] <- retained[, .(
    person_trials = .N,
    continue_trials = sum(treatment == 0L),
    discontinue_trials = sum(treatment == 1L),
    outcomes_observed = sum(!is.na(primary_event)),
    outcome_observation_fraction = mean(!is.na(primary_event)),
    primary_events = sum(primary_event == 1L, na.rm = TRUE)
  ), by = .(cohort, sequence, F_wave, B_country)]
}

flow <- data.table::rbindlist(flow_parts, use.names = TRUE, fill = TRUE)
excluded <- if (length(excluded_parts)) {
  data.table::rbindlist(excluded_parts, use.names = TRUE, fill = TRUE)
} else {
  data.table::data.table(cohort = character(), sequence = character())
}
arms <- data.table::rbindlist(arm_parts, use.names = TRUE, fill = TRUE)
sequences <- data.table::rbindlist(sequence_parts, use.names = TRUE, fill = TRUE)
fi_events <- data.table::rbindlist(fi_parts, use.names = TRUE, fill = TRUE)
country_sequences <- data.table::rbindlist(
  country_sequence_parts, use.names = TRUE, fill = TRUE
)
expanded_rules <- data.table::rbindlist(
  expanded_rule_parts, use.names = TRUE, fill = TRUE
)

share_arm <- arms[cohort == "SHARE"]
if (min(share_arm$person_trials) < as.numeric(config$data_gates$minimum_smaller_arm_person_trials) ||
    min(share_arm$primary_events) < as.numeric(config$data_gates$minimum_smaller_arm_primary_events) ||
    sum(share_arm$primary_events) < as.numeric(config$data_gates$minimum_total_primary_events)) {
  stop("SHARE no longer meets the prespecified sample/event gate after filtering.", call. = FALSE)
}

tte_write_csv(rules, file.path(output_dir, "04f_frozen_followup_rules.csv"))
tte_write_csv(expanded_rules, file.path(output_dir, "04f_expanded_rule_application.csv"))
tte_write_csv(flow, file.path(output_dir, "04f_exclusion_flow.csv"))
tte_write_csv(excluded, file.path(output_dir, "04f_excluded_country_sequences.csv"))
tte_write_csv(arms, file.path(output_dir, "04f_retained_arm_event_counts.csv"))
tte_write_csv(sequences, file.path(output_dir, "04f_retained_sequence_counts.csv"))
tte_write_csv(fi_events, file.path(output_dir, "04f_retained_fi_group_events.csv"))
tte_write_csv(
  country_sequences,
  file.path(output_dir, "04f_country_sequence_outcome_observation.csv")
)

summary_lines <- c(
  "Stage 04f: structural follow-up eligibility filter",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0(
    "SHARE person-trials retained: ",
    flow[cohort == "SHARE", retained_person_trials], " of ",
    flow[cohort == "SHARE", input_person_trials]
  ),
  paste0(
    "SHARE person-trials excluded by frozen country-wave rules: ",
    flow[cohort == "SHARE", structurally_excluded_person_trials]
  ),
  "No individual was excluded because of their observed outcome value.",
  "No imputation, weighting, or treatment-effect model was fitted."
)
writeLines(summary_lines, file.path(output_dir, "04f_stage_summary.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(output_dir, "04f_session_info.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
