# Stage 07i: audit whether prespecified frailty effect-modification analyses
# are supported by the observed data. No treatment effect is estimated here.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8", local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
weight_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "primary_weight_model.yml")
)
audit_config_path <- file.path(
  project_root, "config_r", "frailty_heterogeneity_audit.yml"
)
audit_config <- tte_read_yaml_utf8(audit_config_path)

stage05_dir <- file.path(
  project_root, analysis_config$output_root, "stage05_weighting"
)
stage05_private <- file.path(stage05_dir, "private_do_not_share")
stage07g_dir <- file.path(
  project_root, analysis_config$output_root, "stage07g_functional_weights"
)
stage07g_private <- file.path(stage07g_dir, "private_do_not_share")
output_dir <- file.path(
  project_root, analysis_config$output_root, "stage07i_frailty_audit"
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
continuous_covariates <- unlist(
  weight_config$continuous_covariates, use.names = FALSE
)
categorical_covariates <- unlist(
  weight_config$categorical_covariates, use.names = FALSE
)
balance_variables <- c(continuous_covariates, categorical_covariates)
fi_variable <- as.character(audit_config$effect_modifier$variable)

outcome_manifest <- data.table::rbindlist(lapply(
  names(audit_config$outcomes),
  function(outcome_name) {
    item <- audit_config$outcomes[[outcome_name]]
    data.table::data.table(
      outcome = outcome_name,
      outcome_label = as.character(item$label),
      weight_source = as.character(item$weight_source)
    )
  }
))

group_items <- audit_config$effect_modifier$groups
group_manifest <- data.table::rbindlist(lapply(group_items, function(item) {
  data.table::data.table(
    FI_group = as.character(item$name),
    FI_group_label = as.character(item$label),
    lower = as.numeric(item$lower),
    upper = as.numeric(item$upper)
  )
}))
if (any(!is.finite(group_manifest$lower)) ||
    any(!is.finite(group_manifest$upper)) ||
    any(group_manifest$upper <= group_manifest$lower)) {
  stop("Invalid frailty group boundaries.", call. = FALSE)
}

assign_fi_group <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  result <- rep(NA_character_, length(x))
  for (row_index in seq_len(nrow(group_manifest))) {
    row <- group_manifest[row_index]
    selected <- !is.na(x) & x >= row$lower & x < row$upper
    result[selected] <- row$FI_group
  }
  factor(result, levels = group_manifest$FI_group)
}

effective_sample_size <- function(weight) {
  weight <- suppressWarnings(as.numeric(weight))
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

weighted_mean_safe <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (!any(valid)) return(NA_real_)
  sum(x[valid] * weight[valid]) / sum(weight[valid])
}

weighted_variance_safe <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean_safe(x[valid], weight[valid])
  sum(weight[valid] * (x[valid] - center)^2) / sum(weight[valid])
}

numeric_smd <- function(x, treatment, weight) {
  x <- suppressWarnings(as.numeric(x))
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- x[valid]
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  mean0 <- weighted_mean_safe(x[treatment == 0L], weight[treatment == 0L])
  mean1 <- weighted_mean_safe(x[treatment == 1L], weight[treatment == 1L])
  var0 <- weighted_variance_safe(x[treatment == 0L], weight[treatment == 0L])
  var1 <- weighted_variance_safe(x[treatment == 1L], weight[treatment == 1L])
  denominator <- sqrt((var0 + var1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (mean1 - mean0) / denominator
}

level_smd <- function(x, treatment, weight, level_value) {
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- !is.na(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- as.character(x[valid])
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  indicator <- as.numeric(x == level_value)
  p0 <- weighted_mean_safe(
    indicator[treatment == 0L], weight[treatment == 0L]
  )
  p1 <- weighted_mean_safe(
    indicator[treatment == 1L], weight[treatment == 1L]
  )
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

calculate_group_balance <- function(
  data, cohort_name, outcome_name, imputation_index, fi_group_name
) {
  rows <- list()
  row_index <- 0L
  for (variable_name in balance_variables) {
    x <- data[[variable_name]]
    if (variable_name %in% categorical_covariates) {
      present_levels <- sort(unique(as.character(x[!is.na(x)])))
      for (level_value in present_levels) {
        row_index <- row_index + 1L
        rows[[row_index]] <- data.table::data.table(
          cohort = cohort_name,
          outcome = outcome_name,
          imputation = imputation_index,
          FI_group = fi_group_name,
          variable = variable_name,
          level = level_value,
          standardized_difference = level_smd(
            x, data$treatment, data$analysis_weight, level_value
          )
        )
      }
    } else {
      row_index <- row_index + 1L
      rows[[row_index]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        FI_group = fi_group_name,
        variable = variable_name,
        level = "",
        standardized_difference = numeric_smd(
          x, data$treatment, data$analysis_weight
        )
      )
    }
  }
  result <- data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)
  result[, absolute_standardized_difference := abs(standardized_difference)]
  result
}

balance_parts <- list()
ess_parts <- list()
count_parts <- list()
fi_distribution_parts <- list()
join_parts <- list()

for (cohort_name in cohorts) {
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  functional_path <- file.path(
    stage07g_private,
    paste0(tolower(cohort_name), "_functional_weights_PRIVATE.rds")
  )
  if (!file.exists(stage05_path) || !file.exists(functional_path)) {
    stop("Missing Stage 05 or Stage 07g input for ", cohort_name, call. = FALSE)
  }
  completed_list <- readRDS(stage05_path)
  functional_list <- readRDS(functional_path)
  if (!is.list(completed_list) || !is.list(functional_list) ||
      length(completed_list) != 20L || length(functional_list) != 20L) {
    stop(cohort_name, ": expected 20 Stage 05 and Stage 07g datasets.", call. = FALSE)
  }

  for (imputation_index in seq_along(completed_list)) {
    completed <- data.table::as.data.table(
      data.table::copy(completed_list[[imputation_index]])
    )
    functional <- data.table::as.data.table(
      data.table::copy(functional_list[[imputation_index]])
    )
    required_completed <- c(
      "person_id", "trial_id", "treatment", fi_variable,
      "primary_event", "outcome_observed", "total_weight",
      balance_variables
    )
    missing_completed <- setdiff(required_completed, names(completed))
    if (length(missing_completed)) {
      stop(
        cohort_name, " Stage 05 lacks: ",
        paste(missing_completed, collapse = ", "), call. = FALSE
      )
    }
    required_functional <- c(
      "person_id", "trial_id", "outcome_value",
      "outcome_observed_specific", "total_weight_specific"
    )
    missing_functional <- setdiff(required_functional, names(functional))
    if (length(missing_functional)) {
      stop(
        cohort_name, " Stage 07g lacks: ",
        paste(missing_functional, collapse = ", "), call. = FALSE
      )
    }
    completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    functional[, join_key_check := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    if (anyDuplicated(completed$join_key) ||
        anyDuplicated(functional$join_key_check)) {
      stop(cohort_name, ": duplicate person-trial key.", call. = FALSE)
    }
    functional_index <- match(completed$join_key, functional$join_key_check)
    exact_join <- !anyNA(functional_index) &&
      nrow(completed) == nrow(functional)
    if (!exact_join) {
      stop(
        cohort_name, ": Stage 05/07g join failed in imputation ",
        imputation_index, call. = FALSE
      )
    }
    join_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        stage05_rows = nrow(completed),
        stage07g_rows = nrow(functional),
        unmatched_rows = sum(is.na(functional_index)),
        exact_join = exact_join
      )

    completed[, treatment := suppressWarnings(
      as.integer(as.character(treatment))
    )]
    completed[, FI_group := assign_fi_group(get(fi_variable))]
    completed[, functional_event :=
      suppressWarnings(as.integer(functional$outcome_value[functional_index]))]
    completed[, functional_observed := suppressWarnings(as.integer(
      functional$outcome_observed_specific[functional_index]
    ))]
    completed[, functional_weight := suppressWarnings(as.numeric(
      functional$total_weight_specific[functional_index]
    ))]

    fi_value <- suppressWarnings(as.numeric(completed[[fi_variable]]))
    if (any(fi_value < 0 | fi_value > 1, na.rm = TRUE)) {
      stop(cohort_name, ": FI is outside [0,1].", call. = FALSE)
    }
    fi_distribution_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        person_trials = nrow(completed),
        FI_nonmissing_n = sum(!is.na(fi_value)),
        FI_nonmissing_fraction = mean(!is.na(fi_value)),
        FI_minimum = min(fi_value, na.rm = TRUE),
        FI_p05 = as.numeric(stats::quantile(fi_value, 0.05, na.rm = TRUE)),
        FI_median = stats::median(fi_value, na.rm = TRUE),
        FI_p95 = as.numeric(stats::quantile(fi_value, 0.95, na.rm = TRUE)),
        FI_maximum = max(fi_value, na.rm = TRUE)
      )

    for (outcome_index in seq_len(nrow(outcome_manifest))) {
      outcome_row <- outcome_manifest[outcome_index]
      outcome_name <- outcome_row$outcome
      if (outcome_row$weight_source == "stage05") {
        completed[, audit_outcome := suppressWarnings(
          as.integer(primary_event)
        )]
        completed[, audit_observed := suppressWarnings(
          as.integer(outcome_observed)
        )]
        completed[, analysis_weight := suppressWarnings(as.numeric(total_weight))]
      } else if (outcome_row$weight_source == "stage07g") {
        completed[, audit_outcome := functional_event]
        completed[, audit_observed := functional_observed]
        completed[, analysis_weight := functional_weight]
      } else {
        stop("Unsupported weight source: ", outcome_row$weight_source, call. = FALSE)
      }

      observed <- completed[
        audit_observed == 1L & !is.na(audit_outcome) &
          !is.na(FI_group) & is.finite(analysis_weight) & analysis_weight > 0
      ]
      if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
        stop(
          cohort_name, "/", outcome_name,
          ": invalid outcome-observed sample in imputation ",
          imputation_index, call. = FALSE
        )
      }

      count_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- observed[, .(
        person_trials = .N,
        unique_persons = data.table::uniqueN(person_id),
        events = sum(audit_outcome == 1L)
      ), by = .(FI_group, treatment)][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]

      ess_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- observed[, .(
        effective_sample_size = effective_sample_size(analysis_weight)
      ), by = .(FI_group, treatment)][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]

      for (fi_group_name in levels(observed$FI_group)) {
        stratum_data <- observed[FI_group == fi_group_name]
        if (data.table::uniqueN(stratum_data$treatment) != 2L) next
        balance_parts[[paste(
          cohort_name, outcome_name, imputation_index, fi_group_name, sep = "_"
        )]] <- calculate_group_balance(
          stratum_data, cohort_name, outcome_name,
          imputation_index, fi_group_name
        )
      }
    }
  }
}

counts <- data.table::rbindlist(count_parts, use.names = TRUE, fill = TRUE)
ess <- data.table::rbindlist(ess_parts, use.names = TRUE, fill = TRUE)
balance <- data.table::rbindlist(balance_parts, use.names = TRUE, fill = TRUE)
fi_distribution <- data.table::rbindlist(
  fi_distribution_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(join_parts, use.names = TRUE, fill = TRUE)

# Three originally missing FI values can be assigned to different strata across
# imputations. Report ranges and use the most conservative imputation for gates.
counts_summary <- counts[, .(
  minimum_person_trials = min(person_trials),
  maximum_person_trials = max(person_trials),
  minimum_unique_persons = min(unique_persons),
  maximum_unique_persons = max(unique_persons),
  minimum_events = min(events),
  maximum_events = max(events)
), by = .(cohort, outcome, FI_group, treatment, treatment_label)]

gate_by_imputation <- counts[, .(
  smaller_arm_person_trials = min(person_trials),
  smaller_arm_events = min(events),
  total_events = sum(events)
), by = .(cohort, outcome, FI_group, imputation)]
gate_base <- gate_by_imputation[, .(
  smaller_arm_person_trials = min(smaller_arm_person_trials),
  smaller_arm_events = min(smaller_arm_events),
  total_events = min(total_events)
), by = .(cohort, outcome, FI_group)]

ess_gate <- ess[, .(
  minimum_arm_effective_sample_size = min(effective_sample_size, na.rm = TRUE)
), by = .(cohort, outcome, FI_group)]

balance_summary <- balance[, .(
  mean_absolute_smd = mean(absolute_standardized_difference, na.rm = TRUE),
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE)
), by = .(cohort, outcome, FI_group, variable, level)]
balance_gate <- balance_summary[, .(
  maximum_absolute_smd = max(maximum_absolute_smd, na.rm = TRUE),
  variable_with_largest_imbalance = paste0(
    variable[which.max(maximum_absolute_smd)],
    ifelse(level[which.max(maximum_absolute_smd)] == "", "",
           paste0("=", level[which.max(maximum_absolute_smd)]))
  )
), by = .(cohort, outcome, FI_group)]

categorical_gates <- Reduce(
  function(x, y) merge(
    x, y, by = c("cohort", "outcome", "FI_group"), all = TRUE
  ),
  list(gate_base, ess_gate, balance_gate)
)
categorical_gates <- merge(
  categorical_gates,
  outcome_manifest[, .(outcome, outcome_label)],
  by = "outcome", all.x = TRUE
)
categorical_gates <- merge(
  categorical_gates,
  group_manifest[, .(FI_group, FI_group_label)],
  by = "FI_group", all.x = TRUE
)
categorical_thresholds <- audit_config$categorical_subgroup_gates
categorical_gates[, pass_person_trials := smaller_arm_person_trials >=
  as.numeric(categorical_thresholds$minimum_smaller_arm_person_trials)]
categorical_gates[, pass_events_each_arm := smaller_arm_events >=
  as.numeric(categorical_thresholds$minimum_events_each_arm)]
categorical_gates[, pass_total_events := total_events >=
  as.numeric(categorical_thresholds$minimum_total_events)]
categorical_gates[, pass_effective_sample_size :=
  minimum_arm_effective_sample_size >= as.numeric(
    categorical_thresholds$minimum_effective_sample_size_each_arm
  )]
categorical_gates[, pass_balance := maximum_absolute_smd <
  as.numeric(categorical_thresholds$maximum_absolute_standardized_difference)]
categorical_gates[, ready_for_categorical_frailty_effect :=
  pass_person_trials & pass_events_each_arm & pass_total_events &
    pass_effective_sample_size & pass_balance]

fi_gate_summary <- fi_distribution[, .(
  minimum_nonmissing_fraction = min(FI_nonmissing_fraction),
  minimum_p05_to_p95_width = min(FI_p95 - FI_p05),
  FI_p05 = min(FI_p05),
  FI_p95 = max(FI_p95)
), by = cohort]

overall_events_by_arm <- counts[, .(
  arm_events = sum(events)
), by = .(cohort, outcome, imputation, treatment)]
overall_events_by_imputation <- overall_events_by_arm[, .(
  smaller_arm_events = min(arm_events),
  total_events = sum(arm_events)
), by = .(cohort, outcome, imputation)]
overall_events <- overall_events_by_imputation[, .(
  smaller_arm_events = min(smaller_arm_events),
  total_events = min(total_events)
), by = .(cohort, outcome)]
continuous_gates <- merge(
  overall_events, fi_gate_summary, by = "cohort", all.x = TRUE
)
continuous_gates <- merge(
  continuous_gates,
  outcome_manifest[, .(outcome, outcome_label)],
  by = "outcome", all.x = TRUE
)
continuous_thresholds <- audit_config$continuous_interaction_gate
continuous_gates[, pass_fi_completeness := minimum_nonmissing_fraction >=
  as.numeric(continuous_thresholds$minimum_nonmissing_fraction)]
continuous_gates[, pass_events_each_arm := smaller_arm_events >=
  as.numeric(continuous_thresholds$minimum_events_each_treatment_arm)]
continuous_gates[, pass_total_events := total_events >=
  as.numeric(continuous_thresholds$minimum_total_events)]
continuous_gates[, pass_fi_spread := minimum_p05_to_p95_width >=
  as.numeric(
    continuous_thresholds$minimum_fi_5th_to_95th_percentile_width
  )]
continuous_gates[, ready_for_continuous_frailty_interaction :=
  pass_fi_completeness & pass_events_each_arm &
    pass_total_events & pass_fi_spread]

data.table::setorder(counts_summary, cohort, outcome, FI_group, treatment)
data.table::setorder(ess, cohort, outcome, FI_group, imputation, treatment)
data.table::setorder(balance_summary, cohort, outcome, FI_group, variable, level)
data.table::setorder(categorical_gates, cohort, outcome, FI_group)
data.table::setorder(continuous_gates, cohort, outcome)

tte_write_csv(
  counts_summary,
  file.path(output_dir, "07i_frailty_group_counts.csv")
)
tte_write_csv(
  ess,
  file.path(output_dir, "07i_frailty_group_effective_sample_size.csv")
)
tte_write_csv(
  balance_summary,
  file.path(output_dir, "07i_frailty_group_balance.csv")
)
tte_write_csv(
  categorical_gates,
  file.path(output_dir, "07i_categorical_frailty_gate.csv")
)
tte_write_csv(
  continuous_gates,
  file.path(output_dir, "07i_continuous_frailty_interaction_gate.csv")
)
tte_write_csv(
  fi_distribution,
  file.path(output_dir, "07i_frailty_distribution_by_imputation.csv")
)
tte_write_csv(
  join_checks,
  file.path(output_dir, "07i_join_checks.csv")
)
file.copy(
  audit_config_path,
  file.path(output_dir, "07i_frozen_frailty_heterogeneity_audit.yml"),
  overwrite = TRUE
)

plot_data <- categorical_gates[, .(
  cohort, outcome_label, FI_group_label,
  maximum_absolute_smd, ready_for_categorical_frailty_effect
)]
balance_plot <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(
    x = maximum_absolute_smd, y = FI_group_label,
    colour = ready_for_categorical_frailty_effect
  )
) +
  ggplot2::geom_vline(
    xintercept = as.numeric(
      categorical_thresholds$maximum_absolute_standardized_difference
    ),
    linetype = 2, colour = "grey45"
  ) +
  ggplot2::geom_point(size = 2.2) +
  ggplot2::facet_grid(outcome_label ~ cohort) +
  ggplot2::scale_colour_manual(
    values = c("TRUE" = "#2E7D32", "FALSE" = "#C44E52")
  ) +
  ggplot2::labs(
    x = "Largest absolute weighted standardized difference",
    y = NULL,
    colour = "All gates passed",
    title = "Frailty-stratum balance and feasibility audit"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(legend.position = "bottom")
ggplot2::ggsave(
  file.path(output_dir, "07i_frailty_gate_plot.png"),
  balance_plot, width = 11, height = 7, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07i_frailty_gate_plot.pdf"),
  balance_plot, width = 11, height = 7
)

categorical_lines <- vapply(seq_len(nrow(categorical_gates)), function(i) {
  row <- categorical_gates[i]
  paste0(
    row$cohort, "/", row$outcome, "/", row$FI_group,
    ": smaller-arm trials=", row$smaller_arm_person_trials,
    ", smaller-arm events=", row$smaller_arm_events,
    ", total events=", row$total_events,
    ", min arm ESS=", sprintf("%.1f", row$minimum_arm_effective_sample_size),
    ", max |SMD|=", sprintf("%.3f", row$maximum_absolute_smd),
    ", categorical ready=", row$ready_for_categorical_frailty_effect
  )
}, character(1L))
continuous_lines <- vapply(seq_len(nrow(continuous_gates)), function(i) {
  row <- continuous_gates[i]
  paste0(
    row$cohort, "/", row$outcome,
    ": FI completeness=", sprintf("%.3f", row$minimum_nonmissing_fraction),
    ", FI p05-p95 width=", sprintf("%.3f", row$minimum_p05_to_p95_width),
    ", smaller-arm events=", row$smaller_arm_events,
    ", total events=", row$total_events,
    ", continuous interaction ready=",
    row$ready_for_continuous_frailty_interaction
  )
}, character(1L))

summary_lines <- c(
  "Stage 07i: frailty heterogeneity feasibility and balance audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Outcomes: broad cardiovascular disease/death and death/ADL decline.",
  "Effect modifier: pre-treatment deficit-accumulation frailty index.",
  "Frailty groups: <0.15, 0.15-<0.25, and >=0.25.",
  "Outcome-specific weights from Stages 05 and 07g were reused.",
  "No treatment effect and no treatment-by-frailty interaction was estimated.",
  "",
  "Categorical frailty audit:",
  categorical_lines,
  "",
  "Continuous frailty interaction audit:",
  continuous_lines,
  "",
  "Only categorical strata passing every frozen gate may receive a stratum-specific estimate.",
  "The continuous interaction is the main heterogeneity test; separate subgroup significance is not an interaction test."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07i_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07i_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message(
  "Stage 07i completed: ",
  normalizePath(output_dir, winslash = "/", mustWork = TRUE)
)
