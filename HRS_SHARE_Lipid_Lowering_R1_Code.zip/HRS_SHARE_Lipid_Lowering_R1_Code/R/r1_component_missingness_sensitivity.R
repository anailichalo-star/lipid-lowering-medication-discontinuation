# R1: component-specific standardization across eligible assessment windows.
# Optional functional and cardiovascular modes report mutually exclusive states.
# Read participant data only in local R and write cohort-level summaries.

args <- commandArgs(trailingOnly = TRUE)
project <- if (length(args)) args[[1L]] else getwd()
variant <- match.arg(
  if (length(args) >= 2L) args[[2L]] else "primary",
  c("primary", "functional", "cardiovascular")
)
functional <- variant == "functional"
state_decomposition <- variant != "primary"
source(file.path(project, "R", "_stage06_helpers.R"), local = TRUE)
root <- file.path(project, "outputs_r")
config <- yaml::read_yaml(file.path(project, "config_r", "primary_weight_model.yml"))
counts <- read.csv(file.path(root, "stage07a_outcome_audit", "07a_arm_outcome_counts.csv"))

# Columns give the unknown-versus-observed conditional odds multiplier by arm.
scenarios <- data.frame(
  label = c("Equal conditional odds", "Death odds doubled in both groups",
            "Death odds doubled in continuation only", "Death odds doubled in discontinuation only",
            "CVD odds doubled in continuation only", "CVD odds doubled in discontinuation only"),
  death_0 = c(1, 2, 2, 1, 1, 1),
  death_1 = c(1, 2, 1, 2, 1, 1),
  cvd_0 = c(1, 1, 1, 1, 2, 1),
  cvd_1 = c(1, 1, 1, 1, 1, 2)
)
scenarios$state <- "composite"
if (state_decomposition) {
  scenarios <- scenarios[rep(1L, 3L), ]
  scenarios$label <- if (functional) {
    c("Death or net ADL worsening", "Death", "Alive with net ADL worsening")
  } else {
    c("Death or new CVD", "Death", "Alive with new CVD")
  }
  scenarios$state <- c("composite", "death", "alive_nonfatal")
}

entry_key <- function(x) paste(x$person_id, x$trial_id, sep = "\r")

component_fit <- function(entries, outcome, model_terms, observed) {
  formula <- reformulate(model_terms, response = outcome)
  use <- entries[observed, , drop = FALSE]
  fit <- glm(
    formula, data = use, weights = survey_weight_scaled, na.action = na.fail,
    family = quasibinomial("logit"), control = glm.control(maxit = 100, epsilon = 1e-9)
  )
  stopifnot(isTRUE(fit$converged), all(is.finite(coef(fit))), max(abs(coef(fit))) < 20)
  design <- model.matrix(fit)
  observed_scores <- design * (fit$prior.weights * (model.response(model.frame(fit)) - fitted(fit)))
  scores <- matrix(0, nrow(entries), ncol(design))
  scores[observed, ] <- observed_scores
  bread <- tte_inverse_information(crossprod(design, design * fit$weights))
  influence <- rowsum(scores, group = entries$person_id, reorder = FALSE) %*% bread
  list(fit = fit, influence = influence)
}

score_arm <- function(predictions, components, entries, death_or, cvd_or, state) {
  q <- plogis(predictions[[1L]]$eta)
  d_known <- plogis(predictions[[2L]]$eta)
  c_known <- plogis(predictions[[3L]]$eta)
  d_unknown <- plogis(predictions[[2L]]$eta + log(death_or))
  c_unknown <- plogis(predictions[[3L]]$eta + log(cvd_or))

  count_death <- state %in% c("composite", "death")
  count_worsening <- state %in% c("composite", "alive_nonfatal")
  risk_known <- count_death * d_known + count_worsening * (1 - d_known) * c_known
  risk_unknown <- count_death * d_unknown + count_worsening * (1 - d_unknown) * c_unknown
  conditional_risk <- (1 - q) * risk_known + q * risk_unknown
  w <- entries$survey_weight_scaled / sum(entries$survey_weight_scaled)
  risk <- sum(w * conditional_risk)

  # Chain-rule gradients for all three fitted models. Cluster their scores
  # jointly because the component fits reuse people and landmark entries.
  derivatives <- list(
    q * (1 - q) * (risk_unknown - risk_known),
    (1 - q) * (count_death - count_worsening * c_known) * d_known * (1 - d_known) +
      q * (count_death - count_worsening * c_unknown) * d_unknown * (1 - d_unknown),
    count_worsening * ((1 - q) * (1 - d_known) * c_known * (1 - c_known) +
      q * (1 - d_unknown) * c_unknown * (1 - c_unknown))
  )
  fitted_influence <- lapply(seq_along(components), function(i) {
    gradient <- colSums(predictions[[i]]$design * (w * derivatives[[i]]))
    drop(components[[i]]$influence %*% gradient)
  })
  empirical_influence <- drop(rowsum(w * (conditional_risk - risk), entries$person_id, reorder = FALSE))
  list(risk = risk, influence = Reduce(`+`, fitted_influence) + empirical_influence)
}

fit_imputation <- function(entries, trials, trial_keys, cohort) {
  entries <- as.data.frame(entries)
  index <- match(entry_key(entries), trial_keys)
  stopifnot(nrow(entries) == nrow(trials), !anyNA(index), !anyDuplicated(index))
  trial_data <- trials[index, , drop = FALSE]
  entries$treatment <- as.integer(as.character(entries$treatment))
  stopifnot(all(entries$treatment == trial_data$treatment))

  death <- trial_data$death_in_interval == 1L
  alive <- !death & trial_data$F_interview_observed %in% 1L
  entries$vital_unknown <- as.integer(!(death | alive))
  entries$interval_death <- as.integer(death)
  if (functional) {
    entries$nonfatal_value <- as.integer(trial_data$F_adl5_count > trial_data$L_adl5_count)
  } else {
    entries$nonfatal_value <- as.integer(as.character(trial_data$nonfatal_broad))
  }
  component_observed <- alive & entries$nonfatal_value %in% 0:1
  if (functional) {
    reconstructed <- ifelse(death, 1L, ifelse(component_observed, entries$nonfatal_value, NA_integer_))
    stopifnot(identical(reconstructed, as.integer(as.character(trial_data$death_adl_decline))))
  }
  stopifnot(all(entries$primary_event[death] == 1L))
  for (arm in 0:1) {
    use <- entries$treatment == arm
    ref <- counts[counts$cohort == cohort & counts$treatment == arm, ]
    d <- ref[ref$outcome == "death_component", ]
    component_ref <- ref[ref$outcome == if (functional) "death_adl_decline" else "broad_nonfatal_survivor", ]
    n_death_in_reference <- if (functional) d$events else 0L
    stopifnot(
      sum(use) == d$eligible_person_trials,
      sum(death & use) == d$events, sum(alive & use) == d$non_events,
      sum(component_observed & use) == component_ref$outcome_observed_person_trials - n_death_in_reference,
      sum(entries$nonfatal_value[component_observed & use] == 1L) == component_ref$events - n_death_in_reference
    )
  }

  covariates <- c(config$continuous_covariates, config$categorical_covariates)
  model_terms <- vapply(covariates, function(variable) {
    if (variable %in% config$spline_covariates) {
      sprintf("splines::ns(%s, df = 3)", variable)
    } else {
      variable
    }
  }, character(1L), USE.NAMES = FALSE)
  model_terms <- c("treatment", config$always_adjust[[cohort]], model_terms)
  components <- list(
    component_fit(entries, "vital_unknown", model_terms, rep(TRUE, nrow(entries))),
    component_fit(entries, "interval_death", model_terms, death | alive),
    component_fit(entries, "nonfatal_value", model_terms, component_observed)
  )
  predictions <- lapply(0:1, function(arm) {
    new <- entries
    new$treatment <- arm
    lapply(components, function(component) {
      eta <- predict(component$fit, newdata = new, type = "link")
      design <- tte_prediction_design(component$fit, new)
      stopifnot(max(abs(eta - drop(design %*% coef(component$fit)))) < 1e-8)
      list(eta = eta, design = design)
    })
  })
  clusters <- length(unique(entries$person_id))
  df <- clusters - max(vapply(components, function(x) length(coef(x$fit)), integer(1L)))
  adjustment <- clusters / (clusters - 1)
  result <- lapply(seq_len(nrow(scenarios)), function(i) {
    s <- scenarios[i, ]
    a0 <- score_arm(predictions[[1L]], components, entries, s$death_0, s$cvd_0, s$state)
    a1 <- score_arm(predictions[[2L]], components, entries, s$death_1, s$cvd_1, s$state)
    influence <- cbind(
      a0$influence / (a0$risk * (1 - a0$risk)),
      a1$influence / (a1$risk * (1 - a1$risk)),
      a1$influence - a0$influence,
      a1$influence / a1$risk - a0$influence / a0$risk
    )
    list(
      estimate = c(qlogis(a0$risk), qlogis(a1$risk), a1$risk - a0$risk, log(a1$risk / a0$risk)),
      variance = colSums(influence^2) * adjustment,
      df = df
    )
  })
  if (state_decomposition) {
    arm_risks <- vapply(result, function(x) plogis(x$estimate[1:2]), numeric(2L))
    stopifnot(max(abs(arm_risks[, 1L] - arm_risks[, 2L] - arm_risks[, 3L])) < 1e-12)
  }
  result
}

compare_cohort <- function(cohort) {
  stem <- tolower(cohort)
  trials <- as.data.frame(readRDS(file.path(
    root, "stage04_structural_followup", "private_do_not_share",
    paste0(stem, "_structural_validated_trials_PRIVATE.rds")
  )))
  weight <- as.numeric(trials$L_survey_weight_final)
  trials <- trials[is.finite(weight) & weight > 0, , drop = FALSE]
  keys <- entry_key(trials)
  stopifnot(
    !anyDuplicated(keys), all(trials$death_in_interval %in% 0:1),
    all(is.na(trials$F_interview_observed) | trials$F_interview_observed %in% 0:1)
  )
  imputed <- readRDS(file.path(
    root, "stage05_weighting", "private_do_not_share",
    paste0(stem, "_weighted_imputations_PRIVATE.rds")
  ))
  stopifnot(length(imputed) == 20L)
  results <- lapply(imputed, fit_imputation, trials = trials, trial_keys = keys, cohort = cohort)
  transforms <- list(plogis, plogis, identity, exp)
  measures <- c("risk_continue", "risk_discontinue", "risk_difference", "risk_ratio")
  do.call(rbind, lapply(seq_len(nrow(scenarios)), function(i) {
    scenario <- lapply(results, `[[`, i)
    df <- min(vapply(scenario, function(x) x$df, numeric(1L)))
    do.call(rbind, lapply(seq_along(measures), function(j) {
      pooled <- tte_pool_scalar(
        vapply(scenario, function(x) x$estimate[j], numeric(1L)),
        vapply(scenario, function(x) x$variance[j], numeric(1L)), df
      )
      values <- transforms[[j]](c(pooled$estimate, pooled$lower, pooled$upper))
      data.frame(
        cohort = cohort, state = scenarios$state[i], label = scenarios$label[i],
        measure = measures[j], estimate = values[1L], confidence_lower = values[2L],
        confidence_upper = values[3L], p_value = if (j > 2L) pooled$p_value else NA_real_
      )
    }))
  }))
}

observed_component_counts <- function() {
  rows <- lapply(c("HRS", "SHARE"), function(cohort) {
    vapply(0:1, function(arm) {
      x <- counts[counts$cohort == cohort & counts$treatment == arm, ]
      outcomes <- c(
        "death_component", "broad_nonfatal_survivor",
        "strict_nonfatal_survivor", "death_adl_decline"
      )
      stopifnot(all(outcomes %in% x$outcome), !anyDuplicated(x$outcome))
      x <- x[match(outcomes, x$outcome), ]
      observed <- x$outcome_observed_person_trials
      events <- x$events
      stopifnot(observed[4L] >= events[1L], events[4L] >= events[1L])
      sprintf(
        "| %s | %s | %d/%d | %d/%d | %d/%d | %d/%d |",
        cohort, c("Continuation", "Discontinuation")[[arm + 1L]],
        events[1L], observed[1L], events[2L], observed[2L],
        events[3L], observed[3L], events[4L] - events[1L], observed[4L] - events[1L]
      )
    }, character(1L))
  })
  unlist(rows, use.names = FALSE)
}

pooled <- rbind(compare_cohort("HRS"), compare_cohort("SHARE"))
rows <- vapply(seq.int(1L, nrow(pooled), by = 4L), function(i) {
  x <- pooled[i + 0:3, ]
  sprintf(
    "| %s | %s | %.1f%% | %.1f%% | %.1f (%.1f to %.1f) | %.3f (%.3f to %.3f) |",
    x$cohort[1L], x$label[1L], 100 * x$estimate[1L], 100 * x$estimate[2L],
    1000 * x$estimate[3L], 1000 * x$confidence_lower[3L], 1000 * x$confidence_upper[3L],
    x$estimate[4L], x$confidence_lower[4L], x$confidence_upper[4L]
  )
}, character(1L))
output_dir <- file.path(root, "revision_r1")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output <- file.path(output_dir, switch(
  variant,
  functional = "R1_functional_outcomes_at_reassessment.md",
  cardiovascular = "R1_cardiovascular_components_at_reassessment.md",
  primary = "R1_primary_composite_component_missingness.md"
))
table_content <- if (functional) c(
  "# Death and net ADL worsening at reassessment", "",
  "| Cohort | Outcome | Continuation risk | Discontinuation risk | RD per 1,000 (95% CI) | RR (95% CI) |",
  "|---|---|---:|---:|---:|---:|",
  rows, "",
  "Net worsening was at least one additional difficulty in the five common activities of daily living (ADLs) at reassessment compared with the landmark. Death during the assessment window and being alive with net ADL worsening were mutually exclusive states, expressed as percentages of all eligible entries. Survey-weighted logistic models estimated death among entries with known vital status and net ADL worsening among known survivors with paired assessments. The models included medication group, the original adjustment variables and visit sequence, plus country in SHARE. The conditional models were applied to entries with missing vital status or ADL assessments under conditional outcome similarity. We used normalized survey weights to standardize to each cohort's eligible population across its assessment windows. Person-clustered influence functions were pooled across 20 imputations. The two states sum to the composite before pooling and rounding."
) else if (variant == "cardiovascular") c(
  "# Observed outcome components and standardized cardiovascular states", "",
  "## A. Observed component counts", "",
  "| Cohort | Medication group | Death among known vital status | New broad CVD among assessed survivors | New MI or stroke among assessed survivors | Net ADL worsening among survivors with paired ADLs |",
  "|---|---|---:|---:|---:|---:|",
  observed_component_counts(), "",
  "Counts are unweighted. Each denominator consists of entries with an ascertainable component. ADL denotes activities of daily living, CVD denotes cardiovascular disease, and MI denotes myocardial infarction.",
  "", "## B. Standardized cardiovascular states across assessment windows", "",
  "| Cohort | Outcome | Continuation risk | Discontinuation risk | RD per 1,000 (95% CI) | RR (95% CI) |",
  "|---|---|---:|---:|---:|---:|",
  rows, "",
  "Death during the assessment window and survival with a new CVD report were mutually exclusive states. Both probabilities were standardized to all eligible entries in the cohort, not to survivors alone. Estimation used the component-based equal conditional odds scenario, normalized survey weights, and person-clustered inference pooled over 20 imputations. The states sum to the composite before pooling and rounding. Nonfatal CVD was identified at follow-up interviews. Pre-death diagnoses and event ordering were not systematically ascertained."
) else c(
  "# Component-based missingness sensitivity for the primary composite", "",
  "| Cohort | Assumption for entries with unknown vital status | Continuation risk | Discontinuation risk | RD per 1,000 (95% CI) | RR (95% CI) |",
  "|---|---|---:|---:|---:|---:|",
  rows, "",
  "Risk is for all-cause death or a new report of broad cardiovascular disease in the cohort-specific assessment windows. We fitted survey-weighted logistic models for unknown vital status, death among known-status entries, and nonfatal cardiovascular disease among known survivors with usable responses. We used the prespecified covariate set and visit sequence, plus country in SHARE. A death fulfilled the composite without a nonfatal assessment. For unknown vital status, the conditional odds multiplier changed either the odds of death or the odds of nonfatal disease among those assumed to survive, relative to comparable observed entries. For known survivors with missing nonfatal assessments, we assumed conditional outcome similarity to assessed survivors. Predictions were standardized to the eligible cohort distribution using normalized survey weights. Confidence intervals used joint person-clustered influence functions for the component fits and empirical averaging and were pooled across 20 imputations. The assumed odds multipliers and normalized survey weights were treated as fixed. These risks summarize variable assessment windows."
)
writeLines(table_content, output, useBytes = TRUE)
write.csv(pooled, sub("\\.md$", "_pooled.csv", output), row.names = FALSE, na = "")
message("Reconciled component counts across the 20 imputations in both cohorts.")
message("Wrote ", output)
