# Run from the project root. Write aggregate checks without changing frozen outputs.
suppressPackageStartupMessages(library(data.table))

load_original_builder <- function() {
  source("R/_stage1_helpers.R", encoding = "UTF-8", local = TRUE)
  config <- tte_read_yaml_utf8("config_r/analysis.yml")
  sources <- tte_read_csv_utf8("config_r/cohort_sources.csv")
  project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
  data_root <- config$data_root
  builder <- new.env(parent = environment())
  required <- c("hrs_id", "share_id", "normalize_id", "binary_deficit",
                "ordinal_health_deficit", "strict_any_binary", "valid_range",
                "read_clean_components", "build_fi")
  for (expr in parse("R/04e_rebuild_frailty_validate_exposure.R")) {
    if (is.call(expr) && identical(expr[[1L]], quote(`<-`)) &&
        is.symbol(expr[[2L]]) && as.character(expr[[2L]]) %in% required) {
      eval(expr, envir = builder)
    }
  }
  stopifnot(all(required %in% ls(builder)))
  builder
}

compare_source_codes <- function(clean, cohort_name, builder) {
  hrs <- cohort_name == "HRS"
  id_column <- if (hrs) "hhidpn" else "mergeid"
  stubs <- c(if (hrs) "sight" else "nsight", "hearing", "shlt")
  gateway <- file.path("data_links/stage03c_inputs", if (hrs) "H_HRS_d.dta" else "H_SHARE_f2.dta")
  families <- list(Gateway = gateway)
  if (hrs) {
    families$RAND <- file.path("data_links", "stage03c_inputs", "randhrs1992_2020v2.dta")
  }
  lookup <- CJ(wave = sort(unique(clean$wave)), item = stubs)
  lookup[, `:=`(raw = paste0("r", wave, item), source = fifelse(hrs & item == "shlt", "RAND", "Gateway"))]
  audit <- rbindlist(lapply(names(families), function(family) {
    map <- lookup[source == family]
    file <- families[[family]]
    header <- names(haven::read_dta(file, n_max = 0L))
    raw_columns <- header[match(c(id_column, map$raw), tolower(header))]
    stopifnot(!anyNA(raw_columns))
    source_data <- as.data.table(haven::read_dta(file, col_select = tidyselect::all_of(raw_columns)))
    setnames(source_data, tolower(names(source_data)))
    ids <- builder$normalize_id(source_data[[id_column]], cohort_name)
    stopifnot(!anyDuplicated(ids))
    rbindlist(lapply(seq_len(nrow(map)), function(i) {
      m <- map[i]
      rows <- clean[wave == m$wave]
      index <- match(rows$person_id, ids)
      stopifnot(!anyNA(index))
      original <- as.numeric(source_data[[m$raw]][index])
      cleaned <- as.numeric(rows[[m$item]])
      paired <- !is.na(original) & !is.na(cleaned)
      informative <- paired & original %in% c(1:2, 4:6)
      labels <- attr(source_data[[m$raw]], "labels")
      data.table(cohort = cohort_name, wave = m$wave, item = m$item, source = family,
                 person_waves = nrow(rows), both_observed = sum(paired),
                 matches_cleaned_conversion = sum(6 - original[paired] == cleaned[paired]),
                 informative = sum(informative),
                 missingness_differences = sum(is.na(original) != is.na(cleaned)),
                 cleaned_zero = sum(cleaned %in% 0), cleaned_six = sum(cleaned %in% 6),
                 code_1_label = names(labels)[match(1, labels)],
                 code_5_label = names(labels)[match(5, labels)],
                 code_6_label = names(labels)[match(6, labels)])
    }))
  }))
  stopifnot(all(audit$matches_cleaned_conversion == audit$both_observed),
            all(audit$informative > 0),
            all(grepl("excellent", audit$code_1_label, ignore.case = TRUE)),
            all(grepl("poor", audit$code_5_label, ignore.case = TRUE)))
  audit
}

audit_cohort <- function(cohort_name) {
  if (.Platform$OS.type == "windows") {
    previous_locale <- Sys.getlocale("LC_CTYPE")
    on.exit(Sys.setlocale("LC_CTYPE", previous_locale), add = TRUE)
    invisible(Sys.setlocale("LC_CTYPE", ".UTF-8"))
  }
  builder <- load_original_builder()
  trials <- as.data.table(readRDS(file.path(
    "outputs_r/stage04_structural_followup/private_do_not_share",
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )))[is.finite(L_survey_weight_final) & L_survey_weight_final > 0]
  needed <- unique(rbindlist(lapply(c("E", "L"), function(role) {
    data.table(person_id = builder$normalize_id(trials$person_id, cohort_name),
               wave = as.integer(trials[[paste0(role, "_wave")]]))
  })))
  clean <- builder$read_clean_components(cohort_name)$data[needed, on = .(person_id, wave)]
  stopifnot(nrow(clean) == nrow(needed), !anyNA(clean$cohort))
  source_check <- compare_source_codes(clean, cohort_name, builder)
  original <- builder$build_fi(clean, cohort_name)
  same <- function(x, y) isTRUE(all.equal(as.numeric(x), as.numeric(y), tolerance = 1e-12))
  roles <- c(E = "FI_pre_treatment", L = "FI_landmark_sensitivity")
  summary <- rbindlist(lapply(names(roles), function(role) {
    keys <- data.table(person_id = builder$normalize_id(trials$person_id, cohort_name),
                       wave = as.integer(trials[[paste0(role, "_wave")]]))
    index <- original$fi[keys, on = .(person_id, wave), which = TRUE]
    fi <- original$fi$fi30_rebuilt[index]
    stopifnot(same(fi, trials[[roles[[role]]]]),
              same(clean$shlt[index], trials[[paste0(role, "_self_rated_health")]]))
    depression_flag <- builder$binary_deficit(clean$depressive[index])
    cesd <- builder$valid_range(clean$cesd[index], 0, 8)
    depression_conflicts <- if (cohort_name == "HRS") {
      sum(depression_flag != (cesd >= 3), na.rm = TRUE)
    } else NA_integer_
    data.table(cohort = cohort_name, role, person_trials = length(index), fi_observed = sum(!is.na(fi)),
               cognition_observed = sum(!is.na(original$items$cognition[index])),
               depression_observed = sum(!is.na(original$items$depression[index])),
               hrs_supplied_depression_flag_used = if (cohort_name == "HRS") sum(!is.na(depression_flag)) else NA_integer_,
               hrs_cesd_fallback_used = if (cohort_name == "HRS") sum(is.na(depression_flag) & !is.na(cesd)) else NA_integer_,
               hrs_flag_cesd_paired = if (cohort_name == "HRS") sum(!is.na(depression_flag) & !is.na(cesd)) else NA_integer_,
               hrs_flag_differs_from_cesd_ge3 = depression_conflicts)
  }))
  trials[, prior_health := as.numeric(E_self_rated_health)]
  trials[, landmark_health := as.numeric(L_self_rated_health)]
  stopifnot(same(trials$self_rated_health_worsened, as.integer(trials$landmark_health > trials$prior_health)))
  health_check <- trials[, .(cohort = cohort_name, complete_pairs = sum(!is.na(landmark_health - prior_health)),
                            classified_as_worse_by_current_code = sum(landmark_health > prior_health, na.rm = TRUE),
                            classified_as_worse_by_source_direction = sum(landmark_health < prior_health, na.rm = TRUE)),
                         by = treatment]
  list(source_codes = source_check, reproduction = summary, self_rated_health_direction = health_check)
}

results <- lapply(c("HRS", "SHARE"), audit_cohort)
output_dir <- "outputs_r/revision_r1"
for (part in names(results[[1L]])) {
  result <- rbindlist(lapply(results, `[[`, part))
  fwrite(result, file.path(output_dir, paste0("R1_frailty_", part, ".csv")))
  if (part != "source_codes") print(result)
}
print(rbindlist(lapply(results, `[[`, "source_codes"))[, .(
  observed_source_pairs = sum(both_observed), direction_disagreements = sum(both_observed - matches_cleaned_conversion),
  missingness_differences = sum(missingness_differences), cleaned_zero = sum(cleaned_zero)
), by = .(cohort, item)])
