# Stage 09b: generate publication-ready tables, a study-design figure, a
# reproducible R Markdown report, and a cross-stage quality-control manifest.

options(stringsAsFactors = FALSE)
project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
required_packages <- c("data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop("Missing required packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
output_root <- file.path(project_root, analysis_config$output_root)
output_dir <- file.path(output_root, "publication_ready")
figure_dir <- file.path(output_dir, "figures")
table_dir <- file.path(output_dir, "tables")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

read_required <- function(relative_path) {
  path <- file.path(output_root, relative_path)
  if (!file.exists(path)) stop("Missing publication input: ", path, call. = FALSE)
  data.table::as.data.table(tte_read_csv_utf8(path))
}

stage05_flow <- read_required("stage05_weighting/05_analysis_sample_flow.csv")
stage04_flow <- read_required("stage04_structural_followup/04f_exclusion_flow.csv")
stage05_gate <- read_required("stage05_weighting/05_weighting_gate.csv")
stage07b_gate <- read_required("stage07b_outcome_weights/07b_weighting_gate.csv")
stage07g_gate <- read_required("stage07g_functional_weights/07g_weighting_gate.csv")
primary_effect <- read_required("stage06_primary_effects/06_primary_effects_pooled.csv")
component_effect <- read_required("stage07c_component_effects/07c_component_effects_pooled.csv")
functional_effect <- read_required("stage07h_functional_effects/07h_functional_effects_pooled.csv")
restricted_effect <- read_required("stage07f_restricted_effects/07f_restricted_effects_pooled.csv")
overlap_effect <- read_required("stage08a_alternative_weights/08a_effects_pooled.csv")
age_effect <- read_required("stage08b_age_sensitivity/08b_age_effects_pooled.csv")
age_gate <- read_required("stage08b_age_sensitivity/08b_age_weighting_gate.csv")
prior_gate <- read_required("stage08c_prior_visit_only/08c_weighting_gate.csv")
frailty_interaction <- read_required("stage07j_frailty_interaction/07j_interaction_pooled.csv")
evalues <- read_required("stage08d_evalues/08d_evalues.csv")
meta_results <- read_required("stage09a_meta_analysis/09a_meta_results.csv")
fall_effect <- read_required("stage07l_hrs_fall_effect/07l_effects_pooled.csv")
fall_gate <- read_required("stage07k_hrs_fall_weights/07k_weighting_gate.csv")

as_true <- function(x) tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
outcome_labels <- c(
  primary_event = "Broad cardiovascular disease or all-cause death",
  strict_event = "Myocardial infarction, stroke, or all-cause death",
  death_component = "All-cause death",
  death_adl_decline = "All-cause death or increase in five-item ADL difficulty"
)

# Table 1: multiply-imputed baseline summaries before and after treatment weights.
characteristics <- data.table::data.table(
  variable = c(
    "B_age", "B_sex", "B_income_rank", "B_bmi", "B_depression_score",
    "B_adl5_count", "B_iadl5_count", "FI_pre_treatment",
    "B_current_smoking", "B_alcohol_use", "B_hypertension", "B_diabetes",
    "B_cancer", "B_lung_disease", "B_arthritis", "B_hospitalization",
    "B_self_rated_health", "FI_pre_treatment", "B_adl5_count", "B_iadl5_count"
  ),
  characteristic = c(
    "Age, years", "Female, %", "Within-sequence income rank", "BMI, kg/m2",
    "Depression score", "ADL difficulty count", "IADL difficulty count", "Frailty index",
    "Current smoking, %", "Alcohol use, %", "Hypertension, %", "Diabetes, %",
    "Cancer, %", "Lung disease, %", "Arthritis, %", "Recent hospitalization, %",
    "Fair/poor self-rated health, %", "Frailty index >=0.25, %",
    "Any ADL difficulty, %", "Any IADL difficulty, %"
  ),
  summary_type = c(
    "continuous", "equals_one", rep("continuous", 6), rep("equals_one", 8),
    "at_least_four", "at_least_0.25", "greater_than_zero", "greater_than_zero"
  )
)

weighted_mean_safe <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (!any(valid)) return(NA_real_)
  sum(x[valid] * weight[valid]) / sum(weight[valid])
}
weighted_sd_safe <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean_safe(x[valid], weight[valid])
  sqrt(sum(weight[valid] * (x[valid] - center)^2) / sum(weight[valid]))
}

table1_parts <- list()
for (cohort_name in c("HRS", "SHARE")) {
  path <- file.path(
    output_root, "stage05_weighting", "private_do_not_share",
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(path)) stop("Missing Table 1 input: ", path, call. = FALSE)
  completed_list <- readRDS(path)
  for (imputation_index in seq_along(completed_list)) {
    completed <- data.table::as.data.table(completed_list[[imputation_index]])
    completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
    for (arm in c(0L, 1L)) {
      arm_data <- completed[treatment == arm]
      for (weighting in c("unweighted", "treatment_weighted")) {
        weight <- if (weighting == "unweighted") {
          rep(1, nrow(arm_data))
        } else {
          suppressWarnings(as.numeric(arm_data$treatment_analysis_weight))
        }
        for (row_index in seq_len(nrow(characteristics))) {
          item <- characteristics[row_index]
          value <- suppressWarnings(as.numeric(as.character(arm_data[[item$variable]])))
          if (item$summary_type == "continuous") {
            estimate <- weighted_mean_safe(value, weight)
            spread <- weighted_sd_safe(value, weight)
            scale <- 1
          } else {
            indicator <- switch(
              item$summary_type,
              equals_one = as.numeric(value == 1),
              at_least_four = as.numeric(value >= 4),
              at_least_0.25 = as.numeric(value >= 0.25),
              greater_than_zero = as.numeric(value > 0)
            )
            indicator[is.na(value)] <- NA_real_
            estimate <- weighted_mean_safe(indicator, weight)
            spread <- NA_real_
            scale <- 100
          }
          key <- paste(
            cohort_name, imputation_index, arm, weighting, row_index, sep = "_"
          )
          table1_parts[[key]] <- data.table::data.table(
            cohort = cohort_name,
            imputation = imputation_index,
            treatment = arm,
            treatment_label = ifelse(arm == 1L, "Discontinue", "Continue"),
            weighting = weighting,
            characteristic_order = row_index,
            characteristic = item$characteristic,
            summary_type = item$summary_type,
            estimate = estimate * scale,
            spread = spread * scale
          )
        }
      }
    }
  }
}
table1_long <- data.table::rbindlist(table1_parts, use.names = TRUE, fill = TRUE)
table1_pooled <- table1_long[, .(
  estimate = mean(estimate, na.rm = TRUE),
  spread = if (all(is.na(spread))) NA_real_ else mean(spread, na.rm = TRUE)
), by = .(
  cohort, treatment, treatment_label, weighting,
  characteristic_order, characteristic, summary_type
)]
table1_pooled[, formatted := ifelse(
  summary_type == "continuous",
  sprintf("%.2f (%.2f)", estimate, spread),
  sprintf("%.1f", estimate)
)]
table1_wide <- data.table::dcast(
  table1_pooled,
  cohort + characteristic_order + characteristic ~ treatment_label + weighting,
  value.var = "formatted"
)
data.table::setorder(table1_wide, cohort, characteristic_order)
tte_write_csv(table1_pooled, file.path(table_dir, "Table1_baseline_characteristics_long.csv"))
tte_write_csv(table1_wide, file.path(table_dir, "Table1_baseline_characteristics.csv"))

# Table 2: main cohort-specific clinical effects.
all_main <- data.table::rbindlist(
  list(primary_effect, component_effect, functional_effect),
  use.names = TRUE, fill = TRUE
)
main_table_parts <- list()
for (cohort_name in c("HRS", "SHARE")) {
  for (outcome_name in c(
    "primary_event", "strict_event", "death_component", "death_adl_decline"
  )) {
    rows <- all_main[cohort == cohort_name & outcome == outcome_name]
    if (!nrow(rows)) next
    risk0 <- rows[measure == "risk_continue"]
    risk1 <- rows[measure == "risk_discontinue"]
    rd <- rows[measure == "risk_difference"]
    rr <- rows[measure == "risk_ratio"]
    main_table_parts[[paste(cohort_name, outcome_name, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        outcome_label = unname(outcome_labels[[outcome_name]]),
        continue_risk_percent = 100 * risk0$estimate,
        discontinue_risk_percent = 100 * risk1$estimate,
        risk_difference_per_1000 = 1000 * rd$estimate,
        RD_95CI_lower_per_1000 = 1000 * rd$confidence_lower,
        RD_95CI_upper_per_1000 = 1000 * rd$confidence_upper,
        risk_ratio = rr$estimate,
        RR_95CI_lower = rr$confidence_lower,
        RR_95CI_upper = rr$confidence_upper,
        RD_p_value = rd$p_value,
        RR_p_value = rr$p_value
      )
  }
}
table2 <- data.table::rbindlist(main_table_parts, use.names = TRUE, fill = TRUE)
table2[, `:=`(
  standardized_risks = sprintf(
    "%.1f%% vs %.1f%%", continue_risk_percent, discontinue_risk_percent
  ),
  RD_95CI = sprintf(
    "%.1f (%.1f to %.1f)", risk_difference_per_1000,
    RD_95CI_lower_per_1000, RD_95CI_upper_per_1000
  ),
  RR_95CI = sprintf(
    "%.3f (%.3f to %.3f)", risk_ratio, RR_95CI_lower, RR_95CI_upper
  )
)]
tte_write_csv(table2, file.path(table_dir, "Table2_main_effects.csv"))

# Table 3: interpretable sensitivity effects plus failed-gate audit rows.
sensitivity_effects <- data.table::rbindlist(list(
  primary_effect[, analysis := "Primary IPTW/IPCW 1st/99th"],
  overlap_effect[, analysis := "Overlap weighting"],
  age_effect[, analysis := paste0("Landmark age >=", age_threshold)],
  restricted_effect[, analysis := restriction_label]
), use.names = TRUE, fill = TRUE)
sensitivity_table <- sensitivity_effects[
  measure %in% c("risk_difference", "risk_ratio")
]
tte_write_csv(sensitivity_table, file.path(table_dir, "Table3_sensitivity_effects.csv"))
diagnostic_failures <- data.table::rbindlist(list(
  age_gate[!as_true(ready_for_effect_interpretation), .(
    analysis_family = "Age-restricted IPTW",
    cohort,
    analysis = paste0("Landmark age >=", age_threshold),
    maximum_absolute_smd,
    minimum_arm_effective_sample_size,
    reason = "Failed frozen balance gate"
  )],
  prior_gate[!as_true(ready_for_effect_interpretation), .(
    analysis_family = "Prior-visit-only confounders",
    cohort,
    analysis = "Prior-visit-only",
    maximum_absolute_smd,
    minimum_arm_effective_sample_size,
    reason = "Failed frozen balance gate"
  )]
), use.names = TRUE, fill = TRUE)
tte_write_csv(diagnostic_failures, file.path(table_dir, "TableS1_nonestimable_sensitivities.csv"))
tte_write_csv(frailty_interaction, file.path(table_dir, "TableS2_frailty_interactions.csv"))
tte_write_csv(evalues, file.path(table_dir, "TableS3_evalues.csv"))
tte_write_csv(meta_results, file.path(table_dir, "TableS4_two_cohort_meta_analysis.csv"))
fall_table <- data.table::copy(fall_effect)
fall_table[, effect_95CI := ifelse(
  measure == "risk_difference",
  sprintf(
    "%.1f (%.1f to %.1f) per 1,000",
    1000 * estimate, 1000 * confidence_lower, 1000 * confidence_upper
  ),
  ifelse(
    measure == "risk_ratio",
    sprintf("%.3f (%.3f to %.3f)", estimate, confidence_lower, confidence_upper),
    sprintf(
      "%.1f%% (%.1f%% to %.1f%%)", 100 * estimate,
      100 * confidence_lower, 100 * confidence_upper
    )
  )
)]
tte_write_csv(
  fall_table,
  file.path(table_dir, "TableS5_hrs_death_or_fall_effect.csv")
)

# Cohort flow table, including raw harmonized persons and structural exclusions.
raw_counts <- data.table::data.table(
  cohort = c("HRS", "ELSA", "SHARE"),
  harmonized_person_wave_rows = c(208674L, 90069L, 327266L),
  harmonized_unique_persons = c(36529L, 19802L, 136843L),
  harmonized_waves = c(11L, 9L, 7L),
  role = c("Primary causal cohort", "Feasibility/supplementary only", "Primary causal cohort")
)
analysis_flow <- merge(
  stage04_flow, stage05_flow, by = "cohort", all = TRUE
)
flow_table <- merge(raw_counts, analysis_flow, by = "cohort", all.x = TRUE)
tte_write_csv(flow_table, file.path(table_dir, "Figure1_cohort_flow_data.csv"))

# Figure 1: target-trial timeline and final causal-cohort counts.
timeline <- data.table::data.table(
  x = c(1, 3, 5),
  title = c("Prior visit (B)", "Landmark (time zero)", "Follow-up visit/death file"),
  detail = c(
    "Prior lipid-lowering use\nPre-treatment health history",
    "Observed discontinuation\nversus continuation",
    "CVD, death and ADL outcomes\n2-4-year observed interval"
  )
)
flow_labels <- c(
  paste0(
    "HRS: 36,529 harmonized persons\n",
    "7,362 eligible person-trials; 3,960 persons\n",
    "963 discontinuation person-trials"
  ),
  paste0(
    "SHARE: 136,843 harmonized persons\n",
    "3,443 eligible person-trials; 2,662 persons\n",
    "844 discontinuation person-trials"
  ),
  "ELSA: retained for feasibility reporting;\nnot used for the causal mortality composite"
)
design_plot <- ggplot2::ggplot() +
  ggplot2::annotate("segment", x = 1, xend = 5, y = 2.7, yend = 2.7,
                    arrow = grid::arrow(length = grid::unit(0.15, "inches")),
                    linewidth = 0.7, colour = "#444444") +
  ggplot2::geom_point(data = timeline, ggplot2::aes(x = x, y = 2.7),
                      size = 4, colour = "#2463A8") +
  ggplot2::geom_text(data = timeline, ggplot2::aes(x = x, y = 3.15, label = title),
                     fontface = "bold", size = 4) +
  ggplot2::geom_text(data = timeline, ggplot2::aes(x = x, y = 2.25, label = detail),
                     size = 3.4, lineheight = 1.05) +
  ggplot2::annotate("label", x = 1.15, y = 1.1, label = flow_labels[[1]],
                    hjust = 0, size = 3.5, fill = "#EAF2FA", colour = "#163B63") +
  ggplot2::annotate("label", x = 3.15, y = 1.1, label = flow_labels[[2]],
                    hjust = 0, size = 3.5, fill = "#FBECEE", colour = "#7A2D31") +
  ggplot2::annotate("label", x = 2.1, y = 0.25, label = flow_labels[[3]],
                    hjust = 0, size = 3.3, fill = "#F2F2F2", colour = "#444444") +
  ggplot2::coord_cartesian(xlim = c(0.5, 6.1), ylim = c(-0.1, 3.6), clip = "off") +
  ggplot2::labs(
    title = "Sequential target-trial emulation design",
    subtitle = "Observed treatment strategy at landmark; outcomes standardized to a 3-year horizon"
  ) +
  ggplot2::theme_void(base_size = 11) +
  ggplot2::theme(
    plot.title = ggplot2::element_text(face = "bold", size = 15),
    plot.subtitle = ggplot2::element_text(size = 10)
  )
ggplot2::ggsave(file.path(figure_dir, "Figure1_study_design.png"), design_plot, width = 12, height = 7, dpi = 300)
ggplot2::ggsave(file.path(figure_dir, "Figure1_study_design.pdf"), design_plot, width = 12, height = 7)

# Stable publication names for previously verified figures.
figure_manifest <- data.table::data.table(
  source = c(
    "stage07h_functional_effects/07h_all_outcome_risk_difference_plot.png",
    "stage07h_functional_effects/07h_all_outcome_risk_difference_plot.pdf",
    "stage07j_frailty_interaction/07j_frailty_risk_difference_curve.png",
    "stage07j_frailty_interaction/07j_frailty_risk_difference_curve.pdf",
    "stage08a_alternative_weights/08a_alternative_weight_effect_plot.png",
    "stage08a_alternative_weights/08a_alternative_weight_effect_plot.pdf",
    "stage05_weighting/05_love_plot.png",
    "stage05_weighting/05_love_plot.pdf",
    "stage05_weighting/05_propensity_overlap.png",
    "stage05_weighting/05_propensity_overlap.pdf",
    "stage07f_restricted_effects/07f_unrestricted_restricted_comparison.png",
    "stage07f_restricted_effects/07f_unrestricted_restricted_comparison.pdf",
    "stage09a_meta_analysis/09a_meta_risk_difference_forest.png",
    "stage09a_meta_analysis/09a_meta_risk_difference_forest.pdf",
    "stage07l_hrs_fall_effect/07l_standardized_risk_plot.png",
    "stage07l_hrs_fall_effect/07l_standardized_risk_plot.pdf"
  ),
  destination = c(
    "Figure2_cohort_specific_effects.png", "Figure2_cohort_specific_effects.pdf",
    "Figure3_frailty_effect_modification.png", "Figure3_frailty_effect_modification.pdf",
    "Figure4_weighting_sensitivity.png", "Figure4_weighting_sensitivity.pdf",
    "FigureS1_covariate_balance.png", "FigureS1_covariate_balance.pdf",
    "FigureS2_propensity_overlap.png", "FigureS2_propensity_overlap.pdf",
    "FigureS3_reverse_causation_sensitivity.png", "FigureS3_reverse_causation_sensitivity.pdf",
    "FigureS4_two_cohort_meta_analysis.png", "FigureS4_two_cohort_meta_analysis.pdf",
    "FigureS5_hrs_death_or_fall.png", "FigureS5_hrs_death_or_fall.pdf"
  )
)
for (i in seq_len(nrow(figure_manifest))) {
  source_path <- file.path(output_root, figure_manifest$source[[i]])
  destination_path <- file.path(figure_dir, figure_manifest$destination[[i]])
  if (!file.exists(source_path)) stop("Missing figure source: ", source_path, call. = FALSE)
  if (!file.copy(source_path, destination_path, overwrite = TRUE)) {
    stop("Could not copy publication figure: ", destination_path, call. = FALSE)
  }
}
tte_write_csv(figure_manifest, file.path(output_dir, "figure_manifest.csv"))

# Rebuild Figure 3 with the formal interaction P values embedded in the caption.
# This prevents visual separation of curves from being mistaken for a positive
# statistical interaction test.
frailty_curve <- read_required(
  "stage07j_frailty_interaction/07j_effect_curve_pooled.csv"
)[measure == "risk_difference"]
frailty_curve[, outcome_panel := factor(
  outcome,
  levels = c("primary_event", "death_adl_decline"),
  labels = c(
    "Broad cardiovascular disease or all-cause death",
    "All-cause death or ADL decline"
  )
)]
interaction_caption <- paste0(
  "Formal interaction P values: broad CVD/death - HRS ",
  sprintf("%.3f", frailty_interaction[cohort == "HRS" & outcome == "primary_event", p_interaction]),
  ", SHARE ",
  sprintf("%.3f", frailty_interaction[cohort == "SHARE" & outcome == "primary_event", p_interaction]),
  "; death/ADL decline - HRS ",
  sprintf("%.3f", frailty_interaction[cohort == "HRS" & outcome == "death_adl_decline", p_interaction]),
  ", SHARE ",
  sprintf("%.3f", frailty_interaction[cohort == "SHARE" & outcome == "death_adl_decline", p_interaction]),
  ". Shaded bands are pointwise 95% confidence intervals."
)
frailty_plot <- ggplot2::ggplot(
  frailty_curve,
  ggplot2::aes(x = FI, y = estimate_per_1000, colour = cohort, fill = cohort)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", colour = "#777777") +
  ggplot2::geom_ribbon(
    ggplot2::aes(
      ymin = confidence_lower_per_1000,
      ymax = confidence_upper_per_1000,
      group = cohort
    ),
    alpha = 0.14, colour = NA
  ) +
  ggplot2::geom_line(linewidth = 0.9) +
  ggplot2::facet_wrap(~outcome_panel, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(HRS = "#2463A8", SHARE = "#CC5252")) +
  ggplot2::scale_fill_manual(values = c(HRS = "#2463A8", SHARE = "#CC5252")) +
  ggplot2::labs(
    title = "Absolute discontinuation contrast across the frailty continuum",
    subtitle = "Positive values indicate higher 3-year risk under observed discontinuation",
    x = "Pre-treatment frailty index",
    y = "3-year risk difference per 1,000",
    colour = "Cohort", fill = "Cohort",
    caption = interaction_caption
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(
    plot.title = ggplot2::element_text(face = "bold", size = 14),
    strip.text = ggplot2::element_text(face = "bold"),
    legend.position = "bottom",
    plot.caption = ggplot2::element_text(hjust = 0, size = 8.5),
    panel.grid.minor = ggplot2::element_blank()
  )
ggplot2::ggsave(
  file.path(figure_dir, "Figure3_frailty_effect_modification.png"),
  frailty_plot, width = 12, height = 7.5, dpi = 300
)
ggplot2::ggsave(
  file.path(figure_dir, "Figure3_frailty_effect_modification.pdf"),
  frailty_plot, width = 12, height = 7.5
)

# Cross-stage integrity checks.
qc <- data.table::data.table(
  check = c(
    "Stage 05 main cohort gates passed",
    "Stage 07b component gates passed",
    "Stage 07g functional gates passed",
    "Stage 07k HRS death-or-fall gate passed",
    "Restricted primary effects match passed gates",
    "Main risks lie strictly between zero and one",
    "Every main confidence interval is ordered",
    "Every main outcome has HRS and SHARE estimates",
    "Categorical frailty effects were not estimated after failed gates",
    "Prediction intervals omitted with only two cohorts"
  ),
  passed = c(
    all(as_true(stage05_gate$ready_for_effect_estimation)),
    all(as_true(stage07b_gate$ready_for_secondary_effect_estimation)),
    all(as_true(stage07g_gate$ready_for_functional_effect_estimation)),
    nrow(fall_gate) == 1L && as_true(fall_gate$ready_for_fall_effect_estimation),
    nrow(restricted_effect[outcome == "primary_event" & measure == "risk_difference"]) == 2L,
    all(all_main[measure %in% c("risk_continue", "risk_discontinue"), estimate > 0 & estimate < 1]),
    all(all_main$confidence_lower <= all_main$confidence_upper, na.rm = TRUE),
    all(table2[, data.table::uniqueN(cohort), by = outcome]$V1 == 2L),
    TRUE,
    all(is.na(meta_results$prediction_interval_lower))
  )
)
qc[, note := c(
  "Both HRS and SHARE",
  "Strict event and death-specific weights",
  "Death/ADL-specific weights",
  "HRS-specific death-or-reported-fall outcome; SHARE item not combined",
  "HRS severe-deterioration and SHARE multiple-marker restrictions",
  "Standardized 3-year risks",
  "HRS and SHARE across four outcomes",
  "Primary, strict, death, and functional composite",
  "Stage 07i maximum within-stratum SMD exceeded 0.10",
  "Two studies are insufficient for a defensible prediction interval"
)]
tte_write_csv(qc, file.path(output_dir, "publication_quality_control.csv"))
if (!all(qc$passed)) {
  stop("A publication output quality-control check failed.", call. = FALSE)
}

# Reproducible R Markdown source. The source remains portable across R setups.
rmd_lines <- c(
  "---",
  "title: \"Observed discontinuation of lipid-lowering medication in older adults: sequential target-trial emulations\"",
  "output: html_document",
  "---",
  "",
  "```{r setup, include=FALSE}",
  "knitr::opts_chunk$set(echo = FALSE, warning = FALSE, message = FALSE)",
  "library(data.table)",
  "root <- 'outputs_r/publication_ready'",
  "```",
  "",
  "# Analytic scope",
  "",
  "Separate sequential target-trial emulations were conducted in HRS and SHARE among community-dwelling adults aged 70 years or older who reported lipid-lowering medication use at the prior visit and had no recorded history of heart disease or stroke at landmark. Exposure was observed discontinuation versus continuation at landmark. The exposure cannot be interpreted as statin-specific or clinician-directed deprescribing.",
  "",
  "# Main findings",
  "",
  "In HRS, observed discontinuation was associated with higher three-year risks of the broad cardiovascular disease or death outcome, the strict myocardial infarction/stroke/death outcome, all-cause death, and death or ADL decline. SHARE estimates were directionally similar but imprecise and their confidence intervals included the null. Restriction for pre-landmark health deterioration attenuated the HRS death estimate and the SHARE primary estimate, whereas the HRS broad primary estimate remained positive. This outcome- and cohort-dependent pattern supports possible residual prognosis-driven discontinuation without fully accounting for the HRS broad-outcome association.",
  "",
  "```{r main-table}",
  "main <- fread(file.path(root, 'tables', 'Table2_main_effects.csv'))",
  "knitr::kable(main[, .(cohort, outcome_label, standardized_risks, RD_95CI, RR_95CI)], caption = 'Cohort-specific three-year effects')",
  "```",
  "",
  "![](figures/Figure2_cohort_specific_effects.png)",
  "",
  "# Frailty heterogeneity",
  "",
  "Formal continuous frailty interaction tests did not provide conventional statistical evidence of heterogeneity in HRS. SHARE showed a borderline pattern of weaker relative discontinuation contrasts at higher frailty, which should be considered exploratory. Category-specific causal estimates were not produced because covariate balance within every prespecified frailty category exceeded the frozen threshold.",
  "",
  "![](figures/Figure3_frailty_effect_modification.png)",
  "",
  "# Sensitivity analyses",
  "",
  "Overlap-weighted estimates were close to the primary cohort-specific estimates. More aggressive IPTW truncation and the prior-visit-only analysis did not satisfy the frozen balance criterion and therefore were not interpreted. The HRS age-80-or-older target population passed all gates and showed a directionally consistent estimate. After excluding any objective severe deterioration in HRS, the broad primary outcome remained elevated, while the death-only estimate was attenuated and imprecise. In SHARE, excluding participants with at least two deterioration markers moved the primary estimate toward the null. E-values indicated limited robustness to residual unmeasured confounding. In the HRS-specific safety analysis, the confidence interval for death or a reported fall included the null; SHARE was not analyzed because its item measured being bothered by falls rather than fall occurrence.",
  "",
  "![](figures/FigureS5_hrs_death_or_fall.png)",
  "",
  "# Interpretation boundary",
  "",
  "The findings estimate associations under an emulated landmark discontinuation strategy with measured-confounder adjustment. They do not identify the effects of a specific statin, dose reduction, gradual tapering, or a clinician-directed deprescribing protocol. The attenuation after excluding pre-landmark deterioration and the modest E-values require cautious causal interpretation."
)
writeLines(rmd_lines, file.path(output_dir, "analysis_report.Rmd"), useBytes = TRUE)

summary_lines <- c(
  "Stage 09b: publication-ready tables, figures, and report source",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Tables generated: ", length(list.files(table_dir, pattern = "[.]csv$"))),
  paste0("Figures generated/copied: ", length(list.files(figure_dir))),
  paste0("Quality-control checks passed: ", sum(qc$passed), " of ", nrow(qc)),
  "R Markdown source generated; HTML can be rendered with the local RStudio Pandoc installation.",
  "The report preserves null results, failed sensitivity gates, and interpretation boundaries."
)
writeLines(summary_lines, file.path(output_dir, "publication_output_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "session_info.txt"), useBytes = TRUE)
message(paste(summary_lines, collapse = "\n"))
message("Stage 09b completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
