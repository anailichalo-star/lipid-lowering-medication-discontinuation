# Run from the project root. Writes aggregate diagnostics and frozen estimates.
suppressPackageStartupMessages(library(data.table))
source("R/_weighting_sensitivity_helpers.R")

config <- yaml::read_yaml("config_r/primary_weight_model.yml")
covariates <- c(config$continuous_covariates, config$categorical_covariates)
bands <- c("<0.10", "0.10 to <0.15", "0.15 to <0.20", "0.20 to <0.25",
           "0.25 to <0.30", "0.30 to <0.35", "0.35 to <0.40", ">=0.40")
breaks <- c(-Inf, seq(10, 40, by = 5) / 100, Inf)
outcomes <- c("primary_event", "death_adl_decline")
outcome_labels <- c("Cardiovascular disease or death", "Death or ADL worsening")

band_diagnostics <- function(data, weight_column) {
  stopifnot(setequal(data$treatment, 0:1), all(is.finite(data$propensity_score)))
  ranges <- vapply(0:1, function(arm) range(data$propensity_score[data$treatment == arm]),
                   numeric(2L))
  overlap <- mean(data$propensity_score >= max(ranges[1L, ]) &
                    data$propensity_score <= min(ranges[2L, ]))
  observed <- data[is.finite(get(weight_column)) & get(weight_column) > 0]
  observed_n <- tabulate(observed$treatment + 1L, nbins = 2L)
  stopifnot(all(observed_n >= 2L))
  ess <- observed[, tte_sensitivity_ess(get(weight_column)), by = treatment]$V1
  balance <- tte_sensitivity_balance(observed, weight_column, covariates,
                                     config$categorical_covariates)
  stopifnot(all(is.finite(balance$absolute_standardized_difference)))
  worst <- balance[which.max(absolute_standardized_difference)]
  list(eligible_continue = sum(data$treatment == 0L),
       eligible_discontinue = sum(data$treatment == 1L),
       observed_continue = observed_n[1L], observed_discontinue = observed_n[2L],
       overlap = overlap, ess = min(ess), smd = worst$absolute_standardized_difference,
       variable = worst$variable)
}

by_imputation <- rbindlist(lapply(c("HRS", "SHARE"), function(cohort) {
  prefix <- tolower(cohort)
  primary <- readRDS(file.path(
    "outputs_r/stage05_weighting/private_do_not_share",
    paste0(prefix, "_weighted_imputations_PRIVATE.rds")
  ))
  functional <- readRDS(file.path(
    "outputs_r/stage07g_functional_weights/private_do_not_share",
    paste0(prefix, "_functional_weights_PRIVATE.rds")
  ))
  stopifnot(length(primary) == 20L, length(functional) == 20L)
  rbindlist(lapply(seq_along(primary), function(i) {
    data <- as.data.table(copy(primary[[i]]))
    adl <- as.data.table(functional[[i]])
    id <- paste(data$person_id, data$trial_id, sep = "\r")
    adl_id <- paste(adl$person_id, adl$trial_id, sep = "\r")
    index <- match(id, adl_id)
    stopifnot(!anyDuplicated(id), !anyDuplicated(adl_id), !anyNA(index), length(id) == length(adl_id))
    data[, `:=`(
      treatment = as.integer(as.character(treatment)),
      functional_weight = adl$total_weight_specific[index],
      FI_band = cut(FI_pre_treatment, breaks = breaks, labels = bands, right = FALSE)
    )]
    stopifnot(!anyNA(data$FI_band),
              all((is.finite(data$total_weight) & data$total_weight > 0) ==
                    (data$outcome_observed == 1L)),
              all((is.finite(data$functional_weight) & data$functional_weight > 0) ==
                    (adl$outcome_observed_specific[index] == 1L)))
    weight_columns <- c("total_weight", "functional_weight")
    rbindlist(lapply(seq_along(outcomes), function(o) {
      result <- data[, band_diagnostics(.SD, weight_columns[o]), by = FI_band]
      stopifnot(nrow(result) == length(bands),
                sum(result$eligible_continue + result$eligible_discontinue) == nrow(data),
                sum(result$observed_continue + result$observed_discontinue) ==
                  sum(is.finite(data[[weight_columns[o]]]) & data[[weight_columns[o]]] > 0))
      result[, `:=`(cohort = cohort, outcome = outcomes[o], imputation = i)]
    }))
  }))
}))

format_count <- function(x) {
  counts <- range(x)
  if (counts[1L] == counts[2L]) as.character(counts[1L]) else paste(counts, collapse = "-")
}

diagnostics <- by_imputation[, {
  stopifnot(.N == 20L)
  worst <- which.max(smd)
  .(eligible_continue = format_count(eligible_continue), eligible_discontinue = format_count(eligible_discontinue),
    observed_continue = format_count(observed_continue), observed_discontinue = format_count(observed_discontinue),
    min_overlap = min(overlap), min_ess = min(ess), max_smd = smd[worst],
    largest_imbalance = variable[worst])
}, by = .(cohort, outcome, FI_band)]
setorder(diagnostics, cohort, outcome, FI_band)

interactions <- fread("outputs_r/stage07j_frailty_interaction/07j_interaction_pooled.csv")
stopifnot(nrow(interactions) == 4L, all(interactions$imputations == 20L))
labels <- setNames(c(
  "Age", "Income rank", "Body mass index", "Depressive symptoms", "ADL difficulty count",
  "Instrumental ADL difficulty count", "Frailty index", "Sex", "Education", "Marital status",
  "Living arrangement", "Self-rated health", "Current smoking", "Alcohol use", "Hypertension",
  "Diabetes", "Cancer", "Lung disease", "Arthritis", "Hospitalization"
), covariates)
stopifnot(length(labels) == length(covariates), all(diagnostics$largest_imbalance %in% names(labels)))

output <- c("# Exploratory frailty analysis", "", "## A. Sample size, overlap, and balance by frailty index", "")
for (o in seq_along(outcomes)) {
  rows <- diagnostics[outcome == outcomes[o]]
  output <- c(
    output, paste0("### ", outcome_labels[o]), "",
    "| Cohort | Frailty index | Eligible, C / D | Observed, C / D | Minimum overlap, % | Minimum arm ESS | Maximum abs. SMD | Largest imbalance |",
    "|:--|:--|--:|--:|--:|--:|--:|:--|",
    with(rows, sprintf("| %s | %s | %s / %s | %s / %s | %.1f | %.1f | %.3f | %s |",
      cohort, FI_band, eligible_continue, eligible_discontinue, observed_continue,
      observed_discontinue, 100 * min_overlap, min_ess, max_smd, labels[largest_imbalance])), ""
  )
}
output <- c(
  output,
  "C, continuation; D, discontinuation; ESS, effective sample size; SMD, standardized mean difference. Within each band, overlap is the fraction of eligible entries in the intersection of the observed propensity-score ranges in the two groups. Balance and ESS use outcome-observed entries with the combined survey, treatment, and outcome-observation weights from the corresponding original outcome analysis. SMDs cover the 20 common covariates; categorical levels are assessed separately. Minima, maxima, and variable count ranges are taken across the 20 imputations. These bands were used for diagnostics.",
  "", "## B. Linear interaction tests from the original 3-year models", "",
  "| Cohort | Outcome | Ratio of modeled cumulative-hazard ratios per 0.10 higher FI (95% CI) | P for interaction |",
  "|:--|:--|--:|--:|",
  with(interactions, sprintf("| %s | %s | %.2f (%.2f to %.2f) | %.3f |",
    cohort, outcome_labels[match(outcome, outcomes)], cloglog_contrast_ratio_per_0_10_FI,
    confidence_lower, confidence_upper, p_interaction)),
  "",
  "These tests concern the linear medication-status-by-frailty term on the complementary log-log scale. At each plotted frailty index value, the original curves held frailty fixed at that value for every eligible entry and averaged predicted risks over the survey-weighted cohort distribution of sequences and, in SHARE, countries. The pointwise intervals describe the model-based absolute risk contrasts. The ADL interaction used the original 3-year model, separate from the revised outcome analysis at reassessment."
)
destination <- "outputs_r/revision_r1/R1_exploratory_frailty_diagnostics.md"
writeLines(output, destination)
message("Frailty diagnostics written to ", destination)
