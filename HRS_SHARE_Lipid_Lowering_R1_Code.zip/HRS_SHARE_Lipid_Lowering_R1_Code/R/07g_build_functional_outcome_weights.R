# Stage 07g: rebuild outcome-observation weights for the three-year
# all-cause-death-or-ADL-decline outcome. No treatment effect is estimated.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8", local = TRUE
)
source(
  file.path(project_root, "R", "_stage07e_helpers.R"),
  encoding = "UTF-8", local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
primary_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "primary_weight_model.yml")
)
functional_config_path <- file.path(
  project_root, "config_r", "functional_outcome_weight_model.yml"
)
functional_config <- tte_read_yaml_utf8(functional_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_dir <- file.path(
  project_root, analysis_config$output_root, "stage05_weighting"
)
stage05_private <- file.path(stage05_dir, "private_do_not_share")
output_dir <- file.path(
  project_root, analysis_config$output_root, "stage07g_functional_weights"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
outcome_name <- as.character(functional_config$outcome$name)
continuous_covariates <- unlist(
  primary_config$continuous_covariates, use.names = FALSE
)
categorical_covariates <- unlist(
  primary_config$categorical_covariates, use.names = FALSE
)
primary_covariates <- c(continuous_covariates, categorical_covariates)
spline_covariates <- unlist(
  primary_config$spline_covariates, use.names = FALSE
)
variable_manifest <- data.table::data.table(
  variable_group = "primary_covariate",
  variable = primary_covariates,
  variable_type = ifelse(
    primary_covariates %in% categorical_covariates,
    "categorical", "continuous"
  )
)

probability_floor <- as.numeric(functional_config$probability_floor)
lower_quantile <- as.numeric(functional_config$weight_lower_quantile)
upper_quantile <- as.numeric(functional_config$weight_upper_quantile)
minimum_retention_probability <- as.numeric(
  functional_config$minimum_acceptable_retention_probability
)
maximum_low_retention_fraction <- as.numeric(
  functional_config$maximum_fraction_retention_below_0_05
)

stage05_gate_path <- file.path(stage05_dir, "05_weighting_gate.csv")
if (!file.exists(stage05_gate_path)) {
  stop("Missing Stage 05 gate file: ", stage05_gate_path, call. = FALSE)
}
stage05_gate <- data.table::as.data.table(
  tte_read_csv_utf8(stage05_gate_path)
)
ready_column <- intersect(
  c("ready_for_effect_estimation", "all_gates_pass"),
  names(stage05_gate)
)
if (length(ready_column) != 1L) {
  stop("Could not identify the Stage 05 final gate column.", call. = FALSE)
}
stage05_rows <- stage05_gate[cohort %in% cohorts]
if (!setequal(as.character(stage05_rows$cohort), cohorts) ||
    nrow(stage05_rows) != length(cohorts) ||
    !all(as_logical_value(stage05_rows[[ready_column]]))) {
  stop("Both cohorts must pass Stage 05 before Stage 07g.", call. = FALSE)
}

to_binary_07g <- function(x, variable_name, cohort_name) {
  value <- suppressWarnings(as.integer(as.character(x)))
  if (any(!is.na(value) & !value %in% c(0L, 1L))) {
    stop(
      cohort_name, ": ", variable_name,
      " contains values outside 0/1/NA.", call. = FALSE
    )
  }
  value
}

sample_parts <- list()
sequence_parts <- list()
logic_parts <- list()
join_parts <- list()
model_parts <- list()
retention_parts <- list()
weight_parts <- list()
ess_parts <- list()
balance_parts <- list()
plot_weight_parts <- list()

for (cohort_name in cohorts) {
  stage04_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(stage04_path)) {
    stop("Missing Stage 04f trial file: ", stage04_path, call. = FALSE)
  }
  if (!file.exists(stage05_path)) {
    stop("Missing Stage 05 imputation file: ", stage05_path, call. = FALSE)
  }

  source_trials <- data.table::as.data.table(readRDS(stage04_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  required_source <- c(
    "person_id", "trial_id", "sequence", "treatment",
    "F_interview_observed", "death_in_interval",
    "L_adl5_count", "F_adl5_count", outcome_name
  )
  missing_source <- setdiff(required_source, names(source_trials))
  if (length(missing_source)) {
    stop(
      cohort_name, " source trials lack: ",
      paste(missing_source, collapse = ", "), call. = FALSE
    )
  }
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate Stage 04f person-trial key.", call. = FALSE)
  }
  source_trials[, treatment := to_binary_07g(
    treatment, "treatment", cohort_name
  )]
  source_trials[, F_interview_observed := to_binary_07g(
    F_interview_observed, "F_interview_observed", cohort_name
  )]
  source_trials[, death_in_interval := to_binary_07g(
    death_in_interval, "death_in_interval", cohort_name
  )]
  source_trials[, outcome_value := to_binary_07g(
    get(outcome_name), outcome_name, cohort_name
  )]
  source_trials[, expected_adl_outcome := data.table::fcase(
    death_in_interval == 1L, 1L,
    death_in_interval == 0L & F_interview_observed == 1L &
      !is.na(L_adl5_count) & !is.na(F_adl5_count),
    as.integer(F_adl5_count >= L_adl5_count + 1),
    default = NA_integer_
  )]
  source_trials[, logic_agreement :=
    (is.na(outcome_value) & is.na(expected_adl_outcome)) |
      (!is.na(outcome_value) & !is.na(expected_adl_outcome) &
         outcome_value == expected_adl_outcome)]
  logic_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    check = c(
      "binary_outcome", "all_recorded_deaths_are_events",
      "death_or_observed_adl_rule", "no_outcome_after_unobserved_followup_without_death"
    ),
    failed_rows = c(
      sum(!is.na(source_trials$outcome_value) &
            !source_trials$outcome_value %in% c(0L, 1L)),
      sum(source_trials$death_in_interval == 1L &
            source_trials$outcome_value != 1L, na.rm = TRUE),
      sum(!source_trials$logic_agreement),
      sum(source_trials$death_in_interval == 0L &
            source_trials$F_interview_observed == 0L &
            !is.na(source_trials$outcome_value), na.rm = TRUE)
    )
  )
  if (any(logic_parts[[cohort_name]]$failed_rows > 0L)) {
    stop(cohort_name, ": functional outcome logic check failed.", call. = FALSE)
  }

  sample_table <- source_trials[, .(
    treatment, person_id, sequence, outcome_value
  )]
  sample_parts[[cohort_name]] <- sample_table[, .(
    eligible_person_trials = .N,
    unique_persons = data.table::uniqueN(person_id),
    observed_person_trials = sum(!is.na(outcome_value)),
    observation_fraction = mean(!is.na(outcome_value)),
    events = sum(outcome_value == 1L, na.rm = TRUE),
    non_events = sum(outcome_value == 0L, na.rm = TRUE)
  ), by = treatment][, `:=`(
    cohort = cohort_name,
    outcome = outcome_name,
    treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
  )]
  sequence_parts[[cohort_name]] <- sample_table[, .(
    eligible_person_trials = .N,
    observed_person_trials = sum(!is.na(outcome_value)),
    observation_fraction = mean(!is.na(outcome_value)),
    events = sum(outcome_value == 1L, na.rm = TRUE)
  ), by = .(sequence, treatment)][, `:=`(
    cohort = cohort_name,
    outcome = outcome_name,
    treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
  )]

  imputations <- readRDS(stage05_path)
  if (!is.list(imputations) || length(imputations) != 20L) {
    stop(cohort_name, ": Stage 05 must contain 20 imputations.", call. = FALSE)
  }
  compact_imputations <- vector("list", length(imputations))

  for (imputation_index in seq_along(imputations)) {
    completed <- data.table::as.data.table(
      data.table::copy(imputations[[imputation_index]])
    )
    required_completed <- c(
      "analysis_row_id", "person_id", "trial_id", "treatment", "sequence",
      "survey_weight_scaled", "treatment_weight", primary_covariates
    )
    if (cohort_name == "SHARE") {
      required_completed <- c(required_completed, "B_country")
    }
    missing_completed <- setdiff(required_completed, names(completed))
    if (length(missing_completed)) {
      stop(
        cohort_name, " imputation ", imputation_index, " lacks: ",
        paste(missing_completed, collapse = ", "), call. = FALSE
      )
    }
    completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    index <- match(completed$join_key, source_trials$join_key)
    exact_identity <- !anyNA(index) && nrow(completed) == nrow(source_trials) &&
      !anyDuplicated(completed$join_key) &&
      all(as.integer(as.character(completed$treatment)) ==
            source_trials$treatment[index])
    join_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        stage05_rows = nrow(completed),
        matched_stage04_rows = sum(!is.na(index)),
        exact_person_trial_treatment_identity = exact_identity
      )
    if (!exact_identity) {
      stop(
        cohort_name, ": Stage 04f-to-Stage 05 identity check failed in imputation ",
        imputation_index, ".", call. = FALSE
      )
    }

    completed[, outcome_value := source_trials$outcome_value[index]]
    completed[, outcome_observed_specific := as.integer(!is.na(outcome_value))]
    completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
    for (variable_name in continuous_covariates) {
      data.table::set(
        completed, j = variable_name,
        value = plain_numeric(completed[[variable_name]])
      )
    }
    for (variable_name in categorical_covariates) {
      data.table::set(
        completed, j = variable_name,
        value = droplevels(factor(completed[[variable_name]]))
      )
    }
    completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      completed[, B_country := droplevels(factor(B_country))]
    }
    residual_missing <- vapply(
      primary_covariates,
      function(variable_name) anyNA(completed[[variable_name]]),
      logical(1L)
    )
    if (any(residual_missing)) {
      stop(
        cohort_name, " imputation ", imputation_index,
        " retains missing primary covariates: ",
        paste(names(residual_missing)[residual_missing], collapse = ", "),
        call. = FALSE
      )
    }

    fixed_candidates <- unlist(
      primary_config$always_adjust[[cohort_name]], use.names = FALSE
    )
    usable_primary <- usable_model_variables(completed, primary_covariates)
    usable_fixed <- usable_model_variables(completed, fixed_candidates)
    full_terms <- c(
      vapply(
        usable_primary, model_term_07e, character(1L),
        spline_covariates = spline_covariates
      ),
      usable_fixed
    )
    denominator_formula <- make_formula_07e(
      "outcome_observed_specific", c("treatment", full_terms)
    )
    numerator_formula <- make_formula_07e(
      "outcome_observed_specific", c("treatment", usable_fixed)
    )
    denominator_fit <- fit_binary_model_07e(
      denominator_formula, completed,
      "censoring", "censoring_denominator",
      cohort_name, "unrestricted_functional", outcome_name, imputation_index
    )
    numerator_fit <- fit_binary_model_07e(
      numerator_formula, completed,
      "censoring", "censoring_numerator",
      cohort_name, "unrestricted_functional", outcome_name, imputation_index
    )
    model_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::rbindlist(
        list(denominator_fit$diagnostics, numerator_fit$diagnostics),
        use.names = TRUE, fill = TRUE
      )

    completed[, retention_probability_specific := clamp_probability(
      stats::predict(denominator_fit$fit, newdata = completed, type = "response"),
      probability_floor
    )]
    completed[, numerator_retention_probability_specific := clamp_probability(
      stats::predict(numerator_fit$fit, newdata = completed, type = "response"),
      probability_floor
    )]
    completed[, censoring_weight_specific := ifelse(
      outcome_observed_specific == 1L,
      numerator_retention_probability_specific /
        retention_probability_specific,
      NA_real_
    )]
    completed[, total_weight_specific_raw := ifelse(
      outcome_observed_specific == 1L,
      survey_weight_scaled * treatment_weight * censoring_weight_specific,
      NA_real_
    )]
    weight_lower <- safe_quantile(
      completed$total_weight_specific_raw, lower_quantile
    )
    weight_upper <- safe_quantile(
      completed$total_weight_specific_raw, upper_quantile
    )
    if (!is.finite(weight_lower) || !is.finite(weight_upper) ||
        weight_lower <= 0 || weight_upper < weight_lower) {
      stop(
        cohort_name, ": invalid functional weight bounds in imputation ",
        imputation_index, call. = FALSE
      )
    }
    completed[, total_weight_specific := ifelse(
      outcome_observed_specific == 1L,
      pmax(weight_lower, pmin(weight_upper, total_weight_specific_raw)),
      NA_real_
    )]

    retention_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        minimum_retention_probability = min(
          completed$retention_probability_specific
        ),
        maximum_retention_probability = max(
          completed$retention_probability_specific
        ),
        fraction_retention_probability_below_0_05 = mean(
          completed$retention_probability_specific < 0.05
        ),
        any_retention_probability_below_0_01 = any(
          completed$retention_probability_specific <
            minimum_retention_probability
        )
      )

    observed <- completed[
      outcome_observed_specific == 1L &
        is.finite(total_weight_specific) & total_weight_specific > 0
    ]
    if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
      stop(
        cohort_name, ": invalid observed functional sample in imputation ",
        imputation_index, call. = FALSE
      )
    }
    observed[, unit_weight := 1]
    weight_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      observed[, .(
        observed_person_trials = .N,
        raw_weight_minimum = min(total_weight_specific_raw),
        raw_weight_p01 = safe_quantile(total_weight_specific_raw, 0.01),
        raw_weight_median = safe_quantile(total_weight_specific_raw, 0.50),
        raw_weight_p99 = safe_quantile(total_weight_specific_raw, 0.99),
        raw_weight_maximum = max(total_weight_specific_raw),
        truncated_weight_minimum = min(total_weight_specific),
        truncated_weight_median = safe_quantile(total_weight_specific, 0.50),
        truncated_weight_maximum = max(total_weight_specific)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]
    ess_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      observed[, .(
        effective_sample_size = effective_sample_size(total_weight_specific)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index
      )]
    balance_parts[[paste(cohort_name, imputation_index, "u", sep = "_")]] <-
      calculate_balance_07e(
        observed, "unit_weight", "outcome_observed_unweighted",
        cohort_name, "unrestricted_functional", outcome_name,
        imputation_index, variable_manifest
      )
    balance_parts[[paste(cohort_name, imputation_index, "w", sep = "_")]] <-
      calculate_balance_07e(
        observed, "total_weight_specific", "after_functional_total_weight",
        cohort_name, "unrestricted_functional", outcome_name,
        imputation_index, variable_manifest
      )
    if (imputation_index == 1L) {
      plot_weight_parts[[cohort_name]] <- observed[, .(
        cohort = cohort_name,
        treatment_label = ifelse(treatment == 1L, "Discontinue", "Continue"),
        total_weight_specific
      )]
    }

    compact_imputations[[imputation_index]] <- completed[, .(
      analysis_row_id,
      person_id,
      trial_id,
      join_key,
      treatment,
      sequence = as.character(sequence),
      B_country = if ("B_country" %in% names(completed)) {
        as.character(B_country)
      } else {
        NA_character_
      },
      outcome_value,
      outcome_observed_specific,
      retention_probability_specific,
      numerator_retention_probability_specific,
      censoring_weight_specific,
      total_weight_specific_raw,
      total_weight_specific
    )]
  }

  saveRDS(
    compact_imputations,
    file.path(
      private_dir,
      paste0(tolower(cohort_name), "_functional_weights_PRIVATE.rds")
    ),
    version = 3L
  )
}

sample_counts <- data.table::rbindlist(
  sample_parts, use.names = TRUE, fill = TRUE
)
sequence_counts <- data.table::rbindlist(
  sequence_parts, use.names = TRUE, fill = TRUE
)
logic_checks <- data.table::rbindlist(
  logic_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(
  join_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_parts, use.names = TRUE, fill = TRUE
)
retention <- data.table::rbindlist(
  retention_parts, use.names = TRUE, fill = TRUE
)
weight_distribution <- data.table::rbindlist(
  weight_parts, use.names = TRUE, fill = TRUE
)
ess <- data.table::rbindlist(
  ess_parts, use.names = TRUE, fill = TRUE
)
balance <- data.table::rbindlist(
  balance_parts, use.names = TRUE, fill = TRUE
)
plot_weights <- data.table::rbindlist(
  plot_weight_parts, use.names = TRUE, fill = TRUE
)

balance_summary <- balance[, .(
  imputations = data.table::uniqueN(imputation),
  minimum_observed_fraction = min(
    minimum_arm_observed_fraction, na.rm = TRUE
  ),
  mean_standardized_difference = mean(
    standardized_difference, na.rm = TRUE
  ),
  maximum_absolute_smd = max(
    absolute_standardized_difference, na.rm = TRUE
  )
), by = .(
  cohort, outcome, balance_sample,
  variable_group, variable, level
)]

event_gate <- sample_counts[, .(
  both_arms_present = data.table::uniqueN(treatment) == 2L,
  smaller_arm_observed_person_trials = min(observed_person_trials),
  smaller_arm_events = min(events),
  total_events = sum(events)
), by = .(cohort, outcome)]
balance_gate <- balance[
  balance_sample == "after_functional_total_weight",
  .(maximum_absolute_smd = max(
    absolute_standardized_difference, na.rm = TRUE
  )),
  by = .(cohort, outcome)
]
ess_gate <- ess[, .(
  minimum_arm_effective_sample_size = min(effective_sample_size)
), by = .(cohort, outcome)]
model_gate <- model_diagnostics[, .(
  all_models_converged = all(converged),
  total_model_warnings = sum(warning_n),
  maximum_aliased_coefficients = max(aliased_coefficient_n),
  any_separation_or_convergence_warning = any(
    separation_or_convergence_warning
  )
), by = .(cohort, outcome)]
retention_gate <- retention[, .(
  minimum_retention_probability = min(minimum_retention_probability),
  maximum_fraction_retention_below_0_05 = max(
    fraction_retention_probability_below_0_05
  ),
  any_retention_probability_below_0_01 = any(
    any_retention_probability_below_0_01
  )
), by = .(cohort, outcome)]
support_gate <- stage05_rows[, .(
  cohort,
  primary_treatment_common_support_fraction = suppressWarnings(
    as.numeric(minimum_common_support_fraction)
  )
)]
gate <- Reduce(
  function(left, right) merge(
    left, right, by = c("cohort", "outcome"), all = TRUE, sort = FALSE
  ),
  list(event_gate, balance_gate, ess_gate, model_gate, retention_gate)
)
gate <- merge(gate, support_gate, by = "cohort", all.x = TRUE, sort = FALSE)
gate[, pass_smaller_arm_n := smaller_arm_observed_person_trials >=
  as.numeric(analysis_config$data_gates$minimum_smaller_arm_person_trials)]
gate[, pass_smaller_arm_events := smaller_arm_events >=
  as.numeric(analysis_config$data_gates$minimum_smaller_arm_primary_events)]
gate[, pass_total_events := total_events >=
  as.numeric(analysis_config$data_gates$minimum_total_primary_events)]
gate[, pass_balance := maximum_absolute_smd <
  as.numeric(analysis_config$data_gates$maximum_absolute_standardized_difference)]
gate[, pass_effective_sample_size := minimum_arm_effective_sample_size >=
  as.numeric(analysis_config$data_gates$minimum_weighted_effective_sample_size)]
gate[, pass_common_support := primary_treatment_common_support_fraction >=
  as.numeric(analysis_config$data_gates$minimum_common_support_fraction)]
gate[, pass_model_identifiability :=
  all_models_converged & total_model_warnings == 0L &
    maximum_aliased_coefficients == 0L &
    !any_separation_or_convergence_warning]
gate[, pass_retention_positivity :=
  maximum_fraction_retention_below_0_05 <= maximum_low_retention_fraction &
    !any_retention_probability_below_0_01]
gate[, ready_for_functional_effect_estimation :=
  both_arms_present & pass_smaller_arm_n & pass_smaller_arm_events &
    pass_total_events & pass_balance & pass_effective_sample_size &
    pass_common_support & pass_model_identifiability &
    pass_retention_positivity]

data.table::setorder(sample_counts, cohort, treatment)
data.table::setorder(sequence_counts, cohort, sequence, treatment)
data.table::setorder(logic_checks, cohort, check)
data.table::setorder(join_checks, cohort, imputation)
data.table::setorder(model_diagnostics, cohort, imputation, model)
data.table::setorder(retention, cohort, imputation)
data.table::setorder(weight_distribution, cohort, imputation, treatment)
data.table::setorder(ess, cohort, imputation, treatment)
data.table::setorder(
  balance, cohort, balance_sample, variable, level, imputation
)
data.table::setorder(
  balance_summary, cohort, balance_sample, variable, level
)
data.table::setorder(gate, cohort)

tte_write_csv(sample_counts, file.path(output_dir, "07g_analysis_sample.csv"))
tte_write_csv(
  sequence_counts,
  file.path(output_dir, "07g_sequence_arm_event_counts.csv")
)
tte_write_csv(
  logic_checks,
  file.path(output_dir, "07g_outcome_logic_checks.csv")
)
tte_write_csv(join_checks, file.path(output_dir, "07g_join_checks.csv"))
tte_write_csv(
  model_diagnostics,
  file.path(output_dir, "07g_censoring_model_diagnostics.csv")
)
tte_write_csv(
  retention,
  file.path(output_dir, "07g_retention_diagnostics.csv")
)
tte_write_csv(
  weight_distribution,
  file.path(output_dir, "07g_weight_distribution.csv")
)
tte_write_csv(
  ess,
  file.path(output_dir, "07g_effective_sample_size.csv")
)
tte_write_csv(
  balance,
  file.path(output_dir, "07g_balance_all_imputations.csv")
)
tte_write_csv(
  balance_summary,
  file.path(output_dir, "07g_balance_summary.csv")
)
tte_write_csv(gate, file.path(output_dir, "07g_weighting_gate.csv"))
writeLines(
  readLines(functional_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07g_frozen_functional_weight_model.yml"),
  useBytes = TRUE
)

balance_plot_data <- balance_summary[
  is.finite(maximum_absolute_smd)
]
balance_plot_data[, display_variable := ifelse(
  is.na(level) | level == "", variable, paste0(variable, "=", level)
)]
balance_plot_data[, balance_sample := factor(
  balance_sample,
  levels = c(
    "outcome_observed_unweighted", "after_functional_total_weight"
  ),
  labels = c("Unweighted observed", "Functional-outcome weighted")
)]
balance_plot <- ggplot2::ggplot(
  balance_plot_data,
  ggplot2::aes(
    x = maximum_absolute_smd,
    y = stats::reorder(display_variable, maximum_absolute_smd),
    colour = balance_sample,
    shape = balance_sample
  )
) +
  ggplot2::geom_vline(xintercept = 0.10, linetype = 2, colour = "#B2182B") +
  ggplot2::geom_point(size = 1.7, alpha = 0.85) +
  ggplot2::facet_wrap(~cohort, scales = "free_y") +
  ggplot2::labs(
    x = "Maximum absolute standardized difference across imputations",
    y = NULL,
    colour = NULL,
    shape = NULL,
    title = "Balance for death-or-ADL-decline weighted samples"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(
    legend.position = "bottom",
    axis.text.y = ggplot2::element_text(size = 6.5)
  )

weight_plot <- ggplot2::ggplot(
  plot_weights,
  ggplot2::aes(
    x = treatment_label, y = total_weight_specific,
    fill = treatment_label
  )
) +
  ggplot2::geom_boxplot(outlier.shape = NA, width = 0.65) +
  ggplot2::scale_y_log10() +
  ggplot2::facet_wrap(~cohort, scales = "free_y") +
  ggplot2::scale_fill_manual(values = c(
    "Continue" = "#2463A8", "Discontinue" = "#C44E52"
  )) +
  ggplot2::labs(
    x = NULL,
    y = "Truncated total weight (log scale)",
    fill = NULL,
    title = "Death-or-ADL-decline weight distributions",
    subtitle = "First imputed dataset; displayed without row identifiers"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

ggplot2::ggsave(
  file.path(output_dir, "07g_balance_plot.png"),
  balance_plot, width = 12, height = 8.5, dpi = 220, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "07g_balance_plot.pdf"),
  balance_plot, width = 12, height = 8.5, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "07g_weight_distribution.png"),
  weight_plot, width = 9, height = 5.5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07g_weight_distribution.pdf"),
  weight_plot, width = 9, height = 5.5
)

gate_lines <- apply(gate, 1L, function(row) {
  paste0(
    row[["cohort"]], "/", row[["outcome"]],
    ": max |SMD|=", sprintf("%.3f", as.numeric(row[["maximum_absolute_smd"]])),
    ", min arm ESS=", sprintf(
      "%.1f", as.numeric(row[["minimum_arm_effective_sample_size"]])
    ),
    ", support=", sprintf(
      "%.3f", as.numeric(row[["primary_treatment_common_support_fraction"]])
    ),
    ", smaller-arm events=", row[["smaller_arm_events"]],
    ", total events=", row[["total_events"]],
    ", ready=", row[["ready_for_functional_effect_estimation"]]
  )
})
summary_lines <- c(
  "Stage 07g: death-or-ADL-decline outcome-specific weighting diagnostics",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Outcome: ", functional_config$outcome$label, "."),
  "Death was counted without requiring a completed follow-up interview.",
  "Among survivors, ADL decline required an observed follow-up interview and valid landmark/follow-up ADL5 counts.",
  "Twenty frozen Stage 05 imputed covariate datasets and treatment weights were reused.",
  "Outcome-observation models and censoring weights were rebuilt for this functional outcome.",
  "Combined weights were truncated at the 1st and 99th percentiles.",
  "No treatment effect was estimated in this stage.",
  "",
  gate_lines,
  "",
  "Proceed to functional effect estimation only for cohorts with ready=TRUE."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07g_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07g_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message(
  "Stage 07g completed: ",
  normalizePath(output_dir, winslash = "/", mustWork = TRUE)
)
