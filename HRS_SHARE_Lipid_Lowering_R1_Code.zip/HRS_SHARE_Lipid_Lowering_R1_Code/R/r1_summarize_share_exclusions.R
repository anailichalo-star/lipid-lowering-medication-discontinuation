# Run from the project root. Uses the frozen aggregate flow and exclusion tables.
suppressPackageStartupMessages(library(data.table))

stage04 <- "outputs_r/stage04_structural_followup"
excluded <- fread(file.path(stage04, "04f_excluded_country_sequences.csv"))[cohort == "SHARE"]
rules <- fread(file.path(stage04, "04f_expanded_rule_application.csv"))[
  structural_followup_eligible == FALSE, .(F_wave, B_country = country_code)
]
structural <- fread(file.path(stage04, "04f_exclusion_flow.csv"))[cohort == "SHARE"]
final <- fread("outputs_r/stage05_weighting/05_analysis_sample_flow.csv")[cohort == "SHARE"]
stopifnot(!anyDuplicated(excluded, by = c("sequence", "B_country")),
          nrow(excluded[!rules, on = .(F_wave, B_country)]) == 0L,
          nrow(rules[!excluded, on = .(F_wave, B_country)]) == 0L,
          sum(excluded$excluded_person_trials) == structural$structurally_excluded_person_trials,
          structural$input_person_trials - structural$structurally_excluded_person_trials ==
            structural$retained_person_trials,
          structural$retained_person_trials == final$initial_person_trials,
          final$initial_person_trials - final$excluded_nonpositive_or_missing_survey_weight ==
            final$analysis_person_trials)

# SHARE Release Guide 9.0.0, country identifier table.
countries <- c(`11` = "Austria", `12` = "Germany", `13` = "Sweden", `14` = "Netherlands",
               `15` = "Spain", `16` = "Italy", `17` = "France", `18` = "Denmark",
               `19` = "Greece", `20` = "Switzerland", `23` = "Belgium", `25` = "Israel",
               `28` = "Czech Republic", `31` = "Luxembourg", `34` = "Slovenia")
reasons <- c(`4` = "No regular Wave 4 survey in Greece.",
             `6` = "Separate Dutch mixed-mode study in Wave 6.",
             `7` = "Wave 7 routed respondents to different interview types.")
stopifnot(all(excluded$B_country %in% names(countries)),
          all(excluded$F_wave %in% names(reasons)))
excluded[, `:=`(
  country = unname(countries[as.character(B_country)]),
  wave_sequence = gsub("_", "-", sub("^SHARE_", "", sequence), fixed = TRUE),
  reason = unname(reasons[as.character(F_wave)])
)]
setorder(excluded, F_wave, country)
by_wave <- excluded[, .(country_sequences = .N, excluded_entries = sum(excluded_person_trials)),
                    by = .(F_wave, wave_sequence)]
stopifnot(identical(by_wave$F_wave, c(4L, 6L, 7L)),
          identical(by_wave$excluded_entries, c(25L, 69L, 2018L)))

output <- c(
  "# SHARE exclusions by country and scheduled follow-up wave", "",
  "| Wave sequence | Follow-up wave | Country | Excluded entries | Reason |",
  "|:--|--:|:--|--:|:--|",
  with(excluded, sprintf("| %s | %d | %s | %s | %s |", wave_sequence, F_wave, country,
                         formatC(excluded_person_trials, format = "d", big.mark = ","), reason)),
  sprintf("| **Total** | | | **%s** | |",
          formatC(structural$structurally_excluded_person_trials, format = "d", big.mark = ",")),
  "", "Wave sequences list the preceding, landmark, and scheduled follow-up waves. SHARE Wave 7 assigned some respondents to a life-history interview and others to the regular panel interview according to prior SHARELIFE participation. We excluded Wave 7 as the outcome-assessment visit across countries because current-health ascertainment was not uniform. Wave 7 could contribute preceding or landmark visits when the required items were observed.",
  "", sprintf("The structural rules removed %s of %s candidate SHARE entries. Of the %s retained entries, %d were later excluded because survey weights were missing or nonpositive, leaving %s for analysis.",
               formatC(structural$structurally_excluded_person_trials, format = "d", big.mark = ","),
               formatC(structural$input_person_trials, format = "d", big.mark = ","),
               formatC(structural$retained_person_trials, format = "d", big.mark = ","),
               final$excluded_nonpositive_or_missing_survey_weight,
               formatC(final$analysis_person_trials, format = "d", big.mark = ",")),
  "", "Design documentation. [SHARE Release Guide 9.0.0](https://www.share-eric.eu/fileadmin/user_upload/Release_Guides/SHARE_release_guide_9-0-0.pdf), [wave participation](https://share-eric.eu/data/data-documentation/waves-overview/), [Dutch Wave 6 mixed-mode experiment](https://share-eric.eu/data/data-set-details/dutch-mixed-mode-experiment-w6-1), [Wave 7 questionnaire routing](https://share-eric.eu/news-events/news-details/share-wave-7-data-is-now-available)."
)
destination <- "outputs_r/revision_r1/R1_share_country_wave_exclusions.md"
writeLines(output, destination)
message("Reconciled ", sum(by_wave$excluded_entries), " exclusions across ", nrow(excluded),
        " country-sequence combinations.")
