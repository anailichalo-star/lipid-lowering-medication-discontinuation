# Stage 07f: estimate three-year effects only for restriction-specific
# cohort-outcome combinations that passed every frozen Stage 07e gate.
# Failed combinations remain explicitly documented and are not modelled.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8", local = TRUE
)
source(
  file.path(project_root, "R", "_stage06_helpers.R"),
  encoding = "UTF-8", local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
effect_config_path <- file.path(
  project_root, "config_r", "restricted_sensitivity_effect_model.yml"
)
effect_config <- tte_read_yaml_utf8(effect_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage07c_dir <- file.path(
  project_root, analysis_config$output_root, "stage07c_component_effects"
)
restriction_root <- getOption("tte.restriction_output_root", file.path(project_root, analysis_config$output_root))
stage07e_dir <- file.path(restriction_root, "stage07e_restricted_weights")
stage07e_private <- file.path(stage07e_dir, "private_do_not_share")
output_dir <- file.path(restriction_root, "stage07f_restricted_effects")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

target_years <- as.numeric(effect_config$target_risk_years)
confidence_level <- as.numeric(effect_config$confidence_level)
if (!isTRUE(all.equal(confidence_level, 0.95))) {
  stop("Stage 07f currently requires a 95% confidence level.", call. = FALSE)
}

as_logical_value <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}

gate_path <- file.path(stage07e_dir, "07e_weighting_gate.csv")
if (!file.exists(gate_path)) {
  stop("Missing Stage 07e gate file: ", gate_path, call. = FALSE)
}
gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
required_gate_columns <- c(
  "cohort", "restriction", "outcome",
  "ready_for_restricted_effect_estimation"
)
missing_gate_columns <- setdiff(required_gate_columns, names(gate))
if (length(missing_gate_columns)) {
  stop(
    "Stage 07e gate lacks: ", paste(missing_gate_columns, collapse = ", "),
    call. = FALSE
  )
}
if (anyDuplicated(paste(gate$cohort, gate$restriction, gate$outcome))) {
  stop("Stage 07e gate contains duplicate analysis rows.", call. = FALSE)
}
gate[, ready := as_logical_value(ready_for_restricted_effect_estimation)]
ready_pairs <- gate[ready == TRUE, .(cohort, restriction, outcome)]
if (!nrow(ready_pairs)) {
  stop("No Stage 07e combination passed every weighting gate.", call. = FALSE)
}

known_cohorts <- c("HRS", "SHARE")
known_restrictions <- names(effect_config$restrictions)
known_outcomes <- names(effect_config$outcomes)
if (any(!ready_pairs$cohort %in% known_cohorts) ||
    any(!ready_pairs$restriction %in% known_restrictions) ||
    any(!ready_pairs$outcome %in% known_outcomes)) {
  stop("Stage 07e gate contains an unknown ready analysis combination.", call. = FALSE)
}

failure_reason <- function(row) {
  checks <- c(
    both_arms_present = "one treatment arm absent",
    pass_smaller_arm_n = "smaller arm below 100 observed person-trials",
    pass_smaller_arm_events = "smaller arm below 20 events",
    pass_total_events = "fewer than 100 total events",
    pass_primary_balance = "primary covariate balance above |SMD| 0.10",
    pass_change_balance = "prognosis-change balance above |SMD| 0.10",
    pass_effective_sample_size = "minimum arm ESS below 50",
    pass_common_support = "common support below 90%",
    pass_model_identifiability = "weight model convergence or identifiability failure",
    pass_retention_positivity = "outcome-observation positivity failure"
  )
  failed <- names(checks)[vapply(
    names(checks),
    function(column_name) {
      !column_name %in% names(row) || !as_logical_value(row[[column_name]])
    },
    logical(1L)
  )]
  if (!length(failed)) "none" else paste(unname(checks[failed]), collapse = "; ")
}

estimability_map <- data.table::copy(gate)
estimability_map[, estimated_in_stage07f := ready]
estimability_map[, failure_reason := vapply(
  seq_len(.N),
  function(index) failure_reason(estimability_map[index]),
  character(1L)
)]
estimability_map[, ready := NULL]

effect_parts <- list()
model_diagnostic_parts <- list()
sample_parts <- list()
join_check_parts <- list()

source_cache <- list()
for (cohort_name in unique(ready_pairs$cohort)) {
  source_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  if (!file.exists(source_path)) {
    stop("Missing Stage 04f trial file: ", source_path, call. = FALSE)
  }
  source_trials <- data.table::as.data.table(readRDS(source_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  required_source <- c(
    "person_id", "trial_id", "followup_time_years",
    "L_interview_date", "followup_reference_date"
  )
  missing_source <- setdiff(required_source, names(source_trials))
  if (length(missing_source)) {
    stop(
      cohort_name, " source trials lack: ",
      paste(missing_source, collapse = ", "), call. = FALSE
    )
  }
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate Stage 04f person-trial keys.", call. = FALSE)
  }
  source_cache[[cohort_name]] <- source_trials[, .(
    join_key,
    followup_time_years = suppressWarnings(as.numeric(followup_time_years)),
    L_interview_date,
    followup_reference_date
  )]
}

for (pair_index in seq_len(nrow(ready_pairs))) {
  cohort_name <- ready_pairs$cohort[[pair_index]]
  restriction_name <- ready_pairs$restriction[[pair_index]]
  outcome_name <- ready_pairs$outcome[[pair_index]]
  source_fields <- source_cache[[cohort_name]]

  weight_path <- file.path(
    stage07e_private,
    paste0(
      tolower(cohort_name), "_", restriction_name, "_",
      outcome_name, "_weights_PRIVATE.rds"
    )
  )
  if (!file.exists(weight_path)) {
    stop("Missing Stage 07e restricted weights: ", weight_path, call. = FALSE)
  }
  weighted_datasets <- readRDS(weight_path)
  if (!is.list(weighted_datasets) || length(weighted_datasets) != 20L) {
    stop(
      cohort_name, "/", restriction_name, "/", outcome_name,
      ": expected exactly 20 Stage 07e weighted datasets.", call. = FALSE
    )
  }

  for (imputation_index in seq_along(weighted_datasets)) {
    completed <- data.table::as.data.table(
      data.table::copy(weighted_datasets[[imputation_index]])
    )
    required_completed <- c(
      "person_id", "trial_id", "treatment", "sequence",
      "outcome_value", "outcome_observed_specific",
      "restricted_survey_weight_scaled", "total_weight_specific"
    )
    if (cohort_name == "SHARE") {
      required_completed <- c(required_completed, "B_country")
    }
    missing_completed <- setdiff(required_completed, names(completed))
    if (length(missing_completed)) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": Stage 07e private data lack: ",
        paste(missing_completed, collapse = ", "), call. = FALSE
      )
    }
    completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    if (anyDuplicated(completed$join_key)) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": duplicate restricted key in imputation ", imputation_index,
        call. = FALSE
      )
    }
    source_index <- match(completed$join_key, source_fields$join_key)
    if (anyNA(source_index)) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": Stage 04f follow-up join failed in imputation ", imputation_index,
        call. = FALSE
      )
    }
    completed[, followup_time_years :=
      source_fields$followup_time_years[source_index]]
    completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
    completed[, outcome_value := suppressWarnings(as.integer(outcome_value))]
    completed[, outcome_observed_specific :=
      suppressWarnings(as.integer(outcome_observed_specific))]
    completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      completed[, B_country := droplevels(factor(B_country))]
    }

    if (anyNA(completed$treatment) ||
        !all(completed$treatment %in% c(0L, 1L)) ||
        data.table::uniqueN(completed$treatment) != 2L) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": invalid treatment in imputation ", imputation_index,
        call. = FALSE
      )
    }
    if (any(!is.finite(completed$followup_time_years)) ||
        any(completed$followup_time_years <= 0)) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": invalid follow-up time in imputation ", imputation_index,
        call. = FALSE
      )
    }
    if (!all(completed$outcome_observed_specific %in% c(0L, 1L)) ||
        any(is.na(completed$outcome_value) !=
              (completed$outcome_observed_specific == 0L))) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": outcome-observation indicator is inconsistent in imputation ",
        imputation_index, call. = FALSE
      )
    }
    standardization_weight <- suppressWarnings(as.numeric(
      completed$restricted_survey_weight_scaled
    ))
    if (any(!is.finite(standardization_weight)) ||
        any(standardization_weight <= 0)) {
      stop("Invalid restricted standardization weights.", call. = FALSE)
    }

    observed <- completed[
      outcome_observed_specific == 1L & !is.na(outcome_value) &
        is.finite(total_weight_specific) & total_weight_specific > 0
    ]
    if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": both observed treatment arms are required in imputation ",
        imputation_index, call. = FALSE
      )
    }
    observed[, model_weight := total_weight_specific / mean(total_weight_specific)]

    adjustment_terms <- unlist(
      effect_config$design_adjustment[[cohort_name]], use.names = FALSE
    )
    formula_text <- paste0(
      "outcome_value ~ treatment + ",
      paste(adjustment_terms, collapse = " + "),
      " + offset(log(followup_time_years))"
    )
    outcome_formula <- stats::as.formula(formula_text)
    warning_messages <- character()
    fit <- withCallingHandlers(
      stats::glm(
        formula = outcome_formula,
        data = observed,
        family = stats::quasibinomial(link = "cloglog"),
        weights = model_weight,
        na.action = stats::na.fail,
        control = stats::glm.control(maxit = 100, epsilon = 1e-9)
      ),
      warning = function(warning_condition) {
        warning_messages <<- c(
          warning_messages, conditionMessage(warning_condition)
        )
        invokeRestart("muffleWarning")
      }
    )
    if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
      stop(
        cohort_name, "/", restriction_name, "/", outcome_name,
        ": outcome model failed in imputation ", imputation_index,
        call. = FALSE
      )
    }

    robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
    standardized <- tte_standardized_cloglog_effects(
      fit = fit,
      robust_vcov = robust$vcov,
      target_data = completed,
      standardization_weight = standardization_weight,
      target_years = target_years
    )

    variance_continue <- standardized$risk_covariance[1L, 1L]
    variance_discontinue <- standardized$risk_covariance[2L, 2L]
    variance_logit_continue <- variance_continue /
      (standardized$risk_continue * (1 - standardized$risk_continue))^2
    variance_logit_discontinue <- variance_discontinue /
      (standardized$risk_discontinue *
         (1 - standardized$risk_discontinue))^2

    key <- paste(
      cohort_name, restriction_name, outcome_name,
      imputation_index, sep = "_"
    )
    effect_parts[[key]] <- data.table::data.table(
      cohort = cohort_name,
      restriction = restriction_name,
      outcome = outcome_name,
      imputation = imputation_index,
      target_years = target_years,
      risk_continue = standardized$risk_continue,
      variance_risk_continue = variance_continue,
      logit_risk_continue = tte_logit(standardized$risk_continue),
      variance_logit_risk_continue = variance_logit_continue,
      risk_discontinue = standardized$risk_discontinue,
      variance_risk_discontinue = variance_discontinue,
      logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
      variance_logit_risk_discontinue = variance_logit_discontinue,
      risk_difference = standardized$risk_difference,
      variance_risk_difference = standardized$variance_risk_difference,
      log_risk_ratio = standardized$log_risk_ratio,
      variance_log_risk_ratio = standardized$variance_log_risk_ratio
    )
    model_diagnostic_parts[[key]] <- data.table::data.table(
      cohort = cohort_name,
      restriction = restriction_name,
      outcome = outcome_name,
      imputation = imputation_index,
      formula = formula_text,
      converged = isTRUE(fit$converged),
      iterations = fit$iter,
      coefficient_n = length(stats::coef(fit)),
      aliased_coefficient_n = sum(is.na(stats::coef(fit))),
      warning_n = length(unique(warning_messages)),
      warnings = paste(unique(warning_messages), collapse = " | "),
      eligible_person_trials = nrow(completed),
      outcome_observations = nrow(observed),
      unique_person_clusters = robust$clusters,
      events = sum(observed$outcome_value == 1L),
      continue_observations = sum(observed$treatment == 0L),
      discontinue_observations = sum(observed$treatment == 1L),
      continue_events = sum(
        observed$outcome_value == 1L & observed$treatment == 0L
      ),
      discontinue_events = sum(
        observed$outcome_value == 1L & observed$treatment == 1L
      ),
      followup_minimum_years = min(observed$followup_time_years),
      followup_median_years = stats::median(observed$followup_time_years),
      followup_maximum_years = max(observed$followup_time_years),
      cluster_CR1_correction = robust$correction,
      full_survey_design_variance_available = FALSE
    )

    if (imputation_index == 1L) {
      sample_parts[[paste(
        cohort_name, restriction_name, outcome_name, sep = "_"
      )]] <- completed[, .(
        eligible_person_trials = .N,
        unique_persons = data.table::uniqueN(person_id),
        outcome_observed_n = sum(outcome_observed_specific == 1L),
        outcome_observed_fraction = mean(outcome_observed_specific == 1L),
        events = sum(outcome_value == 1L, na.rm = TRUE),
        followup_minimum_years = min(followup_time_years),
        followup_median_years = stats::median(followup_time_years),
        followup_maximum_years = max(followup_time_years)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        restriction = restriction_name,
        outcome = outcome_name,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]
    }

    join_check_parts[[key]] <- data.table::data.table(
      cohort = cohort_name,
      restriction = restriction_name,
      outcome = outcome_name,
      imputation = imputation_index,
      restricted_weight_rows = nrow(completed),
      matched_source_rows = sum(!is.na(source_index)),
      duplicated_restricted_keys = sum(duplicated(completed$join_key))
    )
  }
}

effects_by_imputation <- data.table::rbindlist(
  effect_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_diagnostic_parts, use.names = TRUE, fill = TRUE
)
sample_description <- data.table::rbindlist(
  sample_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(
  join_check_parts, use.names = TRUE, fill = TRUE
)

pooled_rows <- list()
pooling_rows <- list()
for (pair_index in seq_len(nrow(ready_pairs))) {
  cohort_name <- ready_pairs$cohort[[pair_index]]
  restriction_name <- ready_pairs$restriction[[pair_index]]
  outcome_name <- ready_pairs$outcome[[pair_index]]
  estimates <- effects_by_imputation[
    cohort == cohort_name & restriction == restriction_name &
      outcome == outcome_name
  ]
  diagnostics <- model_diagnostics[
    cohort == cohort_name & restriction == restriction_name &
      outcome == outcome_name
  ]
  if (nrow(estimates) != 20L || nrow(diagnostics) != 20L) {
    stop(
      cohort_name, "/", restriction_name, "/", outcome_name,
      ": expected exactly 20 effect estimates and diagnostics.",
      call. = FALSE
    )
  }
  df_complete <- min(diagnostics$unique_person_clusters) -
    max(diagnostics$coefficient_n)

  pooled_list <- list(
    risk_continue = tte_pool_scalar(
      estimates$logit_risk_continue,
      estimates$variance_logit_risk_continue,
      df_complete = df_complete
    ),
    risk_discontinue = tte_pool_scalar(
      estimates$logit_risk_discontinue,
      estimates$variance_logit_risk_discontinue,
      df_complete = df_complete
    ),
    risk_difference = tte_pool_scalar(
      estimates$risk_difference,
      estimates$variance_risk_difference,
      df_complete = df_complete, null = 0
    ),
    risk_ratio = tte_pool_scalar(
      estimates$log_risk_ratio,
      estimates$variance_log_risk_ratio,
      df_complete = df_complete, null = 0
    )
  )
  transformers <- list(
    risk_continue = tte_expit,
    risk_discontinue = tte_expit,
    risk_difference = identity,
    risk_ratio = exp
  )
  null_values <- c(
    risk_continue = NA_real_, risk_discontinue = NA_real_,
    risk_difference = 0, risk_ratio = 1
  )

  for (measure_name in names(pooled_list)) {
    pooled <- pooled_list[[measure_name]]
    transform_value <- transformers[[measure_name]]
    row_key <- paste(
      cohort_name, restriction_name, outcome_name, measure_name, sep = "_"
    )
    pooled_rows[[row_key]] <- data.table::data.table(
      cohort = cohort_name,
      restriction = restriction_name,
      restriction_label = effect_config$restrictions[[restriction_name]]$label,
      outcome = outcome_name,
      outcome_label = effect_config$outcomes[[outcome_name]]$label,
      target_years = target_years,
      measure = measure_name,
      estimate = transform_value(pooled$estimate),
      confidence_lower = transform_value(pooled$lower),
      confidence_upper = transform_value(pooled$upper),
      null_value = null_values[[measure_name]],
      p_value = if (measure_name %in% c("risk_difference", "risk_ratio")) {
        pooled$p_value
      } else {
        NA_real_
      },
      imputations = pooled$imputations,
      inference = "person-clustered CR1 sandwich; Rubin pooled",
      interpretation = if (measure_name == "risk_difference") {
        "discontinuation minus continuation"
      } else if (measure_name == "risk_ratio") {
        "discontinuation divided by continuation"
      } else {
        gsub("risk_", "standardized risk under ", measure_name)
      }
    )
    pooling_rows[[row_key]] <- data.table::data.table(
      cohort = cohort_name,
      restriction = restriction_name,
      outcome = outcome_name,
      measure = measure_name,
      pooled_transformed_estimate = pooled$estimate,
      transformed_standard_error = pooled$standard_error,
      degrees_freedom = pooled$degrees_freedom,
      within_variance = pooled$within_variance,
      between_variance = pooled$between_variance,
      total_variance = pooled$total_variance,
      relative_increase_variance = pooled$relative_increase_variance,
      fraction_missing_information = pooled$fraction_missing_information,
      complete_data_degrees_freedom = df_complete
    )
  }
}

pooled_effects <- data.table::rbindlist(
  pooled_rows, use.names = TRUE, fill = TRUE
)
pooling_diagnostics <- data.table::rbindlist(
  pooling_rows, use.names = TRUE, fill = TRUE
)
pooled_effects[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000, NA_real_
)]
pooled_effects[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000, NA_real_
)]
pooled_effects[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000, NA_real_
)]

model_summary <- model_diagnostics[, .(
  imputations = .N,
  all_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0L),
  any_warning = any(warning_n > 0L),
  eligible_person_trials = unique(eligible_person_trials)[1L],
  observed_outcomes = unique(outcome_observations)[1L],
  unique_person_clusters = unique(unique_person_clusters)[1L],
  events = unique(events)[1L],
  min_iterations = min(iterations),
  max_iterations = max(iterations),
  minimum_CR1_correction = min(cluster_CR1_correction),
  maximum_CR1_correction = max(cluster_CR1_correction)
), by = .(cohort, restriction, outcome)]

data.table::setorder(
  effects_by_imputation, cohort, restriction, outcome, imputation
)
data.table::setorder(
  pooled_effects, cohort, restriction, outcome, measure
)
data.table::setorder(
  pooling_diagnostics, cohort, restriction, outcome, measure
)
data.table::setorder(
  model_diagnostics, cohort, restriction, outcome, imputation
)
data.table::setorder(model_summary, cohort, restriction, outcome)
data.table::setorder(sample_description, cohort, restriction, outcome, treatment)
data.table::setorder(join_checks, cohort, restriction, outcome, imputation)
data.table::setorder(estimability_map, cohort, restriction, outcome)

tte_write_csv(
  effects_by_imputation,
  file.path(output_dir, "07f_restricted_effects_by_imputation.csv")
)
tte_write_csv(
  pooled_effects,
  file.path(output_dir, "07f_restricted_effects_pooled.csv")
)
tte_write_csv(
  pooling_diagnostics,
  file.path(output_dir, "07f_pooling_diagnostics.csv")
)
tte_write_csv(
  model_diagnostics,
  file.path(output_dir, "07f_model_diagnostics.csv")
)
tte_write_csv(
  model_summary,
  file.path(output_dir, "07f_model_summary.csv")
)
tte_write_csv(
  sample_description,
  file.path(output_dir, "07f_analysis_sample.csv")
)
tte_write_csv(
  join_checks,
  file.path(output_dir, "07f_join_checks.csv")
)
tte_write_csv(
  estimability_map,
  file.path(output_dir, "07f_estimability_map.csv")
)
writeLines(
  readLines(effect_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07f_frozen_restricted_effect_model.yml"),
  useBytes = TRUE
)
saveRDS(
  list(
    ready_pairs = ready_pairs,
    estimability_map = estimability_map,
    effects_by_imputation = effects_by_imputation,
    pooled_effects = pooled_effects,
    pooling_diagnostics = pooling_diagnostics,
    model_diagnostics = model_diagnostics,
    config = effect_config
  ),
  file.path(private_dir, "stage07f_restricted_estimates_PRIVATE.rds"),
  version = 3L
)

risk_plot_data <- pooled_effects[
  measure %in% c("risk_continue", "risk_discontinue")
]
risk_plot_data[, treatment_strategy := factor(
  measure,
  levels = c("risk_continue", "risk_discontinue"),
  labels = c("Continue", "Discontinue")
)]
risk_plot_data[, restriction_short := vapply(
  restriction,
  function(value) effect_config$restrictions[[value]]$short_label,
  character(1L)
)]
risk_plot_data[, facet_label := paste(
  cohort, outcome_label, restriction_short, sep = "\n"
)]
risk_plot <- ggplot2::ggplot(
  risk_plot_data,
  ggplot2::aes(
    x = treatment_strategy, y = estimate,
    ymin = confidence_lower, ymax = confidence_upper,
    colour = treatment_strategy
  )
) +
  ggplot2::geom_pointrange(linewidth = 0.5) +
  ggplot2::facet_wrap(~facet_label, scales = "free_y") +
  ggplot2::scale_y_continuous(
    labels = function(x) paste0(round(100 * x, 1), "%")
  ) +
  ggplot2::scale_colour_manual(values = c(
    "Continue" = "#2463A8", "Discontinue" = "#C44E52"
  )) +
  ggplot2::labs(
    x = NULL,
    y = "Standardized 3-year risk (95% CI)",
    title = "Restriction-based reverse-causation sensitivity analyses",
    subtitle = "Only combinations passing every Stage 07e gate are shown"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "none")

difference_plot_data <- pooled_effects[measure == "risk_difference"]
difference_plot_data[, restriction_short := vapply(
  restriction,
  function(value) effect_config$restrictions[[value]]$short_label,
  character(1L)
)]
difference_plot_data[, analysis_label := paste(
  cohort, outcome_label, restriction_short, sep = " | "
)]
difference_plot_data[, analysis_label := factor(
  analysis_label, levels = rev(unique(analysis_label))
)]
difference_plot <- ggplot2::ggplot(
  difference_plot_data,
  ggplot2::aes(
    x = estimate * 1000, y = analysis_label,
    xmin = confidence_lower * 1000,
    xmax = confidence_upper * 1000,
    colour = cohort
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
  ggplot2::geom_errorbar(orientation = "y", width = 0.12, linewidth = 0.55) +
  ggplot2::geom_point(size = 2.3) +
  ggplot2::scale_colour_manual(values = c("HRS" = "#2463A8", "SHARE" = "#C44E52")) +
  ggplot2::labs(
    x = "3-year risk difference per 1,000 (discontinue - continue)",
    y = NULL,
    colour = "Cohort",
    title = "Restricted sensitivity estimates",
    subtitle = "Positive values indicate higher risk under observed discontinuation"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

ggplot2::ggsave(
  file.path(output_dir, "07f_restricted_standardized_risk.png"),
  risk_plot, width = 11, height = 5.8, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07f_restricted_standardized_risk.pdf"),
  risk_plot, width = 11, height = 5.8
)
ggplot2::ggsave(
  file.path(output_dir, "07f_restricted_risk_difference.png"),
  difference_plot, width = 11, height = 4.8, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07f_restricted_risk_difference.pdf"),
  difference_plot, width = 11, height = 4.8
)

comparison_path <- file.path(stage07c_dir, "07c_component_effects_pooled.csv")
if (file.exists(comparison_path)) {
  unrestricted <- data.table::as.data.table(tte_read_csv_utf8(comparison_path))
  unrestricted <- unrestricted[measure == "risk_difference", .(
    cohort, outcome, measure, estimate, confidence_lower, confidence_upper
  )]
  unrestricted[, analysis := "Unrestricted"]
  restricted_comparison <- difference_plot_data[, .(
    cohort, outcome, measure, estimate, confidence_lower, confidence_upper,
    analysis = restriction_short
  )]
  comparison <- data.table::rbindlist(
    list(unrestricted, restricted_comparison), use.names = TRUE, fill = TRUE
  )
  comparison[, outcome_label := vapply(
    outcome,
    function(value) effect_config$outcomes[[value]]$label,
    character(1L)
  )]
  analysis_levels <- c(
    "Unrestricted",
    effect_config$restrictions$exclude_multiple_deterioration_markers$short_label,
    effect_config$restrictions$exclude_severe_deterioration$short_label
  )
  comparison[, analysis := factor(analysis, levels = analysis_levels)]
  comparison_plot <- ggplot2::ggplot(
    comparison,
    ggplot2::aes(
      x = estimate * 1000, y = analysis,
      xmin = confidence_lower * 1000,
      xmax = confidence_upper * 1000,
      colour = analysis
    )
  ) +
    ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
    ggplot2::geom_errorbar(orientation = "y", width = 0.12, linewidth = 0.5) +
    ggplot2::geom_point(size = 2.1) +
    ggplot2::facet_grid(cohort ~ outcome_label, scales = "free_y") +
    ggplot2::scale_colour_manual(values = c(
      "Unrestricted" = "#4D4D4D",
      "Exclude >=2 deterioration markers" = "#2E8B57",
      "Exclude any severe deterioration" = "#8E5EA2"
    ), drop = FALSE) +
    ggplot2::labs(
      x = "3-year risk difference per 1,000 (discontinue - continue)",
      y = NULL,
      colour = "Analysis",
      title = "Unrestricted and reverse-causation sensitivity estimates",
      subtitle = "Missing restricted estimates indicate failure of a frozen Stage 07e gate"
    ) +
    ggplot2::theme_minimal(base_size = 10) +
    ggplot2::theme(legend.position = "bottom")
  ggplot2::ggsave(
    file.path(output_dir, "07f_unrestricted_restricted_comparison.png"),
    comparison_plot, width = 12, height = 6.5, dpi = 220
  )
  ggplot2::ggsave(
    file.path(output_dir, "07f_unrestricted_restricted_comparison.pdf"),
    comparison_plot, width = 12, height = 6.5
  )
}

effect_lines <- vapply(seq_len(nrow(ready_pairs)), function(pair_index) {
  cohort_name <- ready_pairs$cohort[[pair_index]]
  restriction_name <- ready_pairs$restriction[[pair_index]]
  outcome_name <- ready_pairs$outcome[[pair_index]]
  rd <- pooled_effects[
    cohort == cohort_name & restriction == restriction_name &
      outcome == outcome_name & measure == "risk_difference"
  ]
  rr <- pooled_effects[
    cohort == cohort_name & restriction == restriction_name &
      outcome == outcome_name & measure == "risk_ratio"
  ]
  paste0(
    cohort_name, "/", restriction_name, "/", outcome_name,
    ": RD = ", sprintf("%.1f", rd$estimate_per_1000),
    " per 1,000 (95% CI ",
    sprintf("%.1f", rd$confidence_lower_per_1000), " to ",
    sprintf("%.1f", rd$confidence_upper_per_1000),
    "); RR = ", sprintf("%.3f", rr$estimate),
    " (95% CI ", sprintf("%.3f", rr$confidence_lower), " to ",
    sprintf("%.3f", rr$confidence_upper), ")."
  )
}, character(1L))

failed_lines <- estimability_map[
  !as_logical_value(ready_for_restricted_effect_estimation),
  paste0(cohort, "/", restriction, "/", outcome, ": ", failure_reason)
]

summary_lines <- c(
  "Stage 07f: restricted reverse-causation sensitivity effects",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Target risk horizon: ", target_years, " years"),
  paste0(
    "Estimated combinations passing every Stage 07e gate: ",
    nrow(ready_pairs), " of ", nrow(gate), "."
  ),
  "Restriction- and outcome-specific Stage 07e weights were used.",
  "Model: complementary log-log marginal structural outcome model with log follow-up offset.",
  "Adjustment: sequence in HRS; sequence plus country in SHARE.",
  "Inference: person-clustered CR1 sandwich within each imputation, then Rubin pooling.",
  "No failed combination was estimated and no cross-cohort meta-analysis was performed.",
  "",
  "Estimated combinations:",
  effect_lines,
  "",
  "Not estimated because at least one frozen gate failed:",
  failed_lines,
  "",
  "Positive RD and RR > 1 indicate higher risk under observed discontinuation.",
  "These restricted analyses address, but cannot eliminate, prognosis-driven discontinuation.",
  "Do not interpret the exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07f_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07f_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message(
  "Stage 07f completed: ",
  normalizePath(output_dir, winslash = "/", mustWork = TRUE)
)
