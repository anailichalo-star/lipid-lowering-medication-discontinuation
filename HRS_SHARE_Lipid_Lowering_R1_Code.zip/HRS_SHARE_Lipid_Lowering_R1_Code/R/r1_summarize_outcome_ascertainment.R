# Scientific Reports R1: reconcile vital status and nonfatal outcome observation
# using the saved aggregate audit and independently saved analysis counts.

args <- commandArgs(trailingOnly = TRUE)
project_root <- if (length(args)) args[[1L]] else getwd()
root <- file.path(project_root, "outputs_r")
audit <- read.csv(file.path(root, "stage07a_outcome_audit", "07a_arm_outcome_counts.csv"))
primary <- read.csv(file.path(root, "stage06_primary_effects", "06_analysis_sample.csv"))
functional <- read.csv(file.path(root, "stage07g_functional_weights", "07g_analysis_sample.csv"))

summarize_arm <- function(cohort, arm) {
  x <- audit[audit$cohort == cohort & audit$treatment == arm, ]
  stages <- c("death_component", "broad_nonfatal_survivor", "primary_event", "death_adl_decline")
  stopifnot(all(vapply(stages, function(name) sum(x$outcome == name), integer(1L)) == 1L))
  x <- x[match(stages, x$outcome), ]
  p <- primary[primary$cohort == cohort & primary$treatment == arm, ]
  f <- functional[functional$cohort == cohort & functional$treatment == arm, ]
  stopifnot(nrow(p) == 1L, nrow(f) == 1L)

  n <- p$person_trials
  deaths <- x$events[1L]
  survivors <- x$non_events[1L]
  unknown <- n - deaths - survivors
  cvd_missing <- survivors - x$outcome_observed_person_trials[2L]
  adl_missing <- survivors - (f$observed_person_trials - deaths)
  stopifnot(
    all(x$eligible_person_trials == n), f$eligible_person_trials == n,
    all(c(deaths, survivors, unknown, cvd_missing, adl_missing) >= 0L),
    deaths + survivors == x$outcome_observed_person_trials[1L],
    n - unknown - cvd_missing == p$outcome_observed_n,
    n - unknown - adl_missing == f$observed_person_trials,
    x$outcome_observed_person_trials[3L] == p$outcome_observed_n,
    x$outcome_observed_person_trials[4L] == f$observed_person_trials,
    x$events[3L] == p$primary_events, x$events[4L] == f$events
  )

  data.frame(
    cohort = cohort, group = c("Continuation", "Discontinuation")[[arm + 1L]],
    n = n, deaths = deaths, survivors = survivors, unknown = unknown,
    cvd_missing = cvd_missing, adl_missing = adl_missing
  )
}

arms <- do.call(rbind, lapply(c("HRS", "SHARE"), function(cohort) {
  do.call(rbind, lapply(0:1, function(arm) summarize_arm(cohort, arm)))
}))
numeric_columns <- c("n", "deaths", "survivors", "unknown", "cvd_missing", "adl_missing")
totals <- aggregate(arms[numeric_columns], by = list(cohort = arms$cohort), sum)
stopifnot(
  identical(as.integer(totals$n - totals$unknown), c(6869L, 2653L)),
  identical(as.integer(totals$deaths), c(544L, 197L))
)
totals$group <- "Overall"
rows <- rbind(arms, totals[names(arms)])
rows <- rows[order(rows$cohort, match(rows$group, c("Overall", "Continuation", "Discontinuation"))), ]

display <- vapply(seq_len(nrow(rows)), function(i) {
  x <- rows[i, ]
  sprintf(
    "| %s | %s | %d | %d | %d | %d (%.1f%%) | %d | %d |",
    x$cohort, x$group, x$n, x$deaths, x$survivors, x$unknown,
    100 * x$unknown / x$n, x$cvd_missing, x$adl_missing
  )
}, character(1L))

output_dir <- file.path(root, "revision_r1")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
output <- file.path(output_dir, "R1_supplementary_outcome_ascertainment.md")
writeLines(c(
  "# Vital status and nonfatal outcome availability by cohort and medication group", "",
  "| Cohort | Medication group | Eligible entries | Recorded deaths | Known alive | Vital status unknown, n (%) | Missing CVD assessment among known survivors | Missing paired ADL assessments among known survivors |",
  "|---|---|---:|---:|---:|---:|---:|---:|",
  display, "",
  "Unweighted counts of eligible landmark entries. Under the original analysis rule, a recorded death in the assessment interval established death even without an interview. A follow-up interview established survival in entries without a recorded interval death. All remaining entries had unknown vital status. Nonfatal CVD and paired ADL availability were evaluated among known survivors. CVD denotes cardiovascular disease and ADL denotes activities of daily living."
), output, useBytes = TRUE)
message("Reconciled all four groups against Stage 06 and Stage 07g counts and reproduced the Supplementary Table S3 mortality totals.")
message("Wrote ", output)
