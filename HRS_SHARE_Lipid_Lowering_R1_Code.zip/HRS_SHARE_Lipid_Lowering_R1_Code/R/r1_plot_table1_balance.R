# Run from the project root after r1_correct_table1_self_rated_health.R.
# Use the revised Table 1 display values for Figure S1.
suppressPackageStartupMessages(library(ggplot2))

table1 <- read.csv("outputs_r/revision_r1/Table1_baseline_characteristics.csv",
                   check.names = FALSE, fileEncoding = "UTF-8-BOM")
balance <- data.frame(
  cohort = factor(table1$Cohort, levels = c("HRS", "SHARE")),
  characteristic = table1$Characteristic,
  unweighted = table1[["SMD before"]],
  weighted = table1[["SMD after"]]
)
stopifnot(nrow(balance) == 40L, length(unique(balance$characteristic)) == 20L,
          all(table(balance$cohort, balance$characteristic) == 1L),
          all(is.finite(balance$unweighted)), all(is.finite(balance$weighted)),
          balance$weighted[balance$cohort == "HRS" & balance$characteristic == "Current smoking"] == 0.029,
          balance$weighted[balance$cohort == "SHARE" & balance$characteristic == "Frailty index"] == 0.036)

labels <- c("Age, y" = "Age", "Within-sequence income rank" = "Income rank",
            "Body mass index, kg/m2" = "Body mass index",
            "Frailty index 0.25 or greater" = "Frailty index \u2265 0.25")
keys <- paste(balance$cohort, balance$characteristic, sep = "___")
balance$axis_key <- factor(keys, levels = keys[order(balance$cohort, balance$unweighted)])

statuses <- c("Before weighting", "After weighting")
point_data <- rbind(
  transform(balance, status = statuses[1L], smd = unweighted),
  transform(balance, status = statuses[2L], smd = weighted)
)
point_data$status <- factor(point_data$status, levels = statuses)
plot <- ggplot(point_data, aes(x = smd, y = axis_key, colour = status, shape = status)) +
  geom_vline(xintercept = 0.10, colour = "#B2182B", linetype = "dashed", linewidth = 0.45) +
  geom_point(size = 2.0, alpha = 0.95) +
  facet_wrap(~cohort, scales = "free_y", ncol = 2) +
  scale_y_discrete(labels = function(key) {
    name <- sub("^.*___", "", key)
    replace(name, name %in% names(labels), unname(labels[name[name %in% names(labels)]]))
  }) +
  scale_x_continuous(expand = expansion(mult = c(0.01, 0.05))) +
  scale_colour_manual(values = setNames(c("#D55E00", "#0072B2"), statuses)) +
  scale_shape_manual(values = setNames(c(17L, 16L), statuses)) +
  labs(x = "Absolute standardized mean difference", y = NULL, colour = NULL, shape = NULL) +
  theme_classic(base_family = "Arial", base_size = 9) +
  theme(
    axis.title = element_text(size = 10, colour = "black"),
    axis.text = element_text(size = 9, colour = "black"),
    axis.text.y = element_text(size = 6.7),
    panel.grid.major.x = element_line(colour = "#E6E6E6", linewidth = 0.3),
    panel.grid.minor = element_blank(),
    panel.spacing.x = grid::unit(0.40, "in"),
    strip.background = element_blank(),
    strip.text = element_text(face = "bold", size = 10, colour = "black"),
    legend.position = "bottom",
    legend.text = element_text(size = 9, colour = "black"),
    plot.margin = margin(6, 8, 6, 6)
  )

destination <- "outputs_r/revision_r1/figures"
dir.create(destination, recursive = TRUE, showWarnings = FALSE)
save_balance <- function(extension, device, ...) {
  ggsave(file.path(destination, paste0("FigureS1_covariate_balance.", extension)),
         plot, width = 7.2, height = 8.6, units = "in", device = device, bg = "white", ...)
}
save_balance("pdf", grDevices::cairo_pdf)
save_balance("tiff", grDevices::tiff, dpi = 600, type = "cairo", compression = "lzw")
save_balance("png", grDevices::png, dpi = 300, type = "cairo")
message("Figure S1 uses the same 80 SMD values as Table 1.")
