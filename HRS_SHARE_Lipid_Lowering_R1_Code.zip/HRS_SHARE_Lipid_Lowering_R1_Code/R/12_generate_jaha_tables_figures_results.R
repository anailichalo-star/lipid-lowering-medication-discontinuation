# Generate JAHA-oriented main tables, publication figures, and a Word Results
# package. All numeric content is derived from frozen analysis outputs.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
output_root <- file.path(project_root, "outputs_r")
jaha_root <- file.path(output_root, "jaha_publication")
figure_dir <- file.path(jaha_root, "figures")
table_dir <- file.path(jaha_root, "tables")

dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(table_dir, recursive = TRUE, showWarnings = FALSE)

required_packages <- c("data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop("Missing required packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

library(data.table)
library(ggplot2)

read_output <- function(relative_path) {
  path <- file.path(output_root, relative_path)
  if (!file.exists(path)) stop("Missing frozen analysis output: ", path, call. = FALSE)
  data.table::fread(path, encoding = "UTF-8")
}

write_csv <- function(x, path) {
  data.table::fwrite(x, path, bom = TRUE, quote = TRUE, na = "")
}

blue <- "#0072B2"
orange <- "#D55E00"
green <- "#009E73"
gray <- "#5C5C5C"
light_gray <- "#F4F4F4"
font_family <- "Arial"

format_p_value <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  ifelse(
    !is.finite(p), "",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

format_p_label <- function(p) {
  value <- format_p_value(p)
  ifelse(value == "<0.001", "P<0.001", paste0("P=", value))
}

theme_jaha <- function(base_size = 10) {
  ggplot2::theme_classic(base_size = base_size, base_family = font_family) +
    ggplot2::theme(
      axis.title = ggplot2::element_text(size = 10, colour = "black"),
      axis.text = ggplot2::element_text(size = 9.5, colour = "black"),
      strip.background = ggplot2::element_blank(),
      strip.text = ggplot2::element_text(size = 10, face = "bold", colour = "black"),
      legend.title = ggplot2::element_blank(),
      legend.text = ggplot2::element_text(size = 9.5, colour = "black"),
      plot.tag = ggplot2::element_text(size = 12, face = "bold", colour = "black"),
      panel.grid.major.x = ggplot2::element_line(colour = "#E6E6E6", linewidth = 0.3),
      panel.grid.minor = ggplot2::element_blank(),
      plot.margin = ggplot2::margin(5.5, 8, 5.5, 5.5)
    )
}

open_device <- function(path, width, height, dpi = NULL) {
  extension <- tolower(tools::file_ext(path))
  if (extension == "pdf") {
    if (capabilities("cairo")) {
      grDevices::cairo_pdf(path, width = width, height = height, family = font_family)
    } else {
      grDevices::pdf(path, width = width, height = height, family = "sans")
    }
  } else if (extension %in% c("tif", "tiff")) {
    grDevices::tiff(
      path, width = width, height = height, units = "in", res = dpi,
      compression = "lzw", type = if (capabilities("cairo")) "cairo" else "windows",
      bg = "white"
    )
  } else if (extension == "png") {
    grDevices::png(
      path, width = width, height = height, units = "in", res = dpi,
      type = if (capabilities("cairo")) "cairo" else "windows", bg = "white"
    )
  } else {
    stop("Unsupported figure extension: ", extension, call. = FALSE)
  }
}

save_drawing <- function(draw, stem, width, height, tiff_dpi) {
  files <- c(
    pdf = file.path(figure_dir, paste0(stem, ".pdf")),
    tiff = file.path(figure_dir, paste0(stem, ".tiff")),
    png = file.path(figure_dir, paste0(stem, ".png"))
  )
  open_device(files[["pdf"]], width, height)
  draw()
  grDevices::dev.off()
  open_device(files[["tiff"]], width, height, tiff_dpi)
  draw()
  grDevices::dev.off()
  open_device(files[["png"]], width, height, 300)
  draw()
  grDevices::dev.off()
  invisible(files)
}

weighted_mean_safe <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

weighted_sd_safe <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (sum(ok) < 2L) return(NA_real_)
  mu <- weighted_mean_safe(x[ok], w[ok])
  sqrt(sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok]))
}

standardized_difference <- function(x0, w0, x1, w1) {
  m0 <- weighted_mean_safe(x0, w0)
  m1 <- weighted_mean_safe(x1, w1)
  s0 <- weighted_sd_safe(x0, w0)
  s1 <- weighted_sd_safe(x1, w1)
  denominator <- sqrt((s0^2 + s1^2) / 2)
  if (!is.finite(denominator) || denominator == 0) return(NA_real_)
  (m1 - m0) / denominator
}

transform_characteristic <- function(x, type, threshold = NA_real_) {
  if (is.factor(x) || is.character(x)) {
    x <- suppressWarnings(as.numeric(as.character(x)))
  } else {
    x <- suppressWarnings(as.numeric(x))
  }
  if (type == "continuous") return(x)
  result <- switch(
    type,
    equals_one = as.numeric(x == 1),
    equals_zero = as.numeric(x == 0),
    at_least = as.numeric(x >= threshold),
    greater_than = as.numeric(x > threshold),
    stop("Unknown characteristic type: ", type, call. = FALSE)
  )
  result[is.na(x)] <- NA_real_
  result
}

# -----------------------------------------------------------------------------
# Table 1: selected baseline characteristics and treatment-weight balance.
# -----------------------------------------------------------------------------

table1_spec <- data.table::data.table(
  order = seq_len(20),
  variable = c(
    "B_age", "B_sex", "B_income_rank", "B_bmi", "B_depression_score",
    "B_adl5_count", "B_iadl5_count", "FI_pre_treatment",
    "B_current_smoking", "B_alcohol_use", "B_hypertension", "B_diabetes",
    "B_cancer", "B_lung_disease", "B_arthritis", "B_hospitalization",
    "B_self_rated_health", "FI_pre_treatment", "B_adl5_count", "B_iadl5_count"
  ),
  characteristic = c(
    "Age, y", "Women", "Within-sequence income rank", "Body mass index, kg/m2",
    "Depression score", "ADL difficulty count", "IADL difficulty count",
    "Frailty index", "Current smoking", "Alcohol use", "Hypertension",
    "Diabetes", "Cancer", "Lung disease", "Arthritis", "Recent hospitalization",
    "Fair or poor self-rated health", "Frailty index 0.25 or greater",
    "Any ADL difficulty", "Any IADL difficulty"
  ),
  type = c(
    "continuous", "equals_zero", "continuous", "continuous", "continuous",
    "continuous", "continuous", "continuous", rep("equals_one", 8),
    "at_least", "at_least", "greater_than", "greater_than"
  ),
  threshold = c(
    rep(NA_real_, 16), 4, 0.25, 0, 0
  )
)

table1_long <- list()
for (cohort_name in c("HRS", "SHARE")) {
  source_path <- file.path(
    output_root, "stage05_weighting", "private_do_not_share",
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(source_path)) stop("Missing Table 1 input: ", source_path, call. = FALSE)
  completed_list <- readRDS(source_path)

  for (imp in seq_along(completed_list)) {
    completed <- data.table::as.data.table(completed_list[[imp]])
    completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
    if (!"treatment_analysis_weight" %in% names(completed)) {
      stop("Treatment weight is missing in ", cohort_name, " imputation ", imp, call. = FALSE)
    }

    for (i in seq_len(nrow(table1_spec))) {
      spec <- table1_spec[i]
      values <- transform_characteristic(
        completed[[spec$variable]], spec$type, spec$threshold
      )
      is_percentage <- spec$type != "continuous"

      for (weighting in c("unweighted", "treatment_weighted")) {
        weights <- if (weighting == "unweighted") {
          rep(1, nrow(completed))
        } else {
          suppressWarnings(as.numeric(completed$treatment_analysis_weight))
        }
        summaries <- lapply(c(0L, 1L), function(arm) {
          index <- completed$treatment == arm
          c(
            mean = weighted_mean_safe(values[index], weights[index]),
            sd = weighted_sd_safe(values[index], weights[index])
          )
        })
        smd <- standardized_difference(
          values[completed$treatment == 0L], weights[completed$treatment == 0L],
          values[completed$treatment == 1L], weights[completed$treatment == 1L]
        )
        table1_long[[length(table1_long) + 1L]] <- data.table::data.table(
          cohort = cohort_name,
          imputation = imp,
          characteristic_order = spec$order,
          characteristic = spec$characteristic,
          type = spec$type,
          is_percentage = is_percentage,
          weighting = weighting,
          continue_mean = summaries[[1]][["mean"]],
          continue_sd = summaries[[1]][["sd"]],
          discontinue_mean = summaries[[2]][["mean"]],
          discontinue_sd = summaries[[2]][["sd"]],
          smd = smd
        )
      }
    }
  }
}

table1_long <- data.table::rbindlist(table1_long)
table1_pooled <- table1_long[, .(
  continue_mean = mean(continue_mean, na.rm = TRUE),
  continue_sd = mean(continue_sd, na.rm = TRUE),
  discontinue_mean = mean(discontinue_mean, na.rm = TRUE),
  discontinue_sd = mean(discontinue_sd, na.rm = TRUE),
  absolute_smd = mean(abs(smd), na.rm = TRUE)
), by = .(
  cohort, characteristic_order, characteristic, type, is_percentage, weighting
)]

unweighted_t1 <- table1_pooled[weighting == "unweighted"]
weighted_t1 <- table1_pooled[weighting == "treatment_weighted", .(
  cohort, characteristic_order, weighted_absolute_smd = absolute_smd
)]
table1 <- merge(
  unweighted_t1, weighted_t1,
  by = c("cohort", "characteristic_order"), all.x = TRUE
)
table1[, `:=`(
  Continue = ifelse(
    is_percentage,
    sprintf("%.1f", 100 * continue_mean),
    sprintf("%.2f (%.2f)", continue_mean, continue_sd)
  ),
  Discontinue = ifelse(
    is_percentage,
    sprintf("%.1f", 100 * discontinue_mean),
    sprintf("%.2f (%.2f)", discontinue_mean, discontinue_sd)
  ),
  `SMD before` = sprintf("%.3f", absolute_smd),
  `SMD after` = sprintf("%.3f", weighted_absolute_smd)
)]
table1 <- table1[, .(
  Cohort = cohort, Characteristic = characteristic,
  Continue, Discontinue, `SMD before`, `SMD after`
)]
write_csv(table1, file.path(table_dir, "Table1_baseline_characteristics.csv"))

# -----------------------------------------------------------------------------
# Table 2: main clinical effects with observed event counts.
# -----------------------------------------------------------------------------

primary_effect <- read_output("stage06_primary_effects/06_primary_effects_pooled.csv")
component_effect <- read_output("stage07c_component_effects/07c_component_effects_pooled.csv")
functional_effect <- read_output("stage07h_functional_effects/07h_functional_effects_pooled.csv")
all_effects <- data.table::rbindlist(
  list(primary_effect, component_effect, functional_effect),
  use.names = TRUE, fill = TRUE
)
event_counts <- read_output("stage07a_outcome_audit/07a_arm_outcome_counts.csv")

outcome_order <- c(
  "primary_event", "strict_event", "death_component", "death_adl_decline"
)
short_outcome <- c(
  primary_event = "Broad CVD or death",
  strict_event = "MI, stroke, or death",
  death_component = "All-cause death",
  death_adl_decline = "Death or ADL decline"
)

table2_rows <- list()
for (cohort_name in c("HRS", "SHARE")) {
  for (outcome_name in outcome_order) {
    rows <- all_effects[cohort == cohort_name & outcome == outcome_name]
    if (!nrow(rows)) next
    counts <- event_counts[cohort == cohort_name & outcome == outcome_name]
    risk0 <- rows[measure == "risk_continue"]
    risk1 <- rows[measure == "risk_discontinue"]
    rd <- rows[measure == "risk_difference"]
    rr <- rows[measure == "risk_ratio"]
    table2_rows[[length(table2_rows) + 1L]] <- data.table::data.table(
      Cohort = cohort_name,
      Outcome = unname(short_outcome[[outcome_name]]),
      `Events/N` = sprintf("%s/%s", format(sum(counts$events), big.mark = ","),
                           format(sum(counts$outcome_observed_person_trials), big.mark = ",")),
      `3-y risk, % (C/D)` = sprintf(
        "%.1f / %.1f", 100 * risk0$estimate, 100 * risk1$estimate
      ),
      `Risk difference per 1,000 (95% CI); P value` = sprintf(
        "%.1f (%.1f to %.1f); %s", 1000 * rd$estimate,
        1000 * rd$confidence_lower, 1000 * rd$confidence_upper,
        format_p_value(rd$p_value)
      ),
      `Risk ratio (95% CI); P value` = sprintf(
        "%.3f (%.3f to %.3f); %s", rr$estimate,
        rr$confidence_lower, rr$confidence_upper,
        format_p_value(rr$p_value)
      )
    )
  }
}
table2 <- data.table::rbindlist(table2_rows)
write_csv(table2, file.path(table_dir, "Table2_main_effects.csv"))

# -----------------------------------------------------------------------------
# Table 3: interpretable sensitivity analyses that passed prespecified gates.
# -----------------------------------------------------------------------------

overlap_effect <- read_output("stage08a_alternative_weights/08a_effects_pooled.csv")
age_effect <- read_output("stage08b_age_sensitivity/08b_age_effects_pooled.csv")
restricted_effect <- read_output("stage07f_restricted_effects/07f_restricted_effects_pooled.csv")

make_sensitivity_source <- function() {
  p <- data.table::copy(primary_effect)
  p[, `:=`(analysis_key = "primary", Analysis = "Primary IPTW/IPCW")]
  o <- data.table::copy(overlap_effect)
  o[, `:=`(analysis_key = "overlap", Analysis = "Overlap weighting")]
  a <- data.table::copy(age_effect)
  a[, `:=`(analysis_key = "age80", Analysis = "Age 80 y or older")]
  r <- data.table::copy(restricted_effect)
  r[, `:=`(
    analysis_key = ifelse(cohort == "HRS", "restriction_hrs", "restriction_share"),
    Analysis = ifelse(
      cohort == "HRS", "Exclude objective severe deterioration",
      "Exclude 2 or more deterioration markers"
    )
  )]
  data.table::rbindlist(list(p, o, a, r), use.names = TRUE, fill = TRUE)
}

sensitivity_source <- make_sensitivity_source()
sensitivity_source <- sensitivity_source[
  outcome %in% c("primary_event", "death_component") &
    measure %in% c("risk_difference", "risk_ratio")
]
sensitivity_source <- sensitivity_source[
  analysis_key %in% c("primary", "overlap") & outcome == "primary_event" |
    analysis_key == "age80" & cohort == "HRS" & outcome == "primary_event" |
    analysis_key %in% c("restriction_hrs", "restriction_share")
]

table3_rows <- list()
table3_keys <- unique(sensitivity_source[, .(
  cohort, outcome, analysis_key, Analysis
)])
for (i in seq_len(nrow(table3_keys))) {
  key <- table3_keys[i]
  rows <- sensitivity_source[
    cohort == key$cohort & outcome == key$outcome & analysis_key == key$analysis_key
  ]
  rd <- rows[measure == "risk_difference"]
  rr <- rows[measure == "risk_ratio"]
  if (!nrow(rd) || !nrow(rr)) next
  table3_rows[[length(table3_rows) + 1L]] <- data.table::data.table(
    Cohort = key$cohort,
    Outcome = unname(short_outcome[[key$outcome]]),
    Analysis = key$Analysis,
    `Risk difference per 1,000 (95% CI); P value` = sprintf(
      "%.1f (%.1f to %.1f); %s", 1000 * rd$estimate,
      1000 * rd$confidence_lower, 1000 * rd$confidence_upper,
      format_p_value(rd$p_value)
    ),
    `Risk ratio (95% CI); P value` = sprintf(
      "%.3f (%.3f to %.3f); %s", rr$estimate,
      rr$confidence_lower, rr$confidence_upper,
      format_p_value(rr$p_value)
    )
  )
}
table3 <- data.table::rbindlist(table3_rows)
table3[, analysis_order := match(
  Analysis,
  c(
    "Primary IPTW/IPCW", "Overlap weighting", "Age 80 y or older",
    "Exclude objective severe deterioration", "Exclude 2 or more deterioration markers"
  )
)]
data.table::setorder(table3, Cohort, Outcome, analysis_order)
table3[, analysis_order := NULL]
write_csv(table3, file.path(table_dir, "Table3_sensitivity_analyses.csv"))

# -----------------------------------------------------------------------------
# Figure 1: sequential trial design and cohort flow. No title or figure legend
# is embedded in the image.
# -----------------------------------------------------------------------------

flow <- read_output("publication_ready/tables/Figure1_cohort_flow_data.csv")
hrs_flow <- flow[cohort == "HRS"]
share_flow <- flow[cohort == "SHARE"]

box_data <- data.table::rbindlist(list(
  data.table::data.table(
    x = 2.55, y = c(5.25, 4.15, 3.05, 1.95, 0.85),
    label = c(
      sprintf("Harmonized population\n%s persons", format(hrs_flow$harmonized_unique_persons, big.mark = ",")),
      sprintf("Candidate sequences\n%s person-trials", format(hrs_flow$input_person_trials, big.mark = ",")),
      sprintf("Excluded\n%s missing/nonpositive survey weight", format(hrs_flow$excluded_nonpositive_or_missing_survey_weight, big.mark = ",")),
      sprintf("Analytic sample\n%s person-trials; %s persons", format(hrs_flow$analysis_person_trials, big.mark = ","), format(hrs_flow$unique_persons, big.mark = ",")),
      sprintf("Continue: %s    Discontinue: %s", format(hrs_flow$continue_trials, big.mark = ","), format(hrs_flow$discontinue_trials, big.mark = ","))
    ), cohort = "HRS"
  ),
  data.table::data.table(
    x = 7.45, y = c(5.25, 4.15, 3.05, 1.95, 0.85),
    label = c(
      sprintf("Harmonized population\n%s persons", format(share_flow$harmonized_unique_persons, big.mark = ",")),
      sprintf("Candidate sequences\n%s person-trials", format(share_flow$input_person_trials, big.mark = ",")),
      sprintf("Excluded\n%s structural; %s survey weight", format(share_flow$structurally_excluded_person_trials, big.mark = ","), format(share_flow$excluded_nonpositive_or_missing_survey_weight, big.mark = ",")),
      sprintf("Analytic sample\n%s person-trials; %s persons", format(share_flow$analysis_person_trials, big.mark = ","), format(share_flow$unique_persons, big.mark = ",")),
      sprintf("Continue: %s    Discontinue: %s", format(share_flow$continue_trials, big.mark = ","), format(share_flow$discontinue_trials, big.mark = ","))
    ), cohort = "SHARE"
  )
))

timeline <- data.table::data.table(
  x = c(1.5, 5, 8.5), y = 8.25,
  label = c(
    "Prior visit (B)\nMedication use and\npre-treatment covariates",
    "Landmark visit (L)\nDiscontinue or continue\nTime zero",
    "Follow-up (F)\nCVD, death, and ADL\n3-year risk"
  )
)

figure1 <- ggplot2::ggplot() +
  ggplot2::annotate("text", x = 0.15, y = 9.25, label = "A", hjust = 0,
                    family = font_family, fontface = "bold", size = 4.4) +
  ggplot2::annotate("text", x = 0.15, y = 6.55, label = "B", hjust = 0,
                    family = font_family, fontface = "bold", size = 4.4) +
  ggplot2::annotate(
    "segment", x = 2.75, xend = 3.65, y = 8.25, yend = 8.25,
    linewidth = 0.55, colour = gray,
    arrow = grid::arrow(length = grid::unit(0.085, "inches"), type = "closed")
  ) +
  ggplot2::annotate(
    "segment", x = 6.35, xend = 7.25, y = 8.25, yend = 8.25,
    linewidth = 0.55, colour = gray,
    arrow = grid::arrow(length = grid::unit(0.085, "inches"), type = "closed")
  ) +
  ggplot2::annotate("text", x = 3.25, y = 8.55, label = "1-4 y",
                    family = font_family, size = 3.0) +
  ggplot2::annotate("text", x = 6.75, y = 8.55, label = "2-4 y",
                    family = font_family, size = 3.0) +
  ggplot2::geom_label(
    data = timeline, ggplot2::aes(x = x, y = y, label = label),
    family = font_family, size = 3.10, lineheight = 0.95,
    linewidth = 0.35, label.padding = grid::unit(0.18, "lines"),
    fill = "white", colour = "black"
  ) +
  ggplot2::annotate("text", x = 2.55, y = 6.15, label = "HRS",
                    family = font_family, fontface = "bold", size = 3.9, colour = blue) +
  ggplot2::annotate("text", x = 7.45, y = 6.15, label = "SHARE",
                    family = font_family, fontface = "bold", size = 3.9, colour = orange) +
  ggplot2::geom_label(
    data = box_data,
    ggplot2::aes(x = x, y = y, label = label, colour = cohort, fill = cohort),
    family = font_family, size = 3.0, lineheight = 0.95,
    linewidth = 0.35, label.padding = grid::unit(0.16, "lines")
  ) +
  ggplot2::geom_segment(
    data = data.table::data.table(
      x = rep(c(2.55, 7.45), each = 4),
      xend = rep(c(2.55, 7.45), each = 4),
      y = rep(c(4.84, 3.74, 2.64, 1.54), 2),
      yend = rep(c(4.56, 3.46, 2.36, 1.26), 2)
    ),
    ggplot2::aes(x = x, xend = xend, y = y, yend = yend),
    linewidth = 0.45, colour = gray,
    arrow = grid::arrow(length = grid::unit(0.08, "inches"), type = "closed")
  ) +
  ggplot2::scale_colour_manual(values = c(HRS = blue, SHARE = orange), guide = "none") +
  ggplot2::scale_fill_manual(values = c(HRS = "#EAF4F9", SHARE = "#FCEFEA"), guide = "none") +
  ggplot2::coord_cartesian(xlim = c(0, 10), ylim = c(0.30, 9.5), clip = "off") +
  ggplot2::theme_void(base_family = font_family) +
  ggplot2::theme(plot.margin = ggplot2::margin(5, 8, 5, 8))

save_drawing(
  function() print(figure1), "Figure1_study_design_and_flow",
  width = 7.2, height = 7.0, tiff_dpi = 1200
)

# -----------------------------------------------------------------------------
# Figure 2: absolute and relative cohort-specific effects.
# -----------------------------------------------------------------------------

figure2_data <- all_effects[
  outcome %in% outcome_order & measure %in% c("risk_difference", "risk_ratio")
]
figure2_data[, outcome_label := factor(
  unname(short_outcome[outcome]), levels = rev(unname(short_outcome[outcome_order]))
)]
figure2_data[, cohort := factor(cohort, levels = c("HRS", "SHARE"))]

rd_data <- figure2_data[measure == "risk_difference"]
rd_data[, `:=`(
  estimate_plot = 1000 * estimate,
  lower_plot = 1000 * confidence_lower,
  upper_plot = 1000 * confidence_upper,
  p_label = format_p_label(p_value)
)]
rr_data <- figure2_data[measure == "risk_ratio"]
rr_data[, p_label := format_p_label(p_value)]

figure2_rd <- ggplot2::ggplot(
  rd_data,
  ggplot2::aes(y = outcome_label, x = estimate_plot, colour = cohort, shape = cohort)
) +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.45, colour = gray) +
  ggplot2::geom_errorbar(
    ggplot2::aes(xmin = lower_plot, xmax = upper_plot),
    orientation = "y", position = ggplot2::position_dodge(width = 0.48),
    width = 0.18, linewidth = 0.65
  ) +
  ggplot2::geom_point(position = ggplot2::position_dodge(width = 0.48), size = 2.6) +
  ggplot2::geom_text(
    ggplot2::aes(x = 137, label = p_label),
    position = ggplot2::position_dodge(width = 0.48),
    hjust = 0, size = 3.0, show.legend = FALSE
  ) +
  ggplot2::scale_colour_manual(values = c(HRS = blue, SHARE = orange)) +
  ggplot2::scale_shape_manual(values = c(HRS = 16, SHARE = 17)) +
  ggplot2::scale_x_continuous(
    breaks = c(-20, 0, 20, 40, 60, 80, 100, 120),
    limits = c(-20, 180)
  ) +
  ggplot2::labs(x = "3-year risk difference per 1,000", y = NULL, tag = "A") +
  theme_jaha() +
  ggplot2::theme(legend.position = "none")

figure2_rr <- ggplot2::ggplot(
  rr_data,
  ggplot2::aes(y = outcome_label, x = estimate, colour = cohort, shape = cohort)
) +
  ggplot2::geom_vline(xintercept = 1, linetype = "dashed", linewidth = 0.45, colour = gray) +
  ggplot2::geom_errorbar(
    ggplot2::aes(xmin = confidence_lower, xmax = confidence_upper),
    orientation = "y", position = ggplot2::position_dodge(width = 0.48),
    width = 0.18, linewidth = 0.65
  ) +
  ggplot2::geom_point(position = ggplot2::position_dodge(width = 0.48), size = 2.6) +
  ggplot2::geom_text(
    ggplot2::aes(x = 2.15, label = p_label),
    position = ggplot2::position_dodge(width = 0.48),
    hjust = 0, size = 3.0, show.legend = FALSE
  ) +
  ggplot2::scale_colour_manual(values = c(HRS = blue, SHARE = orange)) +
  ggplot2::scale_shape_manual(values = c(HRS = 16, SHARE = 17)) +
  ggplot2::scale_x_log10(
    breaks = c(0.8, 1, 1.25, 1.5, 2), limits = c(0.78, 2.80)
  ) +
  ggplot2::labs(x = "Risk ratio", y = NULL, tag = "B") +
  theme_jaha() +
  ggplot2::theme(
    legend.position = "none",
    axis.text.y = ggplot2::element_blank(),
    axis.ticks.y = ggplot2::element_blank()
  )

draw_figure2 <- function() {
  grid::grid.newpage()
  layout <- grid::grid.layout(
    nrow = 2, ncol = 2,
    widths = grid::unit(c(0.60, 0.40), "null"),
    heights = grid::unit(c(0.92, 0.08), "null")
  )
  grid::pushViewport(grid::viewport(layout = layout))
  print(figure2_rd, vp = grid::viewport(layout.pos.row = 1, layout.pos.col = 1))
  print(figure2_rr, vp = grid::viewport(layout.pos.row = 1, layout.pos.col = 2))
  grid::pushViewport(grid::viewport(layout.pos.row = 2, layout.pos.col = 1:2))
  grid::grid.points(x = grid::unit(0.40, "npc"), y = grid::unit(0.5, "npc"),
                    pch = 16, size = grid::unit(2.3, "mm"), gp = grid::gpar(col = blue, fill = blue))
  grid::grid.text("HRS", x = grid::unit(0.44, "npc"), y = grid::unit(0.5, "npc"),
                  just = "left", gp = grid::gpar(fontfamily = font_family, fontsize = 10))
  grid::grid.points(x = grid::unit(0.53, "npc"), y = grid::unit(0.5, "npc"),
                    pch = 17, size = grid::unit(2.5, "mm"), gp = grid::gpar(col = orange, fill = orange))
  grid::grid.text("SHARE", x = grid::unit(0.57, "npc"), y = grid::unit(0.5, "npc"),
                  just = "left", gp = grid::gpar(fontfamily = font_family, fontsize = 10))
  grid::popViewport(2)
}

save_drawing(
  draw_figure2, "Figure2_cohort_specific_effects",
  width = 7.2, height = 5.4, tiff_dpi = 1200
)

# -----------------------------------------------------------------------------
# Figure 3: continuous frailty effect modification curves.
# -----------------------------------------------------------------------------

frailty_curve <- read_output("stage07j_frailty_interaction/07j_effect_curve_pooled.csv")
frailty_curve <- frailty_curve[measure == "risk_difference" & FI >= 0.08 & FI <= 0.40]
frailty_curve[, outcome_panel := factor(
  outcome,
  levels = c("primary_event", "death_adl_decline"),
  labels = c("A  Broad CVD or death", "B  Death or ADL decline")
)]
frailty_curve[, cohort := factor(cohort, levels = c("HRS", "SHARE"))]

frailty_interaction <- read_output(
  "stage07j_frailty_interaction/07j_interaction_pooled.csv"
)
frailty_interaction[, outcome_panel := factor(
  outcome,
  levels = c("primary_event", "death_adl_decline"),
  labels = c("A  Broad CVD or death", "B  Death or ADL decline")
)]
frailty_interaction[, cohort := factor(cohort, levels = c("HRS", "SHARE"))]
frailty_panel_range <- frailty_curve[, .(
  panel_min = min(confidence_lower_per_1000, na.rm = TRUE),
  panel_max = max(confidence_upper_per_1000, na.rm = TRUE)
), by = outcome_panel]
frailty_interaction <- merge(
  frailty_interaction, frailty_panel_range, by = "outcome_panel", all.x = TRUE
)
frailty_interaction[, `:=`(
  label_x = 0.09,
  label_y = panel_max - (as.integer(cohort) - 1) * 0.105 * (panel_max - panel_min),
  p_label = paste0(as.character(cohort), ": ", sub("^P", "P for interaction", format_p_label(p_interaction)))
)]

figure3 <- ggplot2::ggplot(
  frailty_curve,
  ggplot2::aes(x = FI, y = estimate_per_1000, colour = cohort, fill = cohort, linetype = cohort)
) +
  ggplot2::geom_hline(yintercept = 0, linetype = "dashed", linewidth = 0.45, colour = gray) +
  ggplot2::geom_ribbon(
    ggplot2::aes(ymin = confidence_lower_per_1000, ymax = confidence_upper_per_1000),
    alpha = 0.13, colour = NA
  ) +
  ggplot2::geom_line(linewidth = 0.85) +
  ggplot2::geom_text(
    data = frailty_interaction,
    ggplot2::aes(x = label_x, y = label_y, label = p_label, colour = cohort),
    inherit.aes = FALSE, hjust = 0, size = 3.0, show.legend = FALSE
  ) +
  ggplot2::facet_wrap(~outcome_panel, nrow = 1, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c(HRS = blue, SHARE = orange)) +
  ggplot2::scale_fill_manual(values = c(HRS = blue, SHARE = orange)) +
  ggplot2::scale_linetype_manual(values = c(HRS = "solid", SHARE = "22")) +
  ggplot2::scale_x_continuous(breaks = c(0.10, 0.20, 0.30, 0.40)) +
  ggplot2::labs(
    x = "Pre-treatment frailty index",
    y = "3-year risk difference per 1,000"
  ) +
  theme_jaha() +
  ggplot2::theme(legend.position = "bottom", panel.spacing = grid::unit(0.6, "lines"))

save_drawing(
  function() print(figure3), "Figure3_frailty_effect_modification",
  width = 7.2, height = 4.5, tiff_dpi = 600
)

# -----------------------------------------------------------------------------
# Figure 4: sensitivity analyses for the primary outcome.
# -----------------------------------------------------------------------------

figure4_data <- sensitivity_source[
  outcome == "primary_event" & measure == "risk_difference"
]
figure4_data[, `:=`(
  estimate_plot = 1000 * estimate,
  lower_plot = 1000 * confidence_lower,
  upper_plot = 1000 * confidence_upper,
  p_label = format_p_label(p_value),
  analysis_short = data.table::fcase(
    Analysis == "Primary IPTW/IPCW", "Primary IPTW/IPCW",
    Analysis == "Overlap weighting", "Overlap weighting",
    Analysis == "Age 80 y or older", "Age 80 y or older",
    Analysis == "Exclude objective severe deterioration", "Exclude severe deterioration",
    Analysis == "Exclude 2 or more deterioration markers", "Exclude multiple deterioration markers",
    default = Analysis
  )
)]
figure4_data[, analysis_short := factor(
  analysis_short,
  levels = rev(c(
    "Primary IPTW/IPCW", "Overlap weighting", "Age 80 y or older",
    "Exclude severe deterioration", "Exclude multiple deterioration markers"
  ))
)]
figure4_data[, cohort := factor(cohort, levels = c("HRS", "SHARE"))]

figure4 <- ggplot2::ggplot(
  figure4_data,
  ggplot2::aes(y = analysis_short, x = estimate_plot, colour = cohort, shape = cohort)
) +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.45, colour = gray) +
  ggplot2::geom_errorbar(
    ggplot2::aes(xmin = lower_plot, xmax = upper_plot),
    orientation = "y", position = ggplot2::position_dodge(width = 0.42),
    width = 0.16, linewidth = 0.65
  ) +
  ggplot2::geom_point(position = ggplot2::position_dodge(width = 0.42), size = 2.7) +
  ggplot2::geom_text(
    ggplot2::aes(x = 168, label = p_label),
    position = ggplot2::position_dodge(width = 0.42),
    hjust = 0, size = 3.0, show.legend = FALSE
  ) +
  ggplot2::scale_colour_manual(values = c(HRS = blue, SHARE = orange)) +
  ggplot2::scale_shape_manual(values = c(HRS = 16, SHARE = 17)) +
  ggplot2::scale_x_continuous(
    breaks = c(-40, 0, 40, 80, 120, 160), limits = c(-40, 220)
  ) +
  ggplot2::labs(x = "3-year risk difference per 1,000", y = NULL) +
  theme_jaha() +
  ggplot2::theme(legend.position = "bottom")

save_drawing(
  function() print(figure4), "Figure4_primary_outcome_sensitivity",
  width = 7.2, height = 4.2, tiff_dpi = 1200
)

