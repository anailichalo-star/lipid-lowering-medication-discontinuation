# Reusable statistical helpers for Stage 06.

tte_inverse_information <- function(information_matrix) {
  information_matrix <- (information_matrix + t(information_matrix)) / 2
  chol_factor <- tryCatch(chol(information_matrix), error = function(e) NULL)
  if (!is.null(chol_factor)) return(chol2inv(chol_factor))
  tryCatch(
    qr.solve(information_matrix, diag(nrow(information_matrix)), tol = 1e-10),
    error = function(e) stop(
      "Outcome-model information matrix is singular: ", conditionMessage(e),
      call. = FALSE
    )
  )
}

tte_cluster_vcov_glm <- function(fit, cluster) {
  if (!inherits(fit, "glm")) stop("fit must inherit from glm.", call. = FALSE)
  coefficient <- stats::coef(fit)
  if (anyNA(coefficient)) {
    stop("Cluster covariance is undefined because the model has aliased coefficients.", call. = FALSE)
  }

  model_matrix <- stats::model.matrix(fit)
  model_frame <- stats::model.frame(fit)
  response <- stats::model.response(model_frame)
  if (is.matrix(response)) response <- response[, 1L]
  response <- as.numeric(response)
  cluster <- as.character(cluster)
  if (length(cluster) != nrow(model_matrix) || anyNA(cluster) || any(!nzchar(cluster))) {
    stop("Cluster identifier is missing or does not align with model rows.", call. = FALSE)
  }

  mu <- as.numeric(stats::fitted(fit))
  eta <- as.numeric(fit$linear.predictors)
  derivative <- as.numeric(fit$family$mu.eta(eta))
  variance <- as.numeric(fit$family$variance(mu))
  prior_weight <- as.numeric(fit$prior.weights)
  safe <- is.finite(variance) & variance > 0 & is.finite(derivative) &
    is.finite(prior_weight) & prior_weight > 0
  if (!all(safe)) stop("Non-finite GLM score components were encountered.", call. = FALSE)

  score_scalar <- prior_weight * (response - mu) * derivative / variance
  score_by_row <- model_matrix * score_scalar
  score_by_cluster <- rowsum(score_by_row, group = cluster, reorder = FALSE)

  working_weight <- as.numeric(fit$weights)
  information <- crossprod(model_matrix, model_matrix * working_weight)
  inverse_information <- tte_inverse_information(information)

  observation_n <- nrow(model_matrix)
  coefficient_n <- ncol(model_matrix)
  cluster_n <- nrow(score_by_cluster)
  if (cluster_n <= 1L || observation_n <= coefficient_n) {
    stop("Too few independent clusters or observations for robust inference.", call. = FALSE)
  }
  correction <- (cluster_n / (cluster_n - 1)) *
    ((observation_n - 1) / (observation_n - coefficient_n))
  meat <- crossprod(score_by_cluster) * correction
  covariance <- inverse_information %*% meat %*% inverse_information
  covariance <- (covariance + t(covariance)) / 2
  dimnames(covariance) <- list(colnames(model_matrix), colnames(model_matrix))
  if (any(!is.finite(covariance)) || any(diag(covariance) < -1e-12)) {
    stop("The cluster-robust covariance matrix is not valid.", call. = FALSE)
  }

  list(
    vcov = covariance,
    clusters = cluster_n,
    observations = observation_n,
    coefficients = coefficient_n,
    correction = correction
  )
}

tte_cloglog_probability <- function(linear_predictor) {
  cumulative_hazard <- exp(pmin(as.numeric(linear_predictor), 700))
  -expm1(-cumulative_hazard)
}

tte_cloglog_derivative <- function(linear_predictor) {
  cumulative_hazard <- exp(pmin(as.numeric(linear_predictor), 700))
  cumulative_hazard * exp(-cumulative_hazard)
}

tte_prediction_design <- function(fit, newdata) {
  design <- stats::model.matrix(
    stats::delete.response(stats::terms(fit)),
    data = newdata,
    contrasts.arg = fit$contrasts,
    xlev = fit$xlevels
  )
  coefficient_names <- names(stats::coef(fit))
  missing_columns <- setdiff(coefficient_names, colnames(design))
  if (length(missing_columns)) {
    stop(
      "Prediction design matrix is missing columns: ",
      paste(missing_columns, collapse = ", "), call. = FALSE
    )
  }
  design[, coefficient_names, drop = FALSE]
}

tte_standardized_cloglog_effects <- function(
  fit, robust_vcov, target_data, standardization_weight, target_years
) {
  standardization_weight <- suppressWarnings(as.numeric(standardization_weight))
  valid_weight <- is.finite(standardization_weight) & standardization_weight > 0
  if (!all(valid_weight)) {
    stop("Standardization weights must all be finite and positive.", call. = FALSE)
  }
  normalized_weight <- standardization_weight / sum(standardization_weight)

  arm_result <- lapply(c(0L, 1L), function(arm) {
    counterfactual <- as.data.frame(target_data)
    counterfactual$treatment <- arm
    counterfactual$followup_time_years <- target_years
    linear_predictor <- as.numeric(stats::predict(
      fit, newdata = counterfactual, type = "link"
    ))
    design <- tte_prediction_design(fit, counterfactual)
    probability <- tte_cloglog_probability(linear_predictor)
    derivative <- tte_cloglog_derivative(linear_predictor)
    risk <- sum(normalized_weight * probability)
    gradient <- colSums(design * (normalized_weight * derivative))
    list(risk = risk, gradient = gradient)
  })

  risk_continue <- arm_result[[1L]]$risk
  risk_discontinue <- arm_result[[2L]]$risk
  gradient_continue <- arm_result[[1L]]$gradient
  gradient_discontinue <- arm_result[[2L]]$gradient
  gradient_matrix <- rbind(gradient_continue, gradient_discontinue)
  risk_covariance <- gradient_matrix %*% robust_vcov %*% t(gradient_matrix)
  risk_covariance <- (risk_covariance + t(risk_covariance)) / 2

  if (!is.finite(risk_continue) || !is.finite(risk_discontinue) ||
      risk_continue <= 0 || risk_discontinue <= 0 ||
      risk_continue >= 1 || risk_discontinue >= 1) {
    stop("A standardized risk is outside the open interval (0, 1).", call. = FALSE)
  }

  risk_difference <- risk_discontinue - risk_continue
  gradient_difference <- gradient_discontinue - gradient_continue
  variance_difference <- as.numeric(
    t(gradient_difference) %*% robust_vcov %*% gradient_difference
  )

  log_risk_ratio <- log(risk_discontinue / risk_continue)
  gradient_log_ratio <- gradient_discontinue / risk_discontinue -
    gradient_continue / risk_continue
  variance_log_ratio <- as.numeric(
    t(gradient_log_ratio) %*% robust_vcov %*% gradient_log_ratio
  )

  list(
    risk_continue = risk_continue,
    risk_discontinue = risk_discontinue,
    risk_covariance = risk_covariance,
    risk_difference = risk_difference,
    variance_risk_difference = variance_difference,
    log_risk_ratio = log_risk_ratio,
    variance_log_risk_ratio = variance_log_ratio
  )
}

tte_logit <- function(probability) {
  probability <- pmax(1e-10, pmin(1 - 1e-10, probability))
  log(probability / (1 - probability))
}

tte_expit <- function(value) 1 / (1 + exp(-value))

tte_pool_scalar <- function(estimates, within_variances, df_complete, null = 0) {
  estimates <- as.numeric(estimates)
  within_variances <- as.numeric(within_variances)
  valid <- is.finite(estimates) & is.finite(within_variances) & within_variances >= 0
  if (!all(valid) || length(estimates) < 2L) {
    stop("Invalid inputs supplied to Rubin pooling.", call. = FALSE)
  }
  m <- length(estimates)
  q_bar <- mean(estimates)
  u_bar <- mean(within_variances)
  between <- stats::var(estimates)
  total <- u_bar + (1 + 1 / m) * between
  if (!is.finite(total) || total <= 0) {
    stop("Rubin total variance is not positive.", call. = FALSE)
  }

  added <- (1 + 1 / m) * between
  lambda <- if (total > 0) min(1, max(0, added / total)) else 0
  if (added <= .Machine$double.eps * max(1, u_bar)) {
    df_old <- Inf
  } else if (u_bar <= .Machine$double.eps) {
    df_old <- m - 1
  } else {
    relative_increase <- added / u_bar
    df_old <- (m - 1) * (1 + 1 / relative_increase)^2
  }
  df_complete <- max(1, as.numeric(df_complete))
  df_observed <- ((df_complete + 1) / (df_complete + 3)) *
    df_complete * (1 - lambda)
  degrees_freedom <- if (is.infinite(df_old)) {
    df_observed
  } else if (df_observed <= 0) {
    df_old
  } else {
    1 / (1 / df_old + 1 / df_observed)
  }
  degrees_freedom <- max(1, degrees_freedom)
  standard_error <- sqrt(total)
  critical <- stats::qt(0.975, df = degrees_freedom)
  test_statistic <- (q_bar - null) / standard_error
  p_value <- 2 * stats::pt(-abs(test_statistic), df = degrees_freedom)
  relative_increase <- if (u_bar > 0) added / u_bar else Inf
  fraction_missing_information <- if (is.finite(relative_increase)) {
    (relative_increase + 2 / (degrees_freedom + 3)) /
      (relative_increase + 1)
  } else {
    1
  }

  list(
    estimate = q_bar,
    standard_error = standard_error,
    lower = q_bar - critical * standard_error,
    upper = q_bar + critical * standard_error,
    p_value = p_value,
    degrees_freedom = degrees_freedom,
    within_variance = u_bar,
    between_variance = between,
    total_variance = total,
    relative_increase_variance = relative_increase,
    fraction_missing_information = fraction_missing_information,
    imputations = m
  )
}
