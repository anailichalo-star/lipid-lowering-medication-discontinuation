# Pure helper functions used by the sequential person-trial builder.

tte_year_fraction <- function(later, earlier) {
  as.numeric(as.Date(later) - as.Date(earlier)) / 365.25
}

tte_valid_interval <- function(later, earlier, minimum_years, maximum_years) {
  days <- as.numeric(as.Date(later) - as.Date(earlier))
  # A calendar year can contain 365 or 366 days. The one-day tolerance keeps
  # exact visit anniversaries on the prespecified boundary.
  lower_days <- minimum_years * 365.25 - 1
  upper_days <- maximum_years * 365.25 + 1
  !is.na(days) & days >= lower_days & days <= upper_days
}

tte_any_binary <- function(...) {
  values <- cbind(...)
  if (is.null(dim(values))) values <- matrix(values, ncol = 1L)
  observed <- rowSums(!is.na(values))
  positive <- rowSums(values == 1L, na.rm = TRUE)
  result <- rep(NA_integer_, nrow(values))
  result[positive > 0L] <- 1L
  result[positive == 0L & observed == ncol(values)] <- 0L
  result
}

tte_choose_value <- function(first, second, choice) {
  result <- first
  result[choice == 2L & !is.na(choice)] <- second[choice == 2L & !is.na(choice)]
  result[is.na(choice)] <- NA
  result
}

tte_midpoint_date <- function(start, end) {
  start <- as.Date(start)
  end <- as.Date(end)
  as.Date(as.numeric(start) + floor(as.numeric(end - start) / 2), origin = "1970-01-01")
}

# In the authorised ELSA Wave 0-5 index, positive mortwave codes use the
# tens digit for the wave by which the death was identified. Codes 0, -3 and
# -5 do not establish an incident death wave and remain missing here.
tte_elsa_mortwave_death_wave <- function(mortwave) {
  value <- suppressWarnings(as.integer(mortwave))
  valid_codes <- c(
    11L, 12L, 13L,
    21L, 22L, 23L,
    31L, 32L, 33L,
    41L, 42L, 43L,
    51L, 52L, 53L,
    61L, 62L, 63L
  )
  result <- rep(NA_integer_, length(value))
  valid <- !is.na(value) & value %in% valid_codes
  result[valid] <- value[valid] %/% 10L
  result
}

tte_elsa_mortwave_covered <- function(mortwave, linked) {
  value <- suppressWarnings(as.integer(mortwave))
  linked <- !is.na(linked) & as.logical(linked)
  as.integer(linked & !is.na(value) & (value == 0L | value > 0L))
}

tte_recode_binary_strict <- function(x) {
  result <- suppressWarnings(as.integer(x))
  result[!result %in% c(0L, 1L)] <- NA_integer_
  result
}
