# Run from the project root. Use the original Stage 05 imputations and isolate the rerun.
run_corrected_deterioration <- function() {
  destination <- file.path(getwd(), "outputs_r", "revision_r1", "deterioration_corrected")
  previous <- options(tte.restriction_output_root = destination)
  on.exit(options(previous), add = TRUE)
  source("R/_stage1_helpers.R", encoding = "UTF-8", local = TRUE)
  test <- tte_self_rated_health_worsened(c(5, 1, 3, 3, NA), c(4, 3, 3, NA, 2))
  stopifnot(identical(test, c(1L, 0L, 0L, NA_integer_, NA_integer_)))

  run_stage <- function(file) {
    message("Running ", file)
    source(file.path("R", file), encoding = "UTF-8", local = new.env(parent = globalenv()))
  }
  run_stage("revision/07d_audit_pre_landmark_deterioration.R")
  run_stage("07e_build_restricted_sensitivity_weights.R")
  gate <- tte_read_csv_utf8(file.path(destination, "stage07e_restricted_weights", "07e_weighting_gate.csv"))
  ready <- tolower(as.character(gate$ready_for_restricted_effect_estimation)) == "true"
  stopifnot(nrow(gate) == 12L, !anyNA(ready))
  if (any(ready)) run_stage("07f_estimate_restricted_sensitivity_effects.R")
  message(sum(ready), " of ", length(ready), " restricted analyses passed every gate.")
}

run_corrected_deterioration()
