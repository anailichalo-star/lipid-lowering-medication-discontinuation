# Historical analysis for reproducing the original submission.
# Use the R1 workflow to apply the corrected deterioration indicator.
# Stage 04d: prepare temporally ordered, model-ready baseline covariates.
# This stage does not impute data, fit propensity scores, or estimate effects.

options(stringsAsFactors = FALSE)

project_root <- getOption("tte.project_root", Sys.getenv("TTE_PROJECT_ROOT", unset = normalizePath(".", winslash = "/", mustWork = FALSE)))
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "data.table"))

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
stage03_dir <- file.path(project_root, config$output_root, "stage03_current")
input_dir <- file.path(stage03_dir, "private_do_not_share")
output_dir <- file.path(project_root, config$output_root, "stage04_model_prep")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
trial_parts <- lapply(cohorts, function(cohort_name) {
  path <- file.path(input_dir, paste0(tolower(cohort_name), "_person_trials_PRIVATE.rds"))
  if (!file.exists(path)) stop("Missing person-trial file: ", path, call. = FALSE)
  data.table::as.data.table(readRDS(path))
})
trials <- data.table::rbindlist(trial_parts, use.names = TRUE, fill = TRUE)

coalesce_two <- function(primary, fallback) {
  out <- primary
  use_fallback <- is.na(out) & !is.na(fallback)
  out[use_fallback] <- fallback[use_fallback]
  out
}

complete_row_sum <- function(data, variables) {
  for (variable_name in setdiff(variables, names(data))) {
    data.table::set(data, j = variable_name, value = NA_real_)
  }
  values <- as.matrix(data[, ..variables])
  storage.mode(values) <- "numeric"
  result <- rowSums(values, na.rm = FALSE)
  result[rowSums(!is.na(values)) < length(variables)] <- NA_real_
  result
}

complete_cognition <- function(data, prefix) {
  variables <- paste0(
    prefix,
    c("cognition_immediate", "cognition_delayed", "cognition_serial7", "cognition_orientation")
  )
  complete_row_sum(data, variables)
}

frailty_to_zero_one <- function(x, scale_divisor) {
  value <- suppressWarnings(as.numeric(x)) / scale_divisor
  value[!is.finite(value) | value < 0 | value > 1] <- NA_real_
  value
}

common_suffixes <- c(
  "age", "sex", "education", "marital_status", "income", "living_arrangement",
  "high_cholesterol", "self_rated_health", "bmi", "current_smoking",
  "alcohol_use", "hypertension", "diabetes", "cancer", "lung_disease",
  "arthritis", "depression_score", "hospitalization", "frailty_existing",
  "physical_activity", "physical_activity_vigorous", "physical_activity_moderate",
  "country"
)
for (prefix in c("E_", "L_")) {
  for (variable_name in paste0(prefix, common_suffixes)) {
    if (!variable_name %in% names(trials)) data.table::set(trials, j = variable_name, value = NA)
  }
}

adl_suffixes <- c("adl_dressing", "adl_bathing", "adl_eating", "adl_transfer", "adl_toileting")
iadl_suffixes <- c("iadl_money", "iadl_phone", "iadl_medications", "iadl_meals", "iadl_shopping")
trials[, E_adl5_count := complete_row_sum(.SD, paste0("E_", adl_suffixes))]
trials[, E_iadl5_count := complete_row_sum(.SD, paste0("E_", iadl_suffixes))]
if (!"L_adl5_count" %in% names(trials)) {
  trials[, L_adl5_count := complete_row_sum(.SD, paste0("L_", adl_suffixes))]
}
if (!"L_iadl5_count" %in% names(trials)) {
  trials[, L_iadl5_count := complete_row_sum(.SD, paste0("L_", iadl_suffixes))]
}
trials[, E_cognition_total := complete_cognition(.SD, "E_")]
trials[, L_cognition_total := complete_cognition(.SD, "L_")]

frailty_scale_rows <- list()
scale_index <- 0L
for (cohort_name in cohorts) {
  cohort_selector <- trials$cohort == cohort_name
  combined_fi <- c(
    suppressWarnings(as.numeric(trials$E_frailty_existing[cohort_selector])),
    suppressWarnings(as.numeric(trials$L_frailty_existing[cohort_selector]))
  )
  combined_fi <- combined_fi[is.finite(combined_fi)]
  scale_divisor <- if (length(combined_fi) && stats::median(combined_fi) > 1) 100 else 1
  trials[cohort == cohort_name, E_frailty_01 := frailty_to_zero_one(E_frailty_existing, scale_divisor)]
  trials[cohort == cohort_name, L_frailty_01 := frailty_to_zero_one(L_frailty_existing, scale_divisor)]

  for (time_name in c("E", "L")) {
    original <- suppressWarnings(as.numeric(
      trials[cohort == cohort_name][[paste0(time_name, "_frailty_existing")]]
    ))
    normalized <- suppressWarnings(as.numeric(
      trials[cohort == cohort_name][[paste0(time_name, "_frailty_01")]]
    ))
    scale_index <- scale_index + 1L
    frailty_scale_rows[[scale_index]] <- data.frame(
      cohort = cohort_name,
      assessment_time = time_name,
      person_trials = sum(cohort_selector),
      original_nonmissing_n = sum(is.finite(original)),
      original_median = if (any(is.finite(original))) stats::median(original, na.rm = TRUE) else NA_real_,
      scale_divisor = scale_divisor,
      normalized_nonmissing_n = sum(is.finite(normalized)),
      normalized_minimum = if (any(is.finite(normalized))) min(normalized, na.rm = TRUE) else NA_real_,
      normalized_median = if (any(is.finite(normalized))) stats::median(normalized, na.rm = TRUE) else NA_real_,
      normalized_maximum = if (any(is.finite(normalized))) max(normalized, na.rm = TRUE) else NA_real_,
      stringsAsFactors = FALSE
    )
  }
}
frailty_rescaling <- data.table::rbindlist(frailty_scale_rows, use.names = TRUE, fill = TRUE)

simple_map <- c(
  B_age = "age",
  B_sex = "sex",
  B_education = "education",
  B_marital_status = "marital_status",
  B_income = "income",
  B_living_arrangement = "living_arrangement",
  B_self_rated_health = "self_rated_health",
  B_bmi = "bmi",
  B_current_smoking = "current_smoking",
  B_alcohol_use = "alcohol_use",
  B_hypertension = "hypertension",
  B_diabetes = "diabetes",
  B_cancer = "cancer",
  B_lung_disease = "lung_disease",
  B_arthritis = "arthritis",
  B_depression_score = "depression_score",
  B_hospitalization = "hospitalization",
  B_physical_activity = "physical_activity",
  B_physical_activity_vigorous = "physical_activity_vigorous",
  B_physical_activity_moderate = "physical_activity_moderate",
  B_country = "country"
)

source_columns <- character()
for (baseline_name in names(simple_map)) {
  suffix <- simple_map[[baseline_name]]
  landmark_name <- paste0("L_", suffix)
  prior_name <- paste0("E_", suffix)
  trials[, (baseline_name) := coalesce_two(get(landmark_name), get(prior_name))]
  source_name <- paste0(baseline_name, "_source")
  trials[, (source_name) := data.table::fcase(
    !is.na(get(landmark_name)), "landmark",
    is.na(get(landmark_name)) & !is.na(get(prior_name)), "prior_fallback",
    default = "missing"
  )]
  source_columns <- c(source_columns, source_name)
}

derived_map <- list(
  B_adl5_count = c("L_adl5_count", "E_adl5_count"),
  B_iadl5_count = c("L_iadl5_count", "E_iadl5_count"),
  B_cognition_total = c("L_cognition_total", "E_cognition_total"),
  B_frailty_01 = c("L_frailty_01", "E_frailty_01")
)
for (baseline_name in names(derived_map)) {
  landmark_name <- derived_map[[baseline_name]][[1L]]
  prior_name <- derived_map[[baseline_name]][[2L]]
  trials[, (baseline_name) := coalesce_two(get(landmark_name), get(prior_name))]
  source_name <- paste0(baseline_name, "_source")
  trials[, (source_name) := data.table::fcase(
    !is.na(get(landmark_name)), "landmark",
    is.na(get(landmark_name)) & !is.na(get(prior_name)), "prior_fallback",
    default = "missing"
  )]
  source_columns <- c(source_columns, source_name)
}

# The treatment cohort already requires medication use at E. Prior high-cholesterol
# diagnosis is retained for sensitivity analysis only; the landmark version is not
# placed in the primary treatment model because it is contemporaneous with and
# empirically close to deterministic of reported medication status.
trials[, B_high_cholesterol_prior := E_high_cholesterol]

trials[, B_income_rank := {
  result <- rep(NA_real_, .N)
  observed <- is.finite(suppressWarnings(as.numeric(B_income)))
  if (any(observed)) {
    result[observed] <- rank(
      suppressWarnings(as.numeric(B_income))[observed],
      ties.method = "average"
    ) / (sum(observed) + 1)
  }
  result
}, by = .(cohort, sequence, B_country)]

trials[, `:=`(
  delta_frailty_01 = L_frailty_01 - E_frailty_01,
  delta_adl5_count = L_adl5_count - E_adl5_count,
  delta_iadl5_count = L_iadl5_count - E_iadl5_count,
  delta_bmi = suppressWarnings(as.numeric(L_bmi)) - suppressWarnings(as.numeric(E_bmi)),
  self_rated_health_worsened = data.table::fcase(
    !is.na(L_self_rated_health) & !is.na(E_self_rated_health),
    as.integer(suppressWarnings(as.numeric(L_self_rated_health)) >
      suppressWarnings(as.numeric(E_self_rated_health))),
    default = NA_integer_
  )
)]

model_candidates <- c(
  "B_age", "B_sex", "B_education", "B_marital_status", "B_income_rank",
  "B_living_arrangement", "B_self_rated_health", "B_bmi",
  "B_current_smoking", "B_alcohol_use", "B_hypertension", "B_diabetes",
  "B_cancer", "B_lung_disease", "B_arthritis", "B_depression_score",
  "B_hospitalization", "B_adl5_count", "B_iadl5_count",
  "B_cognition_total", "B_frailty_01", "B_high_cholesterol_prior",
  "B_physical_activity", "B_physical_activity_vigorous",
  "B_physical_activity_moderate"
)

coverage_rows <- list()
coverage_index <- 0L
structural_rows <- list()
structural_index <- 0L
for (variable_name in model_candidates) {
  coverage_index <- coverage_index + 1L
  coverage_rows[[coverage_index]] <- trials[, .(
    person_trials = .N,
    nonmissing_n = sum(!is.na(get(variable_name))),
    nonmissing_fraction = mean(!is.na(get(variable_name)))
  ), by = .(cohort, treatment)][, variable := variable_name]

  structural_index <- structural_index + 1L
  structural_rows[[structural_index]] <- trials[, .(
    person_trials = .N,
    nonmissing_n = sum(!is.na(get(variable_name))),
    nonmissing_fraction = mean(!is.na(get(variable_name)))
  ), by = .(cohort, sequence, treatment)][, variable := variable_name]
}
baseline_coverage <- data.table::rbindlist(coverage_rows, use.names = TRUE, fill = TRUE)
structural_availability <- data.table::rbindlist(structural_rows, use.names = TRUE, fill = TRUE)
data.table::setcolorder(
  baseline_coverage,
  c("cohort", "treatment", "variable", "person_trials", "nonmissing_n", "nonmissing_fraction")
)
data.table::setcolorder(
  structural_availability,
  c("cohort", "sequence", "treatment", "variable", "person_trials", "nonmissing_n", "nonmissing_fraction")
)

structural_summary <- structural_availability[, .(
  minimum_sequence_arm_fraction = min(nonmissing_fraction),
  sequences_with_zero_observed = sum(nonmissing_n == 0L),
  sequence_arms_below_50_percent = sum(nonmissing_fraction < 0.50),
  passes_structural_50_percent_rule = all(nonmissing_fraction >= 0.50)
), by = .(cohort, variable)]

source_use <- data.table::rbindlist(lapply(source_columns, function(source_name) {
  result <- trials[, .N, by = .(
    cohort, treatment,
    source = get(source_name)
  )]
  result[, variable := sub("_source$", "", source_name)]
  result[, fraction_within_arm := N / sum(N), by = .(cohort, treatment, variable)]
  data.table::setcolorder(result, c("cohort", "treatment", "variable", "source", "N", "fraction_within_arm"))
  result
}), use.names = TRUE, fill = TRUE)

diagnosis_table <- trials[, .N, by = .(
  cohort,
  treatment,
  treatment_label,
  E_high_cholesterol = ifelse(is.na(E_high_cholesterol), "[missing]", as.character(E_high_cholesterol)),
  L_high_cholesterol = ifelse(is.na(L_high_cholesterol), "[missing]", as.character(L_high_cholesterol))
)]
diagnosis_table[, fraction_within_treatment := N / sum(N), by = .(cohort, treatment)]

diagnosis_summary <- trials[, .(
  person_trials = .N,
  prior_diagnosis_observed_fraction = mean(!is.na(E_high_cholesterol)),
  landmark_diagnosis_observed_fraction = mean(!is.na(L_high_cholesterol)),
  prior_diagnosis_positive_fraction = mean(E_high_cholesterol == 1L, na.rm = TRUE),
  landmark_diagnosis_positive_fraction = mean(L_high_cholesterol == 1L, na.rm = TRUE),
  landmark_diagnosis_negative_fraction = mean(L_high_cholesterol == 0L, na.rm = TRUE)
), by = .(cohort, treatment, treatment_label)]

frailty_groups <- trials[, {
  value <- B_frailty_01
  list(
    person_trials = .N,
    nonmissing_n = sum(!is.na(value)),
    robust_n = sum(value < 0.15, na.rm = TRUE),
    intermediate_n = sum(value >= 0.15 & value <= 0.25, na.rm = TRUE),
    frail_n = sum(value > 0.25, na.rm = TRUE)
  )
}, by = .(cohort, treatment, treatment_label)]

manifest <- data.table::data.table(
  variable = c(
    "B_age", "B_sex", "B_education", "B_marital_status", "B_income_rank",
    "B_living_arrangement", "B_self_rated_health", "B_bmi",
    "B_current_smoking", "B_alcohol_use", "B_hypertension", "B_diabetes",
    "B_cancer", "B_lung_disease", "B_arthritis", "B_depression_score",
    "B_hospitalization", "B_adl5_count", "B_iadl5_count",
    "B_cognition_total", "B_frailty_01", "B_high_cholesterol_prior",
    "B_physical_activity", "B_physical_activity_vigorous",
    "B_physical_activity_moderate", "L_high_cholesterol",
    "L_systolic_bp", "L_diastolic_bp", "followup_time_years",
    "sequence", "B_country"
  ),
  planned_role = c(
    rep("primary_treatment_model", 19),
    "include_only_if_no_structural_wave_gap",
    "effect_modifier_and_sensitivity_model",
    "sensitivity_only",
    "exclude_current_mapping",
    "share_specific_sensitivity",
    "share_specific_sensitivity",
    "exclude_primary",
    "exclude_primary", "exclude_primary", "exclude_primary",
    "primary_treatment_model", "share_primary_treatment_model"
  ),
  reason = c(
    rep("Prespecified baseline confounder; landmark value with prior-wave fallback.", 19),
    "Cognition is used only where at least half of each sequence-arm is observed after fallback.",
    "The supplied 30-deficit index was stored on a 0-100 scale and is normalized to 0-1; it overlaps component confounders.",
    "All participants used lipid medication at the prior visit; diagnosis reporting is retained only for sensitivity analysis.",
    "The current HRS generic activity mapping is sparse and the concepts differ by cohort.",
    "SHARE-specific ordinal activity variable; not a common primary covariate.",
    "SHARE-specific ordinal activity variable; not a common primary covariate.",
    "Contemporaneous with medication status, structurally absent in early HRS sequences, and strongly predicts the reported treatment state.",
    "Measured BP is sparse in HRS and absent in SHARE.",
    "Measured BP is sparse in HRS and absent in SHARE.",
    "Occurs after treatment assignment and cannot enter a treatment model.",
    "Controls calendar/trial-specific treatment patterns.",
    "Controls SHARE country-level treatment patterns."
  )
)

for (cohort_name in cohorts) {
  cohort_trials <- trials[cohort == cohort_name]
  saveRDS(
    cohort_trials,
    file.path(private_dir, paste0(tolower(cohort_name), "_model_ready_trials_PRIVATE.rds")),
    version = 3L
  )
}
saveRDS(trials, file.path(private_dir, "combined_model_ready_trials_PRIVATE.rds"), version = 3L)

tte_write_csv(frailty_rescaling, file.path(output_dir, "04d_frailty_rescaling.csv"))
tte_write_csv(frailty_groups, file.path(output_dir, "04d_frailty_groups.csv"))
tte_write_csv(baseline_coverage, file.path(output_dir, "04d_baseline_covariate_coverage.csv"))
tte_write_csv(structural_availability, file.path(output_dir, "04d_structural_availability.csv"))
tte_write_csv(structural_summary, file.path(output_dir, "04d_structural_summary.csv"))
tte_write_csv(source_use, file.path(output_dir, "04d_temporal_source_use.csv"))
tte_write_csv(diagnosis_table, file.path(output_dir, "04d_diagnosis_treatment_transitions.csv"))
tte_write_csv(diagnosis_summary, file.path(output_dir, "04d_diagnosis_treatment_summary.csv"))
tte_write_csv(manifest, file.path(output_dir, "04d_covariate_manifest.csv"))

summary_lines <- c(
  "Stage 04d: temporal covariate preparation and exposure-coherence audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Person-trials prepared: ", nrow(trials)),
  paste0("Unique persons: ", data.table::uniqueN(trials[, paste(cohort, person_id)])),
  paste0(
    "Candidate cohort-variable pairs passing the every-sequence-arm 50% rule: ",
    sum(structural_summary$passes_structural_50_percent_rule), " of ", nrow(structural_summary)
  ),
  "",
  "The supplied frailty variables were rescaled from 0-100 to 0-1.",
  "Landmark high-cholesterol diagnosis is excluded from the primary treatment model.",
  "No missing value was imputed and no treatment or outcome model was fitted."
)
writeLines(summary_lines, file.path(output_dir, "04d_stage_summary.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(output_dir, "04d_session_info.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
