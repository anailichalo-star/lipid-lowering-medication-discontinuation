# Stage 00: inspect the R environment and required files.
# This script deliberately does not install or update any package.

.bootstrap_script <- local({
  frames <- sys.frames()
  values <- vapply(
    frames,
    function(frame) {
      value <- frame$ofile
      if (is.null(value) || length(value) == 0L) "" else as.character(value[[1L]])
    },
    character(1L)
  )
  values <- values[nzchar(values)]
  if (length(values)) normalizePath(tail(values, 1L), winslash = "/", mustWork = FALSE) else NA_character_
})

.bootstrap_root <- if (!is.na(.bootstrap_script)) dirname(dirname(.bootstrap_script)) else getwd()
.helper <- file.path(.bootstrap_root, "R", "_stage1_helpers.R")
if (!file.exists(.helper)) {
  stop("Open TTE_HRS_SHARE.Rproj before running this script.", call. = FALSE)
}
source(.helper, encoding = "UTF-8")

project_root <- tte_find_project_root(.bootstrap_root)
config_path <- file.path(project_root, "config_r", "analysis.yml")
output_dir <- file.path(project_root, "outputs_r", "stage01")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

stage01_packages <- c("yaml", "haven")
later_packages <- c(
  "data.table", "dplyr", "tidyr", "purrr", "lubridate", "mice",
  "WeightIt", "cobalt", "survey", "sandwich", "lmtest", "metafor",
  "ggplot2", "broom", "testthat", "rmarkdown"
)
package_status <- tte_package_status(unique(c(stage01_packages, later_packages)))
package_status$needed_now <- package_status$package %in% stage01_packages
tte_write_csv(package_status, file.path(output_dir, "00_package_status.csv"))

data_root <- tte_read_scalar_yaml_without_package(config_path, "data_root")
config_files <- c(
  analysis_yml = config_path,
  cohort_sources = file.path(project_root, "config_r", "cohort_sources.csv"),
  concept_candidates = file.path(project_root, "config_r", "concept_candidates.csv")
)

path_status <- data.frame(
  item = c(names(config_files), "data_root"),
  path = c(unname(config_files), data_root),
  exists = c(file.exists(config_files), dir.exists(data_root)),
  stringsAsFactors = FALSE
)
tte_write_csv(path_status, file.path(output_dir, "00_path_status.csv"))

missing_now <- package_status$package[package_status$needed_now & !package_status$installed]
install_command <- if (length(missing_now)) {
  paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_now), collapse = ", "),
    "))"
  )
} else {
  "No Stage 01 packages are missing."
}

report <- c(
  "R environment check for the HRS and SHARE analysis",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Project root: ", project_root),
  paste0("Working directory: ", getwd()),
  paste0("R version: ", R.version.string),
  paste0("Platform: ", R.version$platform),
  paste0("Locale: ", paste(Sys.getlocale(), collapse = "; ")),
  "",
  paste0("Data root exists: ", dir.exists(data_root)),
  paste0("All configuration files exist: ", all(path_status$exists)),
  paste0("Stage 01 packages available: ", length(missing_now) == 0L),
  "",
  "No packages were installed or updated.",
  paste0("If needed, run manually: ", install_command),
  "",
  "Session information:",
  capture.output(utils::sessionInfo())
)

writeLines(
  report,
  con = file.path(output_dir, "00_environment_check.txt"),
  useBytes = TRUE
)

cat(paste(report[1:15], collapse = "\n"), "\n")
cat("\nFiles written to: ", tte_normalize_path(output_dir), "\n", sep = "")
