# Shared base-R helpers for the first audit stage.
# No package is installed or updated by this file.

options(stringsAsFactors = FALSE)

tte_script_path <- function() {
  frames <- sys.frames()
  candidates <- vapply(
    frames,
    function(frame) {
      value <- frame$ofile
      if (is.null(value) || length(value) == 0L) "" else as.character(value[[1L]])
    },
    character(1L)
  )
  candidates <- candidates[nzchar(candidates)]
  if (length(candidates) == 0L) return(NA_character_)
  normalizePath(tail(candidates, 1L), winslash = "/", mustWork = FALSE)
}

tte_find_project_root <- function(start = getwd()) {
  explicit <- c(
    getOption("tte.project_root", NA_character_),
    Sys.getenv("TTE_PROJECT_ROOT", unset = NA_character_)
  )
  script <- tte_script_path()
  starts <- c(
    explicit,
    start,
    if (!is.na(script)) dirname(script) else NA_character_,
    if (!is.na(script)) dirname(dirname(script)) else NA_character_
  )
  starts <- unique(starts[!is.na(starts) & nzchar(starts)])

  is_root <- function(path) {
    file.exists(file.path(path, "config_r", "analysis.yml")) &&
      file.exists(file.path(path, "config_r", "cohort_sources.csv"))
  }

  for (candidate in starts) {
    current <- normalizePath(candidate, winslash = "/", mustWork = FALSE)
    repeat {
      if (is_root(current)) return(current)
      parent <- dirname(current)
      if (identical(parent, current)) break
      current <- parent
    }
  }

  stop(
    "Cannot locate the project root. Open TTE_HRS_SHARE.Rproj, or set ",
    "options(tte.project_root = getwd()).",
    call. = FALSE
  )
}

tte_normalize_path <- function(path, must_work = FALSE) {
  normalizePath(path, winslash = "/", mustWork = must_work)
}

tte_trim_quotes <- function(x) {
  x <- trimws(x)
  sub("^(['\"])(.*)\\1$", "\\2", x)
}

tte_read_scalar_yaml_without_package <- function(path, key) {
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  hit <- grep(paste0("^\\s*", key, "\\s*:"), lines, value = TRUE)
  if (length(hit) == 0L) return(NA_character_)
  value <- sub(paste0("^\\s*", key, "\\s*:\\s*"), "", hit[[1L]])
  tte_trim_quotes(sub("\\s+#.*$", "", value))
}

tte_read_csv_utf8 <- function(path) {
  # fread preserves UTF-8 path text on Windows even when Rscript starts in a
  # non-UTF-8 locale.  Return a plain data.frame to keep the historical API.
  if (requireNamespace("data.table", quietly = TRUE)) {
    return(data.table::fread(
      path,
      encoding = "UTF-8",
      na.strings = c("", "NA"),
      data.table = FALSE,
      check.names = FALSE
    ))
  }
  utils::read.csv(
    path,
    stringsAsFactors = FALSE,
    check.names = FALSE,
    na.strings = c("", "NA"),
    fileEncoding = "UTF-8"
  )
}

tte_write_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  con <- file(path, open = "wt", encoding = "UTF-8")
  on.exit(close(con), add = TRUE)
  utils::write.csv(x, con, row.names = FALSE, na = "")
  invisible(path)
}

tte_clean_variable_name <- function(x) {
  x <- sub("^\\ufeff", "", x)
  x <- gsub('^"|"$', "", x)
  x <- sub("\\s+\\(.*$", "", x)
  trimws(x)
}

tte_read_csv_header <- function(path) {
  columns <- names(data.table::fread(path, nrows = 0L, check.names = FALSE, encoding = "UTF-8"))
  data.frame(raw_variable = columns, canonical_variable = tte_clean_variable_name(columns),
             variable_label = ifelse(grepl("\\s+\\(", columns), sub("^[^(]*\\((.*)\\)\\s*$", "\\1", columns), ""),
             stringsAsFactors = FALSE)
}

tte_relative_path <- function(path, root) {
  path <- tte_normalize_path(path, must_work = FALSE)
  root <- sub("/+$", "", tte_normalize_path(root, must_work = FALSE))
  prefix <- paste0(root, "/")
  ifelse(startsWith(tolower(path), tolower(prefix)), substring(path, nchar(prefix) + 1L), path)
}

tte_classify_file_role <- function(relative_path, is_clean = FALSE, is_harmonized = FALSE) {
  if (is_clean) return("cleaned")
  if (is_harmonized) return("harmonized")

  value <- tolower(gsub("\\\\", "/", relative_path))
  name <- basename(value)

  if (grepl("death|deceas|end[ _.-]*of[ _.-]*life|(^|[/_. -])eol([/_. -]|$)|exit|mortality|tracker", value)) {
    return("death_exit")
  }
  if (grepl("weight|gv_weights|sampling", value)) return("survey_weight")
  if (grepl("questionnaire|codebook|data[ _.-]*description|user[ _.-]*guide|documentation|readme", value)) {
    return("documentation")
  }
  if (grepl("\\.(dta|sav|sas7bdat)$", name)) return("raw_data")
  if (grepl("\\.(zip|7z|rar)$", name)) return("archive")
  "other"
}

tte_split_aliases <- function(x) {
  if (is.na(x) || !nzchar(trimws(x))) return(character())
  unique(tolower(trimws(strsplit(x, "|", fixed = TRUE)[[1L]])))
}

tte_collapse_unique <- function(x) {
  x <- unique(x[!is.na(x) & nzchar(x)])
  if (length(x) == 0L) "" else paste(sort(x), collapse = "; ")
}

tte_package_status <- function(packages) {
  rows <- lapply(packages, function(package) {
    installed <- requireNamespace(package, quietly = TRUE)
    data.frame(
      package = package,
      installed = installed,
      version = if (installed) as.character(utils::packageVersion(package)) else "",
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

tte_require_packages <- function(packages) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1L), quietly = TRUE)]
  if (length(missing) > 0L) {
    command <- paste0(
      "install.packages(c(",
      paste(sprintf("'%s'", missing), collapse = ", "),
      "))"
    )
    stop(
      "Missing required packages: ", paste(missing, collapse = ", "),
      ". No package was installed automatically. Run: ", command,
      call. = FALSE
    )
  }
  invisible(TRUE)
}

tte_read_yaml_utf8 <- function(path) {
  if (!requireNamespace("yaml", quietly = TRUE)) {
    stop("Package 'yaml' is required to read configuration files.", call. = FALSE)
  }
  input <- readLines(path, encoding = "UTF-8", warn = FALSE)
  yaml::yaml.load(paste(input, collapse = "\n"), error.label = path)
}

tte_self_rated_health_worsened <- function(prior, landmark) {
  prior_code <- suppressWarnings(as.numeric(as.character(prior)))
  landmark_code <- suppressWarnings(as.numeric(as.character(landmark)))
  stopifnot(all(is.na(prior) | prior_code %in% 1:5),
            all(is.na(landmark) | landmark_code %in% 1:5))
  # Cleaned scale: 1 is poor and 5 is excellent.
  as.integer(landmark_code < prior_code)
}
