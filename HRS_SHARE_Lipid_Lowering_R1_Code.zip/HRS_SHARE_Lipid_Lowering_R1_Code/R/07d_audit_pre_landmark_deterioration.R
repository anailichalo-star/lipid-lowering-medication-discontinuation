# Historical analysis for reproducing the original submission.
# Use the R1 workflow to apply the corrected deterioration indicator.
# Stage 07d: audit pre-landmark health deterioration as a source of
# prognosis-driven medication discontinuation. This stage estimates no
# treatment effect and does not alter the frozen primary analysis.

options(stringsAsFactors = FALSE)

project_root <- getOption("tte.project_root", Sys.getenv("TTE_PROJECT_ROOT", unset = normalizePath(".", winslash = "/", mustWork = FALSE)))
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "data.table", "ggplot2"))

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
input_dir <- file.path(
  project_root, config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_private <- file.path(
  project_root, config$output_root, "stage05_weighting", "private_do_not_share"
)
output_dir <- file.path(
  project_root, config$output_root, "stage07d_deterioration_audit"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
minimum_arm_person_trials <- 100L
minimum_arm_events <- 20L
minimum_total_events <- 100L
bmi_loss_threshold <- -2
fi_increase_threshold <- 0.05
minimum_observed_markers_for_count <- 5L

plain_numeric <- function(x) suppressWarnings(as.numeric(x))

binary_value <- function(x, variable_name, cohort_name) {
  value <- plain_numeric(x)
  invalid <- !is.na(value) & !value %in% c(0, 1)
  if (any(invalid)) {
    stop(
      cohort_name, ": ", variable_name,
      " contains values outside 0/1: ",
      paste(sort(unique(value[invalid])), collapse = ", "),
      call. = FALSE
    )
  }
  as.integer(value)
}

strict_any_binary <- function(...) {
  values <- cbind(...)
  storage.mode(values) <- "numeric"
  result <- rep(NA_integer_, nrow(values))
  result[rowSums(values == 1, na.rm = TRUE) > 0] <- 1L
  fully_observed <- rowSums(!is.na(values)) == ncol(values)
  result[fully_observed & rowSums(values == 1, na.rm = TRUE) == 0] <- 0L
  result
}

weighted_mean_safe <- function(x, weight) {
  value <- plain_numeric(x)
  w <- plain_numeric(weight)
  valid <- is.finite(value) & is.finite(w) & w > 0
  if (!any(valid)) return(NA_real_)
  sum(value[valid] * w[valid]) / sum(w[valid])
}

weighted_variance_safe <- function(x, weight) {
  value <- plain_numeric(x)
  w <- plain_numeric(weight)
  valid <- is.finite(value) & is.finite(w) & w > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean_safe(value[valid], w[valid])
  sum(w[valid] * (value[valid] - center)^2) / sum(w[valid])
}

numeric_smd <- function(x, treatment, weight) {
  value <- plain_numeric(x)
  trt <- as.integer(treatment)
  w <- plain_numeric(weight)
  valid <- is.finite(value) & trt %in% c(0L, 1L) & is.finite(w) & w > 0
  value <- value[valid]
  trt <- trt[valid]
  w <- w[valid]
  if (!any(trt == 0L) || !any(trt == 1L)) return(NA_real_)
  mean0 <- weighted_mean_safe(value[trt == 0L], w[trt == 0L])
  mean1 <- weighted_mean_safe(value[trt == 1L], w[trt == 1L])
  var0 <- weighted_variance_safe(value[trt == 0L], w[trt == 0L])
  var1 <- weighted_variance_safe(value[trt == 1L], w[trt == 1L])
  denominator <- sqrt((var0 + var1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (mean1 - mean0) / denominator
}

safe_quantile <- function(x, probability) {
  value <- plain_numeric(x)
  value <- value[is.finite(value)]
  if (!length(value)) return(NA_real_)
  as.numeric(stats::quantile(value, probability, names = FALSE, type = 2L))
}

marker_definitions <- data.table::data.table(
  marker = c(
    "recent_hospitalization", "incident_cancer", "marked_bmi_loss",
    "adl_worsening", "iadl_worsening", "self_rated_health_worsened",
    "fi_worsening_005", "severe_deterioration",
    "multiple_deterioration_markers"
  ),
  label = c(
    "Hospitalization reported at landmark",
    "New cancer diagnosis between prior and landmark visits",
    "BMI decrease of at least 2 kg/m2",
    "At least one new ADL difficulty",
    "At least one new IADL difficulty",
    "Self-rated health worsened",
    "Frailty index increased by at least 0.05",
    "Any objective severe deterioration marker",
    "At least two deterioration markers"
  ),
  definition = c(
    "L_hospitalization == 1",
    "E_cancer == 0 and L_cancer == 1",
    "L_BMI minus E_BMI <= -2",
    "L_ADL5 minus E_ADL5 >= 1",
    "L_IADL5 minus E_IADL5 >= 1",
    "L_self_rated_health worse than E_self_rated_health",
    "Landmark rebuilt FI minus prior rebuilt FI >= 0.05",
    paste0(
      "Any of incident cancer, marked BMI loss, ADL worsening, ",
      "IADL worsening, or FI increase >=0.05"
    ),
    paste0(
      "At least two of hospitalization, incident cancer, marked BMI loss, ",
      "ADL worsening, IADL worsening, self-rated-health worsening, or FI worsening"
    )
  ),
  planned_use = c(
    rep("individual exclusion audit", 7L),
    "primary prognosis-bias restriction candidate",
    "secondary prognosis-bias restriction candidate"
  )
)

continuous_definitions <- data.table::data.table(
  variable = c(
    "fi_change", "delta_adl5_count", "delta_iadl5_count", "delta_bmi"
  ),
  label = c(
    "Change in rebuilt frailty index",
    "Change in five-item ADL count",
    "Change in five-item IADL count",
    "Change in BMI (kg/m2)"
  )
)

restriction_definitions <- data.table::data.table(
  restriction = c(
    "none", "exclude_recent_hospitalization", "exclude_incident_cancer",
    "exclude_marked_bmi_loss", "exclude_adl_worsening",
    "exclude_iadl_worsening", "exclude_self_rated_health_worsening",
    "exclude_fi_worsening_005", "exclude_severe_deterioration",
    "exclude_multiple_deterioration_markers"
  ),
  exclusion_marker = c(
    NA_character_, "recent_hospitalization", "incident_cancer",
    "marked_bmi_loss", "adl_worsening", "iadl_worsening",
    "self_rated_health_worsened", "fi_worsening_005",
    "severe_deterioration", "multiple_deterioration_markers"
  ),
  description = c(
    "Frozen eligible population without a deterioration restriction",
    "Exclude hospitalization reported at landmark",
    "Exclude incident cancer between prior and landmark visits",
    "Exclude BMI decrease of at least 2 kg/m2",
    "Exclude at least one new ADL difficulty",
    "Exclude at least one new IADL difficulty",
    "Exclude worsening self-rated health",
    "Exclude rebuilt FI increase of at least 0.05",
    "Exclude any objective severe deterioration marker",
    "Exclude participants with at least two deterioration markers"
  )
)

analysis_flow_parts <- list()
availability_parts <- list()
prevalence_parts <- list()
continuous_parts <- list()
balance_parts <- list()
join_check_parts <- list()
outcome_profile_parts <- list()
restriction_arm_parts <- list()
private_parts <- list()

for (cohort_name in cohorts) {
  input_path <- file.path(
    input_dir,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  weight_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(input_path)) stop("Missing trial data: ", input_path, call. = FALSE)
  if (!file.exists(weight_path)) stop("Missing Stage 05 weights: ", weight_path, call. = FALSE)

  trials <- data.table::as.data.table(readRDS(input_path))
  required_columns <- c(
    "person_id", "trial_id", "sequence", "treatment",
    "L_survey_weight_final", "F_interview_observed", "death_in_interval",
    "primary_event", "strict_event", "E_hospitalization", "L_hospitalization",
    "E_cancer", "L_cancer", "delta_bmi", "delta_adl5_count",
    "delta_iadl5_count", "self_rated_health_worsened",
    "FI_pre_treatment", "FI_landmark_sensitivity"
  )
  missing_columns <- setdiff(required_columns, names(trials))
  if (length(missing_columns)) {
    stop(
      cohort_name, " is missing required variables: ",
      paste(missing_columns, collapse = ", "), call. = FALSE
    )
  }

  input_n <- nrow(trials)
  valid_weight <- is.finite(plain_numeric(trials$L_survey_weight_final)) &
    plain_numeric(trials$L_survey_weight_final) > 0
  trials <- data.table::copy(trials[valid_weight])
  trials[, analysis_row_id := seq_len(.N)]
  trials[, treatment := binary_value(treatment, "treatment", cohort_name)]
  trials[, treatment_label := data.table::fcase(
    treatment == 0L, "Continue",
    treatment == 1L, "Discontinue",
    default = NA_character_
  )]

  trials[, death_in_interval := binary_value(
    death_in_interval, "death_in_interval", cohort_name
  )]
  trials[, F_interview_observed := binary_value(
    F_interview_observed, "F_interview_observed", cohort_name
  )]
  trials[, strict_event := binary_value(strict_event, "strict_event", cohort_name)]
  trials[, primary_event := binary_value(primary_event, "primary_event", cohort_name)]
  trials[, death_component := data.table::fcase(
    death_in_interval == 1L, 1L,
    death_in_interval == 0L & F_interview_observed == 1L, 0L,
    default = NA_integer_
  )]

  trials[, fi_change := plain_numeric(FI_landmark_sensitivity) -
    plain_numeric(FI_pre_treatment)]
  trials[, recent_hospitalization := data.table::fcase(
    is.na(L_hospitalization), NA_integer_,
    plain_numeric(L_hospitalization) == 1, 1L,
    plain_numeric(L_hospitalization) == 0, 0L,
    default = NA_integer_
  )]
  trials[, incident_cancer := data.table::fcase(
    is.na(E_cancer) | is.na(L_cancer), NA_integer_,
    plain_numeric(E_cancer) == 0 & plain_numeric(L_cancer) == 1, 1L,
    default = 0L
  )]
  trials[, marked_bmi_loss := data.table::fcase(
    is.na(delta_bmi), NA_integer_,
    plain_numeric(delta_bmi) <= bmi_loss_threshold, 1L,
    default = 0L
  )]
  trials[, adl_worsening := data.table::fcase(
    is.na(delta_adl5_count), NA_integer_,
    plain_numeric(delta_adl5_count) >= 1, 1L,
    default = 0L
  )]
  trials[, iadl_worsening := data.table::fcase(
    is.na(delta_iadl5_count), NA_integer_,
    plain_numeric(delta_iadl5_count) >= 1, 1L,
    default = 0L
  )]
  trials[, self_rated_health_worsened := binary_value(
    self_rated_health_worsened, "self_rated_health_worsened", cohort_name
  )]
  trials[, fi_worsening_005 := data.table::fcase(
    is.na(fi_change), NA_integer_,
    fi_change >= fi_increase_threshold, 1L,
    default = 0L
  )]
  trials[, severe_deterioration := strict_any_binary(
    incident_cancer, marked_bmi_loss, adl_worsening,
    iadl_worsening, fi_worsening_005
  )]

  count_marker_names <- c(
    "recent_hospitalization", "incident_cancer", "marked_bmi_loss",
    "adl_worsening", "iadl_worsening", "self_rated_health_worsened",
    "fi_worsening_005"
  )
  count_matrix <- as.matrix(trials[, ..count_marker_names])
  storage.mode(count_matrix) <- "numeric"
  observed_marker_count <- rowSums(!is.na(count_matrix))
  deterioration_marker_count <- rowSums(count_matrix, na.rm = TRUE)
  deterioration_marker_count[
    observed_marker_count < minimum_observed_markers_for_count
  ] <- NA_real_
  trials[, observed_deterioration_marker_count := observed_marker_count]
  trials[, deterioration_marker_count := deterioration_marker_count]
  trials[, multiple_deterioration_markers := data.table::fcase(
    is.na(deterioration_marker_count), NA_integer_,
    deterioration_marker_count >= 2, 1L,
    default = 0L
  )]

  analysis_flow_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    structural_input_person_trials = input_n,
    excluded_missing_or_nonpositive_survey_weight = input_n - nrow(trials),
    stage05_matched_person_trials = nrow(trials),
    unique_persons = data.table::uniqueN(trials$person_id),
    continue_person_trials = sum(trials$treatment == 0L),
    discontinue_person_trials = sum(trials$treatment == 1L)
  )

  for (marker_name in marker_definitions$marker) {
    value <- trials[[marker_name]]
    availability_parts[[paste(cohort_name, marker_name, sep = "_")]] <-
      trials[, .(
        person_trials = .N,
        observed_n = sum(!is.na(get(marker_name))),
        missing_n = sum(is.na(get(marker_name))),
        observed_fraction = mean(!is.na(get(marker_name)))
      ), by = .(treatment, treatment_label)][, `:=`(
        cohort = cohort_name, marker = marker_name
      )]

    prevalence_parts[[paste(cohort_name, marker_name, sep = "_")]] <-
      trials[, .(
        person_trials = .N,
        observed_n = sum(!is.na(get(marker_name))),
        marker_n = sum(get(marker_name) == 1L, na.rm = TRUE),
        marker_prevalence = mean(get(marker_name) == 1L, na.rm = TRUE)
      ), by = .(treatment, treatment_label)][, `:=`(
        cohort = cohort_name, marker = marker_name
      )]
  }

  for (variable_name in continuous_definitions$variable) {
    continuous_parts[[paste(cohort_name, variable_name, sep = "_")]] <-
      trials[, .(
        person_trials = .N,
        observed_n = sum(!is.na(get(variable_name))),
        mean = mean(plain_numeric(get(variable_name)), na.rm = TRUE),
        standard_deviation = stats::sd(plain_numeric(get(variable_name)), na.rm = TRUE),
        p25 = safe_quantile(get(variable_name), 0.25),
        median = safe_quantile(get(variable_name), 0.50),
        p75 = safe_quantile(get(variable_name), 0.75)
      ), by = .(treatment, treatment_label)][, `:=`(
        cohort = cohort_name, variable = variable_name
      )]
  }

  outcome_names <- c("primary_event", "strict_event", "death_component")
  for (marker_name in marker_definitions$marker) {
    for (outcome_name in outcome_names) {
      outcome_profile_parts[[paste(
        cohort_name, marker_name, outcome_name, sep = "_"
      )]] <- trials[
        !is.na(get(marker_name)) & !is.na(get(outcome_name)),
        .(
          observed_person_trials = .N,
          events = sum(get(outcome_name) == 1L),
          crude_risk = mean(get(outcome_name) == 1L)
        ),
        by = c("treatment", "treatment_label", marker_name)
      ][, `:=`(
        cohort = cohort_name,
        marker = marker_name,
        marker_value = get(marker_name),
        outcome = outcome_name
      )][, (marker_name) := NULL]
    }
  }

  weighted_imputations <- readRDS(weight_path)
  if (!is.list(weighted_imputations) || !length(weighted_imputations)) {
    stop(cohort_name, " Stage 05 weight object is empty or invalid.", call. = FALSE)
  }
  balance_variables <- c(marker_definitions$marker, continuous_definitions$variable)
  for (imputation_index in seq_along(weighted_imputations)) {
    weighted <- data.table::as.data.table(weighted_imputations[[imputation_index]])
    required_weight_columns <- c(
      "analysis_row_id", "person_id", "trial_id", "treatment",
      "treatment_analysis_weight"
    )
    missing_weight_columns <- setdiff(required_weight_columns, names(weighted))
    if (length(missing_weight_columns)) {
      stop(
        cohort_name, " imputation ", imputation_index,
        " lacks weight variables: ",
        paste(missing_weight_columns, collapse = ", "), call. = FALSE
      )
    }
    duplicate_weight_keys <- sum(duplicated(weighted$analysis_row_id))
    compact <- weighted[, .(
      analysis_row_id,
      weight_person_id = as.character(person_id),
      weight_trial_id = as.character(trial_id),
      weight_treatment = as.integer(treatment),
      treatment_analysis_weight = plain_numeric(treatment_analysis_weight)
    )]
    joined <- merge(
      trials, compact, by = "analysis_row_id", all.x = TRUE, sort = FALSE
    )
    data.table::setorder(joined, analysis_row_id)
    exact_identity <- nrow(joined) == nrow(trials) &&
      all(as.character(joined$person_id) == joined$weight_person_id) &&
      all(as.character(joined$trial_id) == joined$weight_trial_id) &&
      all(as.integer(joined$treatment) == joined$weight_treatment)
    join_check_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        trial_rows = nrow(trials),
        weight_rows = nrow(weighted),
        matched_weight_rows = sum(!is.na(joined$treatment_analysis_weight)),
        duplicated_weight_keys = duplicate_weight_keys,
        exact_person_trial_treatment_identity = exact_identity
      )
    if (!exact_identity || duplicate_weight_keys > 0L ||
        anyNA(joined$treatment_analysis_weight)) {
      stop(
        cohort_name, " imputation ", imputation_index,
        " failed the Stage 05 weight join check.", call. = FALSE
      )
    }

    unit_weight <- rep(1, nrow(joined))
    for (variable_name in balance_variables) {
      balance_parts[[paste(
        cohort_name, imputation_index, variable_name, "unweighted", sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        sample = "eligible_unweighted",
        variable = variable_name,
        standardized_difference = numeric_smd(
          joined[[variable_name]], joined$treatment, unit_weight
        )
      )
      balance_parts[[paste(
        cohort_name, imputation_index, variable_name, "weighted", sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        sample = "after_primary_treatment_weight",
        variable = variable_name,
        standardized_difference = numeric_smd(
          joined[[variable_name]], joined$treatment,
          joined$treatment_analysis_weight
        )
      )
    }
  }

  for (restriction_index in seq_len(nrow(restriction_definitions))) {
    restriction_name <- restriction_definitions$restriction[[restriction_index]]
    marker_name <- restriction_definitions$exclusion_marker[[restriction_index]]
    if (is.na(marker_name)) {
      exclusion_status <- rep(0L, nrow(trials))
    } else {
      exclusion_status <- trials[[marker_name]]
    }
    trials[, temporary_exclusion_status := exclusion_status]
    for (outcome_name in c("primary_event", "strict_event", "death_component")) {
      restriction_arm_parts[[paste(
        cohort_name, restriction_name, outcome_name, sep = "_"
      )]] <- trials[, .(
        original_person_trials = .N,
        restriction_status_unknown = sum(is.na(temporary_exclusion_status)),
        excluded_person_trials = sum(temporary_exclusion_status == 1L, na.rm = TRUE),
        retained_person_trials = sum(
          is.na(temporary_exclusion_status) | temporary_exclusion_status != 1L
        ),
        retained_person_trials_complete_status = sum(
          temporary_exclusion_status == 0L, na.rm = TRUE
        ),
        retained_outcome_observed = sum(
          (is.na(temporary_exclusion_status) | temporary_exclusion_status != 1L) &
            !is.na(get(outcome_name))
        ),
        retained_outcome_observed_complete_status = sum(
          temporary_exclusion_status == 0L & !is.na(get(outcome_name)), na.rm = TRUE
        ),
        retained_events = sum(
          (is.na(temporary_exclusion_status) | temporary_exclusion_status != 1L) &
            get(outcome_name) == 1L,
          na.rm = TRUE
        ),
        retained_events_complete_status = sum(
          temporary_exclusion_status == 0L & get(outcome_name) == 1L,
          na.rm = TRUE
        )
      ), by = .(treatment, treatment_label)][, `:=`(
        cohort = cohort_name,
        restriction = restriction_name,
        outcome = outcome_name,
        unknown_status_retained_for_feasibility_count = TRUE
      )]
    }
  }
  trials[, temporary_exclusion_status := NULL]

  private_parts[[cohort_name]] <- trials[, c(
    "cohort", "person_id", "trial_id", "analysis_row_id", "sequence",
    "treatment", "primary_event", "strict_event", "death_component", marker_definitions$marker,
    continuous_definitions$variable, "observed_deterioration_marker_count",
    "deterioration_marker_count"
  ), with = FALSE]
}

analysis_flow <- data.table::rbindlist(analysis_flow_parts, use.names = TRUE, fill = TRUE)
marker_availability <- data.table::rbindlist(
  availability_parts, use.names = TRUE, fill = TRUE
)
marker_prevalence <- data.table::rbindlist(
  prevalence_parts, use.names = TRUE, fill = TRUE
)
continuous_profile <- data.table::rbindlist(
  continuous_parts, use.names = TRUE, fill = TRUE
)
balance_by_imputation <- data.table::rbindlist(
  balance_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(join_check_parts, use.names = TRUE, fill = TRUE)
outcome_profile <- data.table::rbindlist(
  outcome_profile_parts, use.names = TRUE, fill = TRUE
)
restriction_arm <- data.table::rbindlist(
  restriction_arm_parts, use.names = TRUE, fill = TRUE
)
private_flags <- data.table::rbindlist(private_parts, use.names = TRUE, fill = TRUE)

marker_availability <- merge(
  marker_availability,
  marker_definitions[, .(marker, marker_label = label)],
  by = "marker", all.x = TRUE, sort = FALSE
)
marker_prevalence <- merge(
  marker_prevalence,
  marker_definitions[, .(marker, marker_label = label)],
  by = "marker", all.x = TRUE, sort = FALSE
)
continuous_profile <- merge(
  continuous_profile,
  continuous_definitions[, .(variable, variable_label = label)],
  by = "variable", all.x = TRUE, sort = FALSE
)
outcome_profile <- merge(
  outcome_profile,
  marker_definitions[, .(marker, marker_label = label)],
  by = "marker", all.x = TRUE, sort = FALSE
)

balance_summary <- balance_by_imputation[, .(
  imputations = data.table::uniqueN(imputation),
  mean_standardized_difference = mean(standardized_difference, na.rm = TRUE),
  maximum_absolute_standardized_difference = max(
    abs(standardized_difference), na.rm = TRUE
  )
), by = .(cohort, sample, variable)]
balance_labels <- data.table::rbindlist(list(
  marker_definitions[, .(variable = marker, variable_label = label)],
  continuous_definitions[, .(variable, variable_label = label)]
), use.names = TRUE, fill = TRUE)
balance_summary <- merge(
  balance_summary, balance_labels,
  by = "variable", all.x = TRUE, sort = FALSE
)

restriction_gate <- restriction_arm[, .(
  both_treatment_arms_present = data.table::uniqueN(treatment) == 2L,
  smaller_arm_retained_person_trials = min(retained_person_trials),
  smaller_arm_observed_person_trials = min(retained_outcome_observed),
  smaller_arm_events = min(retained_events),
  total_events = sum(retained_events),
  total_unknown_restriction_status = sum(restriction_status_unknown)
), by = .(cohort, restriction, outcome)]
restriction_gate[, `:=`(
  passes_person_trial_gate = smaller_arm_retained_person_trials >= minimum_arm_person_trials,
  passes_arm_event_gate = smaller_arm_events >= minimum_arm_events,
  passes_total_event_gate = total_events >= minimum_total_events
)]
restriction_gate[, passes_all_unweighted_gates :=
  both_treatment_arms_present & passes_person_trial_gate &
  passes_arm_event_gate & passes_total_event_gate]
restriction_gate <- merge(
  restriction_gate,
  restriction_definitions[, .(restriction, description)],
  by = "restriction", all.x = TRUE, sort = FALSE
)

if (any(!join_checks$exact_person_trial_treatment_identity) ||
    any(join_checks$duplicated_weight_keys > 0L) ||
    any(join_checks$matched_weight_rows != join_checks$trial_rows)) {
  stop("At least one Stage 05 weight join check failed.", call. = FALSE)
}

data.table::setorder(marker_availability, cohort, marker, treatment)
data.table::setorder(marker_prevalence, cohort, marker, treatment)
data.table::setorder(continuous_profile, cohort, variable, treatment)
data.table::setorder(balance_by_imputation, cohort, variable, sample, imputation)
data.table::setorder(balance_summary, cohort, variable, sample)
data.table::setorder(outcome_profile, cohort, outcome, marker, treatment, marker_value)
data.table::setorder(restriction_arm, cohort, restriction, outcome, treatment)
data.table::setorder(restriction_gate, cohort, restriction, outcome)

tte_write_csv(marker_definitions, file.path(output_dir, "07d_marker_definitions.csv"))
tte_write_csv(restriction_definitions, file.path(output_dir, "07d_restriction_definitions.csv"))
tte_write_csv(analysis_flow, file.path(output_dir, "07d_analysis_flow.csv"))
tte_write_csv(marker_availability, file.path(output_dir, "07d_marker_availability.csv"))
tte_write_csv(marker_prevalence, file.path(output_dir, "07d_marker_prevalence.csv"))
tte_write_csv(continuous_profile, file.path(output_dir, "07d_continuous_change_profile.csv"))
tte_write_csv(balance_by_imputation, file.path(output_dir, "07d_balance_by_imputation.csv"))
tte_write_csv(balance_summary, file.path(output_dir, "07d_balance_summary.csv"))
tte_write_csv(join_checks, file.path(output_dir, "07d_weight_join_checks.csv"))
tte_write_csv(outcome_profile, file.path(output_dir, "07d_crude_outcome_by_marker.csv"))
tte_write_csv(restriction_arm, file.path(output_dir, "07d_restriction_arm_feasibility.csv"))
tte_write_csv(restriction_gate, file.path(output_dir, "07d_restriction_gate.csv"))
saveRDS(
  private_flags,
  file.path(private_dir, "stage07d_deterioration_flags_PRIVATE.rds"),
  version = 3L
)

plot_prevalence <- merge(
  marker_prevalence,
  marker_definitions[, .(marker, plot_order = seq_len(.N))],
  by = "marker", all.x = TRUE, sort = FALSE
)
plot_prevalence[, marker_label := factor(
  marker_label,
  levels = rev(marker_definitions$label)
)]
prevalence_plot <- ggplot2::ggplot(
  plot_prevalence,
  ggplot2::aes(
    x = marker_prevalence, y = marker_label,
    color = treatment_label, shape = treatment_label
  )
) +
  ggplot2::geom_point(size = 2.3, position = ggplot2::position_dodge(width = 0.45)) +
  ggplot2::facet_wrap(~cohort, ncol = 1L, scales = "free_y") +
  ggplot2::scale_x_continuous(labels = scales::label_percent(accuracy = 1)) +
  ggplot2::labs(
    title = "Pre-landmark health deterioration markers",
    subtitle = "Observed prevalence before imputation; treatment assigned at landmark",
    x = "Prevalence among records with observed marker",
    y = NULL,
    color = "Landmark strategy",
    shape = "Landmark strategy"
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(legend.position = "bottom")
ggplot2::ggsave(
  file.path(output_dir, "07d_marker_prevalence.png"), prevalence_plot,
  width = 10, height = 8, dpi = 300
)
ggplot2::ggsave(
  file.path(output_dir, "07d_marker_prevalence.pdf"), prevalence_plot,
  width = 10, height = 8
)

balance_plot_data <- data.table::copy(balance_summary)
balance_plot_data[, sample_label := data.table::fcase(
  sample == "eligible_unweighted", "Before weighting",
  sample == "after_primary_treatment_weight", "After treatment weighting",
  default = sample
)]
balance_plot_data[, variable_label := factor(
  variable_label,
  levels = rev(unique(balance_labels$variable_label))
)]
balance_plot <- ggplot2::ggplot(
  balance_plot_data,
  ggplot2::aes(
    x = abs(mean_standardized_difference), y = variable_label,
    color = sample_label, shape = sample_label
  )
) +
  ggplot2::geom_vline(xintercept = 0.10, linetype = 2, color = "grey45") +
  ggplot2::geom_point(size = 2.2, position = ggplot2::position_dodge(width = 0.45)) +
  ggplot2::facet_wrap(~cohort, ncol = 1L, scales = "free_y") +
  ggplot2::labs(
    title = "Balance of pre-landmark deterioration measures",
    subtitle = "Absolute standardized differences; dashed line marks 0.10",
    x = "Absolute standardized difference",
    y = NULL,
    color = NULL,
    shape = NULL
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(legend.position = "bottom")
ggplot2::ggsave(
  file.path(output_dir, "07d_deterioration_balance.png"), balance_plot,
  width = 10, height = 9, dpi = 300
)
ggplot2::ggsave(
  file.path(output_dir, "07d_deterioration_balance.pdf"), balance_plot,
  width = 10, height = 9
)

severe_lines <- marker_prevalence[
  marker == "severe_deterioration",
  paste0(
    cohort, "/", treatment_label, ": ", marker_n, " of ", observed_n,
    " (", sprintf("%.1f", 100 * marker_prevalence), "%)"
  )
]
largest_balance <- balance_summary[
  sample == "after_primary_treatment_weight"
][order(cohort, -maximum_absolute_standardized_difference), .SD[1L], by = cohort]
balance_lines <- largest_balance[, paste0(
  cohort, ": largest post-weighting deterioration imbalance was ",
  variable, " (max |SMD|=",
  sprintf("%.3f", maximum_absolute_standardized_difference), ")."
)]
gate_lines <- restriction_gate[
  restriction %in% c(
    "exclude_severe_deterioration",
    "exclude_multiple_deterioration_markers"
  ),
  paste0(
    cohort, "/", outcome, "/", restriction,
    ": smaller-arm trials=", smaller_arm_retained_person_trials,
    ", smaller-arm events=", smaller_arm_events,
    ", total events=", total_events,
    ", passes frozen unweighted gates=", passes_all_unweighted_gates
  )
]

summary_lines <- c(
  "Stage 07d: pre-landmark health-deterioration audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Cohorts audited: ", paste(cohorts, collapse = ", ")),
  paste0("Person-trials audited: ", sum(analysis_flow$stage05_matched_person_trials)),
  "",
  "Objective severe deterioration prevalence:",
  severe_lines,
  "",
  "Residual balance after the frozen primary treatment weights:",
  balance_lines,
  "",
  "Key restriction feasibility:",
  gate_lines,
  "",
  paste0(
    "Frozen feasibility gates: smaller treatment arm >=", minimum_arm_person_trials,
    " person-trials, >=", minimum_arm_events,
    " events per arm, and >=", minimum_total_events, " total events."
  ),
  paste0(
    "The objective severe-deterioration composite excludes incident cancer, ",
    "BMI loss >=", abs(bmi_loss_threshold), " kg/m2, ADL/IADL worsening, or ",
    "FI increase >=", fi_increase_threshold, "."
  ),
  "Hospitalization and self-rated-health worsening are audited separately because they are less specific.",
  "Unknown restriction status was retained only for the feasibility count and is explicitly reported.",
  "Stage 05 treatment weights were used only to audit assignment balance; outcome-specific censoring weights were not used.",
  "No missing value was imputed, no treatment effect was estimated, and the primary analysis was not changed."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07d_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(utils::sessionInfo()),
  file.path(output_dir, "07d_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message("Stage 07d completed: ", output_dir)
