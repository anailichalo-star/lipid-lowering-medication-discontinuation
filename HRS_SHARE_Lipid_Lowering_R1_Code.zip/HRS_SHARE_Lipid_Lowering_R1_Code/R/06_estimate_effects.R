# Stage 06: estimate the primary three-year effect within HRS and SHARE.
# No meta-analysis or sensitivity analysis is performed in this stage.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_stage06_helpers.R"), encoding = "UTF-8", local = TRUE)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
outcome_config_path <- file.path(project_root, "config_r", "primary_outcome_model.yml")
outcome_config <- tte_read_yaml_utf8(outcome_config_path)
stage04_dir <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_dir <- file.path(project_root, analysis_config$output_root, "stage05_weighting")
stage05_private <- file.path(stage05_dir, "private_do_not_share")
output_dir <- file.path(project_root, analysis_config$output_root, "stage06_primary_effects")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
target_years <- as.numeric(outcome_config$target_risk_years)
confidence_level <- as.numeric(outcome_config$confidence_level)
if (!isTRUE(all.equal(confidence_level, 0.95))) {
  stop("This frozen implementation currently requires a 95% confidence level.", call. = FALSE)
}

gate_path <- file.path(stage05_dir, "05_weighting_gate.csv")
if (!file.exists(gate_path)) stop("Missing Stage 05 gate file: ", gate_path, call. = FALSE)
weighting_gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
ready_column <- intersect(c("ready_for_effect_estimation", "all_gates_pass"), names(weighting_gate))
if (length(ready_column) != 1L) {
  stop("Could not identify the Stage 05 final gate column.", call. = FALSE)
}
as_logical_gate <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}
gate_rows <- weighting_gate[cohort %in% cohorts]
if (!setequal(as.character(gate_rows$cohort), cohorts) ||
    anyDuplicated(as.character(gate_rows$cohort)) || nrow(gate_rows) != length(cohorts)) {
  stop("Stage 05 gate file must contain exactly one row for each primary cohort.", call. = FALSE)
}
gate_ready <- all(as_logical_gate(gate_rows[[ready_column]]))
if (!isTRUE(gate_ready)) {
  stop("Stage 06 aborted because not every primary cohort passed Stage 05.", call. = FALSE)
}

effect_by_imputation_parts <- list()
model_diagnostic_parts <- list()
sample_description_parts <- list()
join_check_parts <- list()

for (cohort_name in cohorts) {
  weighted_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  trial_path <- file.path(
    stage04_dir,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  if (!file.exists(weighted_path)) stop("Missing Stage 05 weighted data: ", weighted_path, call. = FALSE)
  if (!file.exists(trial_path)) stop("Missing Stage 04f trial data: ", trial_path, call. = FALSE)

  weighted_imputations <- readRDS(weighted_path)
  source_trials <- data.table::as.data.table(readRDS(trial_path))
  if (length(weighted_imputations) != 20L) {
    stop(cohort_name, " does not contain exactly 20 weighted imputations.", call. = FALSE)
  }

  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  source_trials[, join_key := paste(as.character(person_id), as.character(trial_id), sep = "\r")]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": person_id + trial_id is not unique in Stage 04f.", call. = FALSE)
  }
  source_fields <- source_trials[, .(
    join_key,
    followup_time_years = suppressWarnings(as.numeric(followup_time_years)),
    L_interview_date,
    F_interview_date,
    death_date,
    death_in_interval,
    L_survey_stratum,
    L_community
  )]

  first_imputation <- data.table::as.data.table(weighted_imputations[[1L]])
  first_imputation[, join_key := paste(as.character(person_id), as.character(trial_id), sep = "\r")]
  match_index <- match(first_imputation$join_key, source_fields$join_key)
  join_check_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    weighted_person_trials = nrow(first_imputation),
    unique_weighted_keys = data.table::uniqueN(first_imputation$join_key),
    source_person_trials_after_weight_eligibility = nrow(source_fields),
    matched_person_trials = sum(!is.na(match_index)),
    unmatched_person_trials = sum(is.na(match_index)),
    duplicated_weighted_keys = sum(duplicated(first_imputation$join_key))
  )
  if (anyNA(match_index) || anyDuplicated(first_imputation$join_key)) {
    stop(cohort_name, ": Stage 04f-to-Stage 05 one-to-one join failed.", call. = FALSE)
  }

  for (imputation_index in seq_along(weighted_imputations)) {
    completed <- data.table::as.data.table(weighted_imputations[[imputation_index]])
    completed[, join_key := paste(as.character(person_id), as.character(trial_id), sep = "\r")]
    index <- match(completed$join_key, source_fields$join_key)
    if (anyNA(index)) stop(cohort_name, ": unmatched row in imputation ", imputation_index, call. = FALSE)
    completed[, followup_time_years := source_fields$followup_time_years[index]]
    completed[, L_survey_stratum := source_fields$L_survey_stratum[index]]
    completed[, L_community := source_fields$L_community[index]]

    if (any(!is.finite(completed$followup_time_years)) ||
        any(completed$followup_time_years <= 0)) {
      stop(cohort_name, ": invalid follow-up time in imputation ", imputation_index, call. = FALSE)
    }
    treatment_value <- suppressWarnings(as.integer(as.character(completed$treatment)))
    if (anyNA(treatment_value) || !all(treatment_value %in% c(0L, 1L))) {
      stop(cohort_name, ": treatment must be coded strictly as 0/1 in imputation ",
           imputation_index, call. = FALSE)
    }
    completed[, treatment := treatment_value]
    completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      completed[, B_country := droplevels(factor(B_country))]
    }

    observed <- completed[
      outcome_observed == 1L & !is.na(primary_event) &
        is.finite(total_weight) & total_weight > 0
    ]
    if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
      stop(cohort_name, ": both treatment arms are required in the observed outcome sample.", call. = FALSE)
    }
    observed[, model_weight := total_weight / mean(total_weight)]

    adjustment_terms <- unlist(
      outcome_config$design_adjustment[[cohort_name]], use.names = FALSE
    )
    formula_text <- paste0(
      "primary_event ~ treatment + ",
      paste(adjustment_terms, collapse = " + "),
      " + offset(log(followup_time_years))"
    )
    outcome_formula <- stats::as.formula(formula_text)
    warning_messages <- character()
    fit <- withCallingHandlers(
      stats::glm(
        formula = outcome_formula,
        data = observed,
        family = stats::quasibinomial(link = "cloglog"),
        weights = model_weight,
        na.action = stats::na.fail,
        control = stats::glm.control(maxit = 100, epsilon = 1e-9)
      ),
      warning = function(warning_condition) {
        warning_messages <<- c(warning_messages, conditionMessage(warning_condition))
        invokeRestart("muffleWarning")
      }
    )
    if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
      stop(cohort_name, ": primary model failed in imputation ", imputation_index, call. = FALSE)
    }

    robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
    standardized <- tte_standardized_cloglog_effects(
      fit = fit,
      robust_vcov = robust$vcov,
      target_data = completed,
      standardization_weight = completed$survey_weight_scaled,
      target_years = target_years
    )

    risk_continue_variance <- standardized$risk_covariance[1L, 1L]
    risk_discontinue_variance <- standardized$risk_covariance[2L, 2L]
    risk_continue_logit_variance <- risk_continue_variance /
      (standardized$risk_continue * (1 - standardized$risk_continue))^2
    risk_discontinue_logit_variance <- risk_discontinue_variance /
      (standardized$risk_discontinue * (1 - standardized$risk_discontinue))^2

    effect_by_imputation_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        target_years = target_years,
        risk_continue = standardized$risk_continue,
        variance_risk_continue = risk_continue_variance,
        logit_risk_continue = tte_logit(standardized$risk_continue),
        variance_logit_risk_continue = risk_continue_logit_variance,
        risk_discontinue = standardized$risk_discontinue,
        variance_risk_discontinue = risk_discontinue_variance,
        logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
        variance_logit_risk_discontinue = risk_discontinue_logit_variance,
        risk_difference = standardized$risk_difference,
        variance_risk_difference = standardized$variance_risk_difference,
        log_risk_ratio = standardized$log_risk_ratio,
        variance_log_risk_ratio = standardized$variance_log_risk_ratio
      )

    model_diagnostic_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        imputation = imputation_index,
        formula = formula_text,
        converged = isTRUE(fit$converged),
        iterations = fit$iter,
        coefficient_n = length(stats::coef(fit)),
        aliased_coefficient_n = sum(is.na(stats::coef(fit))),
        warning_n = length(unique(warning_messages)),
        warnings = paste(unique(warning_messages), collapse = " | "),
        outcome_observations = nrow(observed),
        unique_person_clusters = robust$clusters,
        primary_events = sum(observed$primary_event == 1L),
        continue_observations = sum(observed$treatment == 0L),
        discontinue_observations = sum(observed$treatment == 1L),
        continue_events = sum(observed$primary_event == 1L & observed$treatment == 0L),
        discontinue_events = sum(observed$primary_event == 1L & observed$treatment == 1L),
        followup_minimum_years = min(observed$followup_time_years),
        followup_median_years = stats::median(observed$followup_time_years),
        followup_maximum_years = max(observed$followup_time_years),
        cluster_CR1_correction = robust$correction,
        full_survey_design_variance_available = FALSE
      )

    if (imputation_index == 1L) {
      sample_description_parts[[cohort_name]] <- completed[, .(
        person_trials = .N,
        unique_persons = data.table::uniqueN(person_id),
        outcome_observed_n = sum(outcome_observed == 1L),
        outcome_observed_fraction = mean(outcome_observed == 1L),
        primary_events = sum(primary_event == 1L, na.rm = TRUE),
        followup_minimum_years = min(followup_time_years),
        followup_median_years = stats::median(followup_time_years),
        followup_maximum_years = max(followup_time_years)
      ), by = treatment][, cohort := cohort_name]
    }
  }
}

effect_by_imputation <- data.table::rbindlist(
  effect_by_imputation_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_diagnostic_parts, use.names = TRUE, fill = TRUE
)
sample_description <- data.table::rbindlist(
  sample_description_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(join_check_parts, use.names = TRUE, fill = TRUE)

pooled_rows <- list()
pooling_diagnostic_rows <- list()
for (cohort_name in cohorts) {
  estimates <- effect_by_imputation[cohort == cohort_name]
  df_complete <- min(model_diagnostics[cohort == cohort_name, unique_person_clusters]) -
    max(model_diagnostics[cohort == cohort_name, coefficient_n])

  pooled_continue <- tte_pool_scalar(
    estimates$logit_risk_continue,
    estimates$variance_logit_risk_continue,
    df_complete = df_complete
  )
  pooled_discontinue <- tte_pool_scalar(
    estimates$logit_risk_discontinue,
    estimates$variance_logit_risk_discontinue,
    df_complete = df_complete
  )
  pooled_difference <- tte_pool_scalar(
    estimates$risk_difference,
    estimates$variance_risk_difference,
    df_complete = df_complete,
    null = 0
  )
  pooled_ratio <- tte_pool_scalar(
    estimates$log_risk_ratio,
    estimates$variance_log_risk_ratio,
    df_complete = df_complete,
    null = 0
  )

  pooled_list <- list(
    risk_continue = pooled_continue,
    risk_discontinue = pooled_discontinue,
    risk_difference = pooled_difference,
    risk_ratio = pooled_ratio
  )
  transform_list <- list(
    risk_continue = tte_expit,
    risk_discontinue = tte_expit,
    risk_difference = identity,
    risk_ratio = exp
  )
  null_list <- c(
    risk_continue = NA_real_, risk_discontinue = NA_real_,
    risk_difference = 0, risk_ratio = 1
  )

  for (measure_name in names(pooled_list)) {
    pooled <- pooled_list[[measure_name]]
    transformer <- transform_list[[measure_name]]
    pooled_rows[[paste(cohort_name, measure_name, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        outcome = "primary_event",
        target_years = target_years,
        measure = measure_name,
        estimate = transformer(pooled$estimate),
        confidence_lower = transformer(pooled$lower),
        confidence_upper = transformer(pooled$upper),
        null_value = null_list[[measure_name]],
        p_value = if (measure_name %in% c("risk_difference", "risk_ratio")) {
          pooled$p_value
        } else {
          NA_real_
        },
        imputations = pooled$imputations,
        inference = "person-clustered CR1 sandwich; Rubin pooled",
        interpretation = if (measure_name == "risk_difference") {
          "discontinuation minus continuation"
        } else if (measure_name == "risk_ratio") {
          "discontinuation divided by continuation"
        } else {
          gsub("risk_", "standardized risk under ", measure_name)
        }
      )
    pooling_diagnostic_rows[[paste(cohort_name, measure_name, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        measure = measure_name,
        pooled_transformed_estimate = pooled$estimate,
        transformed_standard_error = pooled$standard_error,
        degrees_freedom = pooled$degrees_freedom,
        within_variance = pooled$within_variance,
        between_variance = pooled$between_variance,
        total_variance = pooled$total_variance,
        relative_increase_variance = pooled$relative_increase_variance,
        fraction_missing_information = pooled$fraction_missing_information,
        complete_data_degrees_freedom = df_complete
      )
  }
}

pooled_effects <- data.table::rbindlist(pooled_rows, use.names = TRUE, fill = TRUE)
pooling_diagnostics <- data.table::rbindlist(
  pooling_diagnostic_rows, use.names = TRUE, fill = TRUE
)
pooled_effects[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000, NA_real_
)]
pooled_effects[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000, NA_real_
)]
pooled_effects[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000, NA_real_
)]

model_summary <- model_diagnostics[, .(
  imputations = .N,
  all_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0),
  any_warning = any(warning_n > 0),
  observed_outcomes = unique(outcome_observations)[1L],
  unique_person_clusters = unique(unique_person_clusters)[1L],
  primary_events = unique(primary_events)[1L],
  min_iterations = min(iterations),
  max_iterations = max(iterations),
  minimum_CR1_correction = min(cluster_CR1_correction),
  maximum_CR1_correction = max(cluster_CR1_correction)
), by = cohort]

tte_write_csv(effect_by_imputation, file.path(output_dir, "06_primary_effects_by_imputation.csv"))
tte_write_csv(pooled_effects, file.path(output_dir, "06_primary_effects_pooled.csv"))
tte_write_csv(pooling_diagnostics, file.path(output_dir, "06_pooling_diagnostics.csv"))
tte_write_csv(model_diagnostics, file.path(output_dir, "06_model_diagnostics.csv"))
tte_write_csv(model_summary, file.path(output_dir, "06_model_summary.csv"))
tte_write_csv(sample_description, file.path(output_dir, "06_analysis_sample.csv"))
tte_write_csv(join_checks, file.path(output_dir, "06_stage04f_stage05_join_check.csv"))
writeLines(
  readLines(outcome_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "06_frozen_primary_outcome_model.yml"),
  useBytes = TRUE
)
saveRDS(
  list(
    effects_by_imputation = effect_by_imputation,
    pooled_effects = pooled_effects,
    pooling_diagnostics = pooling_diagnostics,
    model_diagnostics = model_diagnostics,
    config = outcome_config
  ),
  file.path(private_dir, "stage06_primary_estimates_PRIVATE.rds"),
  version = 3L
)

risk_plot_data <- pooled_effects[
  measure %in% c("risk_continue", "risk_discontinue")
]
risk_plot_data[, treatment_strategy := factor(
  measure,
  levels = c("risk_continue", "risk_discontinue"),
  labels = c("Continue", "Discontinue")
)]
risk_plot <- ggplot2::ggplot(
  risk_plot_data,
  ggplot2::aes(
    x = treatment_strategy, y = estimate,
    ymin = confidence_lower, ymax = confidence_upper,
    colour = treatment_strategy
  )
) +
  ggplot2::geom_pointrange(linewidth = 0.55) +
  ggplot2::facet_wrap(~cohort) +
  ggplot2::scale_y_continuous(labels = function(x) paste0(round(100 * x, 1), "%")) +
  ggplot2::scale_colour_manual(values = c("Continue" = "#2463A8", "Discontinue" = "#C44E52")) +
  ggplot2::labs(
    x = NULL, y = "Standardized 3-year risk (95% CI)",
    title = "Primary cardiovascular or mortality outcome",
    subtitle = "IPTW + IPCW + survey-weighted cloglog model; person-clustered inference"
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(legend.position = "none")

difference_plot_data <- pooled_effects[measure == "risk_difference"]
difference_plot <- ggplot2::ggplot(
  difference_plot_data,
  ggplot2::aes(
    x = estimate * 1000, y = cohort,
    xmin = confidence_lower * 1000, xmax = confidence_upper * 1000
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
  ggplot2::geom_errorbar(
    orientation = "y", width = 0.12, linewidth = 0.55
  ) +
  ggplot2::geom_point(size = 2.4, colour = "#C44E52") +
  ggplot2::labs(
    x = "3-year risk difference per 1,000 (discontinue - continue)",
    y = NULL,
    title = "Primary effect of observed lipid-medication discontinuation"
  ) +
  ggplot2::theme_minimal(base_size = 11)

ggplot2::ggsave(
  file.path(output_dir, "06_standardized_risk_plot.png"),
  risk_plot, width = 8, height = 4.8, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "06_standardized_risk_plot.pdf"),
  risk_plot, width = 8, height = 4.8
)
ggplot2::ggsave(
  file.path(output_dir, "06_risk_difference_plot.png"),
  difference_plot, width = 7.5, height = 3.8, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "06_risk_difference_plot.pdf"),
  difference_plot, width = 7.5, height = 3.8
)

effect_lines <- vapply(cohorts, function(cohort_name) {
  rd <- pooled_effects[cohort == cohort_name & measure == "risk_difference"]
  rr <- pooled_effects[cohort == cohort_name & measure == "risk_ratio"]
  paste0(
    cohort_name, ": RD = ", sprintf("%.1f", rd$estimate_per_1000),
    " per 1,000 (95% CI ", sprintf("%.1f", rd$confidence_lower_per_1000),
    " to ", sprintf("%.1f", rd$confidence_upper_per_1000),
    "); RR = ", sprintf("%.3f", rr$estimate),
    " (95% CI ", sprintf("%.3f", rr$confidence_lower),
    " to ", sprintf("%.3f", rr$confidence_upper), ")."
  )
}, character(1L))

summary_lines <- c(
  "Stage 06: primary three-year effect estimation",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Target risk horizon: ", target_years, " years"),
  paste0("Cohorts estimated: ", paste(cohorts, collapse = ", ")),
  "All Stage 05 gates passed before estimation.",
  "Outcome window: landmark through the observed or cohort-scheduled F-wave reference date.",
  "Nonfatal diagnoses are interval-censored at F; death is counted within the same interval endpoint.",
  "Model: complementary log-log marginal structural outcome model with log follow-up offset, standardized to 3 years.",
  "Adjustment: sequence in HRS; sequence plus country in SHARE.",
  "Weights: Stage 05 survey x treatment x censoring weights, truncated at 1st/99th percentiles.",
  "Inference: person-clustered CR1 sandwich within each imputation, then Rubin pooling.",
  "Full survey PSU/stratum variance was unavailable and is not claimed.",
  "The primary variance treats estimated weights and the empirical standardization distribution as fixed.",
  "The target is the frozen eligible person-trial mixture, not a claimed nationally representative risk.",
  "",
  effect_lines,
  "",
  "Positive RD and RR > 1 indicate higher risk under observed discontinuation.",
  "These are cohort-specific estimates; no cross-cohort meta-analysis was performed in Stage 06.",
  "Do not interpret the exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(summary_lines, file.path(output_dir, "06_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "06_session_info.txt"), useBytes = TRUE)

message(paste(summary_lines, collapse = "\n"))
message("Stage 06 completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
