# Run from the project root. Compare frozen fields with Gateway and RAND sources.
# This audit writes aggregate agreement counts only.
suppressPackageStartupMessages(library(data.table))

adl <- c(adl_dressing = "dressa", adl_bathing = "batha", adl_eating = "eata",
         adl_transfer = "beda", adl_toileting = "toilta")
by_role <- list(
  E = "lipid_medication",
  L = c("lipid_medication", "broad_heart_disease", "stroke", names(adl)),
  F = c("broad_heart_disease", "myocardial_infarction", "stroke", names(adl))
)

audit_cohort <- function(cohort) {
  hrs <- cohort == "HRS"
  if (hrs && .Platform$OS.type == "windows") {
    previous_locale <- Sys.getlocale("LC_CTYPE")
    on.exit(Sys.setlocale("LC_CTYPE", previous_locale), add = TRUE)
    invisible(Sys.setlocale("LC_CTYPE", ".UTF-8"))
  }
  cohort_name <- cohort
  stubs <- c(lipid_medication = "rxhchol", broad_heart_disease = "hearte",
             myocardial_infarction = if (hrs) "hrtatt" else "hearte", stroke = "stroke", adl)
  mapping <- fread("config_r/preferred_clean_mapping.csv")[cohort == cohort_name]
  stopifnot(identical(unname(stubs), mapping$variable[match(names(stubs), mapping$concept)]))
  trials <- as.data.table(readRDS(file.path(
    "outputs_r/stage04_structural_followup/private_do_not_share",
    paste0(tolower(cohort), "_structural_validated_trials_PRIVATE.rds")
  )))[is.finite(L_survey_weight_final) & L_survey_weight_final > 0]
  audit_rows <- rbindlist(lapply(names(by_role), function(role) {
    fields <- by_role[[role]]
    waves <- trials[[paste0(role, "_wave")]]
    keep <- waves < if (hrs) 16L else 9L
    if (role == "F") keep <- keep & trials$F_interview_observed %in% 1L
    rbindlist(lapply(fields, function(concept) {
      data.table(person_id = as.character(trials$person_id[keep]), wave = waves[keep], role,
                 concept, analytic = as.numeric(trials[[paste0(role, "_", concept)]][keep]))
    }))
  }))
  audit_rows[, source_var := paste0("r", wave, stubs[concept])]
  id_column <- if (hrs) "hhidpn" else "mergeid"
  source_dir <- "data_links/stage03c_inputs"
  data_root <- yaml::yaml.load(paste(readLines("config_r/analysis.yml", encoding = "UTF-8"),
                                     collapse = "\n"))$data_root
  rand_file <- file.path("data_links", "stage03c_inputs", "randhrs1992_2020v2.dta")
  source_files <- if (hrs) c(Gateway = file.path(source_dir, "H_HRS_d.dta"),
                            RAND = rand_file) else
    c(Gateway = file.path(source_dir, "H_SHARE_f2.dta"))
  audit_rows[, source_family := ifelse(hrs & !concept %in% c("lipid_medication", "myocardial_infarction"),
                                       "RAND", "Gateway")]
  for (family in names(source_files)) {
    file <- source_files[[family]]
    header <- names(haven::read_dta(file, n_max = 0L))
    requested <- c(id_column, unique(audit_rows[source_family == family, source_var]))
    selected <- match(requested, tolower(header))
    if (anyNA(selected)) stop(cohort, ": missing source names: ", paste(requested[is.na(selected)], collapse = ", "))
    original <- as.data.table(haven::read_dta(file, col_select = tidyselect::all_of(header[selected])))
    setnames(original, tolower(names(original)))
    ids <- original[[id_column]]
    original[, person_id := if (hrs) {
      sub("^0+", "", trimws(format(haven::zap_labels(ids), scientific = FALSE)))
    } else toupper(trimws(as.character(ids)))]
    stopifnot(!anyDuplicated(original$person_id))
    audit_rows[source_family == family, source_value := {
      index <- match(person_id, original$person_id)
      stopifnot(!anyNA(index))
      as.numeric(original[[.BY$source_var]][index])
    }, by = source_var]
  }
  audit_rows[, cohort := cohort_name]
  audit_rows[, .(
    n = .N,
    analytic_observed = sum(!is.na(analytic)), source_observed = sum(!is.na(source_value)),
    same_when_observed = sum(analytic == source_value, na.rm = TRUE),
    both_observed = sum(!is.na(analytic) & !is.na(source_value)),
    missingness_differences = sum(is.na(analytic) != is.na(source_value))
  ), by = .(cohort, source_family, role, wave, concept)]
}

audit <- rbindlist(lapply(c("HRS", "SHARE"), audit_cohort))
stopifnot(all(audit$same_when_observed == audit$both_observed),
          all(audit$missingness_differences == 0L))
destination <- "outputs_r/revision_r1/R1_harmonized_item_mapping_check.csv"
fwrite(audit, destination)
print(audit[, .(
  paired_observed = sum(both_observed), values_in_disagreement = sum(both_observed - same_when_observed),
  missingness_differences = sum(missingness_differences)
), by = .(cohort, concept)])
