# Redraw the supporting synthesis with outcomes retained in the revised paper.
suppressPackageStartupMessages(library(ggplot2))
root <- "outputs_r"
read_output <- function(p) read.csv(file.path(root, p))
effects <- rbind(
  read_output("stage06_primary_effects/06_primary_effects_pooled.csv")[, c("cohort","outcome","measure","estimate","confidence_lower","confidence_upper","p_value")],
  read_output("stage07c_component_effects/07c_component_effects_pooled.csv")[, c("cohort","outcome","measure","estimate","confidence_lower","confidence_upper","p_value")]
)
est <- subset(effects, measure == "risk_difference")
names(est)[names(est) == "cohort"] <- "source"
pooled <- subset(read_output("stage09a_meta_analysis/09a_meta_results.csv"), measure == "risk_difference" & outcome != "death_adl_decline")
se <- (pooled$modified_HK_upper - pooled$modified_HK_lower) / (2 * qt(.975, pooled$modified_HK_df))
pooled <- data.frame(source = "Pooled (modified HK)", outcome = pooled$outcome,
                     estimate = pooled$estimate, confidence_lower = pooled$modified_HK_lower,
                     confidence_upper = pooled$modified_HK_upper,
                     p_value = 2 * pt(-abs(pooled$estimate / se), pooled$modified_HK_df))
data <- rbind(est[,names(pooled)], pooled)
labs <- c(primary_event = "Broad CVD or death", strict_event = "MI, stroke, or death", death_component = "All-cause death")
data$panel <- factor(labs[data$outcome], unname(labs))
data$source <- factor(data$source, c("Pooled (modified HK)", "SHARE", "HRS"))
data$label <- ifelse(data$p_value < .001, "P<0.001", sprintf("P=%.3f", data$p_value))
data$p_x <- ave(data$confidence_upper, data$outcome, FUN = max) + .17 * ave(data$confidence_upper - data$confidence_lower, data$outcome, FUN = max)
p <- ggplot(data, aes(x=1000*estimate, y=source, colour=source, shape=source)) +
  geom_vline(xintercept=0, linetype="dashed", linewidth=.45, colour="#5C5C5C") +
  geom_errorbar(aes(xmin=1000*confidence_lower,xmax=1000*confidence_upper), orientation="y", width=.15, linewidth=.6) +
  geom_point(size=2.4) + geom_text(aes(x=1000*p_x,label=label),size=3,show.legend=FALSE) +
  facet_wrap(~panel, scales="free_x", ncol=1) +
  scale_colour_manual(values=c(HRS="#0072B2",SHARE="#D55E00",`Pooled (modified HK)`="black")) +
  scale_shape_manual(values=c(HRS=16,SHARE=15,`Pooled (modified HK)`=17)) +
  scale_x_continuous(expand=expansion(mult=c(.06,.15))) +
  labs(x="Modeled 3-year risk difference per 1,000 entries", y=NULL) +
  theme_classic(base_size=10,base_family="Arial") +
  theme(legend.position="none",strip.background=element_blank(),strip.text=element_text(face="bold"),
        panel.grid.major.x=element_line(colour="#E6E6E6",linewidth=.3),axis.text=element_text(colour="black"))
destination <- file.path(root,"revision_r1","figures","FigureS6_two_cohort_synthesis")
ggsave(paste0(destination,".pdf"),p,device=cairo_pdf,width=7.2,height=6.8)
ggsave(paste0(destination,".tiff"),p,device="tiff",width=7.2,height=6.8,dpi=600,compression="lzw",type="cairo",bg="white")
ggsave(paste0(destination,".png"),p,device="png",width=7.2,height=6.8,dpi=200,type="cairo",bg="white")
