# Run from the project root. Only aggregate results are written.
suppressPackageStartupMessages(library(data.table))
source("R/_stage06_helpers.R")

read_death_dates <- function(cohort) {
  hrs <- cohort == "HRS"
  filename <- if (hrs) "randhrs1992_2022v1.dta" else
    "sharewX_rel9-0-0_gv_allwaves_cv_r.dta"
  columns <- if (hrs) c("hhidpn", "radyear", "radmonth") else
    c("mergeid", "deceased_year", "deceased_month")
  raw <- haven::read_dta(
    file.path("data_links/stage03c_inputs", filename),
    col_select = tidyselect::all_of(columns)
  )
  id <- haven::zap_labels(raw[[columns[1L]]])
  if (hrs) {
    person_id <- if (is.numeric(id)) format(id, scientific = FALSE, trim = TRUE) else
      trimws(as.character(id))
    person_id <- sub("^0+", "", gsub("[^0-9]", "", sub("[.]0+$", "", person_id)))
    person_id[person_id == ""] <- "0"
  } else {
    person_id <- toupper(trimws(as.character(id)))
  }
  person_id[is.na(id) | !nzchar(person_id)] <- NA_character_
  year <- as.integer(raw[[columns[2L]]])
  month <- as.integer(raw[[columns[3L]]])
  year[!year %in% 1900:2100] <- NA_integer_
  month[!month %in% 1:12] <- NA_integer_

  first_day <- function(y, m) {
    as.Date(ifelse(is.na(y), NA_character_, sprintf("%04d-%02d-01", y, m)))
  }
  proxy <- first_day(year, ifelse(is.na(month), 7L, month))
  lower <- first_day(year, ifelse(is.na(month), 1L, month))
  next_year <- is.na(month) | month == 12L
  upper <- first_day(year + next_year, ifelse(next_year, 1L, month + 1L))
  dates <- data.table(person_id, proxy, lower, upper, month_known = !is.na(month))[
    !is.na(person_id)
  ]
  if (!hrs) setorder(dates, proxy, month_known, na.last = TRUE)
  unique(dates, by = "person_id")
}

prepare_intervals <- function(cohort) {
  trials <- as.data.table(readRDS(file.path(
    "outputs_r/stage04_structural_followup/private_do_not_share",
    paste0(tolower(cohort), "_structural_validated_trials_PRIVATE.rds")
  )))[is.finite(L_survey_weight_final) & L_survey_weight_final > 0]
  trials[, trial_key := paste(person_id, trial_id, sep = "\r")]
  stopifnot(!anyDuplicated(trials$trial_key))
  dates <- read_death_dates(cohort)
  index <- match(as.character(trials$person_id), dates$person_id)
  stopifnot(identical(as.numeric(trials$death_date), as.numeric(dates$proxy[index])))
  endpoint <- as.numeric(trials$followup_reference_date - trials$L_interview_date) / 365.25
  stopifnot(all(endpoint > 0), all(abs(endpoint - trials$followup_time_years) < 1e-10))
  start <- as.numeric(trials$L_interview_date)
  lower <- pmax(0, (as.numeric(dates$lower[index]) - start) / 365.25)
  upper <- pmin(endpoint, (as.numeric(dates$upper[index]) - start) / 365.25)
  death <- trials$death_in_interval %in% 1L
  date_usable <- death & !is.na(lower) & !is.na(upper) & upper > lower
  precision <- rep(NA_character_, nrow(trials))
  precision[death & is.na(lower)] <- "No usable recorded date"
  precision[death & !is.na(lower) & lower >= endpoint] <- "Date at or after assessment endpoint"
  precision[death & !is.na(upper) & upper <= 0] <- "Date before landmark"
  precision[date_usable & dates$month_known[index]] <- "Month recorded"
  precision[date_usable & !dates$month_known[index]] <- "Year recorded"
  stopifnot(all(trials$F_died_this_wave[death & !date_usable] %in% 1L))
  data.table(
    trial_key = trials$trial_key, endpoint, death, precision,
    lower = ifelse(date_usable, lower, ifelse(death, 0, endpoint)),
    upper = ifelse(date_usable, upper, ifelse(death, endpoint, Inf))
  )
}

fit_mortality <- function(observed, cohort, scale, robust = TRUE) {
  formula <- if (cohort == "HRS") {
    survival::Surv(lower, upper, type = "interval2") ~ treatment + sequence
  } else {
    survival::Surv(lower, upper, type = "interval2") ~ treatment + sequence + B_country
  }
  fit <- withCallingHandlers(
    survival::survreg(
      formula, data = observed, weights = model_weight, dist = "weibull",
      scale = scale, robust = robust, cluster = person_id,
      control = survival::survreg.control(maxiter = 100L, rel.tolerance = 1e-9),
      na.action = stats::na.fail
    ),
    warning = function(w) stop(conditionMessage(w), call. = FALSE)
  )
  stopifnot(all(is.finite(stats::coef(fit))), is.finite(fit$scale), fit$scale > 0)
  fit
}

standardize_mortality <- function(fit, target, years, scale_estimated) {
  weight <- target$survey_weight_scaled
  stopifnot(all(is.finite(weight)), all(weight > 0))
  weight <- weight / sum(weight)
  beta <- stats::coef(fit)
  covariance <- fit$var
  stopifnot(nrow(covariance) == length(beta) + scale_estimated)

  arm <- lapply(0:1, function(a) {
    newdata <- as.data.frame(target)
    newdata$treatment <- a
    design <- tte_prediction_design(fit, newdata)
    eta <- drop(design %*% beta)
    prediction <- as.numeric(stats::predict(fit, newdata = newdata, type = "lp"))
    stopifnot(max(abs(eta - prediction)) < 1e-8)
    z <- (log(years) - eta) / fit$scale
    gradient <- -design / fit$scale
    if (scale_estimated) gradient <- cbind(gradient, -z)
    list(
      risk = sum(weight * tte_cloglog_probability(z)),
      gradient = colSums(gradient * (weight * tte_cloglog_derivative(z)))
    )
  })
  p0 <- arm[[1L]]$risk
  p1 <- arm[[2L]]$risk
  g0 <- arm[[1L]]$gradient
  g1 <- arm[[2L]]$gradient
  grad <- rbind(g0 / (p0 * (1 - p0)), g1 / (p1 * (1 - p1)), g1 - g0, g1 / p1 - g0 / p0)
  data.table(
    measure = c("risk_continue", "risk_discontinue", "risk_difference", "risk_ratio"),
    estimate = c(qlogis(p0), qlogis(p1), p1 - p0, log(p1 / p0)),
    variance = diag(grad %*% covariance %*% t(grad))
  )
}

original <- fread("outputs_r/stage07c_component_effects/07c_component_effects_pooled.csv")[
  outcome == "death_component" & target_years == 3
]
analyses <- list()
precision_counts <- list()
for (cohort_name in c("HRS", "SHARE")) {
  message("Checking mortality time intervals for ", cohort_name, " ...")
  intervals <- prepare_intervals(cohort_name)
  prefix <- tolower(cohort_name)
  targets <- readRDS(file.path(
    "outputs_r/stage05_weighting/private_do_not_share",
    paste0(prefix, "_weighted_imputations_PRIVATE.rds")
  ))
  compact <- readRDS(file.path(
    "outputs_r/stage07b_outcome_weights/private_do_not_share",
    paste0(prefix, "_death_component_specific_weights_PRIVATE.rds")
  ))
  stopifnot(length(targets) == 20L, length(compact) == length(targets))
  pooled_input <- rbindlist(lapply(seq_along(targets), function(i) {
    target <- as.data.table(copy(targets[[i]]))
    target[, trial_key := paste(person_id, trial_id, sep = "\r")]
    weights <- compact[[i]]
    j <- match(target$trial_key, intervals$trial_key)
    k <- match(target$trial_key, weights$join_key)
    stopifnot(!anyDuplicated(target$trial_key), !anyDuplicated(weights$join_key),
              !anyNA(j), !anyNA(k), nrow(weights) == nrow(target))
    target[, treatment := as.integer(as.character(treatment))]
    target[, `:=`(
      lower = intervals$lower[j], upper = intervals$upper[j],
      endpoint = intervals$endpoint[j], death = intervals$death[j],
      precision = intervals$precision[j], observation = weights$outcome_observed_specific[k],
      outcome_value = weights$outcome_value[k], model_weight = weights$total_weight_specific[k]
    )]
    observed <- target[observation == 1L & is.finite(model_weight) & model_weight > 0]
    expected <- if (cohort_name == "HRS") c(6869L, 544L) else c(2653L, 197L)
    stopifnot(nrow(observed) == expected[1L], sum(observed$death) == expected[2L],
              all(as.integer(observed$death) == observed$outcome_value),
              all(!is.na(observed$precision[observed$death])),
              all(observed$lower < observed$upper))
    observed[, model_weight := model_weight / mean(model_weight)]
    if (i == 1L) {
      precision_counts[[cohort_name]] <<- observed[death == TRUE, .N, by = precision]
    }

    coarse <- copy(observed)
    coarse[death == TRUE, `:=`(lower = 0, upper = endpoint)]
    date_priority <- copy(observed)
    date_priority[precision == "Date at or after assessment endpoint", `:=`(
      lower = endpoint, upper = Inf
    )]
    rbindlist(lapply(1:4, function(model) {
      variable_shape <- model >= 3L
      model_data <- switch(model, coarse, observed, observed, date_priority)
      fit <- fit_mortality(model_data, cohort_name,
                           scale = if (variable_shape) 0 else 1)
      standardized <- standardize_mortality(fit, target, years = 3,
                                            scale_estimated = variable_shape)
      standardized[, `:=`(
        model = model, df = uniqueN(observed$person_id) - nrow(fit$var)
      )]
      standardized
    }))
  }))
  results <- pooled_input[, {
    p <- tte_pool_scalar(estimate, variance, min(df))
    inverse <- if (measure %in% c("risk_continue", "risk_discontinue")) plogis else
      if (measure == "risk_ratio") exp else identity
    .(estimate = inverse(p$estimate), lower = inverse(p$lower), upper = inverse(p$upper),
      p_value = if (measure %in% c("risk_difference", "risk_ratio")) p$p_value else NA_real_)
  }, by = .(model, measure)]
  published <- original[cohort == cohort_name]
  reproduced <- results[model == 1L][match(published$measure, measure)]
  stopifnot(identical(reproduced$measure, published$measure),
            max(abs(reproduced$estimate - published$estimate)) < 1e-5)
  analyses[[cohort_name]] <- results[model != 1L]
}

format_estimate <- function(estimate, lower, upper, scale, digits) {
  sprintf("%.*f (%.*f to %.*f)", digits, scale * estimate,
          digits, scale * lower, digits, scale * upper)
}

output <- c(
  "# Mortality timing sensitivity analysis", "",
  "## Recorded date precision among deaths in the mortality analysis", "",
  "| Cohort | Month within window | Year overlaps window | No usable date | Date at or after endpoint | Date before landmark | Total deaths |",
  "|:--|--:|--:|--:|--:|--:|--:|"
)
for (cohort_name in names(precision_counts)) {
  count <- precision_counts[[cohort_name]]
  groups <- c("Month recorded", "Year recorded", "No usable recorded date",
              "Date at or after assessment endpoint", "Date before landmark")
  n <- count$N[match(groups, count$precision)]
  n[is.na(n)] <- 0L
  output <- c(output, paste0("| ", paste(c(cohort_name, n, sum(n)), collapse = " | "), " |"))
}
output <- c(
  output, "", "## Standardized 3-year mortality risks", "",
  "| Cohort | Model | Continuation, % (95% CI) | Discontinuation, % (95% CI) | Difference per 1,000 (95% CI) | P (difference) | Risk ratio (95% CI) | P (ratio) |",
  "|:--|:--|--:|--:|--:|--:|--:|--:|"
)
measures <- c("risk_continue", "risk_discontinue", "risk_difference", "risk_ratio")
labels <- c("Original assessment-window model", "Date intervals, exponential",
            "Date intervals, Weibull", "Date intervals, Weibull (date priority)")
for (cohort_name in names(analyses)) {
  original_rows <- original[cohort == cohort_name, .(
    model = 1L, measure, estimate, lower = confidence_lower, upper = confidence_upper, p_value
  )]
  models <- rbind(original_rows, analyses[[cohort_name]])
  for (m in seq_along(labels)) {
    rows <- models[model == m][match(measures, measure)]
    fields <- format_estimate(rows$estimate, rows$lower, rows$upper,
                              scale = c(100, 100, 1000, 1), digits = c(1, 1, 1, 2))
    p <- ifelse(rows$p_value[3:4] < 0.001, "<0.001", sprintf("%.3f", rows$p_value[3:4]))
    fields <- c(fields[1:3], p[1L], fields[4L], p[2L])
    output <- c(output, paste0("| ", paste(c(cohort_name, labels[m], fields), collapse = " | "), " |"))
  }
}
output <- c(output, "",
  "Recorded death months or years defined intervals intersected with the assessment window. When there was no usable overlap, the assessment window defined the event interval for wave-flagged deaths. The date-priority analysis right-censored wave-flagged deaths whose recorded date interval started at or after the assessment endpoint. Known survivors were right-censored at their assessment endpoint. Analysis entries, observation weights, and standardization populations were held fixed across all models. Unobserved vital status was handled as in the original mortality analysis.",
  "",
  "Date-interval model uncertainty uses a person-clustered sandwich covariance and Rubin pooling across 20 imputations. The exponential model with whole-assessment death intervals reproduced the original point estimates within 0.00001 on the reported probability, difference, or ratio scale."
)
destination <- "outputs_r/revision_r1/R1_mortality_date_interval_sensitivity.md"
writeLines(output, destination)
message("Aggregate mortality sensitivity results written to ", destination)
