# Stage 01b: exact mapping, coding, wave coverage, death coverage, and missing-source scan.
# This stage reads selected variables only and does not estimate treatment effects.

.bootstrap_script <- local({
  frames <- sys.frames()
  values <- vapply(frames, function(frame) {
    value <- frame$ofile
    if (is.null(value) || length(value) == 0L) "" else as.character(value[[1L]])
  }, character(1L))
  values <- values[nzchar(values)]
  if (length(values)) normalizePath(tail(values, 1L), winslash = "/", mustWork = FALSE) else NA_character_
})
.bootstrap_root <- if (!is.na(.bootstrap_script)) dirname(dirname(.bootstrap_script)) else getwd()
source(file.path(.bootstrap_root, "R", "_stage1_helpers.R"), encoding = "UTF-8")

tte_require_packages(c("yaml", "haven", "data.table"))

project_root <- tte_find_project_root(.bootstrap_root)
config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
sources <- tte_read_csv_utf8(file.path(project_root, "config_r", "cohort_sources.csv"))
mapping <- tte_read_csv_utf8(file.path(project_root, "config_r", "preferred_clean_mapping.csv"))
data_root <- tte_normalize_path(config$data_root, must_work = TRUE)
stage01_dir <- file.path(project_root, config$output_root, "stage01")
output_dir <- file.path(project_root, config$output_root, "stage01b")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

if (!file.exists(file.path(stage01_dir, "01_file_inventory.csv"))) {
  stop("Run R/01_source_inventory.R before Stage 01b.", call. = FALSE)
}

manifest <- tte_read_csv_utf8(file.path(stage01_dir, "01_file_inventory.csv"))

collapse_values <- function(x, max_values = 20L) {
  x <- x[!is.na(x)]
  if (length(x) == 0L) return("")
  counts <- sort(table(as.character(x), useNA = "no"), decreasing = TRUE)
  counts <- head(counts, max_values)
  paste0(names(counts), " (n=", as.integer(counts), ")", collapse = "; ")
}

safe_numeric_summary <- function(x) {
  numeric_x <- suppressWarnings(as.numeric(as.character(x)))
  numeric_x <- numeric_x[is.finite(numeric_x)]
  if (length(numeric_x) == 0L) {
    return(c(minimum = NA_real_, p25 = NA_real_, median = NA_real_, p75 = NA_real_, maximum = NA_real_))
  }
  values <- stats::quantile(numeric_x, probs = c(0, 0.25, 0.5, 0.75, 1), na.rm = TRUE, names = FALSE)
  names(values) <- c("minimum", "p25", "median", "p75", "maximum")
  values
}

mapping_checks <- list()
wave_profiles <- list()
code_profiles <- list()
death_summaries <- list()
check_index <- wave_index <- code_index <- death_index <- 0L

for (source_index in seq_len(nrow(sources))) {
  source_row <- sources[source_index, , drop = FALSE]
  cohort_name <- source_row$cohort
  clean_path <- file.path(data_root, source_row$clean_file)
  cohort_map <- mapping[mapping$cohort == cohort_name, , drop = FALSE]

  header <- data.table::fread(
    clean_path,
    nrows = 0L,
    check.names = FALSE,
    encoding = "UTF-8",
    showProgress = FALSE
  )
  raw_names <- names(header)
  canonical_names <- tte_clean_variable_name(raw_names)

  for (map_index in seq_len(nrow(cohort_map))) {
    configured <- cohort_map$variable[map_index]
    configured <- if (is.na(configured)) "" else configured
    hits <- which(tolower(canonical_names) == tolower(configured))
    check_index <- check_index + 1L
    mapping_checks[[check_index]] <- data.frame(
      cohort = cohort_name,
      concept = cohort_map$concept[map_index],
      configured_variable = configured,
      required = cohort_map$required[map_index],
      role = cohort_map$role[map_index],
      matches_in_clean_file = length(hits),
      matched_raw_header = if (length(hits)) paste(raw_names[hits], collapse = "; ") else "",
      mapping_status = if (!nzchar(configured)) "SOURCE_TO_RESOLVE" else if (length(hits) == 1L) "EXACT" else if (length(hits) == 0L) "NOT_FOUND" else "DUPLICATE",
      note = cohort_map$note[map_index],
      stringsAsFactors = FALSE
    )
  }

  requested <- unique(cohort_map$variable[!is.na(cohort_map$variable) & nzchar(cohort_map$variable)])
  selected_positions <- unique(unlist(lapply(requested, function(variable) {
    which(tolower(canonical_names) == tolower(variable))
  })))
  if (length(selected_positions) == 0L) stop("No configured variables found for ", cohort_name, call. = FALSE)

  message("Reading selected columns for ", cohort_name, " ...")
  selected <- data.table::fread(
    clean_path,
    select = selected_positions,
    check.names = FALSE,
    encoding = "UTF-8",
    showProgress = interactive()
  )
  data.table::setnames(selected, names(selected), canonical_names[selected_positions])

  # A private local cache prevents repeated reading of the 88-250 MB CSV files.
  saveRDS(selected, file.path(private_dir, paste0(tolower(cohort_name), "_selected_longitudinal.rds")), version = 3L)

  wave_variable <- cohort_map$variable[cohort_map$concept == "wave"][[1L]]
  id_variable <- cohort_map$variable[cohort_map$concept == "person_id"][[1L]]
  death_variable <- cohort_map$variable[cohort_map$concept == "death_year"][[1L]]
  status_variable <- cohort_map$variable[cohort_map$concept == "interview_status"][[1L]]
  waves <- if (wave_variable %in% names(selected)) sort(unique(selected[[wave_variable]])) else NA

  for (map_index in seq_len(nrow(cohort_map))) {
    variable <- cohort_map$variable[map_index]
    if (is.na(variable) || !nzchar(variable) || !variable %in% names(selected)) next
    x <- selected[[variable]]
    numeric_summary <- safe_numeric_summary(x)

    code_index <- code_index + 1L
    code_profiles[[code_index]] <- data.frame(
      cohort = cohort_name,
      concept = cohort_map$concept[map_index],
      variable = variable,
      recode_type = cohort_map$recode_type[map_index],
      storage_class = paste(class(x), collapse = "/"),
      rows = length(x),
      nonmissing = sum(!is.na(x)),
      missing_fraction = mean(is.na(x)),
      distinct_nonmissing = data.table::uniqueN(x, na.rm = TRUE),
      minimum = numeric_summary[["minimum"]],
      p25 = numeric_summary[["p25"]],
      median = numeric_summary[["median"]],
      p75 = numeric_summary[["p75"]],
      maximum = numeric_summary[["maximum"]],
      common_values = if (cohort_map$recode_type[map_index] == "id") "WITHHELD" else collapse_values(x),
      stringsAsFactors = FALSE
    )

    if (!all(is.na(waves))) {
      for (wave_value in waves) {
        wave_selector <- !is.na(selected[[wave_variable]]) & selected[[wave_variable]] == wave_value
        wave_x <- x[wave_selector]
        wave_index <- wave_index + 1L
        wave_profiles[[wave_index]] <- data.frame(
          cohort = cohort_name,
          wave = as.character(wave_value),
          concept = cohort_map$concept[map_index],
          variable = variable,
          wave_rows = sum(wave_selector),
          nonmissing = sum(!is.na(wave_x)),
          nonmissing_fraction = if (sum(wave_selector)) mean(!is.na(wave_x)) else NA_real_,
          distinct_nonmissing = data.table::uniqueN(wave_x, na.rm = TRUE),
          common_values = if (cohort_map$recode_type[map_index] == "id") "WITHHELD" else collapse_values(wave_x, 12L),
          stringsAsFactors = FALSE
        )
      }
    }
  }

  death_index <- death_index + 1L
  death_values <- suppressWarnings(as.numeric(as.character(selected[[death_variable]])))
  valid_death <- is.finite(death_values) & death_values >= 1900 & death_values <= 2100
  valid_ids <- unique(selected[[id_variable]][valid_death])
  status_values <- if (status_variable %in% names(selected)) selected[[status_variable]] else NA
  death_summaries[[death_index]] <- data.frame(
    cohort = cohort_name,
    rows = nrow(selected),
    unique_persons = data.table::uniqueN(selected[[id_variable]], na.rm = TRUE),
    persons_with_valid_death_year = length(valid_ids),
    minimum_death_year = if (any(valid_death)) min(death_values[valid_death]) else NA_real_,
    maximum_death_year = if (any(valid_death)) max(death_values[valid_death]) else NA_real_,
    interview_status_values = collapse_values(status_values),
    stringsAsFactors = FALSE
  )
}

mapping_check <- do.call(rbind, mapping_checks)
wave_profile <- do.call(rbind, wave_profiles)
code_profile <- do.call(rbind, code_profiles)
death_summary <- do.call(rbind, death_summaries)

tte_write_csv(mapping_check, file.path(output_dir, "01b_exact_mapping_check.csv"))
tte_write_csv(wave_profile, file.path(output_dir, "01b_wave_variable_profile.csv"))
tte_write_csv(code_profile, file.path(output_dir, "01b_code_profile.csv"))
tte_write_csv(death_summary, file.path(output_dir, "01b_death_coverage.csv"))

private_note <- c(
  "PRIVATE LOCAL CACHE - DO NOT SHARE",
  "This folder contains selected longitudinal rows including person identifiers.",
  "Only return aggregate CSV files from the parent outputs_r/stage01b directory."
)
writeLines(private_note, file.path(private_dir, "DO_NOT_SHARE.txt"), useBytes = TRUE)

required_unresolved <- mapping_check[
  mapping_check$required == "yes" & mapping_check$mapping_status != "EXACT",
  ,
  drop = FALSE
]
summary_lines <- c(
  "Stage 01b exact mapping and coding audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Exact mapping rows: ", sum(mapping_check$mapping_status == "EXACT")),
  paste0("Required mappings still unresolved: ", nrow(required_unresolved)),
  "",
  "No treatment effect was estimated.",
  "Do not return the private_do_not_share folder."
)
writeLines(summary_lines, file.path(output_dir, "01b_stage_summary.txt"), useBytes = TRUE)
cat(paste(summary_lines, collapse = "\n"), "\n")
