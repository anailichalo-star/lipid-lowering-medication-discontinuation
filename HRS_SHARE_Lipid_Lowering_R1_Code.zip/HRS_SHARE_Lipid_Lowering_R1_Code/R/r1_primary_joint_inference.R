# Run from the project root. Writes only an aggregate supplementary table.
suppressPackageStartupMessages(library(data.table))
source("R/_stage06_helpers.R")

fit_checked <- function(x, y, family, label, ...) {
  fit <- stats::glm.fit(x, y, family = family, ...)
  if (!fit$converged || any(!is.finite(fit$coefficients))) {
    stop(label, " model failed or was rank deficient", call. = FALSE)
  }
  fit
}

load_cohort <- function(cohort_name, specifications) {
  prefix <- tolower(cohort_name)
  weighted <- readRDS(file.path(
    "outputs_r/stage05_weighting/private_do_not_share",
    paste0(prefix, "_weighted_imputations_PRIVATE.rds")
  ))
  times <- as.data.table(readRDS(file.path(
    "outputs_r/stage04_structural_followup/private_do_not_share",
    paste0(prefix, "_structural_validated_trials_PRIVATE.rds")
  )))[is.finite(L_survey_weight_final) & L_survey_weight_final > 0]
  stopifnot(length(weighted) == 20L)
  time_id <- paste(times$person_id, times$trial_id, sep = "\r")
  stopifnot(!anyDuplicated(time_id))
  forms <- specifications[cohort == cohort_name]
  form <- function(label) stats::delete.response(stats::terms(stats::as.formula(
    forms$formula[match(label, forms$model)], env = baseenv()
  )))
  list(weighted = weighted, times = times, time_id = time_id,
       formulas = list(full = form("treatment_denominator"), design = form("treatment_numerator")))
}

logit_components <- function(x, y, label, floor) {
  fit <- fit_checked(x, y, stats::binomial(), label,
                     control = stats::glm.control(maxit = 100L, epsilon = 1e-8))
  p <- fit$fitted.values
  information <- crossprod(x, x * (p * (1 - p)))
  list(p = pmax(floor, pmin(1 - floor, p)),
       active = p > floor & p < 1 - floor,
       influence = (x * (y - p)) %*% tte_inverse_information(information))
}

quantile_influence <- function(raw, observed, jacobian, nuisance_if, p, band) {
  quantiles <- stats::quantile(raw, c(p - band, p, p + band), type = 2L, names = FALSE)
  near <- raw >= quantiles[1L] & raw <= quantiles[3L]
  stopifnot(sum(near) > 5L, quantiles[3L] > quantiles[1L])
  density_inverse <- (quantiles[3L] - quantiles[1L]) / (2 * band)
  direct <- numeric(length(observed))
  direct[observed] <- (p - (raw <= quantiles[2L])) * density_inverse / length(raw)
  indirect <- drop(nuisance_if %*% colMeans(jacobian[near, , drop = FALSE]))
  direct + indirect
}

joint_estimates <- function(data, fixed, formulas, settings, bandwidths) {
  a <- as.integer(data$treatment)
  r <- as.integer(data$outcome_observed)
  observed <- r == 1L
  stopifnot(setequal(a, 0:1), setequal(r, 0:1), all(is.na(fixed$event) == !observed))
  den <- stats::model.matrix(formulas$full, data)
  num <- stats::model.matrix(formulas$design, data)
  x_rden <- cbind(den, treatment = a)
  x_rnum <- cbind(num, treatment = a)
  p_den <- logit_components(den, a, "treatment denominator", settings$floor)
  p_num <- logit_components(num, a, "treatment numerator", settings$floor)
  r_den <- logit_components(x_rden, r, "observation denominator", settings$floor)
  r_num <- logit_components(x_rnum, r, "observation numerator", settings$floor)
  log_weight_derivative <- cbind(
    -den * ((a - p_den$p) * p_den$active),
    num * ((a - p_num$p) * p_num$active),
    -x_rden * ((1 - r_den$p) * r_den$active),
    x_rnum * ((1 - r_num$p) * r_num$active)
  )

  strata <- if ("B_country" %in% all.vars(formulas$design)) {
    interaction(data$sequence, data$B_country, drop = TRUE)
  } else data$sequence
  strata_design <- stats::model.matrix(~ 0 + strata)
  stratum_mean <- stats::ave(fixed$survey, strata, FUN = mean)
  stratum_n <- drop(strata_design %*% colSums(strata_design))
  survey <- fixed$survey / stratum_mean
  log_mean_if <- strata_design * ((survey - 1) / stratum_n)
  nuisance_if <- cbind(p_den$influence, p_num$influence, r_den$influence,
                       r_num$influence, log_mean_if)
  w_a <- ifelse(a == 1L, p_num$p / p_den$p, (1 - p_num$p) / (1 - p_den$p))
  raw <- (survey * w_a * r_num$p / r_den$p)[observed]
  raw_derivative <- cbind(log_weight_derivative, -strata_design)[observed, , drop = FALSE] * raw
  bounds <- stats::quantile(raw, settings$truncate, type = 2L, names = FALSE)
  clipped <- pmin(bounds[2L], pmax(bounds[1L], raw))

  design <- cbind(num[, 1L, drop = FALSE], treatment = a, num[, -1L, drop = FALSE])
  x_obs <- design[observed, , drop = FALSE]
  y <- fixed$event[observed]
  model_weight <- clipped / mean(clipped)
  fit <- fit_checked(x_obs, y, stats::quasibinomial(link = "cloglog"), "primary outcome",
                     weights = model_weight, offset = log(fixed$years[observed]),
                     control = stats::glm.control(maxit = 100L, epsilon = 1e-9))
  mu <- fit$fitted.values
  eta <- fit$linear.predictors
  hazard <- exp(eta)
  derivative <- fit$family$mu.eta(eta)
  # Differentiate the cloglog outcome score, including its residual term.
  residual_score <- (y - mu) * hazard / mu
  score_derivative <- residual_score - hazard * y * derivative / mu^2
  inverse_information <- tte_inverse_information(
    crossprod(x_obs, x_obs * (-model_weight * score_derivative))
  )
  score_obs <- x_obs * residual_score
  score <- matrix(0, nrow(data), ncol(design))
  score[observed, ] <- score_obs * model_weight

  lower_tail <- raw < bounds[1L]
  upper_tail <- raw > bounds[2L]
  inside <- !lower_tail & !upper_tail
  score_nuisance <- crossprod(score_obs[inside, , drop = FALSE],
                              raw_derivative[inside, , drop = FALSE]) / mean(clipped)
  adjusted_score <- score + nuisance_if %*% t(score_nuisance)
  tail_score <- rbind(colSums(score_obs[lower_tail, , drop = FALSE]),
                      colSums(score_obs[upper_tail, , drop = FALSE])) / mean(clipped)

  risks <- lapply(0:1, function(arm) {
    target <- design
    target[, "treatment"] <- arm
    lp <- drop(target %*% fit$coefficients) + log(settings$target_years)
    w <- survey / sum(survey)
    probabilities <- fit$family$linkinv(lp)
    value <- sum(w * probabilities)
    direct <- w * (probabilities - value)
    survey_if <- -drop(log_mean_if %*% crossprod(strata_design, direct))
    list(value = value, empirical = direct + survey_if,
         gradient = colSums(target * (w * fit$family$mu.eta(lp))))
  })
  p0 <- risks[[1L]]$value
  p1 <- risks[[2L]]$value
  estimates <- c(risk_continue = qlogis(p0), risk_discontinue = qlogis(p1),
                 risk_difference = p1 - p0, risk_ratio = log(p1 / p0))
  cluster_variances <- lapply(bandwidths, function(band) {
    cutoffs <- vapply(settings$truncate, function(p) {
      quantile_influence(raw, observed, raw_derivative, nuisance_if, p, band)
    }, numeric(nrow(data)))
    beta_if <- (adjusted_score + cutoffs %*% tail_score) %*% inverse_information
    probability_if <- vapply(risks, function(arm) {
      arm$empirical + drop(beta_if %*% arm$gradient)
    }, numeric(nrow(data)))
    a0 <- probability_if[, 1L]
    a1 <- probability_if[, 2L]
    influence <- cbind(a0 / (p0 * (1 - p0)), a1 / (p1 * (1 - p1)), a1 - a0, a1 / p1 - a0 / p0)
    cluster <- rowsum(influence, data$person_id, reorder = FALSE)
    apply(cluster, 2L, stats::var) * nrow(cluster)
  })
  stopifnot(all(is.finite(estimates)), all(unlist(cluster_variances) > 0))
  list(estimates = estimates, variances = do.call(cbind, cluster_variances),
       df = uniqueN(data$person_id[observed]) - ncol(design))
}

weight_config <- yaml::read_yaml("config_r/primary_weight_model.yml")
settings <- list(
  floor = weight_config$probability_floor,
  truncate = c(weight_config$weight_lower_quantile, weight_config$weight_upper_quantile),
  target_years = 3
)
specifications <- fread("outputs_r/stage05_weighting/05_model_specification.csv")
original <- fread("outputs_r/stage06_primary_effects/06_primary_effects_pooled.csv")
by_imputation <- fread("outputs_r/stage06_primary_effects/06_primary_effects_by_imputation.csv")
bandwidths <- c(0.005, 0.003, 0.007)
output <- c("# Joint estimating-equation inference for the primary outcome", "",
  "The primary model and standardization were reproduced in each completed dataset. Person-clustered influence functions propagate uncertainty from the treatment and outcome-observation models, survey-weight normalization, combined-weight percentile cutoffs, the outcome model, and the empirical standardization distribution, conditional on the spline basis. The percentile derivatives use local quantile-density and weight-derivative estimates. Estimates were pooled using Rubin's rules across 20 imputations.", "",
  "| Cohort | Measure | Original estimate (95% CI) | Original P | Joint estimate (95% CI) | Joint P |",
  "|:--|:--|--:|--:|--:|--:|"
)
diagnostics <- character()
for (name in c("HRS", "SHARE")) {
  input <- load_cohort(name, specifications)
  result <- lapply(input$weighted, function(data) {
    id <- paste(data$person_id, data$trial_id, sep = "\r")
    index <- match(id, input$time_id)
    years <- input$times$followup_time_years[index]
    stopifnot(length(id) == length(input$time_id), !anyDuplicated(id), !anyNA(index),
              all(is.finite(years)), all(years > 0), all(data$L_survey_weight_final > 0))
    fixed <- list(event = data$primary_event, survey = data$L_survey_weight_final, years = years)
    joint_estimates(as.data.frame(data), fixed, input$formulas, settings, bandwidths)
  })
  estimates <- do.call(rbind, lapply(result, `[[`, "estimates"))
  expected <- as.matrix(by_imputation[cohort == name][order(imputation), .(
    logit_risk_continue, logit_risk_discontinue, risk_difference, log_risk_ratio
  )])
  max_error <- max(abs(estimates - expected))
  stopifnot(is.finite(max_error), max_error < 1e-7)
  df <- min(vapply(result, `[[`, numeric(1L), "df"))
  variances <- simplify2array(lapply(result, `[[`, "variances"))
  for (j in seq_len(ncol(estimates))) {
    pooled <- lapply(seq_along(bandwidths), function(k) {
      tte_pool_scalar(estimates[, j], variances[j, k, ], df)
    })
    fitted <- pooled[[1L]]
    measure_name <- colnames(estimates)[j]
    old <- original[cohort == name & measure == measure_name]
    stopifnot(nrow(old) == 1L)
    transform <- list(stats::plogis, stats::plogis, identity, exp)[[j]]
    scale <- c(100, 100, 1000, 1)[j]
    digits <- if (j == 4L) 3L else 1L
    format_ci <- function(x) sprintf("%.*f (%.*f to %.*f)", digits, x[1L], digits, x[2L], digits, x[3L])
    format_p <- function(p) if (p < 0.001) "<0.001" else sprintf("%.3f", p)
    labels <- c("Continuation risk, %", "Discontinuation risk, %", "Risk difference per 1,000", "Risk ratio")
    old_ci <- format_ci(scale * c(old$estimate, old$confidence_lower, old$confidence_upper))
    new_ci <- format_ci(scale * transform(c(fitted$estimate, fitted$lower, fitted$upper)))
    output <- c(output, paste0("| ", paste(c(
      name, labels[j], old_ci, if (j >= 3L) format_p(old$p_value) else "-",
      new_ci, if (j >= 3L) format_p(fitted$p_value) else "-"
    ), collapse = " | "), " |"))
    ratio <- vapply(pooled[-1L], function(x) x$standard_error / fitted$standard_error, numeric(1L))
    diagnostics <- c(diagnostics, sprintf("%s, %s: alternate bandwidth SE ratios %.3f and %.3f.",
                                          name, labels[j], ratio[1L], ratio[2L]))
  }
  message(name, ": all primary point estimates reproduced, maximum error ", signif(max_error, 3))
}
destination <- "outputs_r/revision_r1/R1_primary_joint_inference.md"
writeLines(c(output, "", "## Validation", "",
  "All four point estimates in each of the 20 completed datasets matched Stage 06 to within 0.0000001 on the modeling scale. The local quantile probability half-width was 0.005 for the main variance and 0.003 and 0.007 for stability checks.",
  "", diagnostics), destination)
message("Aggregate joint-inference results written to ", destination)
