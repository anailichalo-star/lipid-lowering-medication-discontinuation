# Scientific Reports R1: aggregate the two visit intervals in the Stage 06 sample.
# Participant-level records stay in the local R process.

args <- commandArgs(trailingOnly = TRUE)
project_root <- if (length(args)) args[[1L]] else getwd()
output_root <- file.path(project_root, "outputs_r")
original <- read.csv(file.path(output_root, "stage06_primary_effects", "06_analysis_sample.csv"))

interval_summary <- function(years) {
  quartiles <- quantile(years, probs = c(0.25, 0.50, 0.75), names = FALSE)
  sprintf("%.2f (%.2f-%.2f)", quartiles[2L], quartiles[1L], quartiles[3L])
}

summarize_arm <- function(entries, cohort, group, sequence_label) {
  count <- nrow(entries)
  at_least_three <- sum(entries$followup_time_years >= 3)
  sprintf(
    "| %s | %s | %s | %d | %d | %s | %s | %d (%.1f%%) |",
    cohort, sequence_label, group, count, sum(!is.na(entries$primary_event)),
    interval_summary(entries$prior_interval_years),
    interval_summary(entries$followup_time_years),
    at_least_three, 100 * at_least_three / count
  )
}

summarize_cohort <- function(cohort) {
  path <- file.path(
    output_root, "stage04_structural_followup", "private_do_not_share",
    paste0(tolower(cohort), "_structural_validated_trials_PRIVATE.rds")
  )
  entries <- as.data.frame(readRDS(path))
  weight <- as.numeric(entries$L_survey_weight_final)
  entries <- entries[is.finite(weight) & weight > 0, , drop = FALSE]
  stopifnot(
    !anyDuplicated(entries[c("person_id", "trial_id")]),
    all(entries$treatment %in% c(0L, 1L)),
    all(!is.na(entries$sequence)),
    all(is.finite(entries$prior_interval_years)),
    all(is.finite(entries$followup_time_years))
  )

  reference <- original[original$cohort == cohort, , drop = FALSE]
  for (arm in 0:1) {
    subset <- entries[entries$treatment == arm, , drop = FALSE]
    expected <- reference[reference$treatment == arm, , drop = FALSE]
    actual <- c(
      nrow(subset), length(unique(subset$person_id)),
      sum(!is.na(subset$primary_event)), sum(subset$primary_event == 1L, na.rm = TRUE),
      min(subset$followup_time_years), median(subset$followup_time_years),
      max(subset$followup_time_years)
    )
    fields <- c(
      "person_trials", "unique_persons", "outcome_observed_n", "primary_events",
      "followup_minimum_years", "followup_median_years", "followup_maximum_years"
    )
    stopifnot(nrow(expected) == 1L, isTRUE(all.equal(actual, as.numeric(expected[1L, fields]))))
  }

  sequences <- unique(entries[c("E_wave", "L_wave", "F_wave", "sequence")])
  sequences <- sequences[order(sequences$E_wave, sequences$L_wave, sequences$F_wave), ]
  labels <- c("All eligible sequences", apply(sequences[c("E_wave", "L_wave", "F_wave")], 1L, paste, collapse = "-"))
  sequence_keys <- c(NA_character_, as.character(sequences$sequence))
  rows <- character()
  for (i in seq_along(sequence_keys)) {
    in_sequence <- if (is.na(sequence_keys[i])) rep(TRUE, nrow(entries)) else entries$sequence == sequence_keys[i]
    for (arm in 0:1) {
      subset <- entries[in_sequence & entries$treatment == arm, , drop = FALSE]
      stopifnot(nrow(subset) > 0L)
      group <- c("Continuation", "Discontinuation")[[arm + 1L]]
      rows <- c(rows, summarize_arm(subset, cohort, group, labels[i]))
    }
  }
  rows
}

rows <- c(summarize_cohort("HRS"), summarize_cohort("SHARE"))
output_dir <- file.path(output_root, "revision_r1")
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)
output <- file.path(output_dir, "R1_supplementary_visit_intervals.md")
writeLines(enc2utf8(c(
  "# Visit intervals by cohort, medication group, and visit sequence",
  "",
  "| Cohort | Visit sequence | Medication group | Eligible entries | Primary outcome observed | Previous visit to landmark, median (IQR), y | Landmark to endpoint, median (IQR), y | Landmark to endpoint at least 3 y, n (%) |",
  "|---|---|---|---:|---:|---:|---:|---:|",
  rows,
  "",
  "Intervals are summarized without weights among eligible landmark entries in the primary analysis sample. The endpoint was the follow-up interview date when available and otherwise the median interview date for that wave within the cohort. An interval of at least 3 years refers to the assessment window and does not establish that vital status or other outcomes were observed for 3 years. IQR denotes interquartile range."
)), output, useBytes = TRUE)
message("Stage 06 group counts, observed outcomes, events, and follow-up summaries reproduced in both cohorts.")
message("Wrote ", output)
