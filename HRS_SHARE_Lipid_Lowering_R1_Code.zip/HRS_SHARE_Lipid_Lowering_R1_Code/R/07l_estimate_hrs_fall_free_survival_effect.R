# Stage 07l: estimate the HRS three-year effect on all-cause death or a
# reported fall, using the outcome-specific weights from Stage 07k.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_stage06_helpers.R"), encoding = "UTF-8", local = TRUE)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop("Missing required packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
output_root <- file.path(project_root, analysis_config$output_root)
stage04_path <- file.path(
  output_root, "stage04_structural_followup", "private_do_not_share",
  "hrs_structural_validated_trials_PRIVATE.rds"
)
stage05_path <- file.path(
  output_root, "stage05_weighting", "private_do_not_share",
  "hrs_weighted_imputations_PRIVATE.rds"
)
stage07k_dir <- file.path(output_root, "stage07k_hrs_fall_weights")
weight_path <- file.path(stage07k_dir, "private_do_not_share", "hrs_fall_weights_PRIVATE.rds")
gate_path <- file.path(stage07k_dir, "07k_weighting_gate.csv")
output_dir <- file.path(output_root, "stage07l_hrs_fall_effect")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)
for (path in c(stage04_path, stage05_path, weight_path, gate_path)) {
  if (!file.exists(path)) stop("Missing Stage 07l input: ", path, call. = FALSE)
}

as_true <- function(x) tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
if (nrow(gate) != 1L || !as_true(gate$ready_for_fall_effect_estimation)) {
  stop("HRS did not pass the Stage 07k fall weighting gate.", call. = FALSE)
}

target_years <- as.numeric(analysis_config$design$target_risk_years)
outcome_name <- "death_or_reported_fall"
outcome_label <- "All-cause death or a reported fall"

source_trials <- data.table::as.data.table(readRDS(stage04_path))
source_trials <- source_trials[
  is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
    suppressWarnings(as.numeric(L_survey_weight_final)) > 0
]
source_trials[, join_key := paste(
  as.character(person_id), as.character(trial_id), sep = "\r"
)]
source_fields <- source_trials[, .(
  join_key, followup_time_years = suppressWarnings(as.numeric(followup_time_years))
)]
imputed_datasets <- readRDS(stage05_path)
fall_weights <- readRDS(weight_path)
if (!is.list(imputed_datasets) || !is.list(fall_weights) ||
    length(imputed_datasets) != 20L || length(fall_weights) != 20L) {
  stop("Stage 05 and Stage 07k must each contain 20 datasets.", call. = FALSE)
}

effect_parts <- list()
model_parts <- list()
join_parts <- list()
sample_description <- NULL

for (imputation_index in seq_along(imputed_datasets)) {
  completed <- data.table::as.data.table(data.table::copy(imputed_datasets[[imputation_index]]))
  compact <- data.table::as.data.table(data.table::copy(fall_weights[[imputation_index]]))
  completed[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  weight_index <- match(completed$join_key, compact$join_key)
  source_index <- match(completed$join_key, source_fields$join_key)
  exact_identity <- !anyNA(weight_index) && !anyNA(source_index) &&
    nrow(completed) == nrow(compact) &&
    all(suppressWarnings(as.integer(as.character(completed$treatment))) ==
          compact$treatment[weight_index])
  if (!exact_identity) stop("Stage 07l person-trial join failed.", call. = FALSE)

  completed[, outcome_value := compact$outcome_value[weight_index]]
  completed[, outcome_observed_specific := compact$outcome_observed_specific[weight_index]]
  completed[, total_weight_specific := compact$total_weight_specific[weight_index]]
  completed[, followup_time_years := source_fields$followup_time_years[source_index]]
  completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
  completed[, outcome_value := suppressWarnings(as.integer(outcome_value))]
  completed[, sequence := droplevels(factor(sequence))]

  observed <- completed[
    outcome_observed_specific == 1L & !is.na(outcome_value) &
      is.finite(total_weight_specific) & total_weight_specific > 0
  ]
  if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
    stop("Both observed treatment arms are required for Stage 07l.", call. = FALSE)
  }
  observed[, model_weight := total_weight_specific / mean(total_weight_specific)]
  formula_text <- "outcome_value ~ treatment + sequence + offset(log(followup_time_years))"
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::glm(
      stats::as.formula(formula_text), data = observed,
      family = stats::quasibinomial(link = "cloglog"), weights = model_weight,
      na.action = stats::na.fail,
      control = stats::glm.control(maxit = 100, epsilon = 1e-9)
    ),
    warning = function(w) {
      warning_messages <<- c(warning_messages, conditionMessage(w))
      invokeRestart("muffleWarning")
    }
  )
  if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
    stop("Stage 07l outcome model failed.", call. = FALSE)
  }
  robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
  standardized <- tte_standardized_cloglog_effects(
    fit = fit, robust_vcov = robust$vcov, target_data = completed,
    standardization_weight = completed$survey_weight_scaled,
    target_years = target_years
  )
  variance_continue <- standardized$risk_covariance[1L, 1L]
  variance_discontinue <- standardized$risk_covariance[2L, 2L]
  effect_parts[[imputation_index]] <- data.table::data.table(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index,
    target_years = target_years,
    risk_continue = standardized$risk_continue,
    variance_risk_continue = variance_continue,
    logit_risk_continue = tte_logit(standardized$risk_continue),
    variance_logit_risk_continue = variance_continue /
      (standardized$risk_continue * (1 - standardized$risk_continue))^2,
    risk_discontinue = standardized$risk_discontinue,
    variance_risk_discontinue = variance_discontinue,
    logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
    variance_logit_risk_discontinue = variance_discontinue /
      (standardized$risk_discontinue * (1 - standardized$risk_discontinue))^2,
    risk_difference = standardized$risk_difference,
    variance_risk_difference = standardized$variance_risk_difference,
    log_risk_ratio = standardized$log_risk_ratio,
    variance_log_risk_ratio = standardized$variance_log_risk_ratio
  )
  model_parts[[imputation_index]] <- data.table::data.table(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index,
    formula = formula_text, converged = isTRUE(fit$converged), iterations = fit$iter,
    coefficient_n = length(stats::coef(fit)),
    aliased_coefficient_n = sum(is.na(stats::coef(fit))),
    warning_n = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    outcome_observations = nrow(observed),
    unique_person_clusters = robust$clusters,
    events = sum(observed$outcome_value == 1L),
    continue_events = sum(observed$outcome_value == 1L & observed$treatment == 0L),
    discontinue_events = sum(observed$outcome_value == 1L & observed$treatment == 1L)
  )
  join_parts[[imputation_index]] <- data.table::data.table(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index,
    stage05_rows = nrow(completed), stage07k_weight_rows = nrow(compact),
    exact_person_trial_treatment_identity = exact_identity
  )
  if (imputation_index == 1L) {
    sample_description <- completed[, .(
      eligible_person_trials = .N,
      unique_persons = data.table::uniqueN(person_id),
      outcome_observed_n = sum(outcome_observed_specific == 1L),
      events = sum(outcome_value == 1L, na.rm = TRUE)
    ), by = treatment][, `:=`(
      cohort = "HRS", outcome = outcome_name,
      treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
    )]
  }
}

effects_by_imputation <- data.table::rbindlist(effect_parts, fill = TRUE)
model_diagnostics <- data.table::rbindlist(model_parts, fill = TRUE)
join_checks <- data.table::rbindlist(join_parts, fill = TRUE)
df_complete <- min(model_diagnostics$unique_person_clusters) -
  max(model_diagnostics$coefficient_n)
pooled_list <- list(
  risk_continue = tte_pool_scalar(
    effects_by_imputation$logit_risk_continue,
    effects_by_imputation$variance_logit_risk_continue,
    df_complete = df_complete
  ),
  risk_discontinue = tte_pool_scalar(
    effects_by_imputation$logit_risk_discontinue,
    effects_by_imputation$variance_logit_risk_discontinue,
    df_complete = df_complete
  ),
  risk_difference = tte_pool_scalar(
    effects_by_imputation$risk_difference,
    effects_by_imputation$variance_risk_difference,
    df_complete = df_complete, null = 0
  ),
  risk_ratio = tte_pool_scalar(
    effects_by_imputation$log_risk_ratio,
    effects_by_imputation$variance_log_risk_ratio,
    df_complete = df_complete, null = 0
  )
)
transformers <- list(
  risk_continue = tte_expit, risk_discontinue = tte_expit,
  risk_difference = identity, risk_ratio = exp
)
pooled_parts <- lapply(names(pooled_list), function(measure_name) {
  pooled <- pooled_list[[measure_name]]
  transform_value <- transformers[[measure_name]]
  data.table::data.table(
    cohort = "HRS", outcome = outcome_name, outcome_label = outcome_label,
    target_years = target_years, measure = measure_name,
    estimate = transform_value(pooled$estimate),
    confidence_lower = transform_value(pooled$lower),
    confidence_upper = transform_value(pooled$upper),
    p_value = if (measure_name %in% c("risk_difference", "risk_ratio")) pooled$p_value else NA_real_,
    imputations = pooled$imputations,
    inference = "person-clustered CR1 sandwich; Rubin pooled"
  )
})
pooled_effects <- data.table::rbindlist(pooled_parts, fill = TRUE)
pooled_effects[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000, NA_real_
)]
pooled_effects[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000, NA_real_
)]
pooled_effects[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000, NA_real_
)]

tte_write_csv(effects_by_imputation, file.path(output_dir, "07l_effects_by_imputation.csv"))
tte_write_csv(pooled_effects, file.path(output_dir, "07l_effects_pooled.csv"))
tte_write_csv(model_diagnostics, file.path(output_dir, "07l_model_diagnostics.csv"))
tte_write_csv(sample_description, file.path(output_dir, "07l_analysis_sample.csv"))
tte_write_csv(join_checks, file.path(output_dir, "07l_join_checks.csv"))
saveRDS(
  list(effects_by_imputation = effects_by_imputation, pooled_effects = pooled_effects),
  file.path(private_dir, "stage07l_hrs_fall_effect_PRIVATE.rds"), version = 3L
)

risk_plot <- ggplot2::ggplot(
  pooled_effects[measure %in% c("risk_continue", "risk_discontinue")][,
    strategy := factor(measure,
      levels = c("risk_continue", "risk_discontinue"),
      labels = c("Continue", "Discontinue")
    )
  ],
  ggplot2::aes(
    x = strategy, y = estimate, ymin = confidence_lower,
    ymax = confidence_upper, colour = strategy
  )
) +
  ggplot2::geom_pointrange(linewidth = 0.5) +
  ggplot2::scale_y_continuous(labels = function(x) paste0(round(100 * x, 1), "%")) +
  ggplot2::scale_colour_manual(values = c(Continue = "#2463A8", Discontinue = "#C44E52")) +
  ggplot2::labs(
    x = NULL, y = "Standardized 3-year risk (95% CI)",
    title = "All-cause death or a reported fall in HRS",
    subtitle = "SHARE is not included because its fall item is not comparable"
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(legend.position = "none")
ggplot2::ggsave(
  file.path(output_dir, "07l_standardized_risk_plot.png"),
  risk_plot, width = 7.5, height = 5, dpi = 300
)
ggplot2::ggsave(
  file.path(output_dir, "07l_standardized_risk_plot.pdf"),
  risk_plot, width = 7.5, height = 5
)

risk0 <- pooled_effects[measure == "risk_continue"]
risk1 <- pooled_effects[measure == "risk_discontinue"]
rd <- pooled_effects[measure == "risk_difference"]
rr <- pooled_effects[measure == "risk_ratio"]
summary_lines <- c(
  "Stage 07l: HRS death-or-reported-fall effect estimation",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  sprintf("Continue risk: %.1f%%; discontinue risk: %.1f%%.", 100 * risk0$estimate, 100 * risk1$estimate),
  sprintf(
    "RD = %.1f per 1,000 (95%% CI %.1f to %.1f); RR = %.3f (95%% CI %.3f to %.3f).",
    1000 * rd$estimate, 1000 * rd$confidence_lower, 1000 * rd$confidence_upper,
    rr$estimate, rr$confidence_lower, rr$confidence_upper
  ),
  "Positive values indicate more death or reported falls under observed discontinuation.",
  "The composite is HRS-specific and is interpreted alongside all-cause death.",
  "Do not interpret the exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(summary_lines, file.path(output_dir, "07l_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(utils::sessionInfo()), file.path(output_dir, "07l_session_info.txt"), useBytes = TRUE)
cat(paste(summary_lines, collapse = "\n"), "\n")

