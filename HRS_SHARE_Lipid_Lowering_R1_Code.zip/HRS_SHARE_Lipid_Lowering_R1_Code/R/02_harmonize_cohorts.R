# Stage 02: create canonical long files and recover wave-specific status/weights.
# This script produces no treatment-effect estimate and does not yet create trials.

.bootstrap_script <- local({
  frames <- sys.frames()
  values <- vapply(frames, function(frame) {
    value <- frame$ofile
    if (is.null(value) || length(value) == 0L) "" else as.character(value[[1L]])
  }, character(1L))
  values <- values[nzchar(values)]
  if (length(values)) normalizePath(tail(values, 1L), winslash = "/", mustWork = FALSE) else NA_character_
})
.bootstrap_root <- if (!is.na(.bootstrap_script)) dirname(dirname(.bootstrap_script)) else getwd()
source(file.path(.bootstrap_root, "R", "_stage1_helpers.R"), encoding = "UTF-8")
source(file.path(.bootstrap_root, "R", "_trial_helpers.R"), encoding = "UTF-8")

tte_require_packages(c("yaml", "haven", "data.table", "tidyselect"))

project_root <- tte_find_project_root(.bootstrap_root)
config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
sources <- tte_read_csv_utf8(file.path(project_root, "config_r", "cohort_sources.csv"))
mapping <- tte_read_csv_utf8(file.path(project_root, "config_r", "preferred_clean_mapping.csv"))
aux_map <- tte_read_csv_utf8(file.path(project_root, "config_r", "harmonized_aux_mapping.csv"))
data_root <- tte_normalize_path(config$data_root, must_work = TRUE)
stage01b_private <- file.path(project_root, config$output_root, "stage01b", "private_do_not_share")
output_dir <- file.path(project_root, config$output_root, "stage02")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

as_plain_numeric <- function(x) {
  suppressWarnings(as.numeric(haven::zap_labels(x)))
}

as_stable_character <- function(x) {
  x <- haven::zap_labels(x)
  if (inherits(x, "integer64")) return(as.character(x))
  if (is.numeric(x)) return(format(x, scientific = FALSE, trim = TRUE))
  trimws(as.character(x))
}

get_actual_name <- function(all_names, requested) {
  hit <- which(tolower(all_names) == tolower(requested))
  if (length(hit) == 1L) all_names[[hit]] else NA_character_
}

extract_value_labels <- function(column, cohort, wave, variable, field) {
  labels <- attr(column, "labels", exact = TRUE)
  if (is.null(labels) || length(labels) == 0L) {
    return(data.frame(
      cohort = cohort, wave = wave, field = field, variable = variable,
      code = NA_real_, label = "", stringsAsFactors = FALSE
    ))
  }
  data.frame(
    cohort = cohort,
    wave = wave,
    field = field,
    variable = variable,
    code = as.numeric(labels),
    label = names(labels),
    stringsAsFactors = FALSE
  )
}

infer_incident_death_codes <- function(label_table) {
  label_table$code[
    grepl("died this (wv|wave)|died since", label_table$label, ignore.case = TRUE, perl = TRUE)
  ]
}

infer_known_dead_codes <- function(label_table) {
  label_table$code[
    grepl("died (this|prev|previous|before)", label_table$label, ignore.case = TRUE, perl = TRUE) &
      !grepl("dk if alive or died|unknown.*alive.*died", label_table$label, ignore.case = TRUE, perl = TRUE)
  ]
}

validate_binary <- function(x, cohort, concept) {
  values <- sort(unique(x[!is.na(x)]))
  unexpected <- setdiff(as.character(values), c("0", "1"))
  data.frame(
    cohort = cohort,
    concept = concept,
    observed_values = paste(values, collapse = ";"),
    unexpected_values = paste(unexpected, collapse = ";"),
    valid_binary = length(unexpected) == 0L,
    stringsAsFactors = FALSE
  )
}

locate_authorized_elsa_index <- function(raw_root) {
  override <- Sys.getenv("TTE_ELSA_INDEX_PATH", unset = "")
  if (nzchar(override) && file.exists(override)) return(override)
  preferred <- file.path(raw_root, "index_file_wave_0-wave_5_v2.dta")
  if (file.exists(preferred)) return(preferred)
  matches <- list.files(
    raw_root,
    pattern = "^index_file_wave_0-wave_5_v2[.]dta$",
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )
  if (!length(matches)) {
    stop("Authorised ELSA Wave 0-5 index file was not found under: ", raw_root, call. = FALSE)
  }
  matches[[1L]]
}

aux_selection <- list()
status_labels <- list()
status_counts <- list()
weight_coverage <- list()
binary_checks <- list()
wave_summaries <- list()
selection_index <- label_index <- status_index <- weight_index <- binary_index <- wave_index <- 0L
elsa_index_audit <- NULL

for (source_index in seq_len(nrow(sources))) {
  cohort_name <- sources$cohort[source_index]
  message("Harmonizing ", cohort_name, " ...")
  clean_cache <- file.path(stage01b_private, paste0(tolower(cohort_name), "_selected_longitudinal.rds"))
  if (!file.exists(clean_cache)) stop("Missing Stage 01b private cache: ", clean_cache, call. = FALSE)
  clean <- data.table::as.data.table(readRDS(clean_cache))
  cohort_mapping <- mapping[mapping$cohort == cohort_name, , drop = FALSE]

  # Preallocate the row count. Assigning a full-length vector to a zero-row
  # data.table raises a replacement-size error in recent R/data.table versions.
  canonical <- data.table::data.table(.source_row = seq_len(nrow(clean)))
  for (map_index in seq_len(nrow(cohort_mapping))) {
    variable <- cohort_mapping$variable[map_index]
    concept <- cohort_mapping$concept[map_index]
    if (is.na(variable) || !nzchar(variable) || !variable %in% names(clean)) next
    data.table::set(canonical, j = concept, value = clean[[variable]])
    if (identical(cohort_mapping$recode_type[map_index], "binary")) {
      binary_index <- binary_index + 1L
      binary_checks[[binary_index]] <- validate_binary(clean[[variable]], cohort_name, concept)
    }
  }
  data.table::set(canonical, j = "cohort", value = cohort_name)
  data.table::set(canonical, j = "source_country", value = sources$country[source_index])
  data.table::set(canonical, j = ".source_row", value = NULL)
  canonical[, person_id := as_stable_character(person_id)]
  canonical[, wave := suppressWarnings(as.integer(wave))]
  canonical[, interview_year := suppressWarnings(as.integer(interview_year))]
  if (!"interview_month" %in% names(canonical)) canonical[, interview_month := 7L]
  canonical[, interview_month := suppressWarnings(as.integer(interview_month))]
  canonical[is.na(interview_month) | interview_month < 1L | interview_month > 12L, interview_month := 7L]
  canonical[, interview_date := as.Date(sprintf("%04d-%02d-15", interview_year, interview_month))]

  aux_row <- aux_map[aux_map$cohort == cohort_name, , drop = FALSE]
  harmonized_path <- file.path(data_root, sources$harmonized_file[source_index])
  metadata <- haven::read_dta(harmonized_path, n_max = 0L, .name_repair = "minimal")
  all_names <- names(metadata)
  id_name <- get_actual_name(all_names, aux_row$id_variable)
  death_name <- get_actual_name(all_names, aux_row$death_year_variable)
  waves <- as.integer(strsplit(aux_row$waves, "|", fixed = TRUE)[[1L]])

  status_names <- if (!is.na(aux_row$status_stub) && nzchar(aux_row$status_stub)) {
    vapply(
      waves,
      function(wave) get_actual_name(all_names, paste0("r", wave, aux_row$status_stub)),
      character(1L)
    )
  } else rep(NA_character_, length(waves))
  weight_names <- if (!is.na(aux_row$weight_stub) && nzchar(aux_row$weight_stub)) {
    vapply(waves, function(wave) get_actual_name(all_names, paste0("r", wave, aux_row$weight_stub)), character(1L))
  } else rep(NA_character_, length(waves))
  stratum_names <- if (!is.na(aux_row$stratum_stub) && nzchar(aux_row$stratum_stub)) {
    vapply(waves, function(wave) get_actual_name(all_names, paste0("r", wave, aux_row$stratum_stub)), character(1L))
  } else rep(NA_character_, length(waves))

  selected_names <- unique(na.omit(c(id_name, death_name, status_names, weight_names, stratum_names)))
  wide <- haven::read_dta(
    harmonized_path,
    col_select = tidyselect::all_of(selected_names),
    .name_repair = "minimal"
  )

  aux_parts <- list()
  for (wave_position in seq_along(waves)) {
    wave_value <- waves[[wave_position]]
    status_name <- status_names[[wave_position]]
    weight_name <- weight_names[[wave_position]]
    stratum_name <- stratum_names[[wave_position]]

    selection_index <- selection_index + 1L
    aux_selection[[selection_index]] <- data.frame(
      cohort = cohort_name,
      wave = wave_value,
      status_variable = ifelse(is.na(status_name), "", status_name),
      weight_source = aux_row$weight_source,
      weight_variable = ifelse(is.na(weight_name), "", weight_name),
      stratum_variable = ifelse(is.na(stratum_name), "", stratum_name),
      stringsAsFactors = FALSE
    )

    status_value <- if (!is.na(status_name)) as_plain_numeric(wide[[status_name]]) else rep(NA_real_, nrow(wide))
    weight_value <- if (!is.na(weight_name)) as_plain_numeric(wide[[weight_name]]) else rep(NA_real_, nrow(wide))
    stratum_value <- if (!is.na(stratum_name)) as_stable_character(wide[[stratum_name]]) else rep(NA_character_, nrow(wide))

    label_table <- if (!is.na(status_name)) {
      extract_value_labels(wide[[status_name]], cohort_name, wave_value, status_name, "interview_status")
    } else {
      extract_value_labels(numeric(), cohort_name, wave_value, "", "interview_status")
    }
    label_index <- label_index + 1L
    status_labels[[label_index]] <- label_table
    incident_death_codes <- infer_incident_death_codes(label_table)
    known_dead_codes <- infer_known_dead_codes(label_table)
    status_died_this_wave <- if (length(incident_death_codes)) {
      ifelse(is.na(status_value), NA_integer_, as.integer(status_value %in% incident_death_codes))
    } else {
      rep(NA_integer_, length(status_value))
    }
    status_dead_known <- if (length(known_dead_codes)) {
      ifelse(is.na(status_value), NA_integer_, as.integer(status_value %in% known_dead_codes))
    } else {
      rep(NA_integer_, length(status_value))
    }
    status_unknown_vital <- ifelse(
      is.na(status_value),
      NA_integer_,
      as.integer(status_value == 9)
    )

    status_index <- status_index + 1L
    status_counts[[status_index]] <- data.frame(
      cohort = cohort_name,
      wave = wave_value,
      status_variable = ifelse(is.na(status_name), "", status_name),
      observed_status_values = paste0(
        names(sort(table(status_value, useNA = "ifany"), decreasing = TRUE)),
        " (n=", as.integer(sort(table(status_value, useNA = "ifany"), decreasing = TRUE)), ")",
        collapse = "; "
      ),
      inferred_incident_death_codes = paste(incident_death_codes, collapse = ";"),
      inferred_known_dead_codes = paste(known_dead_codes, collapse = ";"),
      incident_death_identifiable = length(incident_death_codes) > 0L,
      persons_died_this_wave = sum(status_died_this_wave == 1L, na.rm = TRUE),
      persons_known_dead = sum(status_dead_known == 1L, na.rm = TRUE),
      persons_unknown_vital_status = sum(status_unknown_vital == 1L, na.rm = TRUE),
      stringsAsFactors = FALSE
    )

    aux_parts[[wave_position]] <- data.table::data.table(
      person_id = as_stable_character(wide[[id_name]]),
      wave = wave_value,
      status_wide = status_value,
      status_died_this_wave = status_died_this_wave,
      status_dead_known = status_dead_known,
      status_unknown_vital = status_unknown_vital,
      survey_weight_wide = weight_value,
      survey_stratum = stratum_value
    )
  }

  aux_long <- data.table::rbindlist(aux_parts, use.names = TRUE, fill = TRUE)
  if (!is.na(death_name)) {
    death_lookup <- data.table::data.table(
      person_id = as_stable_character(wide[[id_name]]),
      death_year_wide = as_plain_numeric(wide[[death_name]])
    )
    death_lookup <- unique(death_lookup, by = "person_id")
    aux_long <- merge(aux_long, death_lookup, by = "person_id", all.x = TRUE, sort = FALSE)
  } else {
    aux_long[, death_year_wide := NA_real_]
  }

  if (identical(cohort_name, "ELSA")) {
    cohort_raw_root <- file.path(data_root, sources$source_folder[source_index], "Raw_data")
    index_path <- locate_authorized_elsa_index(cohort_raw_root)
    index_raw <- haven::read_dta(
      index_path,
      col_select = tidyselect::all_of(c("idauniq", "mortwave")),
      .name_repair = "minimal"
    )
    index_lookup <- data.table::data.table(
      person_id = as_stable_character(index_raw[["idauniq"]]),
      linked_to_authorized_index = 1L,
      mortwave_index = as_plain_numeric(index_raw[["mortwave"]])
    )
    if (anyDuplicated(index_lookup$person_id)) {
      stop("Authorised ELSA index contains duplicate idauniq values.", call. = FALSE)
    }
    index_lookup[, index_death_wave := tte_elsa_mortwave_death_wave(mortwave_index)]
    index_lookup[, mortality_linkage_eligible := tte_elsa_mortwave_covered(
      mortwave_index, linked_to_authorized_index
    )]
    index_lookup[, index_recorded_death := as.integer(!is.na(index_death_wave))]

    harmonized_ids <- unique(aux_long$person_id)
    linked_harmonized <- index_lookup[person_id %in% harmonized_ids]
    elsa_index_audit <- data.frame(
      source_file = tte_relative_path(index_path, cohort_raw_root),
      index_rows = nrow(index_lookup),
      index_unique_persons = data.table::uniqueN(index_lookup$person_id),
      index_recorded_deaths = sum(index_lookup$index_recorded_death == 1L),
      harmonized_unique_persons = length(harmonized_ids),
      harmonized_persons_linked = nrow(linked_harmonized),
      harmonized_persons_not_linked = length(harmonized_ids) - nrow(linked_harmonized),
      harmonized_persons_mortality_eligible = sum(linked_harmonized$mortality_linkage_eligible == 1L),
      harmonized_persons_recorded_dead = sum(linked_harmonized$index_recorded_death == 1L),
      stringsAsFactors = FALSE
    )

    aux_long <- merge(aux_long, index_lookup, by = "person_id", all.x = TRUE, sort = FALSE)
    aux_long[is.na(linked_to_authorized_index), linked_to_authorized_index := 0L]
    aux_long[is.na(mortality_linkage_eligible), mortality_linkage_eligible := 0L]
    aux_long[is.na(index_recorded_death), index_recorded_death := 0L]
    # For ELSA, the authorised index is the primary mortality source. Replace,
    # rather than supplement, the harmonised interview-status mortality flags.
    aux_long[, status_died_this_wave := data.table::fcase(
      mortality_linkage_eligible == 0L, NA_integer_,
      !is.na(index_death_wave) & wave == index_death_wave, 1L,
      default = 0L
    )]
    aux_long[, status_dead_known := data.table::fcase(
      mortality_linkage_eligible == 0L, NA_integer_,
      !is.na(index_death_wave) & wave >= index_death_wave, 1L,
      default = 0L
    )]
    aux_long[, status_unknown_vital := as.integer(mortality_linkage_eligible == 0L)]
    aux_long[, mortality_source_detail := data.table::fcase(
      mortality_linkage_eligible == 1L, "authorized_index_mortwave",
      linked_to_authorized_index == 1L, "authorized_index_no_usable_mortality",
      default = "not_linked_to_authorized_index"
    )]
  } else {
    aux_long[, `:=`(
      linked_to_authorized_index = NA_integer_,
      mortwave_index = NA_real_,
      index_death_wave = NA_integer_,
      mortality_linkage_eligible = 1L,
      index_recorded_death = NA_integer_,
      mortality_source_detail = ifelse(
        cohort_name == "HRS", "harmonized_death_year", "harmonized_death_year_or_status"
      )
    )]
  }
  saveRDS(
    aux_long,
    file.path(private_dir, paste0(tolower(cohort_name), "_aux_status_long.rds")),
    version = 3L
  )

  canonical <- merge(canonical, aux_long, by = c("person_id", "wave"), all.x = TRUE, sort = FALSE)
  if (identical(aux_row$weight_source, "clean")) {
    canonical[, survey_weight_final := suppressWarnings(as.numeric(survey_weight))]
    canonical[, survey_weight_source := "clean_long"]
  } else {
    canonical[, survey_weight_final := survey_weight_wide]
    canonical[, survey_weight_source := "harmonized_wide"]
  }
  canonical[, death_year_final := suppressWarnings(as.numeric(death_year))]
  canonical[is.na(death_year_final), death_year_final := death_year_wide]
  if (identical(cohort_name, "ELSA") && !is.null(elsa_index_audit)) {
    last_response <- canonical[
      status_wide == 1 & !is.na(interview_year),
      .(last_response_year = max(interview_year)),
      by = person_id
    ]
    death_year_person <- unique(canonical[, .(person_id, death_year_final)])
    death_year_check <- merge(death_year_person, last_response, by = "person_id", all.x = TRUE, sort = FALSE)
    elsa_index_audit$harmonized_death_year_nonmissing <- sum(!is.na(death_year_check$death_year_final))
    elsa_index_audit$death_year_before_last_response <- sum(
      !is.na(death_year_check$death_year_final) &
        !is.na(death_year_check$last_response_year) &
        death_year_check$death_year_final < death_year_check$last_response_year
    )
  }

  for (wave_value in sort(unique(canonical$wave))) {
    wave_rows <- canonical[wave == wave_value]
    weight_index <- weight_index + 1L
    weight_coverage[[weight_index]] <- data.frame(
      cohort = cohort_name,
      wave = wave_value,
      rows = nrow(wave_rows),
      positive_weight_n = sum(is.finite(wave_rows$survey_weight_final) & wave_rows$survey_weight_final > 0),
      positive_weight_fraction = mean(is.finite(wave_rows$survey_weight_final) & wave_rows$survey_weight_final > 0),
      weight_source = unique(wave_rows$survey_weight_source)[[1L]],
      stringsAsFactors = FALSE
    )
    wave_index <- wave_index + 1L
    wave_summaries[[wave_index]] <- data.frame(
      cohort = cohort_name,
      wave = wave_value,
      rows = nrow(wave_rows),
      unique_persons = data.table::uniqueN(wave_rows$person_id),
      median_interview_year = stats::median(wave_rows$interview_year, na.rm = TRUE),
      lipid_medication_nonmissing = sum(!is.na(wave_rows$lipid_medication)),
      lipid_medication_users = sum(wave_rows$lipid_medication == 1L, na.rm = TRUE),
      wide_status_nonmissing = sum(!is.na(wave_rows$status_wide)),
      wide_incident_death_flags = sum(wave_rows$status_died_this_wave == 1L, na.rm = TRUE),
      wide_known_dead_flags = sum(wave_rows$status_dead_known == 1L, na.rm = TRUE),
      wide_unknown_vital_flags = sum(wave_rows$status_unknown_vital == 1L, na.rm = TRUE),
      valid_death_year_n = sum(is.finite(wave_rows$death_year_final) & wave_rows$death_year_final >= 1900),
      mortality_linkage_eligible_n = sum(wave_rows$mortality_linkage_eligible == 1L, na.rm = TRUE),
      authorized_index_death_n = sum(wave_rows$index_recorded_death == 1L, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  }

  saveRDS(canonical, file.path(private_dir, paste0(tolower(cohort_name), "_canonical_long.rds")), version = 3L)
}

aux_selection <- do.call(rbind, aux_selection)
status_labels <- do.call(rbind, status_labels)
status_counts <- do.call(rbind, status_counts)
weight_coverage <- do.call(rbind, weight_coverage)
binary_checks <- do.call(rbind, binary_checks)
wave_summaries <- do.call(rbind, wave_summaries)

tte_write_csv(aux_selection, file.path(output_dir, "02_aux_variable_selection.csv"))
tte_write_csv(status_labels, file.path(output_dir, "02_status_value_labels.csv"))
tte_write_csv(status_counts, file.path(output_dir, "02_status_counts.csv"))
tte_write_csv(weight_coverage, file.path(output_dir, "02_weight_coverage.csv"))
tte_write_csv(binary_checks, file.path(output_dir, "02_clean_binary_validation.csv"))
tte_write_csv(wave_summaries, file.path(output_dir, "02_harmonized_wave_summary.csv"))
if (!is.null(elsa_index_audit)) {
  tte_write_csv(elsa_index_audit, file.path(output_dir, "02_elsa_authorized_index_linkage.csv"))
}

summary_lines <- c(
  "Stage 02 canonical harmonization preflight",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Unexpected cleaned binary codings: ", sum(!binary_checks$valid_binary)),
  paste0(
    "Required wave-status variables missing: ",
    sum(aux_selection$cohort != "HRS" & !nzchar(aux_selection$status_variable))
  ),
  paste0(
    "Required wave-status variables without an incident-death code: ",
    sum(status_counts$cohort != "HRS" & !status_counts$incident_death_identifiable)
  ),
  paste0("Cohort-waves with <80% positive survey weights: ", sum(weight_coverage$positive_weight_fraction < 0.80, na.rm = TRUE)),
  if (!is.null(elsa_index_audit)) paste0(
    "ELSA harmonized persons linked/eligible in authorised index: ",
    elsa_index_audit$harmonized_persons_linked, "/",
    elsa_index_audit$harmonized_persons_mortality_eligible
  ) else "ELSA authorised mortality index was not integrated.",
  "",
  "No treatment effect or person-trial outcome was estimated.",
  "Do not return the private_do_not_share folder."
)
writeLines(summary_lines, file.path(output_dir, "02_stage_summary.txt"), useBytes = TRUE)
writeLines(
  c(
    "PRIVATE LOCAL DATA - DO NOT SHARE",
    "Canonical longitudinal RDS files contain person identifiers.",
    "Only aggregate CSV and TXT files in the parent stage02 directory may be returned."
  ),
  file.path(private_dir, "DO_NOT_SHARE.txt"),
  useBytes = TRUE
)
cat(paste(summary_lines, collapse = "\n"), "\n")
