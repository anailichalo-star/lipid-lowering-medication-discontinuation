# Reusable helpers for weighting sensitivity analyses.

tte_sensitivity_clamp_probability <- function(x, floor = 1e-6) {
  pmax(floor, pmin(1 - floor, suppressWarnings(as.numeric(x))))
}

tte_sensitivity_quantile <- function(x, probability) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  as.numeric(stats::quantile(x, probability, names = FALSE, type = 2L))
}

tte_sensitivity_ess <- function(weight) {
  weight <- suppressWarnings(as.numeric(weight))
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

tte_sensitivity_weighted_mean <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (!any(valid)) return(NA_real_)
  sum(x[valid] * weight[valid]) / sum(weight[valid])
}

tte_sensitivity_weighted_variance <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- tte_sensitivity_weighted_mean(x[valid], weight[valid])
  sum(weight[valid] * (x[valid] - center)^2) / sum(weight[valid])
}

tte_sensitivity_numeric_smd <- function(x, treatment, weight) {
  x <- suppressWarnings(as.numeric(x))
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- x[valid]
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  mean0 <- tte_sensitivity_weighted_mean(
    x[treatment == 0L], weight[treatment == 0L]
  )
  mean1 <- tte_sensitivity_weighted_mean(
    x[treatment == 1L], weight[treatment == 1L]
  )
  var0 <- tte_sensitivity_weighted_variance(
    x[treatment == 0L], weight[treatment == 0L]
  )
  var1 <- tte_sensitivity_weighted_variance(
    x[treatment == 1L], weight[treatment == 1L]
  )
  denominator <- sqrt((var0 + var1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (mean1 - mean0) / denominator
}

tte_sensitivity_level_smd <- function(
  x, treatment, weight, level_value
) {
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- !is.na(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- as.character(x[valid])
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  indicator <- as.numeric(x == level_value)
  p0 <- tte_sensitivity_weighted_mean(
    indicator[treatment == 0L], weight[treatment == 0L]
  )
  p1 <- tte_sensitivity_weighted_mean(
    indicator[treatment == 1L], weight[treatment == 1L]
  )
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

tte_sensitivity_balance <- function(
  data, weight_name, variables, categorical_variables
) {
  treatment <- data$treatment
  weight <- data[[weight_name]]
  rows <- list()
  row_index <- 0L
  for (variable_name in variables) {
    x <- data[[variable_name]]
    if (variable_name %in% categorical_variables) {
      present_levels <- sort(unique(as.character(x[!is.na(x)])))
      for (level_value in present_levels) {
        row_index <- row_index + 1L
        rows[[row_index]] <- data.table::data.table(
          variable = variable_name,
          level = level_value,
          standardized_difference = tte_sensitivity_level_smd(
            x, treatment, weight, level_value
          )
        )
      }
    } else {
      row_index <- row_index + 1L
      rows[[row_index]] <- data.table::data.table(
        variable = variable_name,
        level = "",
        standardized_difference = tte_sensitivity_numeric_smd(
          x, treatment, weight
        )
      )
    }
  }
  result <- data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)
  result[, absolute_standardized_difference := abs(standardized_difference)]
  result
}

tte_sensitivity_fit_binary <- function(
  formula, data, model_name, cohort_name, analysis_name, imputation_index
) {
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::glm(
      formula = formula,
      data = data,
      family = stats::binomial(),
      na.action = stats::na.fail,
      control = stats::glm.control(maxit = 100, epsilon = 1e-8)
    ),
    warning = function(warning_condition) {
      warning_messages <<- c(
        warning_messages, conditionMessage(warning_condition)
      )
      invokeRestart("muffleWarning")
    }
  )
  diagnostics <- data.table::data.table(
    cohort = cohort_name,
    analysis = analysis_name,
    imputation = imputation_index,
    model = model_name,
    converged = isTRUE(fit$converged),
    iterations = fit$iter,
    coefficient_n = length(stats::coef(fit)),
    aliased_coefficient_n = sum(is.na(stats::coef(fit))),
    warning_n = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    separation_or_convergence_warning = any(grepl(
      "did not converge|fitted probabilities numerically 0 or 1 occurred|algorithm stopped",
      warning_messages, ignore.case = TRUE
    ))
  )
  list(fit = fit, diagnostics = diagnostics)
}

tte_sensitivity_fit_binary <- function(
  formula, data, model_name, cohort, analysis, imputation
) {
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::glm(
      formula = formula,
      data = data,
      family = stats::binomial(),
      na.action = stats::na.fail,
      control = stats::glm.control(maxit = 100, epsilon = 1e-8)
    ),
    warning = function(warning_condition) {
      warning_messages <<- c(
        warning_messages, conditionMessage(warning_condition)
      )
      invokeRestart("muffleWarning")
    }
  )
  diagnostics <- data.table::data.table(
    cohort = cohort,
    analysis = analysis,
    imputation = imputation,
    model = model_name,
    converged = isTRUE(fit$converged),
    iterations = fit$iter,
    coefficient_n = length(stats::coef(fit)),
    aliased_coefficient_n = sum(is.na(stats::coef(fit))),
    warning_n = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    separation_or_convergence_warning = any(grepl(
      "did not converge|fitted probabilities numerically 0 or 1 occurred|algorithm stopped",
      warning_messages, ignore.case = TRUE
    ))
  )
  list(fit = fit, diagnostics = diagnostics)
}
