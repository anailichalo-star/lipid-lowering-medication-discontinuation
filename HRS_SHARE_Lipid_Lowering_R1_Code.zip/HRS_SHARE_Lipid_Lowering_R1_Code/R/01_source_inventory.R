# Stage 01: inventory source files and audit candidate variables.
# Run 00_environment_check.R first. This script does not estimate any effect.

.bootstrap_script <- local({
  frames <- sys.frames()
  values <- vapply(
    frames,
    function(frame) {
      value <- frame$ofile
      if (is.null(value) || length(value) == 0L) "" else as.character(value[[1L]])
    },
    character(1L)
  )
  values <- values[nzchar(values)]
  if (length(values)) normalizePath(tail(values, 1L), winslash = "/", mustWork = FALSE) else NA_character_
})

.bootstrap_root <- if (!is.na(.bootstrap_script)) dirname(dirname(.bootstrap_script)) else getwd()
.helper <- file.path(.bootstrap_root, "R", "_stage1_helpers.R")
if (!file.exists(.helper)) stop("Open TTE_HRS_SHARE.Rproj before running this script.", call. = FALSE)
source(.helper, encoding = "UTF-8")

tte_require_packages(c("yaml", "haven"))

project_root <- tte_find_project_root(.bootstrap_root)
config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
sources <- tte_read_csv_utf8(file.path(project_root, "config_r", "cohort_sources.csv"))
concepts <- tte_read_csv_utf8(file.path(project_root, "config_r", "concept_candidates.csv"))

data_root <- tte_normalize_path(config$data_root, must_work = TRUE)
output_dir <- file.path(project_root, config$output_root, "stage01")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

required_source_columns <- c(
  "cohort", "country", "role", "source_folder", "clean_file", "harmonized_file"
)
required_concept_columns <- c(
  "cohort", "concept", "required_stage1", "aliases", "label_regex",
  "pooling_role", "expected_grade", "must_verify", "action", "note"
)
if (!all(required_source_columns %in% names(sources))) {
  stop("cohort_sources.csv is missing required columns.", call. = FALSE)
}
if (!all(required_concept_columns %in% names(concepts))) {
  stop("concept_candidates.csv is missing required columns.", call. = FALSE)
}
if (!setequal(sources$cohort, unlist(config$main_cohorts))) {
  stop("Main cohorts in analysis.yml and cohort_sources.csv do not match.", call. = FALSE)
}

extensions <- paste0("\\.(", paste(tolower(unlist(config$inventory_extensions)), collapse = "|"), ")$")

manifest_parts <- lapply(seq_len(nrow(sources)), function(index) {
  row <- sources[index, , drop = FALSE]
  source_dir <- file.path(data_root, row$source_folder)
  clean_path <- file.path(data_root, row$clean_file)
  harmonized_path <- file.path(data_root, row$harmonized_file)

  manifest <- tte_read_csv_utf8(file.path(project_root, "DATA_INPUT_MANIFEST.csv"))
  discovered <- file.path(project_root, manifest$file[manifest$cohort == row$cohort])
  discovered <- discovered[file.exists(discovered) & grepl(extensions, discovered, ignore.case = TRUE)]
  paths <- unique(c(discovered, clean_path, harmonized_path))
  info <- file.info(paths)
  relative <- vapply(paths, tte_relative_path, character(1L), root = data_root)
  clean_normalized <- tolower(tte_normalize_path(clean_path, must_work = FALSE))
  harmonized_normalized <- tolower(tte_normalize_path(harmonized_path, must_work = FALSE))
  path_normalized <- tolower(tte_normalize_path(paths, must_work = FALSE))

  roles <- mapply(
    tte_classify_file_role,
    relative_path = relative,
    is_clean = path_normalized == clean_normalized,
    is_harmonized = path_normalized == harmonized_normalized,
    USE.NAMES = FALSE
  )

  data.frame(
    cohort = row$cohort,
    country = row$country,
    file_role = roles,
    relative_path = gsub("\\\\", "/", relative),
    extension = tolower(sub("^.*\\.", "", basename(paths))),
    size_bytes = as.numeric(info$size),
    modified_time = format(info$mtime, "%Y-%m-%d %H:%M:%S"),
    exists = file.exists(paths),
    stringsAsFactors = FALSE
  )
})

manifest <- do.call(rbind, manifest_parts)
manifest <- manifest[!duplicated(paste(manifest$cohort, tolower(manifest$relative_path))), , drop = FALSE]
manifest <- manifest[order(manifest$cohort, manifest$file_role, manifest$relative_path), , drop = FALSE]
manifest$file_id <- sprintf("%s_%05d", manifest$cohort, ave(seq_len(nrow(manifest)), manifest$cohort, FUN = seq_along))
manifest <- manifest[, c(
  "file_id", "cohort", "country", "file_role", "relative_path", "extension",
  "size_bytes", "modified_time", "exists"
)]
tte_write_csv(manifest, file.path(output_dir, "01_file_inventory.csv"))

read_haven_metadata <- function(path, extension) {
  object <- if (identical(extension, "dta")) {
    haven::read_dta(path, n_max = 0L, .name_repair = "minimal")
  } else if (identical(extension, "sav")) {
    haven::read_sav(path, n_max = 0L, .name_repair = "minimal")
  } else {
    stop("Unsupported metadata extension: ", extension)
  }
  labels <- vapply(
    object,
    function(column) {
      label <- attr(column, "label", exact = TRUE)
      if (is.null(label) || length(label) == 0L || is.na(label[[1L]])) "" else as.character(label[[1L]])
    },
    character(1L)
  )
  data.frame(
    raw_variable = names(object),
    canonical_variable = tte_clean_variable_name(names(object)),
    variable_label = labels,
    stringsAsFactors = FALSE
  )
}

metadata_parts <- list()
metadata_log <- list()
metadata_index <- 0L
log_index <- 0L

for (cohort_name in sources$cohort) {
  cohort_files <- manifest[
    manifest$cohort == cohort_name &
      manifest$file_role %in% unlist(config$metadata_scan_roles) &
      manifest$extension %in% c("csv", "dta", "sav"),
    ,
    drop = FALSE
  ]

  # If both Stata and SPSS copies share a stem, prefer Stata for metadata inspection.
  cohort_files$stem <- tolower(sub("\\.(dta|sav)$", "", cohort_files$relative_path))
  cohort_files$format_priority <- match(cohort_files$extension, c("csv", "dta", "sav"))
  cohort_files <- cohort_files[order(cohort_files$file_role, cohort_files$stem, cohort_files$format_priority), ]
  duplicate_binary <- duplicated(paste(cohort_files$file_role, cohort_files$stem)) & cohort_files$extension == "sav"
  cohort_files <- cohort_files[!duplicate_binary, , drop = FALSE]

  limit <- as.integer(config$metadata_max_files_per_cohort)
  if (nrow(cohort_files) > limit) cohort_files <- cohort_files[seq_len(limit), , drop = FALSE]

  for (file_index in seq_len(nrow(cohort_files))) {
    file_row <- cohort_files[file_index, , drop = FALSE]
    full_path <- file.path(data_root, file_row$relative_path)
    started <- Sys.time()
    result <- tryCatch(
      {
        if (identical(file_row$extension, "csv")) {
          tte_read_csv_header(full_path)
        } else {
          read_haven_metadata(full_path, file_row$extension)
        }
      },
      error = function(e) e
    )

    log_index <- log_index + 1L
    metadata_log[[log_index]] <- data.frame(
      cohort = cohort_name,
      file_id = file_row$file_id,
      file_role = file_row$file_role,
      relative_path = file_row$relative_path,
      status = if (inherits(result, "error")) "ERROR" else "OK",
      variables_read = if (inherits(result, "error")) 0L else nrow(result),
      seconds = round(as.numeric(difftime(Sys.time(), started, units = "secs")), 3L),
      message = if (inherits(result, "error")) conditionMessage(result) else "",
      stringsAsFactors = FALSE
    )

    if (!inherits(result, "error")) {
      metadata_index <- metadata_index + 1L
      result$cohort <- cohort_name
      result$file_id <- file_row$file_id
      result$file_role <- file_row$file_role
      result$relative_path <- file_row$relative_path
      metadata_parts[[metadata_index]] <- result[, c(
        "cohort", "file_id", "file_role", "relative_path", "raw_variable",
        "canonical_variable", "variable_label"
      )]
    }
  }
}

metadata <- if (length(metadata_parts)) do.call(rbind, metadata_parts) else data.frame()
read_log <- if (length(metadata_log)) do.call(rbind, metadata_log) else data.frame()
saveRDS(metadata, file.path(output_dir, "01_metadata_dictionary.rds"), version = 3L)
tte_write_csv(read_log, file.path(output_dir, "01_metadata_read_log.csv"))

find_concept_hits <- function(cohort_name, aliases, label_regex) {
  cohort_metadata <- metadata[metadata$cohort == cohort_name, , drop = FALSE]
  if (nrow(cohort_metadata) == 0L) return(cohort_metadata)

  alias_values <- tte_split_aliases(aliases)
  exact_hit <- tolower(cohort_metadata$canonical_variable) %in% alias_values
  label_hit <- rep(FALSE, nrow(cohort_metadata))
  if (!is.na(label_regex) && nzchar(trimws(label_regex))) {
    label_hit <- tryCatch(
      grepl(label_regex, cohort_metadata$variable_label, ignore.case = TRUE, perl = TRUE),
      error = function(e) rep(FALSE, nrow(cohort_metadata))
    )
    label_hit[is.na(label_hit)] <- FALSE
  }
  hits <- cohort_metadata[exact_hit | label_hit, , drop = FALSE]
  hits$match_type <- ifelse(
    tolower(hits$canonical_variable) %in% alias_values,
    "exact_alias",
    "label_keyword"
  )
  hits
}

availability_rows <- lapply(seq_len(nrow(concepts)), function(index) {
  row <- concepts[index, , drop = FALSE]
  hits <- find_concept_hits(row$cohort, row$aliases, row$label_regex)
  by_role <- function(role) {
    selected <- hits[hits$file_role == role, , drop = FALSE]
    tte_collapse_unique(paste0(selected$canonical_variable, " [", selected$relative_path, "]"))
  }
  unique_variables <- unique(tolower(hits$canonical_variable))

  status <- if (identical(tolower(row$action), "exclude")) {
    "EXCLUDED_BY_DESIGN"
  } else if (length(unique_variables) == 0L) {
    "NOT_FOUND"
  } else if (identical(tolower(row$must_verify), "yes")) {
    "VERIFY_SOURCE_LABEL"
  } else {
    "READY_FOR_MAPPING"
  }

  data.frame(
    cohort = row$cohort,
    concept = row$concept,
    required_stage1 = row$required_stage1,
    pooling_role = row$pooling_role,
    expected_grade = row$expected_grade,
    configured_aliases = row$aliases,
    cleaned_hits = by_role("cleaned"),
    harmonized_hits = by_role("harmonized"),
    death_exit_hits = by_role("death_exit"),
    survey_weight_hits = by_role("survey_weight"),
    unique_candidate_variables = length(unique_variables),
    mapping_status = status,
    note = row$note,
    stringsAsFactors = FALSE
  )
})

availability <- do.call(rbind, availability_rows)
availability <- availability[order(availability$cohort, availability$concept), , drop = FALSE]
tte_write_csv(availability, file.path(output_dir, "01_variable_availability.csv"))

unresolved <- availability[
  availability$mapping_status != "READY_FOR_MAPPING" |
    availability$expected_grade %in% c("C", "D"),
  ,
  drop = FALSE
]
unresolved$required_action <- ifelse(
  unresolved$mapping_status == "NOT_FOUND",
  "Locate a source variable or document that the concept is unavailable",
  ifelse(
    unresolved$mapping_status == "EXCLUDED_BY_DESIGN",
    "Keep excluded from pooled analysis",
    "Verify wording, recall period, coding, wave coverage, and preferred source"
  )
)
tte_write_csv(unresolved, file.path(output_dir, "01_unresolved_mappings.csv"))

role_counts <- as.data.frame.matrix(table(manifest$cohort, manifest$file_role))
role_counts$cohort <- rownames(role_counts)
rownames(role_counts) <- NULL
role_counts <- role_counts[, c("cohort", setdiff(names(role_counts), "cohort")), drop = FALSE]
tte_write_csv(role_counts, file.path(output_dir, "01_file_role_counts.csv"))

summary_lines <- c(
  "Stage 01 source inventory and variable audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Data root: ", data_root),
  paste0("Files inventoried: ", nrow(manifest)),
  paste0("Metadata files attempted: ", nrow(read_log)),
  paste0("Metadata read errors: ", sum(read_log$status == "ERROR")),
  paste0("Concept rows audited: ", nrow(availability)),
  paste0("Ready for mapping: ", sum(availability$mapping_status == "READY_FOR_MAPPING")),
  paste0("Require source verification: ", sum(availability$mapping_status == "VERIFY_SOURCE_LABEL")),
  paste0("Not found: ", sum(availability$mapping_status == "NOT_FOUND")),
  paste0("Excluded by design: ", sum(availability$mapping_status == "EXCLUDED_BY_DESIGN")),
  "",
  "This stage contains no treatment-effect estimate and no record-level export.",
  "SHARE fall_s is explicitly excluded from pooled fall analyses."
)
writeLines(summary_lines, file.path(output_dir, "01_stage_summary.txt"), useBytes = TRUE)

cat(paste(summary_lines, collapse = "\n"), "\n")
cat("\nRequired return files:\n")
cat("- 00_environment_check.txt\n")
cat("- 01_file_inventory.csv\n")
cat("- 01_variable_availability.csv\n")
cat("- 01_unresolved_mappings.csv\n")
cat("- 01_metadata_read_log.csv if any metadata read failed\n")
