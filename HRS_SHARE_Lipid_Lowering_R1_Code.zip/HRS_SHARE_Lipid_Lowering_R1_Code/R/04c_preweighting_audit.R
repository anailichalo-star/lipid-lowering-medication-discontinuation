# Stage 04c: pre-weighting audit for the current HRS and SHARE person-trials.
# This script creates aggregate diagnostics only and fits no causal model.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "data.table"))

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
stage03_dir <- file.path(project_root, config$output_root, "stage03_current")
private_dir <- file.path(stage03_dir, "private_do_not_share")
output_dir <- file.path(project_root, config$output_root, "stage04_preweighting")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
trial_parts <- lapply(cohorts, function(cohort) {
  path <- file.path(private_dir, paste0(tolower(cohort), "_person_trials_PRIVATE.rds"))
  if (!file.exists(path)) stop("Missing person-trial file: ", path, call. = FALSE)
  data.table::as.data.table(readRDS(path))
})
trials <- data.table::rbindlist(trial_parts, use.names = TRUE, fill = TRUE)

candidate_covariates <- c(
  "L_age", "L_sex", "L_education", "L_marital_status", "L_income",
  "L_living_arrangement", "L_high_cholesterol", "L_self_rated_health",
  "L_bmi", "L_current_smoking", "L_alcohol_use", "L_physical_activity",
  "L_physical_activity_vigorous", "L_physical_activity_moderate",
  "L_hypertension", "L_diabetes", "L_cancer", "L_lung_disease",
  "L_arthritis", "L_depression_score", "L_cognition_immediate",
  "L_cognition_delayed", "L_cognition_serial7", "L_cognition_orientation",
  "L_hospitalization", "L_adl5_count", "L_iadl5_count",
  "L_frailty_existing", "L_systolic_bp", "L_diastolic_bp",
  "L_survey_weight_final", "followup_time_years"
)
for (variable in setdiff(candidate_covariates, names(trials))) {
  data.table::set(trials, j = variable, value = NA)
}

core_covariates <- c(
  "L_age", "L_sex", "L_high_cholesterol", "L_self_rated_health", "L_bmi",
  "L_current_smoking", "L_alcohol_use", "L_hypertension", "L_diabetes",
  "L_cancer", "L_lung_disease", "L_arthritis", "L_depression_score",
  "L_cognition_immediate", "L_cognition_delayed", "L_hospitalization",
  "L_education", "L_marital_status", "L_adl5_count", "L_iadl5_count",
  "L_survey_weight_final"
)

categorical_covariates <- c(
  "L_sex", "L_education", "L_marital_status", "L_living_arrangement",
  "L_self_rated_health", "L_current_smoking", "L_alcohol_use",
  "L_physical_activity", "L_physical_activity_vigorous",
  "L_physical_activity_moderate", "L_high_cholesterol", "L_hypertension",
  "L_diabetes", "L_cancer", "L_lung_disease", "L_arthritis",
  "L_hospitalization"
)

population_summary <- trials[, .(
  person_trials = .N,
  unique_persons = data.table::uniqueN(person_id),
  trial_sequences = data.table::uniqueN(sequence),
  continue_trials = sum(treatment == 0L),
  discontinue_trials = sum(treatment == 1L),
  primary_observed = sum(!is.na(primary_event)),
  primary_events = sum(primary_event == 1L, na.rm = TRUE),
  strict_observed = sum(!is.na(strict_event)),
  strict_events = sum(strict_event == 1L, na.rm = TRUE),
  deaths = sum(death_in_interval == 1L, na.rm = TRUE),
  functional_observed = sum(!is.na(death_adl_decline)),
  functional_events = sum(death_adl_decline == 1L, na.rm = TRUE)
), by = cohort]
population_summary[, `:=`(
  discontinue_fraction = discontinue_trials / person_trials,
  primary_observed_fraction = primary_observed / person_trials
)]

person_repeat <- trials[, .(
  person_trials = .N,
  treatment_states = data.table::uniqueN(treatment),
  ever_continue = any(treatment == 0L),
  ever_discontinue = any(treatment == 1L)
), by = .(cohort, person_id)]
repeat_summary <- person_repeat[, .(
  unique_persons = .N,
  mean_trials_per_person = mean(person_trials),
  median_trials_per_person = stats::median(person_trials),
  maximum_trials_per_person = max(person_trials),
  persons_with_multiple_trials = sum(person_trials > 1L),
  fraction_with_multiple_trials = mean(person_trials > 1L),
  persons_observed_in_both_treatment_states = sum(treatment_states == 2L)
), by = cohort]

missingness_rows <- list()
missing_index <- 0L
for (cohort_name in cohorts) {
  for (arm_value in c(0L, 1L)) {
    subset <- trials[cohort == cohort_name & treatment == arm_value]
    for (variable in candidate_covariates) {
      missing_index <- missing_index + 1L
      missingness_rows[[missing_index]] <- data.frame(
        cohort = cohort_name,
        treatment = arm_value,
        treatment_label = ifelse(arm_value == 1L, "discontinue", "continue"),
        variable = variable,
        person_trials = nrow(subset),
        nonmissing_n = sum(!is.na(subset[[variable]])),
        nonmissing_fraction = mean(!is.na(subset[[variable]])),
        stringsAsFactors = FALSE
      )
    }
  }
}
missingness <- data.table::rbindlist(missingness_rows, use.names = TRUE, fill = TRUE)

sequence_missingness <- data.table::rbindlist(lapply(candidate_covariates, function(variable_name) {
  result <- trials[, .(
    person_trials = .N,
    nonmissing_n = sum(!is.na(get(variable_name))),
    nonmissing_fraction = mean(!is.na(get(variable_name)))
  ), by = .(cohort, sequence, treatment)]
  result[, variable := variable_name]
  result
}), use.names = TRUE, fill = TRUE)
data.table::setcolorder(
  sequence_missingness,
  c("cohort", "sequence", "treatment", "variable", "person_trials",
    "nonmissing_n", "nonmissing_fraction")
)

safe_quantile <- function(x, probability) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  as.numeric(stats::quantile(x, probability, names = FALSE, type = 2L))
}

numeric_range_rows <- list()
range_index <- 0L
for (cohort_name in cohorts) {
  subset <- trials[cohort == cohort_name]
  for (variable in setdiff(candidate_covariates, categorical_covariates)) {
    value <- suppressWarnings(as.numeric(subset[[variable]]))
    finite <- value[is.finite(value)]
    range_index <- range_index + 1L
    numeric_range_rows[[range_index]] <- data.frame(
      cohort = cohort_name,
      variable = variable,
      nonmissing_n = length(finite),
      unique_nonmissing = length(unique(finite)),
      minimum = if (length(finite)) min(finite) else NA_real_,
      p25 = safe_quantile(finite, 0.25),
      median = safe_quantile(finite, 0.50),
      p75 = safe_quantile(finite, 0.75),
      maximum = if (length(finite)) max(finite) else NA_real_,
      stringsAsFactors = FALSE
    )
  }
}
numeric_ranges <- do.call(rbind, numeric_range_rows)

categorical_levels <- data.table::rbindlist(lapply(categorical_covariates, function(variable_name) {
  result <- trials[, .N, by = .(
    cohort, treatment,
    value = ifelse(is.na(get(variable_name)), "[missing]", as.character(get(variable_name)))
  )]
  result[, variable := variable_name]
  data.table::setcolorder(result, c("cohort", "treatment", "variable", "value", "N"))
  result
}), use.names = TRUE, fill = TRUE)
categorical_levels[, fraction_within_arm := N / sum(N), by = .(cohort, treatment, variable)]

numeric_smd <- function(value, treatment) {
  value <- suppressWarnings(as.numeric(value))
  x0 <- value[treatment == 0L & is.finite(value)]
  x1 <- value[treatment == 1L & is.finite(value)]
  if (length(x0) < 2L || length(x1) < 2L) return(NA_real_)
  denominator <- sqrt((stats::var(x0) + stats::var(x1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(NA_real_)
  (mean(x1) - mean(x0)) / denominator
}

binary_level_smd <- function(value, treatment, level) {
  observed <- !is.na(value) & treatment %in% c(0L, 1L)
  value <- as.character(value[observed])
  treatment <- treatment[observed]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  p0 <- mean(value[treatment == 0L] == level)
  p1 <- mean(value[treatment == 1L] == level)
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

smd_rows <- list()
smd_index <- 0L
for (cohort_name in cohorts) {
  subset <- trials[cohort == cohort_name]
  for (variable in candidate_covariates) {
    if (variable %in% categorical_covariates) {
      levels <- sort(unique(as.character(subset[[variable]][!is.na(subset[[variable]])])))
      if (!length(levels)) levels <- "[no observed values]"
      for (level in levels) {
        smd_index <- smd_index + 1L
        smd_rows[[smd_index]] <- data.frame(
          cohort = cohort_name, variable = variable, level = level,
          variable_type = "categorical_level",
          standardized_difference = if (level == "[no observed values]") NA_real_ else
            binary_level_smd(subset[[variable]], subset$treatment, level),
          stringsAsFactors = FALSE
        )
      }
    } else {
      smd_index <- smd_index + 1L
      smd_rows[[smd_index]] <- data.frame(
        cohort = cohort_name, variable = variable, level = "",
        variable_type = "numeric",
        standardized_difference = numeric_smd(subset[[variable]], subset$treatment),
        stringsAsFactors = FALSE
      )
    }
  }
}
unweighted_smd <- do.call(rbind, smd_rows)
unweighted_smd$absolute_standardized_difference <- abs(unweighted_smd$standardized_difference)

frailty_audit <- trials[, {
  value <- suppressWarnings(as.numeric(L_frailty_existing))
  finite <- value[is.finite(value)]
  list(
    person_trials = .N,
    nonmissing_n = length(finite),
    nonmissing_fraction = length(finite) / .N,
    minimum = if (length(finite)) min(finite) else NA_real_,
    median = safe_quantile(finite, 0.50),
    maximum = if (length(finite)) max(finite) else NA_real_,
    outside_zero_one_n = sum(finite < 0 | finite > 1)
  )
}, by = cohort]

survey_weight_audit <- trials[, {
  value <- suppressWarnings(as.numeric(L_survey_weight_final))
  positive <- value[is.finite(value) & value > 0]
  list(
    person_trials = .N,
    nonmissing_n = sum(is.finite(value)),
    positive_n = length(positive),
    positive_fraction = length(positive) / .N,
    minimum_positive = if (length(positive)) min(positive) else NA_real_,
    median_positive = safe_quantile(positive, 0.50),
    maximum_positive = if (length(positive)) max(positive) else NA_real_
  )
}, by = cohort]

sample_path <- file.path(private_dir, "03c_records_for_manual_review_PRIVATE.csv")
if (!file.exists(sample_path)) stop("Missing private manual-review sample.", call. = FALSE)
sample_records <- data.table::fread(sample_path, encoding = "UTF-8")
sample_records[, `:=`(
  check_prior_order = as.Date(E_interview_date) < as.Date(L_interview_date),
  check_followup_order = as.Date(followup_reference_date) > as.Date(L_interview_date),
  check_treatment = (E_lipid_medication == 1L) & (
    (treatment_label == "continue" & L_lipid_medication == 1L) |
      (treatment_label == "discontinue" & L_lipid_medication == 0L)
  ),
  check_age = L_age >= as.numeric(config$design$minimum_age),
  check_community = L_community == 1L,
  check_event_free = L_broad_heart_disease == 0L & L_stroke == 0L,
  check_death_composite = death_in_interval != 1L | primary_event == 1L,
  check_strict_nested = is.na(strict_event) | strict_event != 1L | primary_event == 1L
)]
logic_columns <- grep("^check_", names(sample_records), value = TRUE)
sample_records[, automatic_logic_pass := apply(.SD, 1L, function(x) all(x %in% TRUE)), .SDcols = logic_columns]
sample_logic_summary <- sample_records[, .(
  sampled_records = .N,
  automatic_pass_n = sum(automatic_logic_pass),
  automatic_fail_n = sum(!automatic_logic_pass),
  all_automatic_checks_pass = all(automatic_logic_pass)
), by = cohort]

core_gate <- missingness[variable %in% core_covariates, .(
  minimum_arm_nonmissing_fraction = min(nonmissing_fraction)
), by = .(cohort, variable)]
core_gate[, usable_concept := minimum_arm_nonmissing_fraction >= 0.50]
preweighting_gate <- core_gate[, .(
  core_concepts = .N,
  usable_core_concepts = sum(usable_concept),
  usable_core_fraction = mean(usable_concept),
  pass_80_percent_core_concepts = mean(usable_concept) >=
    as.numeric(config$data_gates$minimum_core_covariate_fraction)
), by = cohort]
preweighting_gate <- merge(
  preweighting_gate,
  survey_weight_audit[, .(cohort, survey_weight_positive_fraction = positive_fraction)],
  by = "cohort", all.x = TRUE, sort = FALSE
)
preweighting_gate[, pass_weight_coverage := survey_weight_positive_fraction >= 0.80]
preweighting_gate[, manual_review_complete := FALSE]
preweighting_gate[, ready_for_weighting := pass_80_percent_core_concepts &
  pass_weight_coverage & manual_review_complete]

tte_write_csv(population_summary, file.path(output_dir, "04c_population_summary.csv"))
tte_write_csv(repeat_summary, file.path(output_dir, "04c_repeated_trial_summary.csv"))
tte_write_csv(missingness, file.path(output_dir, "04c_covariate_missingness_by_arm.csv"))
tte_write_csv(sequence_missingness, file.path(output_dir, "04c_covariate_missingness_by_sequence.csv"))
tte_write_csv(numeric_ranges, file.path(output_dir, "04c_numeric_ranges.csv"))
tte_write_csv(categorical_levels, file.path(output_dir, "04c_categorical_levels.csv"))
tte_write_csv(unweighted_smd, file.path(output_dir, "04c_unweighted_smd.csv"))
tte_write_csv(frailty_audit, file.path(output_dir, "04c_existing_frailty_audit.csv"))
tte_write_csv(survey_weight_audit, file.path(output_dir, "04c_survey_weight_audit.csv"))
tte_write_csv(sample_logic_summary, file.path(output_dir, "04c_sample_logic_summary.csv"))
tte_write_csv(preweighting_gate, file.path(output_dir, "04c_preweighting_gate.csv"))

writeLines(
  c(
    "Manual review remains required before weighting.",
    "Open the private file:",
    file.path(private_dir, "03c_records_for_manual_review_PRIVATE.csv"),
    "Compare the sampled E/L/F values, treatment assignment, eligibility, and outcomes.",
    "Record only aggregate pass/fail counts in 03c_manual_review_signoff.csv.",
    "Do not share the private file because it contains person identifiers."
  ),
  file.path(output_dir, "04c_manual_review_instructions.txt"), useBytes = TRUE
)

summary_lines <- c(
  "Stage 04c: pre-weighting data audit",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Cohorts audited: ", paste(cohorts, collapse = ", ")),
  paste0("Automatic sampled-record checks failed: ", sum(sample_logic_summary$automatic_fail_n)),
  paste0(
    "Cohorts passing variable/weight preflight (manual review still pending): ",
    sum(preweighting_gate$pass_80_percent_core_concepts & preweighting_gate$pass_weight_coverage),
    " of ", nrow(preweighting_gate)
  ),
  "",
  "No imputation, propensity score, weighting, treatment effect, or meta-analysis was fitted."
)
writeLines(summary_lines, file.path(output_dir, "04c_stage_summary.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(output_dir, "04c_session_info.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
