run_stage23_refine_figure1_arrows <- function() {
  project_dir <- normalizePath(".", winslash = "/", mustWork = TRUE)
  flow_path <- file.path(
    project_dir, "outputs_r", "publication_ready", "tables",
    "Figure1_cohort_flow_data.csv"
  )
  png_dir <- file.path(project_dir, "outputs_r", "scientific_reports", "figure_review_png")
  delivery_dir <- file.path(project_dir, "outputs_r", "scientific_reports", "all_figures_pdf_tiff")
  dir.create(png_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(delivery_dir, recursive = TRUE, showWarnings = FALSE)

  required_packages <- c("data.table", "ggplot2")
  missing_packages <- required_packages[
    !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
  ]
  if (length(missing_packages)) {
    stop("Missing required R packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
  }
  if (!file.exists(flow_path)) stop("Missing flow data: ", flow_path, call. = FALSE)

  flow <- data.table::fread(flow_path)
  hrs_flow <- flow[cohort == "HRS"]
  share_flow <- flow[cohort == "SHARE"]
  if (nrow(hrs_flow) != 1L || nrow(share_flow) != 1L) {
    stop("Expected exactly one HRS and one SHARE flow record.", call. = FALSE)
  }

  format_integer <- function(x) format(as.integer(x), big.mark = ",", scientific = FALSE)
  # The generic sans family maps to the Windows publication sans-serif font
  # without requiring a session-specific font registration.
  font_family <- "sans"
  blue <- "#0072B2"
  orange <- "#D55E00"
  gray <- "#666666"

  box_data <- data.table::rbindlist(list(
    data.table::data.table(
      x = 2.55,
      y = c(5.25, 4.15, 3.05, 1.95, 0.85),
      label = c(
        sprintf("Harmonized population\n%s persons", format_integer(hrs_flow$harmonized_unique_persons)),
        sprintf("Eligible sequences\n%s person-trials", format_integer(hrs_flow$input_person_trials)),
        sprintf("Excluded\n%s missing/nonpositive survey weight", format_integer(hrs_flow$excluded_nonpositive_or_missing_survey_weight)),
        sprintf("Analytic sample\n%s person-trials; %s persons", format_integer(hrs_flow$analysis_person_trials), format_integer(hrs_flow$unique_persons)),
        sprintf("Continue: %s    Discontinue: %s", format_integer(hrs_flow$continue_trials), format_integer(hrs_flow$discontinue_trials))
      ),
      cohort = "HRS"
    ),
    data.table::data.table(
      x = 7.45,
      y = c(5.25, 4.15, 3.05, 1.95, 0.85),
      label = c(
        sprintf("Harmonized population\n%s persons", format_integer(share_flow$harmonized_unique_persons)),
        sprintf("Candidate sequences\n%s person-trials", format_integer(share_flow$input_person_trials)),
        sprintf("Excluded\n%s structural; %s survey weight", format_integer(share_flow$structurally_excluded_person_trials), format_integer(share_flow$excluded_nonpositive_or_missing_survey_weight)),
        sprintf("Analytic sample\n%s person-trials; %s persons", format_integer(share_flow$analysis_person_trials), format_integer(share_flow$unique_persons)),
        sprintf("Continue: %s    Discontinue: %s", format_integer(share_flow$continue_trials), format_integer(share_flow$discontinue_trials))
      ),
      cohort = "SHARE"
    )
  ))

  timeline <- data.table::data.table(
    x = c(1.5, 5, 8.5),
    y = 8.25,
    label = c(
      "Prior visit (B)\nMedication use and\npretreatment frailty",
      "Landmark visit (L)\nTreatment and covariates\nTime zero",
      "Follow-up (F)\nCVD, death, and ADL\n3-year risk"
    )
  )

  vertical_arrows <- data.table::data.table(
    x = rep(c(2.55, 7.45), each = 4),
    xend = rep(c(2.55, 7.45), each = 4),
    y = rep(c(4.84, 3.74, 2.64, 1.54), 2),
    yend = rep(c(4.56, 3.46, 2.36, 1.26), 2)
  )

  figure1 <- ggplot2::ggplot() +
    ggplot2::annotate(
      "text", x = 0.15, y = 9.25, label = "a", hjust = 0,
      family = font_family, fontface = "bold", size = 4.4
    ) +
    ggplot2::annotate(
      "text", x = 0.15, y = 6.55, label = "b", hjust = 0,
      family = font_family, fontface = "bold", size = 4.4
    ) +
    # Draw arrows before boxes so no arrow line or head can cover box text.
    ggplot2::annotate(
      "segment", x = 2.75, xend = 3.65, y = 8.25, yend = 8.25,
      linewidth = 0.55, colour = gray,
      arrow = grid::arrow(length = grid::unit(0.085, "inches"), type = "closed")
    ) +
    ggplot2::annotate(
      "segment", x = 6.35, xend = 7.25, y = 8.25, yend = 8.25,
      linewidth = 0.55, colour = gray,
      arrow = grid::arrow(length = grid::unit(0.085, "inches"), type = "closed")
    ) +
    ggplot2::geom_segment(
      data = vertical_arrows,
      ggplot2::aes(x = x, xend = xend, y = y, yend = yend),
      linewidth = 0.45, colour = gray,
      arrow = grid::arrow(length = grid::unit(0.07, "inches"), type = "closed")
    ) +
    ggplot2::annotate(
      "text", x = 3.20, y = 8.57, label = "1-4 y",
      family = font_family, size = 3.0
    ) +
    ggplot2::annotate(
      "text", x = 6.80, y = 8.57, label = "2-4 y",
      family = font_family, size = 3.0
    ) +
    ggplot2::geom_label(
      data = timeline,
      ggplot2::aes(x = x, y = y, label = label),
      family = font_family, size = 3.10, lineheight = 0.95,
      linewidth = 0.35, label.padding = grid::unit(0.18, "lines"),
      fill = "white", colour = "black"
    ) +
    ggplot2::annotate(
      "text", x = 2.55, y = 6.15, label = "HRS",
      family = font_family, fontface = "bold", size = 3.9, colour = blue
    ) +
    ggplot2::annotate(
      "text", x = 7.45, y = 6.15, label = "SHARE",
      family = font_family, fontface = "bold", size = 3.9, colour = orange
    ) +
    ggplot2::geom_label(
      data = box_data,
      ggplot2::aes(x = x, y = y, label = label, colour = cohort, fill = cohort),
      family = font_family, size = 3.0, lineheight = 0.95,
      linewidth = 0.35, label.padding = grid::unit(0.16, "lines")
    ) +
    ggplot2::scale_colour_manual(values = c(HRS = blue, SHARE = orange), guide = "none") +
    ggplot2::scale_fill_manual(values = c(HRS = "#EAF4F9", SHARE = "#FCEFEA"), guide = "none") +
    ggplot2::coord_cartesian(xlim = c(0, 10), ylim = c(0.30, 9.5), clip = "off") +
    ggplot2::theme_void(base_family = font_family) +
    ggplot2::theme(plot.margin = ggplot2::margin(5, 8, 5, 8))

  png_path <- file.path(png_dir, "Figure1_study_design_and_flow_submission.png")
  # Preserve earlier versions used during manuscript drafting.
  pdf_path <- file.path(delivery_dir, "Figure1_study_design_and_flow_submission.pdf")
  tiff_path <- file.path(delivery_dir, "Figure1_study_design_and_flow_submission.tiff")

  grDevices::png(
    png_path, width = 7.2, height = 7.0, units = "in",
    res = 300, type = "windows", bg = "white"
  )
  print(figure1)
  grDevices::dev.off()
  grDevices::pdf(
    pdf_path, width = 7.2, height = 7.0, family = "Helvetica",
    useDingbats = FALSE, bg = "white"
  )
  print(figure1)
  grDevices::dev.off()
  grDevices::tiff(
    tiff_path, width = 7.2, height = 7.0, units = "in",
    res = 1200, compression = "lzw", type = "windows", bg = "white"
  )
  print(figure1)
  grDevices::dev.off()

  if (!file.exists(png_path) || file.info(png_path)$size < 50000L) {
    stop("Figure 1 PNG was not generated correctly.", call. = FALSE)
  }
  if (!file.exists(pdf_path) || file.info(pdf_path)$size < 5000L) {
    stop("Figure 1 PDF was not generated correctly.", call. = FALSE)
  }
  if (!file.exists(tiff_path) || file.info(tiff_path)$size < 50000L) {
    stop("Figure 1 TIFF was not generated correctly.", call. = FALSE)
  }

  log_lines <- c(
    "Stage 23: submission Figure 1",
    paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
    paste0("PNG: ", png_path),
    paste0("PDF: ", pdf_path),
    paste0("TIFF: ", tiff_path),
    "Horizontal arrows are behind timeline boxes; panel labels are lower-case.",
    "Timeline distinguishes preceding-visit frailty from landmark covariates."
  )
  writeLines(log_lines, file.path(png_dir, "23_figure1_refinement_log.txt"), useBytes = TRUE)
  cat(paste(log_lines, collapse = "\n"), "\n")
  invisible(c(png = png_path, pdf = pdf_path, tiff = tiff_path))
}

run_stage23_refine_figure1_arrows()
