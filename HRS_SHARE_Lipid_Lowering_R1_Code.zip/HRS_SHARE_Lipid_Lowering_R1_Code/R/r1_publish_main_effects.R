# Build revised Table 2 and Figure 2 from the same cohort-level estimates.
# Run from the project root after exporting the functional reassessment results.
suppressPackageStartupMessages(library(ggplot2))

root <- "outputs_r"
destination <- file.path(root, "revision_r1")
figure_dir <- file.path(destination, "figures")
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)
read_output <- function(path) read.csv(file.path(root, path), check.names = FALSE)

cohorts <- c("HRS", "SHARE")
outcomes <- c(
  primary_event = "Broad CVD or death", strict_event = "MI, stroke, or death",
  death_component = "All-cause death", death_adl_decline = "Death or net ADL worsening"
)
measures <- c("risk_continue", "risk_discontinue", "risk_difference", "risk_ratio")
columns <- c("cohort", "outcome", "measure", "estimate", "confidence_lower",
             "confidence_upper", "p_value")
primary <- read_output("stage06_primary_effects/06_primary_effects_pooled.csv")
secondary <- read_output("stage07c_component_effects/07c_component_effects_pooled.csv")
functional <- read_output("revision_r1/R1_functional_outcomes_at_reassessment_pooled.csv")
functional <- subset(functional, state == "composite")
functional$outcome <- "death_adl_decline"
effects <- rbind(primary[, columns], secondary[, columns], functional[, columns])
stopifnot(
  nrow(effects) == length(cohorts) * length(outcomes) * length(measures),
  all(table(factor(effects$cohort, cohorts), factor(effects$outcome, names(outcomes)),
            factor(effects$measure, measures)) == 1L),
  all(effects$confidence_lower <= effects$estimate & effects$estimate <= effects$confidence_upper)
)
contrasts <- subset(effects, measure %in% measures[3:4])
stopifnot(all(is.finite(contrasts$p_value) & contrasts$p_value >= 0 & contrasts$p_value <= 1))

counts <- read_output("stage07a_outcome_audit/07a_arm_outcome_counts.csv")
format_p <- function(p) ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
format_n <- function(n) format(n, big.mark = ",", scientific = FALSE, trim = TRUE)
rows <- lapply(cohorts, function(cohort) {
  do.call(rbind, lapply(names(outcomes), function(outcome) {
    estimates <- effects[effects$cohort == cohort & effects$outcome == outcome, ]
    x <- estimates[match(measures, estimates$measure), ]
    observed <- counts[counts$cohort == cohort & counts$outcome == outcome, ]
    stopifnot(nrow(observed) == 2L, setequal(observed$treatment, 0:1))
    rd <- 1000 * unlist(x[3L, c("estimate", "confidence_lower", "confidence_upper")])
    rr <- unlist(x[4L, c("estimate", "confidence_lower", "confidence_upper")])
    data.frame(
      Cohort = cohort, Outcome = unname(outcomes[outcome]),
      `Events/observed` = paste(format_n(sum(observed$events)),
                                format_n(sum(observed$outcome_observed_person_trials)), sep = "/"),
      `Risk, % (C/D)` = sprintf("%.1f / %.1f", 100 * x$estimate[1L], 100 * x$estimate[2L]),
      `Risk difference per 1,000 (95% CI), P` = sprintf(
        "%.1f (%.1f to %.1f), %s", rd[1L], rd[2L], rd[3L], format_p(x$p_value[3L])
      ),
      `Risk ratio (95% CI), P` = sprintf(
        "%.3f (%.3f to %.3f), %s", rr[1L], rr[2L], rr[3L], format_p(x$p_value[4L])
      ), check.names = FALSE
    )
  }))
})
table2 <- do.call(rbind, rows)
legacy <- read_output("scientific_reports/main_tables/Table2_main_effects.csv")
old <- legacy[legacy$Outcome != "Death or ADL decline", ]
current <- table2[table2$Outcome != outcomes[["death_adl_decline"]], ]
stopifnot(identical(old[[3L]], current[[3L]]), identical(old[[4L]], current[[4L]]),
          identical(sub("; ", ", ", old[[5L]], fixed = TRUE), current[[5L]]),
          identical(sub("; ", ", ", old[[6L]], fixed = TRUE), current[[6L]]))
write.csv(table2, file.path(destination, "Table2_main_effects.csv"), row.names = FALSE)

plot_outcomes <- outcomes
plot_outcomes[["death_adl_decline"]] <- "Death or net ADL worsening\nat reassessment"
contrasts$outcome_label <- factor(plot_outcomes[contrasts$outcome], rev(unname(plot_outcomes)))
contrasts$cohort <- factor(contrasts$cohort, cohorts)
contrasts$p_label <- paste0(ifelse(contrasts$p_value < 0.001, "P", "P="), format_p(contrasts$p_value))
palette <- c(HRS = "#0072B2", SHARE = "#D55E00")
symbols <- c(HRS = 16, SHARE = 17)
font <- "Arial"

forest_panel <- function(measure, multiplier, null, p_position, x_scale, x_label, tag) {
  data <- contrasts[contrasts$measure == measure, ]
  dodge <- position_dodge(width = 0.48)
  ggplot(data, aes(x = multiplier * estimate, y = outcome_label, colour = cohort, shape = cohort)) +
    geom_vline(xintercept = null, linetype = "dashed", linewidth = 0.45, colour = "#5C5C5C") +
    geom_errorbar(aes(xmin = multiplier * confidence_lower, xmax = multiplier * confidence_upper),
                  orientation = "y", position = dodge, width = 0.18, linewidth = 0.65) +
    geom_point(position = dodge, size = 2.6) +
    geom_text(aes(x = p_position, label = p_label), position = dodge, hjust = 0, size = 3,
              show.legend = FALSE) +
    scale_colour_manual(values = palette) + scale_shape_manual(values = symbols) + x_scale +
    labs(x = x_label, y = NULL, tag = tag) +
    theme_classic(base_size = 10, base_family = font) +
    theme(legend.position = "none", axis.text = element_text(size = 9.5, colour = "black"),
          plot.tag = element_text(size = 12, face = "bold"),
          panel.grid.major.x = element_line(colour = "#E6E6E6", linewidth = 0.3),
          plot.margin = margin(5.5, 8, 5.5, 5.5))
}

rd <- forest_panel(
  "risk_difference", 1000, 0, 125,
  scale_x_continuous(breaks = c(-20, 0, 30, 60, 90, 120), limits = c(-20, 169)),
  "Risk difference per 1,000 eligible entries", "a"
)
rr <- forest_panel(
  "risk_ratio", 1, 1, 2.12,
  scale_x_log10(breaks = c(0.8, 1, 1.25, 1.5, 2), limits = c(0.78, 2.76)),
  "Risk ratio", "b"
) + theme(axis.text.y = element_blank(), axis.ticks.y = element_blank())

draw <- function() {
  grid::grid.newpage()
  layout <- grid::grid.layout(2, 2, widths = grid::unit(c(0.60, 0.40), "null"),
                             heights = grid::unit(c(0.92, 0.08), "null"))
  grid::pushViewport(grid::viewport(layout = layout))
  print(rd, vp = grid::viewport(layout.pos.row = 1, layout.pos.col = 1))
  print(rr, vp = grid::viewport(layout.pos.row = 1, layout.pos.col = 2))
  grid::pushViewport(grid::viewport(layout.pos.row = 2, layout.pos.col = 1:2))
  legend_y <- grid::unit(c(0.5, 0.5), "npc")
  grid::grid.points(x = grid::unit(c(0.40, 0.53), "npc"), y = legend_y, pch = symbols,
                    size = grid::unit(2.4, "mm"),
                    gp = grid::gpar(col = palette, fill = palette))
  grid::grid.text(cohorts, x = grid::unit(c(0.44, 0.57), "npc"), y = legend_y, just = "left",
                  gp = grid::gpar(fontfamily = font, fontsize = 10))
  grid::popViewport(2)
}

stem <- file.path(figure_dir, "Figure2_cohort_specific_effects")
grDevices::cairo_pdf(paste0(stem, ".pdf"), width = 7.2, height = 5.4, family = font)
draw()
invisible(grDevices::dev.off())
grDevices::tiff(paste0(stem, ".tiff"), width = 7.2, height = 5.4, units = "in", res = 600,
                type = "cairo", compression = "lzw", bg = "white")
draw()
invisible(grDevices::dev.off())
grDevices::png(paste0(stem, ".png"), width = 7.2, height = 5.4, units = "in", res = 250,
               type = "cairo", bg = "white")
draw()
invisible(grDevices::dev.off())
