# Stage 03c: build current-release primary person-trials for HRS and SHARE.
# No propensity score or treatment-effect model is fitted here.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_trial_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "haven", "data.table", "tidyselect"))

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
stage02_private <- file.path(project_root, config$output_root, "stage02", "private_do_not_share")
output_dir <- file.path(project_root, config$output_root, "stage03_current")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

read_selected <- function(path, variables, required = variables) {
  header <- haven::read_dta(path, n_max = 0L, .name_repair = "minimal")
  actual <- vapply(variables, function(variable) {
    hit <- which(tolower(names(header)) == tolower(variable))
    if (length(hit) == 1L) names(header)[hit] else NA_character_
  }, character(1L))
  missing_required <- required[is.na(actual[match(required, variables)])]
  if (length(missing_required)) {
    stop(
      "Required variables missing in ", basename(path), ": ",
      paste(missing_required, collapse = ", "), call. = FALSE
    )
  }
  selected <- unname(actual[!is.na(actual)])
  data <- haven::read_dta(
    path, col_select = tidyselect::all_of(selected), .name_repair = "minimal"
  )
  returned_order <- match(tolower(selected), tolower(names(data)))
  if (anyNA(returned_order)) {
    stop("Selected columns were not returned by ", basename(path), call. = FALSE)
  }
  data <- data[, returned_order, drop = FALSE]
  names(data) <- names(actual)[!is.na(actual)]
  data
}

num <- function(x) suppressWarnings(as.numeric(haven::zap_labels(x)))

hrs_id <- function(x) {
  value <- haven::zap_labels(x)
  out <- if (is.numeric(value)) format(value, scientific = FALSE, trim = TRUE) else trimws(as.character(value))
  out <- sub("[.]0+$", "", out)
  out <- gsub("[^0-9]", "", out)
  out <- sub("^0+", "", out)
  out[out == ""] <- "0"
  out[is.na(value)] <- NA_character_
  out
}

share_id <- function(x) {
  value <- haven::zap_labels(x)
  out <- toupper(trimws(as.character(value)))
  out[is.na(value) | !nzchar(out)] <- NA_character_
  out
}

binary01 <- function(x) {
  value <- num(x)
  out <- rep(NA_integer_, length(value))
  out[value == 0] <- 0L
  out[value == 1] <- 1L
  out
}

yes1_no5 <- function(x) {
  value <- num(x)
  out <- rep(NA_integer_, length(value))
  out[value == 1] <- 1L
  out[value == 5] <- 0L
  out
}

difficulty_binary <- function(x) {
  value <- num(x)
  out <- rep(NA_integer_, length(value))
  out[value == 5] <- 0L
  out[value %in% c(1, 6, 7)] <- 1L
  out
}

any_binary <- function(...) {
  values <- cbind(...)
  if (is.null(dim(values))) values <- matrix(values, ncol = 1L)
  out <- rep(NA_integer_, nrow(values))
  yes <- rowSums(values == 1L, na.rm = TRUE) > 0L
  complete <- rowSums(!is.na(values)) == ncol(values)
  out[yes] <- 1L
  out[complete & !yes] <- 0L
  out
}

date_from_year_month <- function(year, month, default_month = 7L) {
  year <- suppressWarnings(as.integer(year))
  month <- suppressWarnings(as.integer(month))
  year[!is.na(year) & year >= 0L & year <= 30L] <-
    year[!is.na(year) & year >= 0L & year <= 30L] + 2000L
  year[!is.na(year) & year >= 31L & year <= 99L] <-
    year[!is.na(year) & year >= 31L & year <= 99L] + 1900L
  month[is.na(month) | month < 1L | month > 12L] <- default_month
  out <- as.Date(rep(NA_character_, length(year)))
  valid <- !is.na(year) & year >= 1900L & year <= 2100L
  out[valid] <- as.Date(sprintf("%04d-%02d-15", year[valid], month[valid]))
  out
}

death_date_from_year_month <- function(year, month = NULL) {
  if (is.null(month)) month <- rep(7L, length(year))
  year <- suppressWarnings(as.integer(year))
  month <- suppressWarnings(as.integer(month))
  month[is.na(month) | month < 1L | month > 12L] <- 7L
  out <- as.Date(rep(NA_character_, length(year)))
  valid <- !is.na(year) & year >= 1900L & year <= 2100L
  out[valid] <- as.Date(sprintf("%04d-%02d-01", year[valid], month[valid]))
  out
}

complete_sum <- function(data, variables) {
  values <- as.matrix(data[, ..variables])
  out <- rowSums(values, na.rm = FALSE)
  out[rowSums(!is.na(values)) < length(variables)] <- NA_real_
  out
}

add_missing <- function(data, variables) {
  for (variable in setdiff(variables, names(data))) {
    data.table::set(data, j = variable, value = NA)
  }
  invisible(data)
}

snapshot_variables <- c(
  "wave", "interview_date", "interview_year", "age", "sex", "country",
  "lipid_medication", "high_cholesterol", "broad_heart_disease",
  "myocardial_infarction", "stroke",
  "adl_dressing", "adl_bathing", "adl_eating", "adl_transfer", "adl_toileting",
  "iadl_money", "iadl_phone", "iadl_medications", "iadl_meals", "iadl_shopping",
  "frailty_existing", "self_rated_health", "bmi", "current_smoking",
  "alcohol_use", "physical_activity", "physical_activity_vigorous",
  "physical_activity_moderate", "hypertension", "diabetes", "cancer",
  "lung_disease", "arthritis", "depression_score", "cognition_immediate",
  "cognition_delayed", "cognition_serial7", "cognition_orientation",
  "hospitalization", "education", "marital_status", "income",
  "living_arrangement", "systolic_bp", "diastolic_bp", "survey_weight_final",
  "survey_stratum", "community", "interview_observed"
)

rename_snapshot <- function(data, prefix) {
  out <- data.table::copy(data)
  add_missing(out, snapshot_variables)
  out <- out[, c("person_id", snapshot_variables), with = FALSE]
  data.table::setnames(out, snapshot_variables, paste0(prefix, snapshot_variables))
  out
}

median_date <- function(x) {
  if (all(is.na(x))) return(as.Date(NA))
  as.Date(stats::median(as.numeric(x), na.rm = TRUE), origin = "1970-01-01")
}

load_canonical <- function(cohort) {
  path <- file.path(stage02_private, paste0(tolower(cohort), "_canonical_long.rds"))
  if (!file.exists(path)) stop("Missing Stage 02 canonical data: ", path, call. = FALSE)
  data <- data.table::as.data.table(readRDS(path))
  add_missing(data, snapshot_variables)
  if (cohort == "HRS") data[, person_id := hrs_id(person_id)]
  if (cohort == "SHARE") data[, person_id := share_id(person_id)]
  data[, interview_date := as.Date(interview_date)]
  data[, interview_observed := as.integer(!is.na(interview_date))]
  data
}

make_community_long <- function(path, id_variable, waves, cohort) {
  header <- haven::read_dta(path, n_max = 0L, .name_repair = "minimal")
  chosen <- vapply(waves, function(wave) {
    candidates <- c(paste0("r", wave, "nhmliv"), paste0("r", wave, "nhmliv_s"))
    hit <- candidates[tolower(candidates) %in% tolower(names(header))]
    if (length(hit)) hit[[1L]] else NA_character_
  }, character(1L))
  if (anyNA(chosen)) {
    stop(
      cohort, " community-residence variable missing for wave(s): ",
      paste(waves[is.na(chosen)], collapse = ", "), call. = FALSE
    )
  }
  wide <- data.table::as.data.table(read_selected(path, c(id_variable, chosen)))
  id <- if (cohort == "HRS") hrs_id(wide[[id_variable]]) else share_id(wide[[id_variable]])
  parts <- lapply(seq_along(waves), function(index) {
    value <- binary01(wide[[chosen[[index]]]])
    data.table::data.table(
      person_id = id,
      wave = waves[[index]],
      community = as.integer(value == 0L)
    )
  })
  data.table::rbindlist(parts, use.names = TRUE, fill = TRUE)
}

# -----------------------------------------------------------------------------
# Current HRS sources
# -----------------------------------------------------------------------------
hrs_long <- load_canonical("HRS")
stage03c_ascii_root <- file.path(project_root, "data_links", "stage03c_inputs")
hrs_rand_file <- file.path(stage03c_ascii_root, "randhrs1992_2022v1.dta")
hrs_ascii_audit_root <- file.path(project_root, "data_links", "hrs_2022_audit")
hrs_a_file <- file.path(hrs_ascii_audit_root, "H22A_R.dta")
hrs_core_file <- file.path(hrs_ascii_audit_root, "H22C_R.dta")
hrs_g_file <- file.path(hrs_ascii_audit_root, "H22G_R.dta")
hrs_community <- make_community_long(hrs_rand_file, "hhidpn", 9:15, "HRS")
hrs_long[, community := NULL]
hrs_long <- merge(hrs_long, hrs_community, by = c("person_id", "wave"), all.x = TRUE, sort = FALSE)

hrs_status_vars <- paste0("r", 10:16, "iwstat")
hrs_rand_vars <- c("hhidpn", "radyear", "radmonth", hrs_status_vars)
hrs_rand <- data.table::as.data.table(read_selected(hrs_rand_file, hrs_rand_vars))
hrs_rand[, person_id := hrs_id(hhidpn)]
hrs_death <- unique(hrs_rand[, .(
  person_id,
  death_date = death_date_from_year_month(num(radyear), num(radmonth))
)], by = "person_id")
hrs_status <- data.table::rbindlist(lapply(seq_along(10:16), function(index) {
  wave <- (10:16)[[index]]
  value <- num(hrs_rand[[hrs_status_vars[[index]]]])
  data.table::data.table(
    person_id = hrs_rand$person_id,
    wave = wave,
    died_this_wave = as.integer(value == 5L)
  )
}), use.names = TRUE, fill = TRUE)

hrs_a <- data.table::as.data.table(read_selected(
  hrs_a_file, c("HHID", "PN", "SA500", "SA501")
))
hrs_a[, person_id := hrs_id(paste0(
  trimws(as.character(haven::zap_labels(HHID))),
  sprintf("%03d", suppressWarnings(as.integer(num(PN))))
))]
hrs_a[, interview_date := date_from_year_month(num(SA501), num(SA500))]
hrs_a <- unique(hrs_a[, .(person_id, interview_date)], by = "person_id")

hrs_core <- data.table::as.data.table(read_selected(
  hrs_core_file, c("HHID", "PN", "SC036", "SC040", "SC053")
))
hrs_core[, person_id := hrs_id(paste0(
  trimws(as.character(haven::zap_labels(HHID))),
  sprintf("%03d", suppressWarnings(as.integer(num(PN))))
))]
hrs_core[, heart_condition := yes1_no5(SC036)]
hrs_core[, mi := data.table::fcase(
  num(SC040) == 1, 1L,
  num(SC040) == 5 | num(SC036) == 5, 0L,
  default = NA_integer_
)]
hrs_core[, stroke := yes1_no5(SC053)]
hrs_core[, broad_heart_disease := any_binary(heart_condition, mi)]
hrs_core <- unique(hrs_core[, .(
  person_id, broad_heart_disease, mi, stroke
)], by = "person_id")

hrs_g <- data.table::as.data.table(read_selected(
  hrs_g_file,
  c("HHID", "PN", "SG013", "SG014", "SG021", "SG023", "SG025", "SG030")
))
hrs_g[, person_id := hrs_id(paste0(
  trimws(as.character(haven::zap_labels(HHID))),
  sprintf("%03d", suppressWarnings(as.integer(num(PN))))
))]
hrs_g[, mobility_difficulty_count := num(SG013)]
hrs_g[, skip_all_adls := mobility_difficulty_count == 0]
hrs_g[, skip_after_dressing :=
        mobility_difficulty_count == 0 |
        (mobility_difficulty_count == 1 & num(SG014) == 5)]
hrs_g[, `:=`(
  adl_dressing = difficulty_binary(SG014),
  adl_bathing = difficulty_binary(SG021),
  adl_eating = difficulty_binary(SG023),
  adl_transfer = difficulty_binary(SG025),
  adl_toileting = difficulty_binary(SG030)
)]
hrs_g[skip_all_adls == TRUE, adl_dressing := 0L]
hrs_g[skip_after_dressing == TRUE, `:=`(
  adl_bathing = 0L,
  adl_eating = 0L,
  adl_transfer = 0L,
  adl_toileting = 0L
)]
hrs_g <- unique(hrs_g[, .(
  person_id, adl_dressing, adl_bathing, adl_eating,
  adl_transfer, adl_toileting
)], by = "person_id")

hrs_f16 <- Reduce(
  function(x, y) merge(x, y, by = "person_id", all = TRUE, sort = FALSE),
  list(hrs_a, hrs_core, hrs_g)
)
hrs_f16[, `:=`(
  wave = 16L,
  interview_observed = as.integer(!is.na(interview_date))
)]
data.table::setnames(hrs_f16, "mi", "myocardial_infarction")
hrs_f16[interview_observed != 1L, interview_date := as.Date(NA)]

# -----------------------------------------------------------------------------
# Current SHARE sources
# -----------------------------------------------------------------------------
share_long <- load_canonical("SHARE")
share_h_file <- file.path(stage03c_ascii_root, "H_SHARE_f2.dta")
share_community <- make_community_long(share_h_file, "mergeid", c(2, 4, 5, 6, 7, 8), "SHARE")
share_long[, community := NULL]
share_long <- merge(share_long, share_community, by = c("person_id", "wave"), all.x = TRUE, sort = FALSE)

share_aux_path <- file.path(stage02_private, "share_aux_status_long.rds")
if (!file.exists(share_aux_path)) stop("Missing SHARE status data: ", share_aux_path, call. = FALSE)
share_status <- data.table::as.data.table(readRDS(share_aux_path))
share_status[, person_id := share_id(person_id)]
share_status <- share_status[, .(
  person_id, wave = as.integer(wave),
  died_this_wave = as.integer(status_died_this_wave == 1L)
)]

share_ph_file <- file.path(stage03c_ascii_root, "sharew9_rel9-0-0_ph.dta")
share_cv_file <- file.path(stage03c_ascii_root, "sharew9_rel9-0-0_cv_r.dta")
share_death_file <- file.path(stage03c_ascii_root, "sharewX_rel9-0-0_gv_allwaves_cv_r.dta")
share_ph <- data.table::as.data.table(read_selected(
  share_ph_file,
  c("mergeid", "ph006d1", "ph006d4", "ph072_1", "ph072_2",
    "ph049d1", "ph049d3", "ph049d4", "ph049d5", "ph049d6")
))
share_ph[, person_id := share_id(mergeid)]
share_ph[, myocardial_infarction := yes1_no5(ph072_1)]
share_ph[is.na(myocardial_infarction), myocardial_infarction := binary01(ph006d1)]
share_ph[, stroke := yes1_no5(ph072_2)]
share_ph[is.na(stroke), stroke := binary01(ph006d4)]
share_ph[, broad_heart_disease := myocardial_infarction]
share_ph[, `:=`(
  adl_dressing = binary01(ph049d1),
  adl_bathing = binary01(ph049d3),
  adl_eating = binary01(ph049d4),
  adl_transfer = binary01(ph049d5),
  adl_toileting = binary01(ph049d6)
)]
share_ph <- unique(share_ph[, .(
  person_id, broad_heart_disease, myocardial_infarction, stroke,
  adl_dressing, adl_bathing, adl_eating, adl_transfer, adl_toileting
)], by = "person_id")

share_cv <- data.table::as.data.table(read_selected(
  share_cv_file, c("mergeid", "int_year", "int_month", "deceased")
))
share_cv[, person_id := share_id(mergeid)]
share_cv[, interview_date := date_from_year_month(num(int_year), num(int_month))]
share_cv[, interview_observed := as.integer(!is.na(interview_date) & num(deceased) == 0L)]
share_cv[, died_this_wave := as.integer(num(deceased) == 1L)]
share_f9 <- merge(
  share_cv[, .(person_id, wave = 9L, interview_date, interview_observed)],
  share_ph, by = "person_id", all.x = TRUE, sort = FALSE
)
share_f9[interview_observed != 1L, interview_date := as.Date(NA)]
share_status <- data.table::rbindlist(list(
  share_status,
  share_cv[, .(person_id, wave = 9L, died_this_wave)]
), use.names = TRUE, fill = TRUE)

share_death_raw <- data.table::as.data.table(read_selected(
  share_death_file, c("mergeid", "deceased_year", "deceased_month")
))
share_death_raw[, person_id := share_id(mergeid)]
share_death_raw[, death_date := death_date_from_year_month(
  num(deceased_year), num(deceased_month)
)]
share_death <- share_death_raw[!is.na(person_id), .(
  death_date = if (all(is.na(death_date))) as.Date(NA) else min(death_date, na.rm = TRUE)
), by = person_id]

# -----------------------------------------------------------------------------
# Common person-trial builder
# -----------------------------------------------------------------------------
flow_rows <- list()
arm_rows <- list()
sequence_rows <- list()
validation_rows <- list()
coverage_rows <- list()
private_trials <- list()
flow_index <- arm_index <- sequence_index <- validation_index <- coverage_index <- private_index <- 0L

build_trials <- function(cohort, longitudinal, sequences, latest_f, status_long, death_lookup) {
  cohort_value <- as.character(cohort[[1L]])
  longitudinal <- data.table::copy(longitudinal)
  data.table::setorder(longitudinal, person_id, wave)
  if (longitudinal[, anyDuplicated(paste(person_id, wave))] > 0L) {
    stop(cohort, " canonical data contain duplicate person-wave records.", call. = FALSE)
  }
  latest_f <- data.table::copy(latest_f)
  add_missing(latest_f, snapshot_variables)
  latest_wave <- unique(latest_f$wave)
  scheduled <- longitudinal[, .(scheduled_date = median_date(interview_date)), by = wave]
  scheduled <- data.table::rbindlist(list(
    scheduled[!wave %in% latest_wave],
    latest_f[, .(scheduled_date = median_date(interview_date)), by = wave]
  ), use.names = TRUE, fill = TRUE)

  cohort_trials <- list()
  cohort_trial_index <- 0L
  for (row_index in seq_len(nrow(sequences))) {
    e_wave <- sequences$E_wave[[row_index]]
    l_wave <- sequences$L_wave[[row_index]]
    f_wave <- sequences$F_wave[[row_index]]
    sequence_name <- paste(cohort, e_wave, l_wave, f_wave, sep = "_")

    e <- rename_snapshot(longitudinal[wave == e_wave & interview_observed == 1L], "E_")
    l <- rename_snapshot(longitudinal[wave == l_wave & interview_observed == 1L], "L_")
    f_source <- if (f_wave %in% latest_wave) latest_f[wave == f_wave] else longitudinal[wave == f_wave]
    f <- rename_snapshot(f_source[interview_observed == 1L], "F_")
    trials <- merge(e, l, by = "person_id", all = FALSE, sort = FALSE)
    trials <- merge(trials, f, by = "person_id", all.x = TRUE, sort = FALSE)
    f_status <- status_long[wave == f_wave, .(person_id, F_died_this_wave = died_this_wave)]
    trials <- merge(trials, f_status, by = "person_id", all.x = TRUE, sort = FALSE)
    trials <- merge(trials, death_lookup, by = "person_id", all.x = TRUE, sort = FALSE)

    scheduled_f <- scheduled[wave == f_wave, scheduled_date]
    if (length(scheduled_f) != 1L || is.na(scheduled_f)) {
      stop(cohort, " has no valid scheduled date for wave ", f_wave, call. = FALSE)
    }
    trials[, followup_reference_date := as.Date(
      ifelse(!is.na(F_interview_date), as.numeric(F_interview_date), as.numeric(scheduled_f)),
      origin = "1970-01-01"
    )]
    trials[, treatment := data.table::fcase(
      E_lipid_medication == 1L & L_lipid_medication == 0L, 1L,
      E_lipid_medication == 1L & L_lipid_medication == 1L, 0L,
      default = NA_integer_
    )]
    trials[, treatment_label := ifelse(
      treatment == 1L, "discontinue", ifelse(treatment == 0L, "continue", NA_character_)
    )]
    trials[, prior_interval_years := tte_year_fraction(L_interview_date, E_interview_date)]
    trials[, followup_time_years := tte_year_fraction(followup_reference_date, L_interview_date)]
    trials[, valid_prior_interval := tte_valid_interval(
      L_interview_date, E_interview_date,
      as.numeric(config$design$prior_to_landmark_min_years),
      as.numeric(config$design$prior_to_landmark_max_years)
    )]
    trials[, valid_followup_interval := tte_valid_interval(
      followup_reference_date, L_interview_date,
      as.numeric(config$design$landmark_to_followup_min_years),
      as.numeric(config$design$landmark_to_followup_max_years)
    )]
    trials[, event_free := L_broad_heart_disease == 0L & L_stroke == 0L]
    trials[, eligible := valid_prior_interval & valid_followup_interval &
      !is.na(L_age) & L_age >= as.numeric(config$design$minimum_age) &
      E_lipid_medication == 1L & !is.na(treatment) & event_free & L_community == 1L]

    adl <- c("adl_dressing", "adl_bathing", "adl_eating", "adl_transfer", "adl_toileting")
    iadl <- c("iadl_money", "iadl_phone", "iadl_medications", "iadl_meals", "iadl_shopping")
    trials[, L_adl5_count := complete_sum(.SD, paste0("L_", adl))]
    trials[, F_adl5_count := complete_sum(.SD, paste0("F_", adl))]
    trials[, L_iadl5_count := complete_sum(.SD, paste0("L_", iadl))]

    trials[, death_in_interval := as.integer(
      (!is.na(death_date) & death_date > L_interview_date & death_date <= followup_reference_date) |
        (!is.na(F_died_this_wave) & F_died_this_wave == 1L)
    )]
    trials[, nonfatal_broad := any_binary(F_broad_heart_disease, F_stroke)]
    trials[F_myocardial_infarction == 1L, nonfatal_broad := 1L]
    trials[, nonfatal_strict := any_binary(F_myocardial_infarction, F_stroke)]
    trials[, primary_event := data.table::fcase(
      death_in_interval == 1L, 1L,
      F_interview_observed == 1L & nonfatal_broad == 1L, 1L,
      F_interview_observed == 1L & nonfatal_broad == 0L, 0L,
      default = NA_integer_
    )]
    trials[, strict_event := data.table::fcase(
      death_in_interval == 1L, 1L,
      F_interview_observed == 1L & nonfatal_strict == 1L, 1L,
      F_interview_observed == 1L & nonfatal_strict == 0L, 0L,
      default = NA_integer_
    )]
    trials[, adl_decline := data.table::fcase(
      F_interview_observed == 1L & !is.na(L_adl5_count) & !is.na(F_adl5_count) &
        F_adl5_count > L_adl5_count, 1L,
      F_interview_observed == 1L & !is.na(L_adl5_count) & !is.na(F_adl5_count), 0L,
      default = NA_integer_
    )]
    trials[, death_adl_decline := data.table::fcase(
      death_in_interval == 1L, 1L,
      !is.na(adl_decline), adl_decline,
      default = NA_integer_
    )]
    trials[, censored_primary := as.integer(is.na(primary_event))]
    trials[, `:=`(
      cohort = cohort_value,
      sequence = sequence_name,
      E_wave = e_wave,
      L_wave = l_wave,
      F_wave = f_wave
    )]

    stages <- list(
      linked_prior_and_landmark = rep(TRUE, nrow(trials)),
      valid_prior_interval = trials$valid_prior_interval,
      valid_followup_interval = trials$valid_prior_interval & trials$valid_followup_interval,
      age_70_or_older = trials$valid_prior_interval & trials$valid_followup_interval &
        !is.na(trials$L_age) & trials$L_age >= as.numeric(config$design$minimum_age),
      prior_lipid_user = trials$valid_prior_interval & trials$valid_followup_interval &
        !is.na(trials$L_age) & trials$L_age >= as.numeric(config$design$minimum_age) &
        trials$E_lipid_medication == 1L,
      treatment_observed = trials$valid_prior_interval & trials$valid_followup_interval &
        !is.na(trials$L_age) & trials$L_age >= as.numeric(config$design$minimum_age) &
        trials$E_lipid_medication == 1L & !is.na(trials$treatment),
      event_free = trials$valid_prior_interval & trials$valid_followup_interval &
        !is.na(trials$L_age) & trials$L_age >= as.numeric(config$design$minimum_age) &
        trials$E_lipid_medication == 1L & !is.na(trials$treatment) & trials$event_free,
      community_dwelling = trials$eligible,
      primary_outcome_observed = trials$eligible & !is.na(trials$primary_event)
    )
    for (stage in names(stages)) {
      selector <- !is.na(stages[[stage]]) & stages[[stage]]
      flow_index <<- flow_index + 1L
      flow_rows[[flow_index]] <<- data.frame(
        cohort = cohort_value, sequence = sequence_name, stage = stage,
        person_trials = sum(selector),
        unique_persons = data.table::uniqueN(trials$person_id[selector]),
        stringsAsFactors = FALSE
      )
    }

    eligible_trials <- trials[eligible == TRUE]
    cohort_trial_index <- cohort_trial_index + 1L
    cohort_trials[[cohort_trial_index]] <- eligible_trials
    sequence_index <<- sequence_index + 1L
    sequence_rows[[sequence_index]] <<- data.frame(
      cohort = cohort_value, sequence = sequence_name,
      eligible_person_trials = nrow(eligible_trials),
      discontinue_trials = sum(eligible_trials$treatment == 1L),
      continue_trials = sum(eligible_trials$treatment == 0L),
      primary_observed = sum(!is.na(eligible_trials$primary_event)),
      primary_events = sum(eligible_trials$primary_event == 1L, na.rm = TRUE),
      strict_events = sum(eligible_trials$strict_event == 1L, na.rm = TRUE),
      deaths = sum(eligible_trials$death_in_interval == 1L, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  }

  result <- data.table::rbindlist(cohort_trials, use.names = TRUE, fill = TRUE)
  result[, trial_id := sprintf("%s_%07d", cohort, seq_len(.N))]
  data.table::setorder(result, L_interview_date, person_id, sequence)
  result
}

hrs_sequences <- data.table::data.table(E_wave = 8:14, L_wave = 9:15, F_wave = 10:16)
share_wave_order <- c(1, 2, 4, 5, 6, 7, 8, 9)
share_sequences <- data.table::data.table(
  E_wave = share_wave_order[1:(length(share_wave_order) - 2L)],
  L_wave = share_wave_order[2:(length(share_wave_order) - 1L)],
  F_wave = share_wave_order[3:length(share_wave_order)]
)

hrs_trials <- build_trials(
  "HRS", hrs_long, hrs_sequences, hrs_f16, hrs_status, hrs_death
)
share_trials <- build_trials(
  "SHARE", share_long, share_sequences, share_f9, share_status, share_death
)
all_primary_trials <- data.table::rbindlist(list(hrs_trials, share_trials), use.names = TRUE, fill = TRUE)

if (any(all_primary_trials$strict_event == 1L & all_primary_trials$primary_event == 0L, na.rm = TRUE)) {
  stop("A strict event is not nested within the broad primary outcome.", call. = FALSE)
}

for (cohort_name in c("HRS", "SHARE")) {
  cohort_trials <- all_primary_trials[cohort == cohort_name]
  saveRDS(
    cohort_trials,
    file.path(private_dir, paste0(tolower(cohort_name), "_person_trials_PRIVATE.rds")),
    version = 3L
  )
  for (arm_value in c(0L, 1L)) {
    arm <- cohort_trials[treatment == arm_value]
    arm_index <- arm_index + 1L
    arm_rows[[arm_index]] <- data.frame(
      cohort = cohort_name,
      treatment = arm_value,
      treatment_label = ifelse(arm_value == 1L, "discontinue", "continue"),
      person_trials = nrow(arm),
      unique_persons = data.table::uniqueN(arm$person_id),
      primary_observed = sum(!is.na(arm$primary_event)),
      primary_events = sum(arm$primary_event == 1L, na.rm = TRUE),
      strict_observed = sum(!is.na(arm$strict_event)),
      strict_events = sum(arm$strict_event == 1L, na.rm = TRUE),
      deaths = sum(arm$death_in_interval == 1L, na.rm = TRUE),
      adl_observed = sum(!is.na(arm$death_adl_decline)),
      adl_events = sum(arm$death_adl_decline == 1L, na.rm = TRUE),
      stringsAsFactors = FALSE
    )
  }

  checks <- list(
    unique_trial_id = !anyDuplicated(cohort_trials$trial_id),
    prior_precedes_landmark = all(cohort_trials$E_interview_date < cohort_trials$L_interview_date),
    followup_after_landmark = all(cohort_trials$followup_reference_date > cohort_trials$L_interview_date),
    valid_prior_interval = all(cohort_trials$valid_prior_interval),
    valid_followup_interval = all(cohort_trials$valid_followup_interval),
    prior_treatment_is_one = all(cohort_trials$E_lipid_medication == 1L),
    treatment_is_binary = all(cohort_trials$treatment %in% c(0L, 1L)),
    event_free_at_landmark = all(cohort_trials$event_free),
    age_at_least_70 = all(cohort_trials$L_age >= as.numeric(config$design$minimum_age)),
    community_dwelling = all(cohort_trials$L_community == 1L),
    counted_death_within_followup = all(
      cohort_trials$death_in_interval != 1L |
        cohort_trials$F_died_this_wave == 1L |
        (!is.na(cohort_trials$death_date) &
           cohort_trials$death_date > cohort_trials$L_interview_date &
           cohort_trials$death_date <= cohort_trials$followup_reference_date),
      na.rm = TRUE
    ),
    strict_nested_in_broad = !any(
      cohort_trials$strict_event == 1L & cohort_trials$primary_event == 0L,
      na.rm = TRUE
    ),
    share_fall_not_pooled = if (cohort_name == "SHARE") !"fall" %in% names(cohort_trials) else TRUE
  )
  for (check_name in names(checks)) {
    validation_index <- validation_index + 1L
    validation_rows[[validation_index]] <- data.frame(
      cohort = cohort_name, check = check_name,
      passed = isTRUE(checks[[check_name]]), stringsAsFactors = FALSE
    )
  }
}

arm_table <- do.call(rbind, arm_rows)
gate <- data.table::as.data.table(arm_table)[, .(
  smaller_arm_person_trials = min(person_trials),
  smaller_arm_primary_events = min(primary_events),
  total_primary_events = sum(primary_events),
  both_arms_present = data.table::uniqueN(treatment) == 2L
), by = cohort]
gate[, pass_smaller_arm_n := smaller_arm_person_trials >=
       as.numeric(config$data_gates$minimum_smaller_arm_person_trials)]
gate[, pass_smaller_arm_events := smaller_arm_primary_events >=
       as.numeric(config$data_gates$minimum_smaller_arm_primary_events)]
gate[, pass_total_events := total_primary_events >=
       as.numeric(config$data_gates$minimum_total_primary_events)]
gate[, unweighted_data_gate := pass_smaller_arm_n & pass_smaller_arm_events &
       pass_total_events & both_arms_present]

core_covariates <- c(
  "L_age", "L_sex", "L_high_cholesterol", "L_self_rated_health", "L_bmi",
  "L_current_smoking", "L_alcohol_use", "L_hypertension", "L_diabetes",
  "L_cancer", "L_lung_disease", "L_arthritis", "L_depression_score",
  "L_cognition_immediate", "L_cognition_delayed", "L_hospitalization",
  "L_education", "L_marital_status", "L_adl5_count", "L_iadl5_count",
  "L_survey_weight_final"
)
for (cohort_name in c("HRS", "SHARE")) {
  cohort_trials <- all_primary_trials[cohort == cohort_name]
  for (variable in core_covariates) {
    coverage_index <- coverage_index + 1L
    coverage_rows[[coverage_index]] <- data.frame(
      cohort = cohort_name, variable = variable,
      person_trials = nrow(cohort_trials),
      nonmissing_n = sum(!is.na(cohort_trials[[variable]])),
      nonmissing_fraction = mean(!is.na(cohort_trials[[variable]])),
      stringsAsFactors = FALSE
    )
  }
}
coverage_table <- do.call(rbind, coverage_rows)

validation_table <- do.call(rbind, validation_rows)
flow_table <- data.table::rbindlist(flow_rows, use.names = TRUE, fill = TRUE)
sequence_table <- data.table::rbindlist(sequence_rows, use.names = TRUE, fill = TRUE)

set.seed(as.integer(config$seed))
manual_private <- data.table::rbindlist(lapply(c("HRS", "SHARE"), function(cohort_name) {
  cohort_trials <- all_primary_trials[cohort == cohort_name]
  data.table::rbindlist(lapply(c(0L, 1L), function(arm_value) {
    arm <- cohort_trials[treatment == arm_value]
    if (!nrow(arm)) return(NULL)
    arm[sample.int(.N, min(25L, .N))]
  }), use.names = TRUE, fill = TRUE)
}), use.names = TRUE, fill = TRUE)
manual_private[, review_number := seq_len(.N), by = cohort]
manual_fields <- c(
  "cohort", "review_number", "person_id", "trial_id", "sequence",
  "E_wave", "L_wave", "F_wave", "E_interview_date", "L_interview_date",
  "F_interview_date", "followup_reference_date", "E_lipid_medication",
  "L_lipid_medication", "treatment_label", "L_age", "L_community",
  "L_broad_heart_disease", "L_stroke", "death_date", "death_in_interval",
  "F_broad_heart_disease", "F_myocardial_infarction", "F_stroke",
  "primary_event", "strict_event", "L_adl5_count", "F_adl5_count",
  "death_adl_decline"
)
tte_write_csv(
  manual_private[, ..manual_fields],
  file.path(private_dir, "03c_records_for_manual_review_PRIVATE.csv")
)
review_signoff <- manual_private[, .(
  cohort, review_number, treatment_label,
  reviewer_pass = "", reviewer_note = ""
)]

role_decision <- data.frame(
  cohort = c("HRS", "SHARE", "ELSA"),
  role = c("primary_composite", "primary_composite", "supplementary_nonfatal"),
  reason = c(
    "Current mortality and cardiovascular follow-up available",
    "Current mortality and cardiovascular follow-up available",
    "Post-Wave-5 complete registry mortality unavailable in local EUL files"
  ),
  stringsAsFactors = FALSE
)

tte_write_csv(flow_table, file.path(output_dir, "03c_inclusion_flow.csv"))
tte_write_csv(arm_table, file.path(output_dir, "03c_arm_event_counts.csv"))
tte_write_csv(sequence_table, file.path(output_dir, "03c_sequence_counts.csv"))
tte_write_csv(validation_table, file.path(output_dir, "03c_longitudinal_validation.csv"))
tte_write_csv(gate, file.path(output_dir, "03c_unweighted_data_gates.csv"))
tte_write_csv(coverage_table, file.path(output_dir, "03c_core_covariate_coverage.csv"))
tte_write_csv(review_signoff, file.path(output_dir, "03c_manual_review_signoff.csv"))
tte_write_csv(role_decision, file.path(output_dir, "03c_cohort_role_decision.csv"))
writeLines(
  c(
    "PRIVATE LOCAL DATA - DO NOT SHARE",
    "RDS and review files contain person identifiers and longitudinal records.",
    "Return only aggregate files from the parent stage03_current directory."
  ),
  file.path(private_dir, "DO_NOT_SHARE.txt"), useBytes = TRUE
)

summary_lines <- c(
  "Stage 03c: current-release HRS/SHARE primary trial construction",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Validation checks failed: ", sum(!validation_table$passed)),
  paste0("Primary cohorts passing unweighted gate: ", sum(gate$unweighted_data_gate), " of ", nrow(gate)),
  "",
  "No propensity score, causal weight, treatment effect, or meta-analysis was fitted.",
  "Review the private records locally and complete 03c_manual_review_signoff.csv."
)
writeLines(summary_lines, file.path(output_dir, "03c_stage_summary.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(output_dir, "03c_session_info.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
