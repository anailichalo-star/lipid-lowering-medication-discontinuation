# Stage 07b: build and diagnose outcome-specific censoring weights for
# strict cardiovascular/death and all-cause death outcomes.
# No treatment-effect model is fitted in this stage.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8",
  local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
primary_weight_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "primary_weight_model.yml")
)
secondary_config_path <- file.path(
  project_root, "config_r", "secondary_outcome_weight_model.yml"
)
secondary_config <- tte_read_yaml_utf8(secondary_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_dir <- file.path(
  project_root, analysis_config$output_root, "stage05_weighting"
)
stage05_private <- file.path(stage05_dir, "private_do_not_share")
stage07a_dir <- file.path(
  project_root, analysis_config$output_root, "stage07a_outcome_audit"
)
output_dir <- file.path(
  project_root, analysis_config$output_root, "stage07b_outcome_weights"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
outcomes <- c("strict_event", "death_component")
continuous_covariates <- unlist(
  primary_weight_config$continuous_covariates, use.names = FALSE
)
categorical_covariates <- unlist(
  primary_weight_config$categorical_covariates, use.names = FALSE
)
primary_covariates <- c(continuous_covariates, categorical_covariates)
spline_covariates <- unlist(
  primary_weight_config$spline_covariates, use.names = FALSE
)
probability_floor <- as.numeric(secondary_config$probability_floor)
lower_quantile <- as.numeric(secondary_config$weight_lower_quantile)
upper_quantile <- as.numeric(secondary_config$weight_upper_quantile)
minimum_retention_probability <- as.numeric(
  secondary_config$minimum_acceptable_retention_probability
)
maximum_low_retention_fraction <- as.numeric(
  secondary_config$maximum_fraction_retention_below_0_05
)

stage05_gate_path <- file.path(stage05_dir, "05_weighting_gate.csv")
stage07a_check_path <- file.path(stage07a_dir, "07a_consistency_checks.csv")
if (!file.exists(stage05_gate_path)) {
  stop("Missing Stage 05 gate file: ", stage05_gate_path, call. = FALSE)
}
if (!file.exists(stage07a_check_path)) {
  stop("Missing Stage 07a consistency checks: ", stage07a_check_path, call. = FALSE)
}

as_logical_value <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}
stage05_gate <- data.table::as.data.table(tte_read_csv_utf8(stage05_gate_path))
ready_column <- intersect(
  c("ready_for_effect_estimation", "all_gates_pass"),
  names(stage05_gate)
)
if (length(ready_column) != 1L) {
  stop("Could not identify the Stage 05 final gate column.", call. = FALSE)
}
stage05_rows <- stage05_gate[cohort %in% cohorts]
if (!setequal(as.character(stage05_rows$cohort), cohorts) ||
    nrow(stage05_rows) != length(cohorts) ||
    !all(as_logical_value(stage05_rows[[ready_column]]))) {
  stop("Both cohorts must pass Stage 05 before Stage 07b.", call. = FALSE)
}
stage07a_checks <- data.table::as.data.table(
  tte_read_csv_utf8(stage07a_check_path)
)
if (!nrow(stage07a_checks) || !all(as_logical_value(stage07a_checks$passed))) {
  stop("Stage 07a contains a failed consistency check.", call. = FALSE)
}

clamp_probability <- function(x) {
  pmax(probability_floor, pmin(1 - probability_floor, x))
}

safe_quantile <- function(x, probability) {
  value <- suppressWarnings(as.numeric(x))
  value <- value[is.finite(value)]
  if (!length(value)) return(NA_real_)
  as.numeric(stats::quantile(value, probability, names = FALSE, type = 2L))
}

effective_sample_size <- function(weight) {
  weight <- suppressWarnings(as.numeric(weight))
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

weighted_mean_value <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (!any(valid)) return(NA_real_)
  sum(weight[valid] * x[valid]) / sum(weight[valid])
}

weighted_variance_value <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean_value(x[valid], weight[valid])
  sum(weight[valid] * (x[valid] - center)^2) / sum(weight[valid])
}

numeric_smd <- function(x, treatment, weight) {
  x <- suppressWarnings(as.numeric(x))
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- x[valid]
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  mean0 <- weighted_mean_value(x[treatment == 0L], weight[treatment == 0L])
  mean1 <- weighted_mean_value(x[treatment == 1L], weight[treatment == 1L])
  var0 <- weighted_variance_value(x[treatment == 0L], weight[treatment == 0L])
  var1 <- weighted_variance_value(x[treatment == 1L], weight[treatment == 1L])
  denominator <- sqrt((var0 + var1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (mean1 - mean0) / denominator
}

level_smd <- function(x, treatment, weight, level_value) {
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- !is.na(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- as.character(x[valid])
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  indicator <- as.numeric(x == level_value)
  p0 <- weighted_mean_value(
    indicator[treatment == 0L], weight[treatment == 0L]
  )
  p1 <- weighted_mean_value(
    indicator[treatment == 1L], weight[treatment == 1L]
  )
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

calculate_balance <- function(
  data, weight_name, sample_name, cohort_name, outcome_name, imputation_index
) {
  treatment <- data$treatment
  weight <- data[[weight_name]]
  rows <- list()
  row_index <- 0L
  for (variable_name in primary_covariates) {
    x <- data[[variable_name]]
    if (variable_name %in% categorical_covariates) {
      levels_present <- sort(unique(as.character(x[!is.na(x)])))
      for (level_value in levels_present) {
        row_index <- row_index + 1L
        rows[[row_index]] <- data.table::data.table(
          cohort = cohort_name,
          outcome = outcome_name,
          imputation = imputation_index,
          balance_sample = sample_name,
          variable = variable_name,
          level = level_value,
          standardized_difference = level_smd(
            x, treatment, weight, level_value
          )
        )
      }
    } else {
      row_index <- row_index + 1L
      rows[[row_index]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        balance_sample = sample_name,
        variable = variable_name,
        level = "",
        standardized_difference = numeric_smd(x, treatment, weight)
      )
    }
  }
  result <- data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)
  result[, absolute_standardized_difference := abs(standardized_difference)]
  result
}

model_term <- function(variable_name) {
  if (variable_name %in% spline_covariates) {
    paste0("splines::ns(", variable_name, ", df = 3)")
  } else {
    variable_name
  }
}

fit_censoring_model <- function(
  formula, data, model_name, cohort_name, outcome_name, imputation_index
) {
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::glm(
      formula = formula,
      data = data,
      family = stats::binomial(),
      na.action = stats::na.fail,
      control = stats::glm.control(maxit = 100, epsilon = 1e-8)
    ),
    warning = function(warning_condition) {
      warning_messages <<- c(
        warning_messages, conditionMessage(warning_condition)
      )
      invokeRestart("muffleWarning")
    }
  )
  diagnostics <- data.table::data.table(
    cohort = cohort_name,
    outcome = outcome_name,
    imputation = imputation_index,
    model = model_name,
    formula = paste(deparse(formula), collapse = " "),
    converged = isTRUE(fit$converged),
    iterations = fit$iter,
    coefficient_n = length(stats::coef(fit)),
    aliased_coefficient_n = sum(is.na(stats::coef(fit))),
    warning_n = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    separation_or_convergence_warning = any(grepl(
      "did not converge|fitted probabilities numerically 0 or 1 occurred|algorithm stopped",
      warning_messages,
      ignore.case = TRUE
    ))
  )
  list(fit = fit, diagnostics = diagnostics)
}

to_binary <- function(x, variable_name, cohort_name) {
  value <- suppressWarnings(as.integer(as.character(x)))
  if (any(!is.na(value) & !value %in% c(0L, 1L))) {
    stop(
      cohort_name, ": ", variable_name,
      " contains values outside 0/1/NA.",
      call. = FALSE
    )
  }
  value
}

sample_parts <- list()
sequence_sample_parts <- list()
model_diagnostic_parts <- list()
retention_parts <- list()
weight_distribution_parts <- list()
ess_parts <- list()
balance_parts <- list()
plot_weight_parts <- list()

for (cohort_name in cohorts) {
  stage04_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(stage04_path)) {
    stop("Missing Stage 04f trial file: ", stage04_path, call. = FALSE)
  }
  if (!file.exists(stage05_path)) {
    stop("Missing Stage 05 weighted file: ", stage05_path, call. = FALSE)
  }

  source_trials <- data.table::as.data.table(readRDS(stage04_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  required_source <- c(
    "person_id", "trial_id", "sequence", "treatment",
    "F_interview_observed", "death_in_interval", "strict_event"
  )
  missing_source <- setdiff(required_source, names(source_trials))
  if (length(missing_source)) {
    stop(
      cohort_name, " source trials are missing: ",
      paste(missing_source, collapse = ", "),
      call. = FALSE
    )
  }
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate person-trial keys in Stage 04f.", call. = FALSE)
  }
  source_trials[, F_interview_observed := to_binary(
    F_interview_observed, "F_interview_observed", cohort_name
  )]
  source_trials[, death_in_interval := to_binary(
    death_in_interval, "death_in_interval", cohort_name
  )]
  source_trials[, strict_event := to_binary(
    strict_event, "strict_event", cohort_name
  )]
  source_trials[, death_component := data.table::fcase(
    death_in_interval == 1L, 1L,
    death_in_interval == 0L & F_interview_observed == 1L, 0L,
    default = NA_integer_
  )]

  stage05_imputations <- readRDS(stage05_path)
  if (length(stage05_imputations) != 20L) {
    stop(cohort_name, ": Stage 05 does not contain 20 imputations.", call. = FALSE)
  }

  first_completed <- data.table::as.data.table(stage05_imputations[[1L]])
  first_completed[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  first_match <- match(first_completed$join_key, source_trials$join_key)
  if (anyNA(first_match) || anyDuplicated(first_completed$join_key) ||
      nrow(first_completed) != nrow(source_trials)) {
    stop(cohort_name, ": Stage 04f-to-Stage 05 key alignment failed.", call. = FALSE)
  }

  fixed_terms <- unlist(
    primary_weight_config$always_adjust[[cohort_name]], use.names = FALSE
  )
  full_terms <- c(
    vapply(primary_covariates, model_term, character(1L)), fixed_terms
  )
  denominator_formula <- stats::as.formula(paste(
    "outcome_observed_specific ~ treatment +",
    paste(full_terms, collapse = " + ")
  ))
  numerator_formula <- stats::as.formula(paste(
    "outcome_observed_specific ~ treatment +",
    paste(fixed_terms, collapse = " + ")
  ))

  for (outcome_name in outcomes) {
    source_outcome <- source_trials[[outcome_name]]
    sample_table <- data.table::data.table(
      treatment = source_trials$treatment,
      person_id = source_trials$person_id,
      sequence = source_trials$sequence,
      outcome_value = source_outcome
    )
    sample_parts[[paste(cohort_name, outcome_name, sep = "_")]] <- sample_table[, .(
      eligible_person_trials = .N,
      unique_persons = data.table::uniqueN(person_id),
      observed_person_trials = sum(!is.na(outcome_value)),
      observation_fraction = mean(!is.na(outcome_value)),
      events = sum(outcome_value == 1L, na.rm = TRUE),
      non_events = sum(outcome_value == 0L, na.rm = TRUE)
    ), by = treatment][, `:=`(
      cohort = cohort_name,
      outcome = outcome_name,
      treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
    )]
    sequence_sample_parts[[paste(cohort_name, outcome_name, sep = "_")]] <-
      sample_table[, .(
        observed_person_trials = sum(!is.na(outcome_value)),
        observation_fraction = mean(!is.na(outcome_value)),
        events = sum(outcome_value == 1L, na.rm = TRUE)
      ), by = .(sequence, treatment)][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]

    compact_imputations <- vector("list", length(stage05_imputations))
    for (imputation_index in seq_along(stage05_imputations)) {
      completed <- data.table::as.data.table(
        data.table::copy(stage05_imputations[[imputation_index]])
      )
      completed[, join_key := paste(
        as.character(person_id), as.character(trial_id), sep = "\r"
      )]
      index <- match(completed$join_key, source_trials$join_key)
      if (anyNA(index)) {
        stop(
          cohort_name, "/", outcome_name,
          ": unmatched row in imputation ", imputation_index,
          call. = FALSE
        )
      }
      completed[, outcome_value := source_outcome[index]]
      completed[, outcome_observed_specific := as.integer(!is.na(outcome_value))]
      completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
      if (anyNA(completed$treatment) ||
          !all(completed$treatment %in% c(0L, 1L))) {
        stop(
          cohort_name, "/", outcome_name,
          ": invalid treatment coding in imputation ", imputation_index,
          call. = FALSE
        )
      }
      residual_missing <- vapply(
        primary_covariates,
        function(variable_name) anyNA(completed[[variable_name]]),
        logical(1L)
      )
      if (any(residual_missing)) {
        stop(
          cohort_name, "/", outcome_name,
          ": imputed covariates remain missing in imputation ",
          imputation_index, ": ",
          paste(names(residual_missing)[residual_missing], collapse = ", "),
          call. = FALSE
        )
      }

      denominator_fit <- fit_censoring_model(
        denominator_formula, completed, "censoring_denominator",
        cohort_name, outcome_name, imputation_index
      )
      numerator_fit <- fit_censoring_model(
        numerator_formula, completed, "censoring_numerator",
        cohort_name, outcome_name, imputation_index
      )
      model_diagnostic_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- data.table::rbindlist(
        list(denominator_fit$diagnostics, numerator_fit$diagnostics),
        use.names = TRUE,
        fill = TRUE
      )

      completed[, retention_probability_specific := clamp_probability(
        stats::predict(denominator_fit$fit, newdata = completed, type = "response")
      )]
      completed[, numerator_retention_probability_specific := clamp_probability(
        stats::predict(numerator_fit$fit, newdata = completed, type = "response")
      )]
      if (any(!is.finite(completed$retention_probability_specific)) ||
          any(!is.finite(completed$numerator_retention_probability_specific))) {
        stop(
          cohort_name, "/", outcome_name,
          ": non-finite retention prediction in imputation ",
          imputation_index,
          call. = FALSE
        )
      }
      completed[, censoring_weight_specific := ifelse(
        outcome_observed_specific == 1L,
        numerator_retention_probability_specific /
          retention_probability_specific,
        NA_real_
      )]
      completed[, total_weight_specific_raw := ifelse(
        outcome_observed_specific == 1L,
        survey_weight_scaled * treatment_weight * censoring_weight_specific,
        NA_real_
      )]
      weight_lower <- safe_quantile(
        completed$total_weight_specific_raw, lower_quantile
      )
      weight_upper <- safe_quantile(
        completed$total_weight_specific_raw, upper_quantile
      )
      if (!is.finite(weight_lower) || !is.finite(weight_upper) ||
          weight_lower <= 0 || weight_upper < weight_lower) {
        stop(
          cohort_name, "/", outcome_name,
          ": invalid weight truncation bounds in imputation ",
          imputation_index,
          call. = FALSE
        )
      }
      completed[, total_weight_specific := ifelse(
        outcome_observed_specific == 1L,
        pmax(weight_lower, pmin(weight_upper, total_weight_specific_raw)),
        NA_real_
      )]

      retention_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        minimum_retention_probability = min(
          completed$retention_probability_specific
        ),
        maximum_retention_probability = max(
          completed$retention_probability_specific
        ),
        fraction_retention_probability_below_0_05 = mean(
          completed$retention_probability_specific < 0.05
        ),
        any_retention_probability_below_0_01 = any(
          completed$retention_probability_specific <
            minimum_retention_probability
        )
      )

      observed <- completed[outcome_observed_specific == 1L]
      if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L ||
          any(!is.finite(observed$total_weight_specific)) ||
          any(observed$total_weight_specific <= 0)) {
        stop(
          cohort_name, "/", outcome_name,
          ": invalid observed weighted sample in imputation ",
          imputation_index,
          call. = FALSE
        )
      }
      observed[, unit_weight := 1]

      weight_distribution_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- observed[, .(
        observed_person_trials = .N,
        raw_weight_minimum = min(total_weight_specific_raw),
        raw_weight_p01 = safe_quantile(total_weight_specific_raw, 0.01),
        raw_weight_median = safe_quantile(total_weight_specific_raw, 0.50),
        raw_weight_p99 = safe_quantile(total_weight_specific_raw, 0.99),
        raw_weight_maximum = max(total_weight_specific_raw),
        truncated_weight_minimum = min(total_weight_specific),
        truncated_weight_median = safe_quantile(total_weight_specific, 0.50),
        truncated_weight_maximum = max(total_weight_specific)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]

      ess_parts[[paste(
        cohort_name, outcome_name, imputation_index, sep = "_"
      )]] <- data.table::rbindlist(list(
        observed[, .(
          treatment = NA_integer_,
          effective_sample_size = effective_sample_size(total_weight_specific)
        )],
        observed[, .(
          effective_sample_size = effective_sample_size(total_weight_specific)
        ), by = treatment]
      ), use.names = TRUE, fill = TRUE)[, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        imputation = imputation_index
      )]

      balance_parts[[paste(
        cohort_name, outcome_name, imputation_index, "unweighted", sep = "_"
      )]] <- calculate_balance(
        observed, "unit_weight", "outcome_observed_unweighted",
        cohort_name, outcome_name, imputation_index
      )
      balance_parts[[paste(
        cohort_name, outcome_name, imputation_index, "weighted", sep = "_"
      )]] <- calculate_balance(
        observed, "total_weight_specific",
        "after_outcome_specific_total_weight",
        cohort_name, outcome_name, imputation_index
      )

      if (imputation_index == 1L) {
        plot_weight_parts[[paste(cohort_name, outcome_name, sep = "_")]] <-
          observed[, .(
            cohort = cohort_name,
            outcome = outcome_name,
            treatment_label = ifelse(
              treatment == 1L, "Discontinue", "Continue"
            ),
            total_weight_specific
          )]
      }

      compact_imputations[[imputation_index]] <- completed[, .(
        analysis_row_id,
        person_id,
        trial_id,
        join_key,
        outcome_value,
        outcome_observed_specific,
        retention_probability_specific,
        numerator_retention_probability_specific,
        censoring_weight_specific,
        total_weight_specific_raw,
        total_weight_specific
      )]
    }

    saveRDS(
      compact_imputations,
      file.path(
        private_dir,
        paste0(
          tolower(cohort_name), "_", outcome_name,
          "_specific_weights_PRIVATE.rds"
        )
      ),
      version = 3L
    )
  }
}

sample_counts <- data.table::rbindlist(
  sample_parts, use.names = TRUE, fill = TRUE
)
sequence_counts <- data.table::rbindlist(
  sequence_sample_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_diagnostic_parts, use.names = TRUE, fill = TRUE
)
retention_diagnostics <- data.table::rbindlist(
  retention_parts, use.names = TRUE, fill = TRUE
)
weight_distribution <- data.table::rbindlist(
  weight_distribution_parts, use.names = TRUE, fill = TRUE
)
effective_sample_sizes <- data.table::rbindlist(
  ess_parts, use.names = TRUE, fill = TRUE
)
balance <- data.table::rbindlist(
  balance_parts, use.names = TRUE, fill = TRUE
)
plot_weights <- data.table::rbindlist(
  plot_weight_parts, use.names = TRUE, fill = TRUE
)

balance_summary <- balance[, .(
  mean_standardized_difference = mean(
    standardized_difference, na.rm = TRUE
  ),
  mean_absolute_standardized_difference = mean(
    absolute_standardized_difference, na.rm = TRUE
  ),
  maximum_absolute_standardized_difference_across_imputations = max(
    absolute_standardized_difference, na.rm = TRUE
  )
), by = .(cohort, outcome, balance_sample, variable, level)]

event_gate <- sample_counts[, .(
  both_arms_present = data.table::uniqueN(treatment) == 2L,
  smaller_arm_observed_person_trials = min(observed_person_trials),
  smaller_arm_events = min(events),
  total_events = sum(events)
), by = .(cohort, outcome)]
balance_gate <- balance[
  balance_sample == "after_outcome_specific_total_weight",
  .(
    maximum_absolute_smd = max(
      absolute_standardized_difference, na.rm = TRUE
    )
  ),
  by = .(cohort, outcome)
]
ess_gate <- effective_sample_sizes[
  !is.na(treatment),
  .(minimum_arm_effective_sample_size = min(effective_sample_size)),
  by = .(cohort, outcome)
]
model_gate <- model_diagnostics[, .(
  all_models_converged = all(converged),
  total_model_warnings = sum(warning_n),
  maximum_aliased_coefficients = max(aliased_coefficient_n),
  any_separation_or_convergence_warning = any(
    separation_or_convergence_warning
  )
), by = .(cohort, outcome)]
retention_gate <- retention_diagnostics[, .(
  minimum_retention_probability = min(minimum_retention_probability),
  maximum_fraction_retention_below_0_05 = max(
    fraction_retention_probability_below_0_05
  ),
  any_retention_probability_below_0_01 = any(
    any_retention_probability_below_0_01
  )
), by = .(cohort, outcome)]

gate <- Reduce(
  function(left, right) merge(
    left, right, by = c("cohort", "outcome"), all = TRUE, sort = FALSE
  ),
  list(event_gate, balance_gate, ess_gate, model_gate, retention_gate)
)
support_gate <- stage05_rows[, .(
  cohort,
  primary_treatment_common_support_fraction = suppressWarnings(
    as.numeric(minimum_common_support_fraction)
  )
)]
gate <- merge(gate, support_gate, by = "cohort", all.x = TRUE, sort = FALSE)
gate[, pass_smaller_arm_n :=
  smaller_arm_observed_person_trials >=
    as.numeric(analysis_config$data_gates$minimum_smaller_arm_person_trials)]
gate[, pass_smaller_arm_events :=
  smaller_arm_events >=
    as.numeric(analysis_config$data_gates$minimum_smaller_arm_primary_events)]
gate[, pass_total_events :=
  total_events >=
    as.numeric(analysis_config$data_gates$minimum_total_primary_events)]
gate[, pass_balance :=
  maximum_absolute_smd <
    as.numeric(analysis_config$data_gates$maximum_absolute_standardized_difference)]
gate[, pass_effective_sample_size :=
  minimum_arm_effective_sample_size >=
    as.numeric(analysis_config$data_gates$minimum_weighted_effective_sample_size)]
gate[, pass_common_support :=
  primary_treatment_common_support_fraction >=
    as.numeric(analysis_config$data_gates$minimum_common_support_fraction)]
gate[, pass_model_identifiability :=
  all_models_converged & total_model_warnings == 0L &
    maximum_aliased_coefficients == 0L &
    !any_separation_or_convergence_warning]
gate[, pass_retention_positivity :=
  maximum_fraction_retention_below_0_05 <= maximum_low_retention_fraction &
    !any_retention_probability_below_0_01]
gate[, ready_for_secondary_effect_estimation :=
  both_arms_present & pass_smaller_arm_n & pass_smaller_arm_events &
    pass_total_events & pass_balance & pass_effective_sample_size &
    pass_common_support &
    pass_model_identifiability & pass_retention_positivity]

data.table::setorder(sample_counts, cohort, outcome, treatment)
data.table::setorder(sequence_counts, cohort, sequence, outcome, treatment)
data.table::setorder(model_diagnostics, cohort, outcome, imputation, model)
data.table::setorder(retention_diagnostics, cohort, outcome, imputation)
data.table::setorder(weight_distribution, cohort, outcome, imputation, treatment)
data.table::setorder(effective_sample_sizes, cohort, outcome, imputation, treatment)
data.table::setorder(balance, cohort, outcome, balance_sample, variable, level, imputation)
data.table::setorder(balance_summary, cohort, outcome, balance_sample, variable, level)
data.table::setorder(gate, cohort, outcome)

tte_write_csv(sample_counts, file.path(output_dir, "07b_analysis_sample.csv"))
tte_write_csv(
  sequence_counts,
  file.path(output_dir, "07b_sequence_arm_event_counts.csv")
)
tte_write_csv(
  model_diagnostics,
  file.path(output_dir, "07b_censoring_model_diagnostics.csv")
)
tte_write_csv(
  retention_diagnostics,
  file.path(output_dir, "07b_retention_diagnostics.csv")
)
tte_write_csv(
  weight_distribution,
  file.path(output_dir, "07b_weight_distribution.csv")
)
tte_write_csv(
  effective_sample_sizes,
  file.path(output_dir, "07b_effective_sample_size.csv")
)
tte_write_csv(
  balance,
  file.path(output_dir, "07b_balance_all_imputations.csv")
)
tte_write_csv(
  balance_summary,
  file.path(output_dir, "07b_balance_summary.csv")
)
tte_write_csv(gate, file.path(output_dir, "07b_weighting_gate.csv"))
writeLines(
  readLines(secondary_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07b_frozen_outcome_weight_model.yml"),
  useBytes = TRUE
)

balance_plot_data <- balance_summary[
  is.finite(maximum_absolute_standardized_difference_across_imputations)
]
balance_plot_data[, display_variable := ifelse(
  is.na(level) | level == "",
  variable,
  paste0(variable, "=", level)
)]
balance_plot_data[, balance_sample := factor(
  balance_sample,
  levels = c(
    "outcome_observed_unweighted",
    "after_outcome_specific_total_weight"
  ),
  labels = c("Unweighted observed", "Outcome-specific weighted")
)]
balance_plot <- ggplot2::ggplot(
  balance_plot_data,
  ggplot2::aes(
    x = maximum_absolute_standardized_difference_across_imputations,
    y = stats::reorder(display_variable,
                       maximum_absolute_standardized_difference_across_imputations),
    colour = balance_sample,
    shape = balance_sample
  )
) +
  ggplot2::geom_vline(xintercept = 0.10, linetype = 2, colour = "#B2182B") +
  ggplot2::geom_point(size = 1.7, alpha = 0.85) +
  ggplot2::facet_grid(cohort ~ outcome, scales = "free_y") +
  ggplot2::labs(
    x = "Maximum absolute standardized difference across imputations",
    y = NULL,
    colour = NULL,
    shape = NULL,
    title = "Balance for outcome-specific weighted samples"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(
    legend.position = "bottom",
    axis.text.y = ggplot2::element_text(size = 6.5)
  )

weight_plot <- ggplot2::ggplot(
  plot_weights,
  ggplot2::aes(
    x = treatment_label,
    y = total_weight_specific,
    fill = treatment_label
  )
) +
  ggplot2::geom_boxplot(outlier.shape = NA, width = 0.65) +
  ggplot2::scale_y_log10() +
  ggplot2::facet_grid(cohort ~ outcome, scales = "free_y") +
  ggplot2::scale_fill_manual(values = c(
    "Continue" = "#2463A8", "Discontinue" = "#C44E52"
  )) +
  ggplot2::labs(
    x = NULL,
    y = "Truncated total weight (log scale)",
    fill = NULL,
    title = "Outcome-specific weight distributions",
    subtitle = "First imputed dataset; displayed without row identifiers"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

ggplot2::ggsave(
  file.path(output_dir, "07b_balance_plot.png"),
  balance_plot, width = 12, height = 11, dpi = 220, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "07b_balance_plot.pdf"),
  balance_plot, width = 12, height = 11, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "07b_weight_distribution.png"),
  weight_plot, width = 10, height = 6.5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07b_weight_distribution.pdf"),
  weight_plot, width = 10, height = 6.5
)

gate_lines <- apply(gate, 1L, function(row) {
  paste0(
    row[["cohort"]], "/", row[["outcome"]],
    ": max |SMD|=", sprintf("%.3f", as.numeric(row[["maximum_absolute_smd"]])),
    ", min arm ESS=", sprintf(
      "%.1f", as.numeric(row[["minimum_arm_effective_sample_size"]])
    ),
    ", smaller-arm events=", row[["smaller_arm_events"]],
    ", total events=", row[["total_events"]],
    ", ready=", row[["ready_for_secondary_effect_estimation"]]
  )
})
summary_lines <- c(
  "Stage 07b: outcome-specific censoring-weight diagnostics",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Outcomes: strict MI/stroke/death and all-cause death.",
  "Twenty Stage 05 imputed covariate datasets were reused without new imputation.",
  "Treatment and normalized survey weights were reused.",
  "Censoring models and combined weights were rebuilt separately for every outcome.",
  "Combined weights were truncated at the 1st and 99th percentiles.",
  "No treatment effect was estimated in this stage.",
  "",
  gate_lines,
  "",
  "Proceed to secondary effect estimation only for cohort-outcome pairs with ready=TRUE."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07b_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07b_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message("Stage 07b completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
