# Run from the project root. Recompute one display row from the frozen imputations.
suppressPackageStartupMessages(library(data.table))

load_summary_functions <- function() {
  summary_env <- new.env()
  required <- c("weighted_mean_safe", "weighted_sd_safe", "standardized_difference")
  for (expr in parse("R/12_generate_jaha_tables_figures_results.R")) {
    if (is.call(expr) && identical(expr[[1L]], quote(`<-`)) &&
        is.symbol(expr[[2L]]) && as.character(expr[[2L]]) %in% required) {
      eval(expr, envir = summary_env)
    }
  }
  stopifnot(all(required %in% ls(summary_env)))
  summary_env
}

summarize_imputation <- function(completed, summary_functions) {
  treatment <- as.integer(as.character(completed$treatment))
  health <- as.integer(as.character(completed$B_self_rated_health))
  weight <- as.numeric(completed$treatment_analysis_weight)
  stopifnot(all(treatment %in% 0:1), all(health %in% 1:5),
            all(is.finite(weight) & weight > 0))

  # Lower cleaned codes denote worse health. The previous row used levels 4 and 5.
  indicators <- list(original = as.numeric(health >= 4L), corrected = as.numeric(health <= 2L))
  rbindlist(lapply(indicators, function(indicator) {
    smd <- function(w) {
      continue <- treatment == 0L
      abs(summary_functions$standardized_difference(
        indicator[continue], w[continue], indicator[!continue], w[!continue]
      ))
    }
    data.table(continue = mean(indicator[treatment == 0L]),
               discontinue = mean(indicator[treatment == 1L]),
               before = smd(rep(1, length(indicator))), after = smd(weight))
  }), idcol = "version")
}

summarize_cohort <- function(cohort_name, summary_functions) {
  source <- file.path("outputs_r/stage05_weighting/private_do_not_share",
                      paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds"))
  imputations <- readRDS(source)
  stopifnot(length(imputations) == 20L)
  values <- rbindlist(lapply(imputations, summarize_imputation,
                             summary_functions = summary_functions))
  stopifnot(all(is.finite(values$before)), all(is.finite(values$after)))
  values[, .(Cohort = cohort_name,
             Continue = sprintf("%.1f", 100 * mean(continue)),
             Discontinue = sprintf("%.1f", 100 * mean(discontinue)),
             `SMD before` = sprintf("%.3f", mean(before)),
             `SMD after` = sprintf("%.3f", mean(after))), by = version]
}

table1 <- fread("outputs_r/jaha_publication/tables/Table1_baseline_characteristics.csv",
                colClasses = "character")
characteristic <- "Fair or poor self-rated health"
display_columns <- c("Continue", "Discontinue", "SMD before", "SMD after")
original <- copy(table1)
summary_functions <- load_summary_functions()
audit <- rbindlist(lapply(c("HRS", "SHARE"), summarize_cohort,
                         summary_functions = summary_functions))
for (cohort_name in c("HRS", "SHARE")) {
  position <- which(table1$Cohort == cohort_name & table1$Characteristic == characteristic)
  stopifnot(length(position) == 1L,
            identical(as.list(table1[position, ..display_columns]),
                      as.list(audit[Cohort == cohort_name & version == "original", ..display_columns])))
  replacement <- audit[Cohort == cohort_name & version == "corrected", ..display_columns]
  table1[position, (display_columns) := as.list(replacement)]
}
stopifnot(identical(original[Characteristic != characteristic], table1[Characteristic != characteristic]))
destination <- "outputs_r/revision_r1"
fwrite(table1, file.path(destination, "Table1_baseline_characteristics.csv"))
fwrite(audit, file.path(destination, "R1_self_rated_health_table1_audit.csv"))
print(audit)
