# Stage 07k: HRS-only weighting audit for all-cause death or a reported fall.
# SHARE is excluded because its harmonized item measures being bothered by falls,
# not fall occurrence. No treatment effect is estimated in this stage.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_stage07e_helpers.R"), encoding = "UTF-8", local = TRUE)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically.", call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
primary_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "primary_weight_model.yml"))
functional_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "functional_outcome_weight_model.yml")
)
output_root <- file.path(project_root, analysis_config$output_root)
stage01b_path <- file.path(
  output_root, "stage01b", "private_do_not_share", "hrs_selected_longitudinal.rds"
)
stage04_path <- file.path(
  output_root, "stage04_structural_followup", "private_do_not_share",
  "hrs_structural_validated_trials_PRIVATE.rds"
)
stage05_path <- file.path(
  output_root, "stage05_weighting", "private_do_not_share",
  "hrs_weighted_imputations_PRIVATE.rds"
)
stage05_gate_path <- file.path(output_root, "stage05_weighting", "05_weighting_gate.csv")
output_dir <- file.path(output_root, "stage07k_hrs_fall_weights")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

for (path in c(stage01b_path, stage04_path, stage05_path, stage05_gate_path)) {
  if (!file.exists(path)) stop("Missing Stage 07k input: ", path, call. = FALSE)
}

as_true <- function(x) tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
stage05_gate <- data.table::as.data.table(tte_read_csv_utf8(stage05_gate_path))
ready_column <- intersect(c("ready_for_effect_estimation", "all_gates_pass"), names(stage05_gate))
if (length(ready_column) != 1L ||
    nrow(stage05_gate[cohort == "HRS"]) != 1L ||
    !as_true(stage05_gate[cohort == "HRS"][[ready_column]])) {
  stop("HRS must pass Stage 05 before Stage 07k.", call. = FALSE)
}

continuous_covariates <- unlist(primary_config$continuous_covariates, use.names = FALSE)
categorical_covariates <- unlist(primary_config$categorical_covariates, use.names = FALSE)
primary_covariates <- c(continuous_covariates, categorical_covariates)
spline_covariates <- unlist(primary_config$spline_covariates, use.names = FALSE)
fixed_candidates <- unlist(primary_config$always_adjust$HRS, use.names = FALSE)
probability_floor <- as.numeric(functional_config$probability_floor)
lower_quantile <- as.numeric(functional_config$weight_lower_quantile)
upper_quantile <- as.numeric(functional_config$weight_upper_quantile)
minimum_retention_probability <- as.numeric(
  functional_config$minimum_acceptable_retention_probability
)
maximum_low_retention_fraction <- as.numeric(
  functional_config$maximum_fraction_retention_below_0_05
)
outcome_name <- "death_or_reported_fall"
outcome_label <- "All-cause death or a reported fall"

# Recover the HRS fall item from the frozen cleaned longitudinal source.
clean <- data.table::as.data.table(readRDS(stage01b_path))
required_clean <- c("hhidpn", "wave", "fall")
if (length(setdiff(required_clean, names(clean)))) {
  stop("The frozen HRS longitudinal source lacks the fall item.", call. = FALSE)
}
fall_long <- data.table::data.table(
  person_id = as.character(clean[["hhidpn"]]),
  wave_id = suppressWarnings(as.integer(clean[["wave"]])),
  fall_value = suppressWarnings(as.integer(clean[["fall"]]))
)
if (any(!is.na(fall_long$fall_value) & !fall_long$fall_value %in% c(0L, 1L))) {
  stop("HRS fall contains values outside 0/1/NA.", call. = FALSE)
}
if (anyDuplicated(fall_long[, .(person_id, wave_id)])) {
  stop("HRS cleaned fall source has duplicate person-wave keys.", call. = FALSE)
}

source_trials <- data.table::as.data.table(readRDS(stage04_path))
source_trials <- source_trials[
  is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
    suppressWarnings(as.numeric(L_survey_weight_final)) > 0
]
required_source <- c(
  "person_id", "trial_id", "sequence", "treatment", "L_wave", "F_wave",
  "F_interview_observed", "death_in_interval", "followup_time_years"
)
missing_source <- setdiff(required_source, names(source_trials))
if (length(missing_source)) {
  stop("HRS source trials lack: ", paste(missing_source, collapse = ", "), call. = FALSE)
}
source_trials[, person_id := as.character(person_id)]

landmark_fall <- data.table::copy(fall_long)
data.table::setnames(landmark_fall, c("wave_id", "fall_value"), c("L_wave", "L_fall"))
followup_fall <- data.table::copy(fall_long)
data.table::setnames(followup_fall, c("wave_id", "fall_value"), c("F_wave", "F_fall"))
source_trials <- merge(
  source_trials, landmark_fall, by = c("person_id", "L_wave"), all.x = TRUE, sort = FALSE
)
source_trials <- merge(
  source_trials, followup_fall, by = c("person_id", "F_wave"), all.x = TRUE, sort = FALSE
)
source_trials[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
source_trials[, death_in_interval := suppressWarnings(as.integer(death_in_interval))]
source_trials[, B_fall_history := factor(
  data.table::fcase(
    L_fall == 1L, "yes",
    L_fall == 0L, "no",
    default = "missing"
  ),
  levels = c("no", "yes", "missing")
)]
source_trials[, outcome_value := data.table::fcase(
  death_in_interval == 1L, 1L,
  death_in_interval == 0L & !is.na(F_fall), as.integer(F_fall == 1L),
  default = NA_integer_
)]
source_trials[, outcome_observed_specific := as.integer(!is.na(outcome_value))]
source_trials[, join_key := paste(person_id, as.character(trial_id), sep = "\r")]
if (anyDuplicated(source_trials$join_key)) {
  stop("Duplicate HRS person-trial keys after fall linkage.", call. = FALSE)
}

logic_checks <- data.table::data.table(
  check = c(
    "binary_fall_source", "all_interval_deaths_are_composite_events",
    "survivor_outcome_requires_observed_fall", "SHARE_fall_not_combined"
  ),
  failed_rows = c(
    sum(!is.na(source_trials$F_fall) & !source_trials$F_fall %in% c(0L, 1L)),
    sum(source_trials$death_in_interval == 1L & source_trials$outcome_value != 1L, na.rm = TRUE),
    sum(source_trials$death_in_interval == 0L & is.na(source_trials$F_fall) &
          !is.na(source_trials$outcome_value)),
    0L
  )
)
if (any(logic_checks$failed_rows > 0L)) {
  stop("Stage 07k outcome logic check failed.", call. = FALSE)
}

sample_counts <- source_trials[, .(
  eligible_person_trials = .N,
  unique_persons = data.table::uniqueN(person_id),
  landmark_fall_observed_n = sum(!is.na(L_fall)),
  landmark_fall_prevalence = mean(L_fall == 1L, na.rm = TRUE),
  followup_fall_observed_n = sum(!is.na(F_fall)),
  followup_fall_events = sum(F_fall == 1L, na.rm = TRUE),
  composite_observed_n = sum(outcome_observed_specific == 1L),
  composite_observation_fraction = mean(outcome_observed_specific == 1L),
  composite_events = sum(outcome_value == 1L, na.rm = TRUE),
  deaths = sum(death_in_interval == 1L, na.rm = TRUE)
), by = treatment]
sample_counts[, `:=`(
  cohort = "HRS", outcome = outcome_name,
  treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
)]

imputations <- readRDS(stage05_path)
if (!is.list(imputations) || length(imputations) != 20L) {
  stop("Stage 05 HRS input must contain 20 completed datasets.", call. = FALSE)
}

variable_manifest <- data.table::rbindlist(list(
  data.table::data.table(
    variable_group = "primary_covariate",
    variable = primary_covariates,
    variable_type = ifelse(
      primary_covariates %in% categorical_covariates, "categorical", "continuous"
    )
  ),
  data.table::data.table(
    variable_group = "fall_history",
    variable = "B_fall_history",
    variable_type = "categorical"
  )
))

compact_imputations <- vector("list", length(imputations))
join_parts <- list()
model_parts <- list()
retention_parts <- list()
weight_parts <- list()
ess_parts <- list()
balance_parts <- list()

for (imputation_index in seq_along(imputations)) {
  completed <- data.table::as.data.table(data.table::copy(imputations[[imputation_index]]))
  completed[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  index <- match(completed$join_key, source_trials$join_key)
  exact_identity <- !anyNA(index) && nrow(completed) == nrow(source_trials) &&
    !anyDuplicated(completed$join_key) &&
    all(suppressWarnings(as.integer(as.character(completed$treatment))) ==
          source_trials$treatment[index])
  join_parts[[imputation_index]] <- data.table::data.table(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index,
    stage05_rows = nrow(completed), matched_source_rows = sum(!is.na(index)),
    exact_person_trial_treatment_identity = exact_identity
  )
  if (!exact_identity) stop("Stage 04f-to-Stage 05 fall join failed.", call. = FALSE)

  completed[, outcome_value := source_trials$outcome_value[index]]
  completed[, outcome_observed_specific := source_trials$outcome_observed_specific[index]]
  completed[, B_fall_history := source_trials$B_fall_history[index]]
  completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
  for (variable_name in continuous_covariates) {
    data.table::set(completed, j = variable_name, value = plain_numeric(completed[[variable_name]]))
  }
  for (variable_name in categorical_covariates) {
    data.table::set(completed, j = variable_name, value = droplevels(factor(completed[[variable_name]])))
  }
  completed[, B_fall_history := droplevels(factor(B_fall_history))]
  completed[, sequence := droplevels(factor(sequence))]

  required_completed <- c(
    "analysis_row_id", "person_id", "trial_id", "treatment", "sequence",
    "survey_weight_scaled", "treatment_weight", primary_covariates,
    "B_fall_history"
  )
  missing_completed <- setdiff(required_completed, names(completed))
  if (length(missing_completed)) {
    stop("Stage 05 HRS input lacks: ", paste(missing_completed, collapse = ", "), call. = FALSE)
  }
  if (any(vapply(primary_covariates, function(v) anyNA(completed[[v]]), logical(1L)))) {
    stop("Stage 05 HRS input retains missing imputed covariates.", call. = FALSE)
  }

  usable_primary <- usable_model_variables(completed, primary_covariates)
  usable_fixed <- usable_model_variables(completed, fixed_candidates)
  full_terms <- c(
    vapply(usable_primary, model_term_07e, character(1L), spline_covariates = spline_covariates),
    "B_fall_history", usable_fixed
  )
  denominator_formula <- make_formula_07e(
    "outcome_observed_specific", c("treatment", full_terms)
  )
  numerator_formula <- make_formula_07e(
    "outcome_observed_specific", c("treatment", usable_fixed)
  )
  denominator_fit <- fit_binary_model_07e(
    denominator_formula, completed, "censoring", "censoring_denominator",
    "HRS", "unrestricted_fall", outcome_name, imputation_index
  )
  numerator_fit <- fit_binary_model_07e(
    numerator_formula, completed, "censoring", "censoring_numerator",
    "HRS", "unrestricted_fall", outcome_name, imputation_index
  )
  model_parts[[imputation_index]] <- data.table::rbindlist(
    list(denominator_fit$diagnostics, numerator_fit$diagnostics), fill = TRUE
  )

  completed[, retention_probability_specific := clamp_probability(
    stats::predict(denominator_fit$fit, newdata = completed, type = "response"),
    probability_floor
  )]
  completed[, numerator_retention_probability_specific := clamp_probability(
    stats::predict(numerator_fit$fit, newdata = completed, type = "response"),
    probability_floor
  )]
  completed[, censoring_weight_specific := ifelse(
    outcome_observed_specific == 1L,
    numerator_retention_probability_specific / retention_probability_specific,
    NA_real_
  )]
  completed[, total_weight_specific_raw := ifelse(
    outcome_observed_specific == 1L,
    survey_weight_scaled * treatment_weight * censoring_weight_specific,
    NA_real_
  )]
  lower <- safe_quantile(completed$total_weight_specific_raw, lower_quantile)
  upper <- safe_quantile(completed$total_weight_specific_raw, upper_quantile)
  if (!is.finite(lower) || !is.finite(upper) || lower <= 0 || upper < lower) {
    stop("Invalid HRS fall weight truncation bounds.", call. = FALSE)
  }
  completed[, total_weight_specific := ifelse(
    outcome_observed_specific == 1L,
    pmax(lower, pmin(upper, total_weight_specific_raw)),
    NA_real_
  )]

  retention_parts[[imputation_index]] <- data.table::data.table(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index,
    minimum_retention_probability = min(completed$retention_probability_specific),
    maximum_retention_probability = max(completed$retention_probability_specific),
    fraction_retention_probability_below_0_05 = mean(
      completed$retention_probability_specific < 0.05
    ),
    any_retention_probability_below_0_01 = any(
      completed$retention_probability_specific < minimum_retention_probability
    )
  )
  observed <- completed[
    outcome_observed_specific == 1L & is.finite(total_weight_specific) &
      total_weight_specific > 0
  ]
  observed[, unit_weight := 1]
  weight_parts[[imputation_index]] <- observed[, .(
    observed_person_trials = .N,
    raw_weight_minimum = min(total_weight_specific_raw),
    raw_weight_median = safe_quantile(total_weight_specific_raw, 0.50),
    raw_weight_maximum = max(total_weight_specific_raw),
    truncated_weight_minimum = min(total_weight_specific),
    truncated_weight_median = safe_quantile(total_weight_specific, 0.50),
    truncated_weight_maximum = max(total_weight_specific)
  ), by = treatment][, `:=`(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index
  )]
  ess_parts[[imputation_index]] <- observed[, .(
    effective_sample_size = effective_sample_size(total_weight_specific)
  ), by = treatment][, `:=`(
    cohort = "HRS", outcome = outcome_name, imputation = imputation_index
  )]
  balance_parts[[paste0(imputation_index, "_u")]] <- calculate_balance_07e(
    observed, "unit_weight", "outcome_observed_unweighted", "HRS",
    "unrestricted_fall", outcome_name, imputation_index, variable_manifest
  )
  balance_parts[[paste0(imputation_index, "_w")]] <- calculate_balance_07e(
    observed, "total_weight_specific", "after_fall_total_weight", "HRS",
    "unrestricted_fall", outcome_name, imputation_index, variable_manifest
  )
  compact_imputations[[imputation_index]] <- completed[, .(
    analysis_row_id, person_id, trial_id, join_key, treatment,
    sequence = as.character(sequence), B_fall_history = as.character(B_fall_history),
    outcome_value, outcome_observed_specific,
    retention_probability_specific, numerator_retention_probability_specific,
    censoring_weight_specific, total_weight_specific_raw, total_weight_specific
  )]
}

model_diagnostics <- data.table::rbindlist(model_parts, fill = TRUE)
retention <- data.table::rbindlist(retention_parts, fill = TRUE)
weight_distribution <- data.table::rbindlist(weight_parts, fill = TRUE)
ess <- data.table::rbindlist(ess_parts, fill = TRUE)
balance <- data.table::rbindlist(balance_parts, fill = TRUE)
join_checks <- data.table::rbindlist(join_parts, fill = TRUE)

balance_summary <- balance[, .(
  imputations = data.table::uniqueN(imputation),
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE),
  mean_standardized_difference = mean(standardized_difference, na.rm = TRUE)
), by = .(cohort, outcome, balance_sample, variable_group, variable, level)]

event_gate <- sample_counts[, .(
  both_arms_present = data.table::uniqueN(treatment) == 2L,
  smaller_arm_observed_person_trials = min(composite_observed_n),
  smaller_arm_events = min(composite_events),
  total_events = sum(composite_events)
), by = .(cohort, outcome)]
balance_gate <- balance[balance_sample == "after_fall_total_weight", .(
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE)
), by = .(cohort, outcome)]
ess_gate <- ess[, .(
  minimum_arm_effective_sample_size = min(effective_sample_size)
), by = .(cohort, outcome)]
model_gate <- model_diagnostics[, .(
  all_models_converged = all(converged),
  total_model_warnings = sum(warning_n),
  maximum_aliased_coefficients = max(aliased_coefficient_n),
  any_separation_or_convergence_warning = any(separation_or_convergence_warning)
), by = .(cohort, outcome)]
retention_gate <- retention[, .(
  minimum_retention_probability = min(minimum_retention_probability),
  maximum_fraction_retention_below_0_05 = max(fraction_retention_probability_below_0_05),
  any_retention_probability_below_0_01 = any(any_retention_probability_below_0_01)
), by = .(cohort, outcome)]
gate <- Reduce(
  function(left, right) merge(left, right, by = c("cohort", "outcome"), all = TRUE),
  list(event_gate, balance_gate, ess_gate, model_gate, retention_gate)
)
gate[, common_support_fraction := as.numeric(
  stage05_gate[cohort == "HRS", minimum_common_support_fraction]
)]
gate[, pass_smaller_arm_n := smaller_arm_observed_person_trials >=
  as.numeric(analysis_config$data_gates$minimum_smaller_arm_person_trials)]
gate[, pass_smaller_arm_events := smaller_arm_events >=
  as.numeric(analysis_config$data_gates$minimum_smaller_arm_primary_events)]
gate[, pass_total_events := total_events >=
  as.numeric(analysis_config$data_gates$minimum_total_primary_events)]
gate[, pass_balance := maximum_absolute_smd <
  as.numeric(analysis_config$data_gates$maximum_absolute_standardized_difference)]
gate[, pass_effective_sample_size := minimum_arm_effective_sample_size >=
  as.numeric(analysis_config$data_gates$minimum_weighted_effective_sample_size)]
gate[, pass_common_support := common_support_fraction >=
  as.numeric(analysis_config$data_gates$minimum_common_support_fraction)]
gate[, pass_model_identifiability := all_models_converged &
  total_model_warnings == 0L & maximum_aliased_coefficients == 0L &
  !any_separation_or_convergence_warning]
gate[, pass_retention_positivity :=
  maximum_fraction_retention_below_0_05 <= maximum_low_retention_fraction &
    !any_retention_probability_below_0_01]
gate[, ready_for_fall_effect_estimation :=
  both_arms_present & pass_smaller_arm_n & pass_smaller_arm_events &
    pass_total_events & pass_balance & pass_effective_sample_size &
    pass_common_support & pass_model_identifiability & pass_retention_positivity]

saveRDS(
  compact_imputations,
  file.path(private_dir, "hrs_fall_weights_PRIVATE.rds"), version = 3L
)
tte_write_csv(sample_counts, file.path(output_dir, "07k_analysis_sample.csv"))
tte_write_csv(logic_checks, file.path(output_dir, "07k_outcome_logic_checks.csv"))
tte_write_csv(join_checks, file.path(output_dir, "07k_join_checks.csv"))
tte_write_csv(model_diagnostics, file.path(output_dir, "07k_censoring_model_diagnostics.csv"))
tte_write_csv(retention, file.path(output_dir, "07k_retention_diagnostics.csv"))
tte_write_csv(weight_distribution, file.path(output_dir, "07k_weight_distribution.csv"))
tte_write_csv(ess, file.path(output_dir, "07k_effective_sample_size.csv"))
tte_write_csv(balance, file.path(output_dir, "07k_balance_by_imputation.csv"))
tte_write_csv(balance_summary, file.path(output_dir, "07k_balance_summary.csv"))
tte_write_csv(gate, file.path(output_dir, "07k_weighting_gate.csv"))

fall_history_balance <- balance_summary[
  variable == "B_fall_history" & balance_sample == "after_fall_total_weight"
]
summary_lines <- c(
  "Stage 07k: HRS death-or-reported-fall weighting diagnostics",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "SHARE was excluded because its item is not a fall-occurrence measure.",
  sprintf(
    "HRS: composite observed=%d; events=%d; smaller-arm events=%d.",
    sum(sample_counts$composite_observed_n), sum(sample_counts$composite_events),
    min(sample_counts$composite_events)
  ),
  sprintf(
    "Weighting: max |SMD|=%.3f; min arm ESS=%.1f; ready=%s.",
    gate$maximum_absolute_smd, gate$minimum_arm_effective_sample_size,
    ifelse(gate$ready_for_fall_effect_estimation, "TRUE", "FALSE")
  ),
  sprintf(
    "Prior-fall balance after weighting: max |SMD|=%.3f.",
    max(fall_history_balance$maximum_absolute_smd, na.rm = TRUE)
  ),
  "The estimable outcome is death or a reported fall, not fall alone, because falls before death are not dated.",
  "No treatment effect was estimated in this stage."
)
writeLines(summary_lines, file.path(output_dir, "07k_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(utils::sessionInfo()), file.path(output_dir, "07k_session_info.txt"), useBytes = TRUE)
cat(paste(summary_lines, collapse = "\n"), "\n")

