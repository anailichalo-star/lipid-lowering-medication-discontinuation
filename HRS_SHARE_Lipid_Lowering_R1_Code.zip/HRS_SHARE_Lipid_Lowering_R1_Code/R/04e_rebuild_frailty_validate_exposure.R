# Stage 04e: rebuild a 30-deficit frailty index in R and validate medication
# exposure against the Gateway harmonized source. No causal model is fitted.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "data.table", "haven", "tidyselect"))

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
sources <- tte_read_csv_utf8(file.path(project_root, "config_r", "cohort_sources.csv"))
aux_map <- tte_read_csv_utf8(file.path(project_root, "config_r", "harmonized_aux_mapping.csv"))
data_root <- tte_normalize_path(config$data_root, must_work = TRUE)
stage04_dir <- file.path(project_root, config$output_root, "stage04_model_prep")
stage04_private <- file.path(stage04_dir, "private_do_not_share")
output_dir <- file.path(project_root, config$output_root, "stage04_fi_exposure_validation")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")

hrs_id <- function(x) {
  out <- if (is.numeric(x)) format(x, scientific = FALSE, trim = TRUE) else trimws(as.character(x))
  out <- sub("[.]0+$", "", out)
  out <- gsub("[^0-9]", "", out)
  out <- sub("^0+", "", out)
  out[out == ""] <- "0"
  out[is.na(x)] <- NA_character_
  out
}

share_id <- function(x) {
  out <- toupper(trimws(as.character(x)))
  out[is.na(x) | !nzchar(out)] <- NA_character_
  out
}

normalize_id <- function(x, cohort_name) {
  if (identical(cohort_name, "HRS")) hrs_id(x) else share_id(x)
}

plain_numeric <- function(x) suppressWarnings(as.numeric(haven::zap_labels(x)))

binary_deficit <- function(x) {
  value <- suppressWarnings(as.numeric(x))
  ifelse(value %in% c(0, 1), value, NA_real_)
}

ordinal_health_deficit <- function(x) {
  value <- suppressWarnings(as.numeric(x))
  result <- rep(NA_real_, length(value))
  result[value %in% c(0, 1)] <- 1
  result[value == 2] <- 0.75
  result[value == 3] <- 0.50
  result[value == 4] <- 0.25
  result[value == 5] <- 0
  result
}

strict_any_binary <- function(...) {
  values <- cbind(...)
  storage.mode(values) <- "numeric"
  result <- rep(NA_real_, nrow(values))
  result[rowSums(values == 1, na.rm = TRUE) > 0] <- 1
  fully_observed <- rowSums(!is.na(values)) == ncol(values)
  result[fully_observed & rowSums(values == 1, na.rm = TRUE) == 0] <- 0
  result
}

valid_range <- function(x, minimum, maximum) {
  value <- suppressWarnings(as.numeric(x))
  value[!is.finite(value) | value < minimum | value > maximum] <- NA_real_
  value
}

safe_quantile <- function(x, probability) {
  value <- suppressWarnings(as.numeric(x))
  value <- value[is.finite(value)]
  if (!length(value)) return(NA_real_)
  as.numeric(stats::quantile(value, probability, names = FALSE, type = 2L))
}

read_clean_components <- function(cohort_name) {
  source_row <- sources[sources$cohort == cohort_name, , drop = FALSE]
  if (nrow(source_row) != 1L) stop("Missing cohort source row for ", cohort_name, call. = FALSE)
  ascii_link <- file.path(
    project_root, "data_links", "clean_components",
    paste0(tolower(cohort_name), ".csv")
  )
  path <- if (file.exists(ascii_link)) ascii_link else file.path(data_root, source_row$clean_file)
  if (!file.exists(path)) stop("Missing cleaned longitudinal source: ", path, call. = FALSE)

  id_name <- if (cohort_name == "HRS") "hhidpn" else "mergeid"
  requested <- unique(c(
    id_name, "wave", "rxhchol",
    "hibpe", "diabe", "hearte", "stroke", "cancre", "arthre", "lunge", "psyche",
    "memrye", "alzhee", "demene", "alzdeme",
    "sight", "nsight", "hearing", "hearaid", "shlt",
    "dressa", "batha", "eata", "beda", "toilta",
    "moneya", "medsa", "shopa", "mealsa",
    "walk1a", "walk100a", "chaira", "climsa", "lifta", "dimea", "stoopa", "armsa",
    "depressive", "cesd", "eurod", "tr20", "mo", "dy", "yr", "dw", "ser7"
  ))

  header <- data.table::fread(
    path, nrows = 0L, check.names = FALSE, encoding = "UTF-8", showProgress = FALSE
  )
  raw_names <- names(header)
  canonical_names <- tte_clean_variable_name(raw_names)
  if (!id_name %in% canonical_names || !"wave" %in% canonical_names) {
    stop(cohort_name, " cleaned source lacks its ID or wave variable.", call. = FALSE)
  }
  selected_positions <- which(tolower(canonical_names) %in% tolower(requested))
  selected <- data.table::fread(
    path, select = selected_positions, check.names = FALSE,
    encoding = "UTF-8", showProgress = interactive()
  )
  data.table::setnames(selected, names(selected), canonical_names[selected_positions])
  for (variable_name in setdiff(requested, names(selected))) {
    data.table::set(selected, j = variable_name, value = NA_real_)
  }
  selected[, person_id := normalize_id(get(id_name), cohort_name)]
  selected[, wave := suppressWarnings(as.integer(wave))]
  selected[, cohort := cohort_name]

  availability <- data.table::data.table(
    cohort = cohort_name,
    variable = requested,
    present_in_source = requested %in% canonical_names
  )
  list(data = selected, availability = availability, source_path = path)
}

build_fi <- function(data, cohort_name) {
  data <- data.table::copy(data)
  memory_deficit <- if (cohort_name == "HRS") {
    early <- binary_deficit(data$memrye)
    later <- strict_any_binary(binary_deficit(data$alzhee), binary_deficit(data$demene))
    ifelse(data$wave <= 9L, early, later)
  } else {
    binary_deficit(data$alzdeme)
  }

  sight_source <- if (cohort_name == "HRS") data$sight else data$nsight
  sight_deficit <- ordinal_health_deficit(sight_source)
  hearing_deficit <- ordinal_health_deficit(data$hearing)
  hearing_aid <- binary_deficit(data$hearaid)
  hearing_deficit[!is.na(hearing_aid) & hearing_aid == 1] <- 1
  health_deficit <- ordinal_health_deficit(data$shlt)

  depression_deficit <- if (cohort_name == "HRS") {
    supplied <- binary_deficit(data$depressive)
    cesd <- valid_range(data$cesd, 0, 8)
    derived <- ifelse(is.na(cesd), NA_real_, as.numeric(cesd >= 3))
    ifelse(!is.na(supplied), supplied, derived)
  } else {
    eurod <- valid_range(data$eurod, 0, 12)
    ifelse(is.na(eurod), NA_real_, as.numeric(eurod >= 4))
  }

  tr20 <- valid_range(data$tr20, 0, 20)
  mo <- valid_range(data$mo, 0, 1)
  dy <- valid_range(data$dy, 0, 1)
  yr <- valid_range(data$yr, 0, 1)
  dw <- valid_range(data$dw, 0, 1)
  ser7 <- valid_range(data$ser7, 0, 5)
  cognitive_matrix <- cbind(tr20, mo, dy, yr, dw, ser7)
  cognition_deficit <- rep(NA_real_, nrow(data))
  cognition_complete <- rowSums(!is.na(cognitive_matrix)) == ncol(cognitive_matrix)
  cognition_deficit[cognition_complete] <- (
    29 - rowSums(cognitive_matrix[cognition_complete, , drop = FALSE])
  ) / 29
  cognition_invalid <- !is.na(cognition_deficit) &
    (cognition_deficit < 0 | cognition_deficit > 1)
  cognition_deficit[cognition_invalid] <- NA_real_

  walking_source <- if (cohort_name == "HRS") data$walk1a else data$walk100a
  item_list <- list(
    hypertension = binary_deficit(data$hibpe),
    diabetes = binary_deficit(data$diabe),
    heart_disease = binary_deficit(data$hearte),
    stroke = binary_deficit(data$stroke),
    cancer = binary_deficit(data$cancre),
    arthritis = binary_deficit(data$arthre),
    lung_disease = binary_deficit(data$lunge),
    psychiatric_problem = binary_deficit(data$psyche),
    memory_or_dementia = memory_deficit,
    vision = sight_deficit,
    hearing = hearing_deficit,
    self_rated_health = health_deficit,
    adl_dressing = binary_deficit(data$dressa),
    adl_bathing = binary_deficit(data$batha),
    adl_eating = binary_deficit(data$eata),
    adl_transfer = binary_deficit(data$beda),
    adl_toileting = binary_deficit(data$toilta),
    iadl_money = binary_deficit(data$moneya),
    iadl_medications = binary_deficit(data$medsa),
    iadl_shopping = binary_deficit(data$shopa),
    iadl_meals = binary_deficit(data$mealsa),
    walking_distance = binary_deficit(walking_source),
    chair_rise = binary_deficit(data$chaira),
    climbing_stairs = binary_deficit(data$climsa),
    lifting = binary_deficit(data$lifta),
    picking_coin = binary_deficit(data$dimea),
    stooping = binary_deficit(data$stoopa),
    reaching_arms = binary_deficit(data$armsa),
    depression = depression_deficit,
    cognition = cognition_deficit
  )
  items <- data.table::as.data.table(item_list)
  if (ncol(items) != 30L) stop("The rebuilt FI must contain exactly 30 items.", call. = FALSE)

  observed_items <- rowSums(!is.na(items))
  deficit_sum <- rowSums(items, na.rm = TRUE)
  minimum_items <- ceiling(30 * as.numeric(config$design$frailty_minimum_observed_fraction))
  fi30 <- ifelse(observed_items >= minimum_items, deficit_sum / observed_items, NA_real_)

  functional_names <- c(
    "adl_dressing", "adl_bathing", "adl_eating", "adl_transfer", "adl_toileting",
    "iadl_money", "iadl_medications", "iadl_shopping", "iadl_meals"
  )
  nonfunctional_names <- setdiff(names(items), functional_names)
  nonfunctional_items <- as.matrix(items[, ..nonfunctional_names])
  nonfunctional_observed <- rowSums(!is.na(nonfunctional_items))
  nonfunctional_sum <- rowSums(nonfunctional_items, na.rm = TRUE)
  nonfunctional_minimum <- ceiling(
    length(nonfunctional_names) * as.numeric(config$design$frailty_minimum_observed_fraction)
  )
  fi_nonfunctional <- ifelse(
    nonfunctional_observed >= nonfunctional_minimum,
    nonfunctional_sum / nonfunctional_observed,
    NA_real_
  )

  fi_long <- data.table::data.table(
    cohort = cohort_name,
    person_id = data$person_id,
    wave = data$wave,
    fi30_rebuilt = fi30,
    fi30_observed_items = observed_items,
    fi30_required_items = minimum_items,
    fi_nonfunctional = fi_nonfunctional,
    fi_nonfunctional_observed_items = nonfunctional_observed,
    fi_nonfunctional_required_items = nonfunctional_minimum
  )
  list(fi = fi_long, items = items)
}

model_trials <- data.table::rbindlist(lapply(cohorts, function(cohort_name) {
  path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_model_ready_trials_PRIVATE.rds")
  )
  if (!file.exists(path)) stop("Missing Stage 04d model-ready data: ", path, call. = FALSE)
  data.table::as.data.table(readRDS(path))
}), use.names = TRUE, fill = TRUE)

needed_records <- unique(data.table::rbindlist(list(
  model_trials[, .(cohort, person_id, wave = E_wave, assessment_time = "E")],
  model_trials[, .(cohort, person_id, wave = L_wave, assessment_time = "L")]
), use.names = TRUE, fill = TRUE))

availability_parts <- list()
fi_parts <- list()
item_missing_parts <- list()
clean_exposure_parts <- list()
source_path_rows <- list()

for (cohort_name in cohorts) {
  clean_result <- read_clean_components(cohort_name)
  clean <- clean_result$data
  needed_waves <- sort(unique(needed_records[cohort == cohort_name]$wave))
  needed_ids <- unique(needed_records[cohort == cohort_name]$person_id)
  clean <- clean[wave %in% needed_waves & person_id %in% needed_ids]
  if (anyDuplicated(clean[, paste(person_id, wave)])) {
    stop(cohort_name, " source has duplicate person-wave component records.", call. = FALSE)
  }
  fi_result <- build_fi(clean, cohort_name)
  fi_parts[[cohort_name]] <- fi_result$fi
  availability_parts[[cohort_name]] <- clean_result$availability
  source_path_rows[[cohort_name]] <- data.frame(
    cohort = cohort_name,
    component_source = clean_result$source_path,
    stringsAsFactors = FALSE
  )
  clean_exposure_parts[[cohort_name]] <- clean[, .(
    cohort, person_id, wave,
    clean_source_rxhchol = binary_deficit(rxhchol),
    clean_source_rxhchol_raw = suppressWarnings(as.numeric(rxhchol))
  )]

  item_names <- names(fi_result$items)
  for (item_name in item_names) {
    item_missing_parts[[paste(cohort_name, item_name, sep = "_")]] <- data.table::data.table(
      cohort = cohort_name,
      person_id = clean$person_id,
      wave = clean$wave,
      item = item_name,
      item_value = fi_result$items[[item_name]]
    )
  }
}

fi_long <- data.table::rbindlist(fi_parts, use.names = TRUE, fill = TRUE)
variable_availability <- data.table::rbindlist(availability_parts, use.names = TRUE, fill = TRUE)
component_sources <- data.table::rbindlist(source_path_rows, use.names = TRUE, fill = TRUE)
clean_exposure_long <- data.table::rbindlist(clean_exposure_parts, use.names = TRUE, fill = TRUE)
item_long <- data.table::rbindlist(item_missing_parts, use.names = TRUE, fill = TRUE)

needed_fi <- merge(
  needed_records, fi_long,
  by = c("cohort", "person_id", "wave"), all.x = TRUE, sort = FALSE
)
fi_completeness <- needed_fi[, .(
  person_wave_records = .N,
  fi_valid_n = sum(!is.na(fi30_rebuilt)),
  fi_valid_fraction = mean(!is.na(fi30_rebuilt)),
  mean_observed_items = mean(fi30_observed_items, na.rm = TRUE),
  p10_observed_items = safe_quantile(fi30_observed_items, 0.10),
  minimum_observed_items = if (any(!is.na(fi30_observed_items)))
    min(fi30_observed_items, na.rm = TRUE) else NA_real_,
  nonfunctional_fi_valid_fraction = mean(!is.na(fi_nonfunctional))
), by = .(cohort, assessment_time, wave)]

item_needed <- merge(
  needed_records, item_long,
  by = c("cohort", "person_id", "wave"), all.x = TRUE, allow.cartesian = TRUE, sort = FALSE
)
item_missingness <- item_needed[, .(
  person_wave_records = .N,
  observed_n = sum(!is.na(item_value)),
  observed_fraction = mean(!is.na(item_value)),
  mean_deficit_among_observed = mean(item_value, na.rm = TRUE)
), by = .(cohort, assessment_time, wave, item)]
item_missingness[!is.finite(mean_deficit_among_observed), mean_deficit_among_observed := NA_real_]

e_lookup <- fi_long[, .(
  cohort, person_id, E_wave = wave,
  E_fi30_rebuilt = fi30_rebuilt,
  E_fi30_observed_items = fi30_observed_items,
  E_fi_nonfunctional = fi_nonfunctional,
  E_fi_nonfunctional_observed_items = fi_nonfunctional_observed_items
)]
l_lookup <- fi_long[, .(
  cohort, person_id, L_wave = wave,
  L_fi30_rebuilt = fi30_rebuilt,
  L_fi30_observed_items = fi30_observed_items,
  L_fi_nonfunctional = fi_nonfunctional,
  L_fi_nonfunctional_observed_items = fi_nonfunctional_observed_items
)]
updated_trials <- merge(
  model_trials, e_lookup,
  by = c("cohort", "person_id", "E_wave"), all.x = TRUE, sort = FALSE
)
updated_trials <- merge(
  updated_trials, l_lookup,
  by = c("cohort", "person_id", "L_wave"), all.x = TRUE, sort = FALSE
)
updated_trials[, FI_pre_treatment := E_fi30_rebuilt]
updated_trials[, FI_landmark_sensitivity := L_fi30_rebuilt]
updated_trials[, FI_pre_treatment_nonfunctional := E_fi_nonfunctional]
updated_trials[, FI_group := data.table::fcase(
  is.na(FI_pre_treatment), "missing",
  FI_pre_treatment < 0.15, "robust_<0.15",
  FI_pre_treatment < 0.25, "intermediate_0.15-<0.25",
  default = "frail_>=0.25"
)]

fi_distribution <- updated_trials[, .(
  person_trials = .N,
  unique_persons = data.table::uniqueN(person_id),
  valid_fi_n = sum(!is.na(FI_pre_treatment)),
  valid_fi_fraction = mean(!is.na(FI_pre_treatment)),
  mean_fi = if (any(!is.na(FI_pre_treatment))) mean(FI_pre_treatment, na.rm = TRUE) else NA_real_,
  median_fi = safe_quantile(FI_pre_treatment, 0.50),
  p25_fi = safe_quantile(FI_pre_treatment, 0.25),
  p75_fi = safe_quantile(FI_pre_treatment, 0.75)
), by = .(cohort, treatment, treatment_label)]

fi_group_events <- updated_trials[, .(
  person_trials = .N,
  unique_persons = data.table::uniqueN(person_id),
  primary_observed_n = sum(!is.na(primary_event)),
  primary_events = sum(primary_event == 1L, na.rm = TRUE),
  strict_observed_n = sum(!is.na(strict_event)),
  strict_events = sum(strict_event == 1L, na.rm = TRUE)
), by = .(cohort, FI_group, treatment, treatment_label)]

fi_group_gate <- fi_group_events[FI_group != "missing", .(
  smaller_arm_person_trials = min(person_trials),
  smaller_arm_unique_persons = min(unique_persons),
  smaller_arm_primary_events = min(primary_events),
  total_primary_events = sum(primary_events),
  passes_person_trial_gate = min(person_trials) >=
    as.numeric(config$data_gates$minimum_smaller_arm_person_trials),
  passes_event_gate = min(primary_events) >=
    as.numeric(config$data_gates$minimum_smaller_arm_primary_events)
), by = .(cohort, FI_group)]

fi_comparison <- data.table::rbindlist(lapply(cohorts, function(cohort_name) {
  cohort_trials <- updated_trials[cohort == cohort_name]
  data.table::rbindlist(lapply(c("E", "L"), function(assessment_time) {
    rebuilt <- cohort_trials[[paste0(assessment_time, "_fi30_rebuilt")]]
    supplied <- cohort_trials[[paste0(assessment_time, "_frailty_01")]]
    pair <- is.finite(rebuilt) & is.finite(supplied)
    data.table::data.table(
      cohort = cohort_name,
      assessment_time = assessment_time,
      paired_n = sum(pair),
      correlation = if (sum(pair) >= 3L) stats::cor(rebuilt[pair], supplied[pair]) else NA_real_,
      mean_rebuilt_minus_supplied = if (any(pair)) mean(rebuilt[pair] - supplied[pair]) else NA_real_,
      median_absolute_difference = if (any(pair)) stats::median(abs(rebuilt[pair] - supplied[pair])) else NA_real_
    )
  }), use.names = TRUE, fill = TRUE)
}), use.names = TRUE, fill = TRUE)

get_actual_name <- function(all_names, requested) {
  hit <- which(tolower(all_names) == tolower(requested))
  if (length(hit) == 1L) all_names[[hit]] else NA_character_
}

raw_exposure_parts <- list()
raw_label_parts <- list()
for (cohort_name in cohorts) {
  source_row <- sources[sources$cohort == cohort_name, , drop = FALSE]
  aux_row <- aux_map[aux_map$cohort == cohort_name, , drop = FALSE]
  harmonized_link <- file.path(
    project_root, "data_links", "stage03c_inputs",
    if (cohort_name == "HRS") "H_HRS_d.dta" else "H_SHARE_f2.dta"
  )
  harmonized_path <- if (file.exists(harmonized_link)) {
    harmonized_link
  } else {
    file.path(data_root, source_row$harmonized_file)
  }
  metadata <- haven::read_dta(harmonized_path, n_max = 0L, .name_repair = "minimal")
  all_names <- names(metadata)
  id_actual <- get_actual_name(all_names, aux_row$id_variable)
  if (is.na(id_actual)) stop(cohort_name, " Gateway file lacks its configured ID.", call. = FALSE)
  waves <- sort(unique(needed_records[cohort == cohort_name]$wave))
  requested_names <- paste0("r", waves, "rxhchol")
  actual_names <- vapply(requested_names, function(x) get_actual_name(all_names, x), character(1L))
  selected_names <- unique(na.omit(c(id_actual, actual_names)))
  raw <- haven::read_dta(
    harmonized_path,
    col_select = tidyselect::all_of(selected_names),
    .name_repair = "minimal"
  )
  for (wave_value in waves) {
    requested_name <- paste0("r", wave_value, "rxhchol")
    actual_name <- actual_names[[match(requested_name, requested_names)]]
    if (is.na(actual_name)) {
      raw_value <- rep(NA_real_, nrow(raw))
      labels <- NULL
    } else {
      raw_value <- plain_numeric(raw[[actual_name]])
      labels <- attr(raw[[actual_name]], "labels", exact = TRUE)
    }
    raw_exposure_parts[[paste(cohort_name, wave_value, sep = "_")]] <- data.table::data.table(
      cohort = cohort_name,
      person_id = normalize_id(raw[[id_actual]], cohort_name),
      wave = wave_value,
      gateway_rxhchol_raw = raw_value,
      gateway_rxhchol_binary = ifelse(raw_value %in% c(0, 1), raw_value, NA_real_)
    )
    if (is.null(labels) || !length(labels)) {
      raw_label_parts[[paste(cohort_name, wave_value, sep = "_")]] <- data.frame(
        cohort = cohort_name, wave = wave_value, variable = requested_name,
        code = NA_real_, label = "", stringsAsFactors = FALSE
      )
    } else {
      raw_label_parts[[paste(cohort_name, wave_value, sep = "_")]] <- data.frame(
        cohort = cohort_name, wave = wave_value, variable = requested_name,
        code = as.numeric(labels), label = names(labels), stringsAsFactors = FALSE
      )
    }
  }
}
raw_exposure_long <- data.table::rbindlist(raw_exposure_parts, use.names = TRUE, fill = TRUE)
raw_exposure_labels <- data.table::rbindlist(raw_label_parts, use.names = TRUE, fill = TRUE)

exposure_records <- data.table::rbindlist(list(
  model_trials[, .(
    cohort, person_id, wave = E_wave, assessment_time = "E",
    trial_rxhchol = E_lipid_medication
  )],
  model_trials[, .(
    cohort, person_id, wave = L_wave, assessment_time = "L",
    trial_rxhchol = L_lipid_medication
  )]
), use.names = TRUE, fill = TRUE)
exposure_records <- merge(
  exposure_records,
  clean_exposure_long,
  by = c("cohort", "person_id", "wave"), all.x = TRUE, sort = FALSE
)
exposure_records <- merge(
  exposure_records,
  raw_exposure_long,
  by = c("cohort", "person_id", "wave"), all.x = TRUE, sort = FALSE
)

exposure_validation <- exposure_records[, {
  clean_pair <- !is.na(trial_rxhchol) & !is.na(clean_source_rxhchol)
  gateway_pair <- !is.na(trial_rxhchol) & !is.na(gateway_rxhchol_binary)
  list(
    person_trial_records = .N,
    trial_observed_n = sum(!is.na(trial_rxhchol)),
    clean_pair_n = sum(clean_pair),
    clean_agreement_n = sum(trial_rxhchol[clean_pair] == clean_source_rxhchol[clean_pair]),
    clean_agreement_fraction = if (any(clean_pair))
      mean(trial_rxhchol[clean_pair] == clean_source_rxhchol[clean_pair]) else NA_real_,
    gateway_pair_n = sum(gateway_pair),
    gateway_coverage_fraction = mean(!is.na(gateway_rxhchol_binary)),
    gateway_agreement_n = sum(trial_rxhchol[gateway_pair] == gateway_rxhchol_binary[gateway_pair]),
    gateway_agreement_fraction = if (any(gateway_pair))
      mean(trial_rxhchol[gateway_pair] == gateway_rxhchol_binary[gateway_pair]) else NA_real_,
    trial_zero_gateway_missing_n = sum(trial_rxhchol == 0 & is.na(gateway_rxhchol_binary), na.rm = TRUE),
    trial_one_gateway_missing_n = sum(trial_rxhchol == 1 & is.na(gateway_rxhchol_binary), na.rm = TRUE)
  )
}, by = .(cohort, assessment_time, wave)]

exposure_code_crosswalk <- exposure_records[, .N, by = .(
  cohort, assessment_time, wave,
  trial_rxhchol = ifelse(is.na(trial_rxhchol), "[missing]", as.character(trial_rxhchol)),
  clean_source_rxhchol_raw = ifelse(
    is.na(clean_source_rxhchol_raw), "[missing]", as.character(clean_source_rxhchol_raw)
  ),
  gateway_rxhchol_raw = ifelse(
    is.na(gateway_rxhchol_raw), "[missing]", as.character(gateway_rxhchol_raw)
  )
)]

exposure_gate <- exposure_validation[, .(
  minimum_clean_agreement = min(clean_agreement_fraction, na.rm = TRUE),
  minimum_gateway_coverage = min(gateway_coverage_fraction, na.rm = TRUE),
  minimum_gateway_agreement = min(gateway_agreement_fraction, na.rm = TRUE),
  clean_validation_pass = all(clean_agreement_fraction >= 0.99),
  gateway_validation_pass = all(
    gateway_coverage_fraction >= 0.95 & gateway_agreement_fraction >= 0.99
  )
), by = cohort]

for (cohort_name in cohorts) {
  saveRDS(
    updated_trials[cohort == cohort_name],
    file.path(private_dir, paste0(tolower(cohort_name), "_fi_validated_trials_PRIVATE.rds")),
    version = 3L
  )
}
saveRDS(
  updated_trials,
  file.path(private_dir, "combined_fi_validated_trials_PRIVATE.rds"),
  version = 3L
)

tte_write_csv(component_sources, file.path(output_dir, "04e_component_sources.csv"))
tte_write_csv(variable_availability, file.path(output_dir, "04e_component_variable_availability.csv"))
tte_write_csv(fi_completeness, file.path(output_dir, "04e_fi_completeness_by_wave.csv"))
tte_write_csv(item_missingness, file.path(output_dir, "04e_fi_item_missingness.csv"))
tte_write_csv(fi_distribution, file.path(output_dir, "04e_pre_treatment_fi_distribution.csv"))
tte_write_csv(fi_group_events, file.path(output_dir, "04e_fi_group_event_counts.csv"))
tte_write_csv(fi_group_gate, file.path(output_dir, "04e_fi_group_gate.csv"))
tte_write_csv(fi_comparison, file.path(output_dir, "04e_rebuilt_vs_supplied_fi.csv"))
tte_write_csv(raw_exposure_labels, file.path(output_dir, "04e_gateway_exposure_value_labels.csv"))
tte_write_csv(exposure_validation, file.path(output_dir, "04e_exposure_validation_by_wave.csv"))
tte_write_csv(exposure_code_crosswalk, file.path(output_dir, "04e_exposure_code_crosswalk.csv"))
tte_write_csv(exposure_gate, file.path(output_dir, "04e_exposure_validation_gate.csv"))

summary_lines <- c(
  "Stage 04e: rebuilt frailty and medication-exposure validation",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Person-trials: ", nrow(updated_trials)),
  paste0(
    "Pre-treatment FI available: ", sum(!is.na(updated_trials$FI_pre_treatment)),
    " of ", nrow(updated_trials), " (",
    sprintf("%.1f", 100 * mean(!is.na(updated_trials$FI_pre_treatment))), "%)"
  ),
  paste0(
    "FI strata passing the unweighted >=20-events-per-arm gate: ",
    sum(fi_group_gate$passes_event_gate), " of ", nrow(fi_group_gate)
  ),
  paste0(
    "Cohorts passing clean-source exposure agreement: ",
    sum(exposure_gate$clean_validation_pass), " of ", nrow(exposure_gate)
  ),
  paste0(
    "Cohorts passing Gateway exposure coverage/agreement: ",
    sum(exposure_gate$gateway_validation_pass), " of ", nrow(exposure_gate)
  ),
  "",
  "FI was calculated only with >=24 observed items and used the observed-item denominator.",
  "Frailty group boundaries are <0.15, 0.15-<0.25, and >=0.25.",
  "No missing value was imputed and no causal model was fitted."
)
writeLines(summary_lines, file.path(output_dir, "04e_stage_summary.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(output_dir, "04e_session_info.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
