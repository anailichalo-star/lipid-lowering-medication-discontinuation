# Stage 09a: two-stage synthesis of HRS and SHARE. With only two cohorts,
# modified Hartung-Knapp intervals are reported and prediction intervals are
# deliberately not estimated.

options(stringsAsFactors = FALSE)
project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
required_packages <- c("data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop("Missing required packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
output_root <- file.path(project_root, analysis_config$output_root)
output_dir <- file.path(output_root, "stage09a_meta_analysis")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

sources <- list(
  primary = list(
    effects = file.path(output_root, "stage06_primary_effects", "06_primary_effects_pooled.csv"),
    diagnostics = file.path(output_root, "stage06_primary_effects", "06_pooling_diagnostics.csv")
  ),
  component = list(
    effects = file.path(output_root, "stage07c_component_effects", "07c_component_effects_pooled.csv"),
    diagnostics = file.path(output_root, "stage07c_component_effects", "07c_pooling_diagnostics.csv")
  ),
  functional = list(
    effects = file.path(output_root, "stage07h_functional_effects", "07h_functional_effects_pooled.csv"),
    diagnostics = file.path(output_root, "stage07h_functional_effects", "07h_pooling_diagnostics.csv")
  )
)
for (family_name in names(sources)) {
  paths <- unlist(sources[[family_name]], use.names = FALSE)
  if (any(!file.exists(paths))) {
    stop("Missing meta-analysis input for ", family_name, call. = FALSE)
  }
}

input_parts <- list()
for (family_name in names(sources)) {
  effect <- data.table::as.data.table(tte_read_csv_utf8(sources[[family_name]]$effects))
  diagnostic <- data.table::as.data.table(tte_read_csv_utf8(sources[[family_name]]$diagnostics))
  if (!"outcome" %in% names(diagnostic)) {
    diagnostic[, outcome := "primary_event"]
  }
  if (!"outcome_label" %in% names(effect)) {
    effect[, outcome_label := outcome]
  }
  selected_effect <- effect[
    cohort %in% c("HRS", "SHARE") &
      measure %in% c("risk_difference", "risk_ratio")
  ]
  selected_diagnostic <- diagnostic[
    cohort %in% c("HRS", "SHARE") &
      measure %in% c("risk_difference", "risk_ratio"),
    .(cohort, outcome, measure,
      transformed_estimate = suppressWarnings(as.numeric(pooled_transformed_estimate)),
      transformed_standard_error = suppressWarnings(as.numeric(transformed_standard_error)))
  ]
  joined <- merge(
    selected_effect,
    selected_diagnostic,
    by = c("cohort", "outcome", "measure"),
    all.x = TRUE
  )
  if (anyNA(joined$transformed_estimate) ||
      anyNA(joined$transformed_standard_error)) {
    stop("Failed to recover within-cohort meta-analysis standard errors.", call. = FALSE)
  }
  joined[, analysis_family := family_name]
  input_parts[[family_name]] <- joined[, .(
    analysis_family, cohort, outcome, outcome_label, measure,
    display_estimate = suppressWarnings(as.numeric(estimate)),
    display_lower = suppressWarnings(as.numeric(confidence_lower)),
    display_upper = suppressWarnings(as.numeric(confidence_upper)),
    transformed_estimate,
    transformed_standard_error
  )]
}
meta_input <- data.table::rbindlist(input_parts, use.names = TRUE, fill = TRUE)
if (any(meta_input$transformed_standard_error <= 0)) {
  stop("Meta-analysis standard errors must be positive.", call. = FALSE)
}

reml_two_stage <- function(y, se) {
  y <- as.numeric(y)
  vi <- as.numeric(se)^2
  k <- length(y)
  if (k < 2L || any(!is.finite(y)) || any(!is.finite(vi)) || any(vi <= 0)) {
    stop("Invalid inputs for random-effects synthesis.", call. = FALSE)
  }
  fixed_weight <- 1 / vi
  fixed_mean <- sum(fixed_weight * y) / sum(fixed_weight)
  q_fixed <- sum(fixed_weight * (y - fixed_mean)^2)
  i_squared <- if (q_fixed > 0) max(0, (q_fixed - (k - 1)) / q_fixed) else 0

  restricted_objective <- function(tau_squared) {
    weight <- 1 / (vi + tau_squared)
    mean_value <- sum(weight * y) / sum(weight)
    0.5 * (
      sum(log(vi + tau_squared)) + log(sum(weight)) +
        sum(weight * (y - mean_value)^2)
    )
  }
  upper <- max(1, 100 * stats::var(y), 100 * max(vi))
  optimized <- stats::optimize(restricted_objective, c(0, upper))
  objective_zero <- restricted_objective(0)
  tau_squared <- if (objective_zero <= optimized$objective + 1e-10) {
    0
  } else {
    optimized$minimum
  }
  random_weight <- 1 / (vi + tau_squared)
  random_mean <- sum(random_weight * y) / sum(random_weight)
  conventional_se <- sqrt(1 / sum(random_weight))
  q_random <- sum(random_weight * (y - random_mean)^2)
  hk_scale <- q_random / (k - 1)
  modified_hk_scale <- max(1, hk_scale)
  modified_hk_se <- sqrt(modified_hk_scale / sum(random_weight))
  critical_hk <- stats::qt(0.975, df = k - 1)
  list(
    k = k,
    estimate = random_mean,
    tau_squared = tau_squared,
    q_fixed = q_fixed,
    q_df = k - 1,
    q_p_value = stats::pchisq(q_fixed, df = k - 1, lower.tail = FALSE),
    i_squared = i_squared,
    conventional_se = conventional_se,
    conventional_lower = random_mean - stats::qnorm(0.975) * conventional_se,
    conventional_upper = random_mean + stats::qnorm(0.975) * conventional_se,
    hk_scale = hk_scale,
    modified_hk_se = modified_hk_se,
    modified_hk_df = k - 1,
    modified_hk_lower = random_mean - critical_hk * modified_hk_se,
    modified_hk_upper = random_mean + critical_hk * modified_hk_se
  )
}

meta_parts <- list()
for (outcome_name in unique(meta_input$outcome)) {
  for (measure_name in c("risk_difference", "risk_ratio")) {
    rows <- meta_input[outcome == outcome_name & measure == measure_name]
    if (nrow(rows) != 2L || !setequal(rows$cohort, c("HRS", "SHARE"))) {
      stop(outcome_name, "/", measure_name, ": exactly HRS and SHARE are required.", call. = FALSE)
    }
    fit <- reml_two_stage(rows$transformed_estimate, rows$transformed_standard_error)
    transform <- if (measure_name == "risk_ratio") exp else identity
    key <- paste(outcome_name, measure_name, sep = "_")
    meta_parts[[key]] <- data.table::data.table(
      outcome = outcome_name,
      outcome_label = unique(rows$outcome_label),
      measure = measure_name,
      cohorts = "HRS; SHARE",
      cohort_n = fit$k,
      transformed_estimate = fit$estimate,
      estimate = transform(fit$estimate),
      modified_HK_lower = transform(fit$modified_hk_lower),
      modified_HK_upper = transform(fit$modified_hk_upper),
      conventional_REML_lower = transform(fit$conventional_lower),
      conventional_REML_upper = transform(fit$conventional_upper),
      tau_squared_transformed_scale = fit$tau_squared,
      I_squared = fit$i_squared,
      Cochran_Q = fit$q_fixed,
      Q_df = fit$q_df,
      Q_p_value = fit$q_p_value,
      modified_HK_df = fit$modified_hk_df,
      HK_variance_scale = fit$hk_scale,
      prediction_interval_lower = NA_real_,
      prediction_interval_upper = NA_real_,
      prediction_interval_note = "Not estimated because only two cohorts are available"
    )
  }
}
meta_results <- data.table::rbindlist(meta_parts, use.names = TRUE, fill = TRUE)
meta_results[, estimate_per_1000 := ifelse(
  measure == "risk_difference", estimate * 1000, NA_real_
)]
meta_results[, modified_HK_lower_per_1000 := ifelse(
  measure == "risk_difference", modified_HK_lower * 1000, NA_real_
)]
meta_results[, modified_HK_upper_per_1000 := ifelse(
  measure == "risk_difference", modified_HK_upper * 1000, NA_real_
)]
data.table::setorder(meta_results, outcome, measure)
tte_write_csv(meta_input, file.path(output_dir, "09a_meta_input.csv"))
tte_write_csv(meta_results, file.path(output_dir, "09a_meta_results.csv"))

outcome_order <- c(
  "primary_event", "strict_event", "death_component", "death_adl_decline"
)
outcome_labels <- c(
  primary_event = "Broad CVD or death",
  strict_event = "MI, stroke, or death",
  death_component = "All-cause death",
  death_adl_decline = "Death or ADL decline"
)

make_forest_data <- function(measure_name) {
  individual <- meta_input[measure == measure_name, .(
    outcome, cohort,
    row_label = cohort,
    estimate = display_estimate,
    lower = display_lower,
    upper = display_upper
  )]
  pooled <- meta_results[measure == measure_name, .(
    outcome,
    cohort = "Pooled",
    row_label = "Pooled (modified HK)",
    estimate,
    lower = modified_HK_lower,
    upper = modified_HK_upper
  )]
  result <- data.table::rbindlist(list(individual, pooled), fill = TRUE)
  result[, outcome_label := factor(
    outcome_labels[outcome],
    levels = rev(unname(outcome_labels[outcome_order]))
  )]
  result[, row_label := factor(
    row_label,
    levels = c("Pooled (modified HK)", "SHARE", "HRS")
  )]
  result
}

rd_data <- make_forest_data("risk_difference")
rd_plot <- ggplot2::ggplot(
  rd_data,
  ggplot2::aes(
    x = estimate * 1000, y = row_label,
    xmin = lower * 1000, xmax = upper * 1000,
    colour = cohort, shape = cohort
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey45") +
  ggplot2::geom_errorbar(orientation = "y", width = 0.12) +
  ggplot2::geom_point(size = 2.1) +
  ggplot2::facet_wrap(~outcome_label, ncol = 1, scales = "free_x") +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52", "Pooled" = "#222222"
  )) +
  ggplot2::labs(
    x = "3-year risk difference per 1,000", y = NULL,
    colour = NULL, shape = NULL,
    title = "Cohort-specific and two-cohort pooled absolute effects",
    subtitle = "Pooled intervals use modified Hartung-Knapp with 1 degree of freedom"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(legend.position = "none")

rr_data <- make_forest_data("risk_ratio")
rr_plot <- ggplot2::ggplot(
  rr_data,
  ggplot2::aes(
    x = estimate, y = row_label,
    xmin = lower, xmax = upper,
    colour = cohort, shape = cohort
  )
) +
  ggplot2::geom_vline(xintercept = 1, linetype = 2, colour = "grey45") +
  ggplot2::geom_errorbar(orientation = "y", width = 0.12) +
  ggplot2::geom_point(size = 2.1) +
  ggplot2::facet_wrap(~outcome_label, ncol = 1, scales = "free_x") +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52", "Pooled" = "#222222"
  )) +
  ggplot2::labs(
    x = "3-year risk ratio", y = NULL,
    colour = NULL, shape = NULL,
    title = "Cohort-specific and two-cohort pooled relative effects",
    subtitle = "Pooled intervals use modified Hartung-Knapp with 1 degree of freedom"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(legend.position = "none")

ggplot2::ggsave(file.path(output_dir, "09a_meta_risk_difference_forest.png"), rd_plot, width = 10, height = 10, dpi = 220)
ggplot2::ggsave(file.path(output_dir, "09a_meta_risk_difference_forest.pdf"), rd_plot, width = 10, height = 10)
ggplot2::ggsave(file.path(output_dir, "09a_meta_risk_ratio_forest.png"), rr_plot, width = 10, height = 10, dpi = 220)
ggplot2::ggsave(file.path(output_dir, "09a_meta_risk_ratio_forest.pdf"), rr_plot, width = 10, height = 10)

result_lines <- vapply(seq_len(nrow(meta_results)), function(i) {
  row <- meta_results[i]
  if (row$measure == "risk_difference") {
    paste0(
      row$outcome, "/RD: ", sprintf("%.1f", row$estimate_per_1000),
      " per 1,000 (modified HK 95% CI ",
      sprintf("%.1f", row$modified_HK_lower_per_1000), " to ",
      sprintf("%.1f", row$modified_HK_upper_per_1000),
      "); I2=", sprintf("%.1f%%", 100 * row$I_squared), "."
    )
  } else {
    paste0(
      row$outcome, "/RR: ", sprintf("%.3f", row$estimate),
      " (modified HK 95% CI ", sprintf("%.3f", row$modified_HK_lower),
      " to ", sprintf("%.3f", row$modified_HK_upper),
      "); I2=", sprintf("%.1f%%", 100 * row$I_squared), "."
    )
  }
}, character(1L))
summary_lines <- c(
  "Stage 09a: HRS-SHARE two-stage synthesis",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Estimator: REML random effects with modified Hartung-Knapp confidence intervals.",
  "Only two cohorts are available; modified HK uses one degree of freedom and is intentionally conservative.",
  "Prediction intervals and meta-regression were not estimated.",
  "", result_lines,
  "",
  "Cohort-specific estimates remain the primary presentation; pooled estimates are supportive summaries."
)
writeLines(summary_lines, file.path(output_dir, "09a_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "09a_session_info.txt"), useBytes = TRUE)
message(paste(summary_lines, collapse = "\n"))
message("Stage 09a completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
