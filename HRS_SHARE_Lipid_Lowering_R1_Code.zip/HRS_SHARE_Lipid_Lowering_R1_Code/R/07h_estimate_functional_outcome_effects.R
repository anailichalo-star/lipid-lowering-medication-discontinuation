# Stage 07h: estimate the three-year effect on all-cause death or worsening
# in the five common ADL items, using Stage 07g outcome-specific weights.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(
  file.path(project_root, "R", "_stage1_helpers.R"),
  encoding = "UTF-8", local = TRUE
)
source(
  file.path(project_root, "R", "_stage06_helpers.R"),
  encoding = "UTF-8", local = TRUE
)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "analysis.yml")
)
effect_config_path <- file.path(
  project_root, "config_r", "functional_outcome_effect_model.yml"
)
effect_config <- tte_read_yaml_utf8(effect_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_private <- file.path(
  project_root, analysis_config$output_root,
  "stage05_weighting", "private_do_not_share"
)
stage07g_dir <- file.path(
  project_root, analysis_config$output_root, "stage07g_functional_weights"
)
stage07g_private <- file.path(stage07g_dir, "private_do_not_share")
output_dir <- file.path(
  project_root, analysis_config$output_root, "stage07h_functional_effects"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

outcome_name <- as.character(effect_config$outcome$name)
outcome_label <- as.character(effect_config$outcome$label)
target_years <- as.numeric(effect_config$target_risk_years)
confidence_level <- as.numeric(effect_config$confidence_level)
if (!isTRUE(all.equal(confidence_level, 0.95))) {
  stop("Stage 07h currently requires a 95% confidence level.", call. = FALSE)
}

as_logical_value <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}

gate_path <- file.path(stage07g_dir, "07g_weighting_gate.csv")
if (!file.exists(gate_path)) {
  stop("Missing Stage 07g gate file: ", gate_path, call. = FALSE)
}
gate <- data.table::as.data.table(tte_read_csv_utf8(gate_path))
required_gate <- c(
  "cohort", "outcome", "ready_for_functional_effect_estimation"
)
missing_gate <- setdiff(required_gate, names(gate))
if (length(missing_gate)) {
  stop(
    "Stage 07g gate lacks: ", paste(missing_gate, collapse = ", "),
    call. = FALSE
  )
}
ready_rows <- gate[
  outcome == outcome_name &
    as_logical_value(ready_for_functional_effect_estimation)
]
if (!nrow(ready_rows)) {
  stop("No cohort passed the Stage 07g functional gate.", call. = FALSE)
}
if (anyDuplicated(ready_rows$cohort) ||
    any(!ready_rows$cohort %in% c("HRS", "SHARE"))) {
  stop("Stage 07g contains invalid ready cohort rows.", call. = FALSE)
}
cohorts <- as.character(ready_rows$cohort)

effect_parts <- list()
model_parts <- list()
sample_parts <- list()
join_parts <- list()

for (cohort_name in cohorts) {
  source_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  weight_path <- file.path(
    stage07g_private,
    paste0(tolower(cohort_name), "_functional_weights_PRIVATE.rds")
  )
  for (required_path in c(source_path, stage05_path, weight_path)) {
    if (!file.exists(required_path)) {
      stop("Missing required Stage 07h input: ", required_path, call. = FALSE)
    }
  }

  source_trials <- data.table::as.data.table(readRDS(source_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  required_source <- c(
    "person_id", "trial_id", "followup_time_years",
    "L_interview_date", "followup_reference_date"
  )
  missing_source <- setdiff(required_source, names(source_trials))
  if (length(missing_source)) {
    stop(
      cohort_name, " source trials lack: ",
      paste(missing_source, collapse = ", "), call. = FALSE
    )
  }
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate Stage 04f person-trial key.", call. = FALSE)
  }
  source_fields <- source_trials[, .(
    join_key,
    followup_time_years = suppressWarnings(as.numeric(followup_time_years)),
    L_interview_date,
    followup_reference_date
  )]

  imputed_datasets <- readRDS(stage05_path)
  functional_weights <- readRDS(weight_path)
  if (!is.list(imputed_datasets) || !is.list(functional_weights) ||
      length(imputed_datasets) != 20L || length(functional_weights) != 20L) {
    stop(
      cohort_name, ": Stage 05 and Stage 07g must each contain 20 datasets.",
      call. = FALSE
    )
  }

  for (imputation_index in seq_along(imputed_datasets)) {
    completed <- data.table::as.data.table(
      data.table::copy(imputed_datasets[[imputation_index]])
    )
    compact <- data.table::as.data.table(
      data.table::copy(functional_weights[[imputation_index]])
    )
    completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    if (anyDuplicated(completed$join_key) ||
        !"join_key" %in% names(compact) || anyDuplicated(compact$join_key)) {
      stop(
        cohort_name, ": invalid person-trial key in imputation ",
        imputation_index, call. = FALSE
      )
    }
    weight_index <- match(completed$join_key, compact$join_key)
    source_index <- match(completed$join_key, source_fields$join_key)
    exact_identity <- !anyNA(weight_index) && !anyNA(source_index) &&
      nrow(completed) == nrow(compact) &&
      all(as.integer(as.character(completed$treatment)) ==
            as.integer(as.character(compact$treatment[weight_index])))
    if (!exact_identity) {
      stop(
        cohort_name, ": Stage 05/07g/04f join failed in imputation ",
        imputation_index, call. = FALSE
      )
    }

    completed[, outcome_value := compact$outcome_value[weight_index]]
    completed[, outcome_observed_specific :=
      compact$outcome_observed_specific[weight_index]]
    completed[, total_weight_specific :=
      compact$total_weight_specific[weight_index]]
    completed[, followup_time_years :=
      source_fields$followup_time_years[source_index]]
    completed[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
    completed[, outcome_value := suppressWarnings(as.integer(outcome_value))]
    completed[, outcome_observed_specific :=
      suppressWarnings(as.integer(outcome_observed_specific))]
    completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      completed[, B_country := droplevels(factor(B_country))]
    }

    if (anyNA(completed$treatment) ||
        !all(completed$treatment %in% c(0L, 1L)) ||
        data.table::uniqueN(completed$treatment) != 2L) {
      stop(cohort_name, ": invalid treatment coding.", call. = FALSE)
    }
    if (any(!is.finite(completed$followup_time_years)) ||
        any(completed$followup_time_years <= 0)) {
      stop(cohort_name, ": invalid follow-up time.", call. = FALSE)
    }
    if (!all(completed$outcome_observed_specific %in% c(0L, 1L)) ||
        any(is.na(completed$outcome_value) !=
              (completed$outcome_observed_specific == 0L))) {
      stop(
        cohort_name, ": functional outcome observation mismatch.",
        call. = FALSE
      )
    }

    observed <- completed[
      outcome_observed_specific == 1L & !is.na(outcome_value) &
        is.finite(total_weight_specific) & total_weight_specific > 0
    ]
    if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
      stop(
        cohort_name, ": both observed treatment arms are required.",
        call. = FALSE
      )
    }
    observed[, model_weight := total_weight_specific / mean(total_weight_specific)]

    adjustment_terms <- unlist(
      effect_config$design_adjustment[[cohort_name]], use.names = FALSE
    )
    formula_text <- paste0(
      "outcome_value ~ treatment + ",
      paste(adjustment_terms, collapse = " + "),
      " + offset(log(followup_time_years))"
    )
    outcome_formula <- stats::as.formula(formula_text)
    warning_messages <- character()
    fit <- withCallingHandlers(
      stats::glm(
        formula = outcome_formula,
        data = observed,
        family = stats::quasibinomial(link = "cloglog"),
        weights = model_weight,
        na.action = stats::na.fail,
        control = stats::glm.control(maxit = 100, epsilon = 1e-9)
      ),
      warning = function(warning_condition) {
        warning_messages <<- c(
          warning_messages, conditionMessage(warning_condition)
        )
        invokeRestart("muffleWarning")
      }
    )
    if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
      stop(
        cohort_name, ": functional outcome model failed in imputation ",
        imputation_index, call. = FALSE
      )
    }

    robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
    standardized <- tte_standardized_cloglog_effects(
      fit = fit,
      robust_vcov = robust$vcov,
      target_data = completed,
      standardization_weight = completed$survey_weight_scaled,
      target_years = target_years
    )
    variance_continue <- standardized$risk_covariance[1L, 1L]
    variance_discontinue <- standardized$risk_covariance[2L, 2L]
    variance_logit_continue <- variance_continue /
      (standardized$risk_continue * (1 - standardized$risk_continue))^2
    variance_logit_discontinue <- variance_discontinue /
      (standardized$risk_discontinue *
         (1 - standardized$risk_discontinue))^2

    key <- paste(cohort_name, imputation_index, sep = "_")
    effect_parts[[key]] <- data.table::data.table(
      cohort = cohort_name,
      outcome = outcome_name,
      imputation = imputation_index,
      target_years = target_years,
      risk_continue = standardized$risk_continue,
      variance_risk_continue = variance_continue,
      logit_risk_continue = tte_logit(standardized$risk_continue),
      variance_logit_risk_continue = variance_logit_continue,
      risk_discontinue = standardized$risk_discontinue,
      variance_risk_discontinue = variance_discontinue,
      logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
      variance_logit_risk_discontinue = variance_logit_discontinue,
      risk_difference = standardized$risk_difference,
      variance_risk_difference = standardized$variance_risk_difference,
      log_risk_ratio = standardized$log_risk_ratio,
      variance_log_risk_ratio = standardized$variance_log_risk_ratio
    )
    model_parts[[key]] <- data.table::data.table(
      cohort = cohort_name,
      outcome = outcome_name,
      imputation = imputation_index,
      formula = formula_text,
      converged = isTRUE(fit$converged),
      iterations = fit$iter,
      coefficient_n = length(stats::coef(fit)),
      aliased_coefficient_n = sum(is.na(stats::coef(fit))),
      warning_n = length(unique(warning_messages)),
      warnings = paste(unique(warning_messages), collapse = " | "),
      outcome_observations = nrow(observed),
      unique_person_clusters = robust$clusters,
      events = sum(observed$outcome_value == 1L),
      continue_observations = sum(observed$treatment == 0L),
      discontinue_observations = sum(observed$treatment == 1L),
      continue_events = sum(
        observed$outcome_value == 1L & observed$treatment == 0L
      ),
      discontinue_events = sum(
        observed$outcome_value == 1L & observed$treatment == 1L
      ),
      followup_minimum_years = min(observed$followup_time_years),
      followup_median_years = stats::median(observed$followup_time_years),
      followup_maximum_years = max(observed$followup_time_years),
      cluster_CR1_correction = robust$correction,
      full_survey_design_variance_available = FALSE
    )
    if (imputation_index == 1L) {
      sample_parts[[cohort_name]] <- completed[, .(
        eligible_person_trials = .N,
        unique_persons = data.table::uniqueN(person_id),
        outcome_observed_n = sum(outcome_observed_specific == 1L),
        outcome_observed_fraction = mean(outcome_observed_specific == 1L),
        events = sum(outcome_value == 1L, na.rm = TRUE),
        followup_minimum_years = min(followup_time_years),
        followup_median_years = stats::median(followup_time_years),
        followup_maximum_years = max(followup_time_years)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        outcome = outcome_name,
        treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
      )]
    }
    join_parts[[key]] <- data.table::data.table(
      cohort = cohort_name,
      outcome = outcome_name,
      imputation = imputation_index,
      stage05_rows = nrow(completed),
      stage07g_weight_rows = nrow(compact),
      matched_weight_rows = sum(!is.na(weight_index)),
      matched_source_rows = sum(!is.na(source_index)),
      exact_person_trial_treatment_identity = exact_identity
    )
  }
}

effects_by_imputation <- data.table::rbindlist(
  effect_parts, use.names = TRUE, fill = TRUE
)
model_diagnostics <- data.table::rbindlist(
  model_parts, use.names = TRUE, fill = TRUE
)
sample_description <- data.table::rbindlist(
  sample_parts, use.names = TRUE, fill = TRUE
)
join_checks <- data.table::rbindlist(
  join_parts, use.names = TRUE, fill = TRUE
)

pooled_rows <- list()
pooling_rows <- list()
for (cohort_name in cohorts) {
  estimates <- effects_by_imputation[cohort == cohort_name]
  diagnostics <- model_diagnostics[cohort == cohort_name]
  if (nrow(estimates) != 20L || nrow(diagnostics) != 20L) {
    stop(cohort_name, ": expected 20 effect estimates.", call. = FALSE)
  }
  df_complete <- min(diagnostics$unique_person_clusters) -
    max(diagnostics$coefficient_n)
  pooled_list <- list(
    risk_continue = tte_pool_scalar(
      estimates$logit_risk_continue,
      estimates$variance_logit_risk_continue,
      df_complete = df_complete
    ),
    risk_discontinue = tte_pool_scalar(
      estimates$logit_risk_discontinue,
      estimates$variance_logit_risk_discontinue,
      df_complete = df_complete
    ),
    risk_difference = tte_pool_scalar(
      estimates$risk_difference,
      estimates$variance_risk_difference,
      df_complete = df_complete, null = 0
    ),
    risk_ratio = tte_pool_scalar(
      estimates$log_risk_ratio,
      estimates$variance_log_risk_ratio,
      df_complete = df_complete, null = 0
    )
  )
  transformers <- list(
    risk_continue = tte_expit,
    risk_discontinue = tte_expit,
    risk_difference = identity,
    risk_ratio = exp
  )
  null_values <- c(
    risk_continue = NA_real_, risk_discontinue = NA_real_,
    risk_difference = 0, risk_ratio = 1
  )
  for (measure_name in names(pooled_list)) {
    pooled <- pooled_list[[measure_name]]
    transform_value <- transformers[[measure_name]]
    key <- paste(cohort_name, measure_name, sep = "_")
    pooled_rows[[key]] <- data.table::data.table(
      cohort = cohort_name,
      outcome = outcome_name,
      outcome_label = outcome_label,
      target_years = target_years,
      measure = measure_name,
      estimate = transform_value(pooled$estimate),
      confidence_lower = transform_value(pooled$lower),
      confidence_upper = transform_value(pooled$upper),
      null_value = null_values[[measure_name]],
      p_value = if (measure_name %in% c("risk_difference", "risk_ratio")) {
        pooled$p_value
      } else {
        NA_real_
      },
      imputations = pooled$imputations,
      inference = "person-clustered CR1 sandwich; Rubin pooled",
      interpretation = if (measure_name == "risk_difference") {
        "discontinuation minus continuation"
      } else if (measure_name == "risk_ratio") {
        "discontinuation divided by continuation"
      } else {
        gsub("risk_", "standardized risk under ", measure_name)
      }
    )
    pooling_rows[[key]] <- data.table::data.table(
      cohort = cohort_name,
      outcome = outcome_name,
      measure = measure_name,
      pooled_transformed_estimate = pooled$estimate,
      transformed_standard_error = pooled$standard_error,
      degrees_freedom = pooled$degrees_freedom,
      within_variance = pooled$within_variance,
      between_variance = pooled$between_variance,
      total_variance = pooled$total_variance,
      relative_increase_variance = pooled$relative_increase_variance,
      fraction_missing_information = pooled$fraction_missing_information,
      complete_data_degrees_freedom = df_complete
    )
  }
}

pooled_effects <- data.table::rbindlist(
  pooled_rows, use.names = TRUE, fill = TRUE
)
pooling_diagnostics <- data.table::rbindlist(
  pooling_rows, use.names = TRUE, fill = TRUE
)
pooled_effects[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000, NA_real_
)]
pooled_effects[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000, NA_real_
)]
pooled_effects[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000, NA_real_
)]

model_summary <- model_diagnostics[, .(
  imputations = .N,
  all_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0L),
  any_warning = any(warning_n > 0L),
  observed_outcomes = unique(outcome_observations)[1L],
  unique_person_clusters = unique(unique_person_clusters)[1L],
  events = unique(events)[1L],
  min_iterations = min(iterations),
  max_iterations = max(iterations),
  minimum_CR1_correction = min(cluster_CR1_correction),
  maximum_CR1_correction = max(cluster_CR1_correction)
), by = .(cohort, outcome)]

data.table::setorder(effects_by_imputation, cohort, imputation)
data.table::setorder(pooled_effects, cohort, measure)
data.table::setorder(pooling_diagnostics, cohort, measure)
data.table::setorder(model_diagnostics, cohort, imputation)
data.table::setorder(model_summary, cohort)
data.table::setorder(sample_description, cohort, treatment)
data.table::setorder(join_checks, cohort, imputation)

tte_write_csv(
  effects_by_imputation,
  file.path(output_dir, "07h_functional_effects_by_imputation.csv")
)
tte_write_csv(
  pooled_effects,
  file.path(output_dir, "07h_functional_effects_pooled.csv")
)
tte_write_csv(
  pooling_diagnostics,
  file.path(output_dir, "07h_pooling_diagnostics.csv")
)
tte_write_csv(
  model_diagnostics,
  file.path(output_dir, "07h_model_diagnostics.csv")
)
tte_write_csv(
  model_summary,
  file.path(output_dir, "07h_model_summary.csv")
)
tte_write_csv(
  sample_description,
  file.path(output_dir, "07h_analysis_sample.csv")
)
tte_write_csv(join_checks, file.path(output_dir, "07h_join_checks.csv"))
writeLines(
  readLines(effect_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07h_frozen_functional_effect_model.yml"),
  useBytes = TRUE
)
saveRDS(
  list(
    effects_by_imputation = effects_by_imputation,
    pooled_effects = pooled_effects,
    pooling_diagnostics = pooling_diagnostics,
    model_diagnostics = model_diagnostics,
    config = effect_config
  ),
  file.path(private_dir, "stage07h_functional_estimates_PRIVATE.rds"),
  version = 3L
)

risk_plot_data <- pooled_effects[
  measure %in% c("risk_continue", "risk_discontinue")
]
risk_plot_data[, treatment_strategy := factor(
  measure,
  levels = c("risk_continue", "risk_discontinue"),
  labels = c("Continue", "Discontinue")
)]
risk_plot <- ggplot2::ggplot(
  risk_plot_data,
  ggplot2::aes(
    x = treatment_strategy, y = estimate,
    ymin = confidence_lower, ymax = confidence_upper,
    colour = treatment_strategy
  )
) +
  ggplot2::geom_pointrange(linewidth = 0.5) +
  ggplot2::facet_wrap(~cohort) +
  ggplot2::scale_y_continuous(
    labels = function(x) paste0(round(100 * x, 1), "%")
  ) +
  ggplot2::scale_colour_manual(values = c(
    "Continue" = "#2463A8", "Discontinue" = "#C44E52"
  )) +
  ggplot2::labs(
    x = NULL,
    y = "Standardized 3-year risk (95% CI)",
    title = "All-cause death or worsening in five common ADL items",
    subtitle = "Outcome-specific censoring weights; person-clustered inference"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "none")

rd_plot_data <- pooled_effects[measure == "risk_difference"]
rd_plot <- ggplot2::ggplot(
  rd_plot_data,
  ggplot2::aes(
    x = estimate * 1000, y = cohort,
    xmin = confidence_lower * 1000,
    xmax = confidence_upper * 1000,
    colour = cohort
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
  ggplot2::geom_errorbar(orientation = "y", width = 0.12, linewidth = 0.55) +
  ggplot2::geom_point(size = 2.3) +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52"
  )) +
  ggplot2::labs(
    x = "3-year risk difference per 1,000 (discontinue - continue)",
    y = NULL,
    colour = NULL,
    title = "Functional composite effect",
    subtitle = "Positive values indicate more death or ADL deterioration"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "none")

ggplot2::ggsave(
  file.path(output_dir, "07h_standardized_risk_plot.png"),
  risk_plot, width = 8.5, height = 5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07h_standardized_risk_plot.pdf"),
  risk_plot, width = 8.5, height = 5
)
ggplot2::ggsave(
  file.path(output_dir, "07h_risk_difference_plot.png"),
  rd_plot, width = 8.5, height = 4.5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "07h_risk_difference_plot.pdf"),
  rd_plot, width = 8.5, height = 4.5
)

primary_path <- file.path(
  project_root, analysis_config$output_root,
  "stage06_primary_effects", "06_primary_effects_pooled.csv"
)
component_path <- file.path(
  project_root, analysis_config$output_root,
  "stage07c_component_effects", "07c_component_effects_pooled.csv"
)
if (file.exists(primary_path) && file.exists(component_path)) {
  primary <- data.table::as.data.table(tte_read_csv_utf8(primary_path))[
    measure == "risk_difference"
  ]
  primary[, outcome_label := "Broad cardiovascular disease or death"]
  components <- data.table::as.data.table(
    tte_read_csv_utf8(component_path)
  )[measure == "risk_difference"]
  functional <- data.table::copy(rd_plot_data)
  comparison <- data.table::rbindlist(
    list(
      primary[, .(
        cohort, outcome, outcome_label, measure,
        estimate, confidence_lower, confidence_upper
      )],
      components[, .(
        cohort, outcome, outcome_label, measure,
        estimate, confidence_lower, confidence_upper
      )],
      functional[, .(
        cohort, outcome, outcome_label, measure,
        estimate, confidence_lower, confidence_upper
      )]
    ),
    use.names = TRUE, fill = TRUE
  )
  outcome_levels <- c(
    "Broad cardiovascular disease or death",
    "Myocardial infarction, stroke, or all-cause death",
    "All-cause death",
    outcome_label
  )
  comparison[, outcome_label := factor(
    outcome_label, levels = rev(outcome_levels)
  )]
  comparison_plot <- ggplot2::ggplot(
    comparison,
    ggplot2::aes(
      x = estimate * 1000, y = outcome_label,
      xmin = confidence_lower * 1000,
      xmax = confidence_upper * 1000,
      colour = cohort
    )
  ) +
    ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey50") +
    ggplot2::geom_errorbar(
      orientation = "y", width = 0.12, linewidth = 0.5,
      position = ggplot2::position_dodge(width = 0.45)
    ) +
    ggplot2::geom_point(
      size = 2.1,
      position = ggplot2::position_dodge(width = 0.45)
    ) +
    ggplot2::scale_colour_manual(values = c(
      "HRS" = "#2463A8", "SHARE" = "#C44E52"
    )) +
    ggplot2::labs(
      x = "3-year risk difference per 1,000 (discontinue - continue)",
      y = NULL,
      colour = "Cohort",
      title = "Three-year absolute effects across clinical outcomes"
    ) +
    ggplot2::theme_minimal(base_size = 10) +
    ggplot2::theme(legend.position = "bottom")
  ggplot2::ggsave(
    file.path(output_dir, "07h_all_outcome_risk_difference_plot.png"),
    comparison_plot, width = 11, height = 6.5, dpi = 220
  )
  ggplot2::ggsave(
    file.path(output_dir, "07h_all_outcome_risk_difference_plot.pdf"),
    comparison_plot, width = 11, height = 6.5
  )
}

effect_lines <- vapply(cohorts, function(cohort_name) {
  rd <- pooled_effects[
    cohort == cohort_name & measure == "risk_difference"
  ]
  rr <- pooled_effects[
    cohort == cohort_name & measure == "risk_ratio"
  ]
  paste0(
    cohort_name, "/", outcome_name,
    ": RD = ", sprintf("%.1f", rd$estimate_per_1000),
    " per 1,000 (95% CI ",
    sprintf("%.1f", rd$confidence_lower_per_1000), " to ",
    sprintf("%.1f", rd$confidence_upper_per_1000),
    "); RR = ", sprintf("%.3f", rr$estimate),
    " (95% CI ", sprintf("%.3f", rr$confidence_lower), " to ",
    sprintf("%.3f", rr$confidence_upper), ")."
  )
}, character(1L))

summary_lines <- c(
  "Stage 07h: death-or-ADL-decline effect estimation",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Target risk horizon: ", target_years, " years"),
  paste0("Cohorts estimated after Stage 07g gates: ", paste(cohorts, collapse = ", "), "."),
  "Outcome-specific Stage 07g censoring weights were used.",
  "Model: complementary log-log marginal structural outcome model with log follow-up offset.",
  "Adjustment: sequence in HRS; sequence plus country in SHARE.",
  "Inference: person-clustered CR1 sandwich within each imputation, then Rubin pooling.",
  "No cross-cohort meta-analysis was performed.",
  "",
  effect_lines,
  "",
  "Positive RD and RR > 1 indicate more death or ADL deterioration under observed discontinuation.",
  "The composite is interpreted alongside its all-cause death component, not in isolation.",
  "Do not interpret the exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(
  summary_lines,
  file.path(output_dir, "07h_stage_summary.txt"),
  useBytes = TRUE
)
writeLines(
  capture.output(sessionInfo()),
  file.path(output_dir, "07h_session_info.txt"),
  useBytes = TRUE
)

message(paste(summary_lines, collapse = "\n"))
message(
  "Stage 07h completed: ",
  normalizePath(output_dir, winslash = "/", mustWork = TRUE)
)
