# Assemble the JAHA figure-delivery folder and a separate supplemental Word file.
# All data transformations, figure generation, and document generation are run in R.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
output_root <- file.path(project_root, "outputs_r")
source_main_figure_dir <- file.path(output_root, "jaha_publication", "figures")
source_publication_dir <- file.path(output_root, "publication_ready")
submission_root <- file.path(output_root, "jaha_submission")
figure_dir <- file.path(submission_root, "all_figures_pdf_tiff")
word_image_dir <- file.path(submission_root, "word_figure_images")
table_dir <- file.path(submission_root, "supplement_tables")

for (path in c(figure_dir, word_image_dir, table_dir)) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
}

required_packages <- c("data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop("Missing required packages: ", paste(missing_packages, collapse = ", "), call. = FALSE)
}

library(data.table)
library(ggplot2)

read_output <- function(relative_path) {
  path <- file.path(output_root, relative_path)
  if (!file.exists(path)) stop("Missing frozen analysis output: ", path, call. = FALSE)
  data.table::fread(path, encoding = "UTF-8")
}

write_csv <- function(x, path) {
  data.table::fwrite(x, path, bom = TRUE, quote = TRUE, na = "")
}

blue <- "#0072B2"
orange <- "#D55E00"
green <- "#009E73"
gray <- "#5C5C5C"
font_family <- "Arial"

format_p_value <- function(p) {
  p <- suppressWarnings(as.numeric(p))
  ifelse(
    !is.finite(p), "",
    ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
  )
}

format_p_label <- function(p) {
  value <- format_p_value(p)
  ifelse(value == "<0.001", "P<0.001", paste0("P=", value))
}

modified_hk_p_value <- function(transformed_estimate, lower, upper, measure, df) {
  transformed_estimate <- suppressWarnings(as.numeric(transformed_estimate))
  lower <- suppressWarnings(as.numeric(lower))
  upper <- suppressWarnings(as.numeric(upper))
  df <- suppressWarnings(as.numeric(df))
  lower_transformed <- lower
  upper_transformed <- upper
  rr <- measure == "risk_ratio"
  lower_transformed[rr] <- log(lower[rr])
  upper_transformed[rr] <- log(upper[rr])
  standard_error <- (upper_transformed - lower_transformed) /
    (2 * stats::qt(0.975, df = df))
  2 * stats::pt(-abs(transformed_estimate / standard_error), df = df)
}

theme_jaha_supplement <- function(base_size = 10) {
  ggplot2::theme_classic(base_size = base_size, base_family = font_family) +
    ggplot2::theme(
      axis.title = ggplot2::element_text(size = 10, colour = "black"),
      axis.text = ggplot2::element_text(size = 9, colour = "black"),
      strip.background = ggplot2::element_blank(),
      strip.text = ggplot2::element_text(size = 10, face = "bold", colour = "black"),
      legend.title = ggplot2::element_blank(),
      legend.text = ggplot2::element_text(size = 9, colour = "black"),
      panel.grid.major.x = ggplot2::element_line(colour = "#E6E6E6", linewidth = 0.3),
      panel.grid.minor = ggplot2::element_blank(),
      plot.margin = ggplot2::margin(6, 8, 6, 6)
    )
}

open_device <- function(path, width, height, dpi = NULL) {
  extension <- tolower(tools::file_ext(path))
  if (extension == "pdf") {
    if (capabilities("cairo")) {
      grDevices::cairo_pdf(path, width = width, height = height, family = font_family)
    } else {
      grDevices::pdf(path, width = width, height = height, family = "sans")
    }
  } else if (extension %in% c("tif", "tiff")) {
    grDevices::tiff(
      path, width = width, height = height, units = "in", res = dpi,
      compression = "lzw", type = if (capabilities("cairo")) "cairo" else "windows",
      bg = "white"
    )
  } else if (extension == "png") {
    grDevices::png(
      path, width = width, height = height, units = "in", res = dpi,
      type = if (capabilities("cairo")) "cairo" else "windows", bg = "white"
    )
  } else {
    stop("Unsupported figure extension: ", extension, call. = FALSE)
  }
}

save_supplement_plot <- function(plot, stem, width, height, tiff_dpi = 600) {
  pdf_path <- file.path(figure_dir, paste0(stem, ".pdf"))
  tiff_path <- file.path(figure_dir, paste0(stem, ".tiff"))
  png_path <- file.path(word_image_dir, paste0(stem, ".png"))

  open_device(pdf_path, width, height)
  print(plot)
  grDevices::dev.off()

  open_device(tiff_path, width, height, tiff_dpi)
  print(plot)
  grDevices::dev.off()

  open_device(png_path, width, height, 300)
  print(plot)
  grDevices::dev.off()

  invisible(c(pdf = pdf_path, tiff = tiff_path, png = png_path))
}

# -----------------------------------------------------------------------------
# Copy the four verified main figures into the common PDF/TIFF delivery folder.
# -----------------------------------------------------------------------------

main_stems <- c(
  "Figure1_study_design_and_flow",
  "Figure2_cohort_specific_effects",
  "Figure3_frailty_effect_modification",
  "Figure4_primary_outcome_sensitivity"
)

for (stem in main_stems) {
  for (extension in c("pdf", "tiff")) {
    source_path <- file.path(source_main_figure_dir, paste0(stem, ".", extension))
    destination_path <- file.path(figure_dir, paste0(stem, ".", extension))
    if (!file.exists(source_path)) stop("Missing main figure: ", source_path, call. = FALSE)
    if (!file.copy(source_path, destination_path, overwrite = TRUE)) {
      stop("Could not copy main figure: ", destination_path, call. = FALSE)
    }
  }
}

# -----------------------------------------------------------------------------
# Figure S1: covariate balance before and after total weighting.
# -----------------------------------------------------------------------------

balance <- read_output("stage05_weighting/05_balance_summary.csv")
balance <- balance[
  balance_role == "confounder_gate" &
    balance_sample %in% c("eligible_unweighted", "after_total_weight")
]

base_labels <- c(
  B_age = "Age",
  B_income_rank = "Income rank",
  B_bmi = "Body mass index",
  B_depression_score = "Depression score",
  B_adl5_count = "ADL difficulty count",
  B_iadl5_count = "IADL difficulty count",
  FI_pre_treatment = "Frailty index",
  B_sex = "Sex",
  B_education = "Education",
  B_marital_status = "Marital status",
  B_living_arrangement = "Living arrangement",
  B_self_rated_health = "Self-rated health",
  B_current_smoking = "Current smoking",
  B_alcohol_use = "Alcohol use",
  B_hypertension = "Hypertension",
  B_diabetes = "Diabetes",
  B_cancer = "Cancer",
  B_lung_disease = "Lung disease",
  B_arthritis = "Arthritis",
  B_hospitalization = "Recent hospitalization",
  sequence = "Trial sequence",
  B_country = "Country"
)

balance[, base_label := ifelse(
  variable %in% names(base_labels),
  unname(base_labels[variable]),
  gsub("_", " ", variable, fixed = TRUE)
)]
balance[, level_text := ifelse(is.na(level) | !nzchar(as.character(level)), "", as.character(level))]
balance[, covariate_label := ifelse(
  nzchar(level_text), paste0(base_label, ": ", level_text), base_label
)]
balance[, weighting := factor(
  balance_sample,
  levels = c("eligible_unweighted", "after_total_weight"),
  labels = c("Before weighting", "After weighting")
)]
balance[, value := mean_absolute_standardized_difference]

balance_order <- balance[weighting == "Before weighting", .(
  order_value = max(value, na.rm = TRUE)
), by = .(cohort, covariate_label)]
balance <- merge(balance, balance_order, by = c("cohort", "covariate_label"), all.x = TRUE)
balance[, label_key := paste(cohort, covariate_label, sep = "___")]
ordered_keys <- balance_order[order(cohort, order_value), paste(cohort, covariate_label, sep = "___")]
balance[, label_key := factor(label_key, levels = unique(ordered_keys))]

figure_s1 <- ggplot2::ggplot(
  balance,
  ggplot2::aes(x = value, y = label_key, colour = weighting, shape = weighting)
) +
  ggplot2::geom_vline(xintercept = 0.10, linetype = "dashed", linewidth = 0.45,
                      colour = "#B2182B") +
  ggplot2::geom_point(size = 2.0, alpha = 0.95) +
  ggplot2::facet_wrap(~cohort, scales = "free_y", ncol = 2) +
  ggplot2::scale_y_discrete(labels = function(x) sub("^.*___", "", x)) +
  ggplot2::scale_colour_manual(values = c("Before weighting" = orange, "After weighting" = blue)) +
  ggplot2::scale_shape_manual(values = c("Before weighting" = 17, "After weighting" = 16)) +
  ggplot2::scale_x_continuous(expand = ggplot2::expansion(mult = c(0.01, 0.05))) +
  ggplot2::labs(x = "Absolute standardized mean difference", y = NULL) +
  theme_jaha_supplement(base_size = 9) +
  ggplot2::theme(
    axis.text.y = ggplot2::element_text(size = 6.7),
    legend.position = "bottom",
    panel.spacing.x = grid::unit(0.40, "in")
  )

save_supplement_plot(
  figure_s1, "FigureS1_covariate_balance",
  width = 7.2, height = 8.6, tiff_dpi = 600
)

# -----------------------------------------------------------------------------
# Figure S2: propensity score overlap in the first imputed data set.
# -----------------------------------------------------------------------------

propensity_parts <- list()
for (cohort_name in c("HRS", "SHARE")) {
  source_path <- file.path(
    output_root, "stage05_weighting", "private_do_not_share",
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(source_path)) stop("Missing weighted imputation file: ", source_path, call. = FALSE)
  first_imputation <- data.table::as.data.table(readRDS(source_path)[[1L]])
  propensity_parts[[cohort_name]] <- first_imputation[, .(
    cohort = cohort_name,
    propensity_score = as.numeric(propensity_score),
    treatment = suppressWarnings(as.integer(as.character(treatment)))
  )]
}
propensity <- data.table::rbindlist(propensity_parts)
propensity[, strategy := factor(
  treatment, levels = c(0, 1), labels = c("Continue", "Discontinue")
)]

figure_s2 <- ggplot2::ggplot(
  propensity,
  ggplot2::aes(x = propensity_score, colour = strategy, fill = strategy)
) +
  ggplot2::geom_density(alpha = 0.18, linewidth = 0.75, adjust = 1.05, na.rm = TRUE) +
  ggplot2::facet_wrap(~cohort, scales = "free_y", ncol = 2) +
  ggplot2::scale_colour_manual(values = c(Continue = blue, Discontinue = orange)) +
  ggplot2::scale_fill_manual(values = c(Continue = blue, Discontinue = orange)) +
  ggplot2::scale_x_continuous(limits = c(0, NA), expand = ggplot2::expansion(mult = c(0, 0.02))) +
  ggplot2::labs(x = "Propensity score", y = "Density") +
  theme_jaha_supplement() +
  ggplot2::theme(legend.position = "bottom")

save_supplement_plot(
  figure_s2, "FigureS2_propensity_overlap",
  width = 7.2, height = 4.5, tiff_dpi = 600
)

# -----------------------------------------------------------------------------
# Figure S3: unrestricted and prognosis-deterioration-restricted estimates.
# -----------------------------------------------------------------------------

primary_effect <- read_output("stage06_primary_effects/06_primary_effects_pooled.csv")
component_effect <- read_output("stage07c_component_effects/07c_component_effects_pooled.csv")
restricted_effect <- read_output("stage07f_restricted_effects/07f_restricted_effects_pooled.csv")

unrestricted <- data.table::rbindlist(
  list(primary_effect, component_effect), use.names = TRUE, fill = TRUE
)[measure == "risk_difference" & outcome %in% c("death_component", "primary_event", "strict_event")]
unrestricted[, analysis := "Unrestricted"]

restricted <- restricted_effect[
  measure == "risk_difference" & outcome %in% c("death_component", "primary_event", "strict_event")
]
restricted[, analysis := "Restricted"]

reverse_causation <- data.table::rbindlist(
  list(unrestricted, restricted), use.names = TRUE, fill = TRUE
)
reverse_causation[, p_label := format_p_label(p_value)]
outcome_short <- c(
  death_component = "All-cause death",
  primary_event = "Broad CVD or death",
  strict_event = "MI, stroke, or death"
)
reverse_causation[, outcome_panel := factor(
  outcome,
  levels = names(outcome_short),
  labels = unname(outcome_short)
)]
reverse_causation[, cohort := factor(cohort, levels = c("HRS", "SHARE"))]
reverse_causation[, analysis := factor(analysis, levels = c("Restricted", "Unrestricted"))]

figure_s3 <- ggplot2::ggplot(
  reverse_causation,
  ggplot2::aes(
    x = estimate_per_1000, y = analysis,
    colour = analysis
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.45, colour = gray) +
  ggplot2::geom_errorbar(
    ggplot2::aes(
      xmin = confidence_lower_per_1000,
      xmax = confidence_upper_per_1000
    ),
    orientation = "y", width = 0.14, linewidth = 0.60
  ) +
  ggplot2::geom_point(size = 2.4) +
  ggplot2::geom_text(
    ggplot2::aes(x = 145, label = p_label),
    hjust = 0.5, size = 2.55, show.legend = FALSE
  ) +
  ggplot2::facet_grid(cohort ~ outcome_panel) +
  ggplot2::scale_colour_manual(values = c(Restricted = green, Unrestricted = gray)) +
  ggplot2::scale_x_continuous(
    breaks = c(0, 40, 80, 120), limits = c(-50, 175)
  ) +
  ggplot2::labs(x = "3-year risk difference per 1,000", y = NULL) +
  theme_jaha_supplement() +
  ggplot2::theme(
    legend.position = "none",
    axis.text.y = ggplot2::element_text(size = 8.5)
  )

save_supplement_plot(
  figure_s3, "FigureS3_reverse_causation_sensitivity",
  width = 7.2, height = 4.8, tiff_dpi = 600
)

# -----------------------------------------------------------------------------
# Figure S4: cohort-specific and exploratory two-cohort pooled estimates.
# -----------------------------------------------------------------------------

meta_input <- read_output("stage09a_meta_analysis/09a_meta_input.csv")
meta_results <- read_output("stage09a_meta_analysis/09a_meta_results.csv")

meta_cohort <- meta_input[measure == "risk_difference", .(
  outcome,
  source = cohort,
  estimate_plot = 1000 * display_estimate,
  lower_plot = 1000 * display_lower,
  upper_plot = 1000 * display_upper,
  p_value = 2 * stats::pnorm(
    -abs(transformed_estimate / transformed_standard_error)
  )
)]
meta_pooled <- meta_results[measure == "risk_difference", .(
  outcome,
  source = "Pooled (modified HK)",
  estimate_plot = estimate_per_1000,
  lower_plot = modified_HK_lower_per_1000,
  upper_plot = modified_HK_upper_per_1000,
  p_value = modified_hk_p_value(
    transformed_estimate, modified_HK_lower, modified_HK_upper,
    measure, modified_HK_df
  )
)]
meta_figure <- data.table::rbindlist(list(meta_cohort, meta_pooled), use.names = TRUE)
meta_labels <- c(
  primary_event = "Broad CVD or death",
  strict_event = "MI, stroke, or death",
  death_component = "All-cause death",
  death_adl_decline = "Death or ADL decline"
)
meta_figure[, outcome_panel := factor(
  outcome,
  levels = names(meta_labels),
  labels = unname(meta_labels)
)]
meta_figure[, source := factor(
  source,
  levels = c("Pooled (modified HK)", "SHARE", "HRS")
)]
meta_figure[, `:=`(
  p_x = max(upper_plot, na.rm = TRUE) +
    0.18 * diff(range(c(lower_plot, upper_plot), na.rm = TRUE)),
  p_label = format_p_label(p_value)
), by = outcome]

figure_s4 <- ggplot2::ggplot(
  meta_figure,
  ggplot2::aes(x = estimate_plot, y = source, colour = source, shape = source)
) +
  ggplot2::geom_vline(xintercept = 0, linetype = "dashed", linewidth = 0.45, colour = gray) +
  ggplot2::geom_errorbar(
    ggplot2::aes(xmin = lower_plot, xmax = upper_plot),
    orientation = "y", width = 0.15, linewidth = 0.60
  ) +
  ggplot2::geom_point(size = 2.4) +
  ggplot2::geom_text(
    ggplot2::aes(x = p_x, label = p_label),
    hjust = 0.5, size = 2.7, show.legend = FALSE
  ) +
  ggplot2::facet_wrap(~outcome_panel, scales = "free_x", ncol = 2) +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = blue, "SHARE" = orange, "Pooled (modified HK)" = "black"
  )) +
  ggplot2::scale_shape_manual(values = c(
    "HRS" = 16, "SHARE" = 15, "Pooled (modified HK)" = 17
  )) +
  ggplot2::scale_x_continuous(
    expand = ggplot2::expansion(mult = c(0.05, 0.14))
  ) +
  ggplot2::labs(x = "3-year risk difference per 1,000", y = NULL) +
  theme_jaha_supplement() +
  ggplot2::theme(legend.position = "none")

save_supplement_plot(
  figure_s4, "FigureS4_two_cohort_meta_analysis",
  width = 7.2, height = 6.2, tiff_dpi = 600
)

# -----------------------------------------------------------------------------
# Figure S5: HRS-specific death or reported fall.
# -----------------------------------------------------------------------------

fall_effect <- read_output("stage07l_hrs_fall_effect/07l_effects_pooled.csv")
fall_risks <- fall_effect[measure %in% c("risk_continue", "risk_discontinue")]
fall_risks[, strategy := factor(
  measure,
  levels = c("risk_continue", "risk_discontinue"),
  labels = c("Continue", "Discontinue")
)]
fall_rd <- fall_effect[measure == "risk_difference"]
fall_rr <- fall_effect[measure == "risk_ratio"]
fall_p_label <- paste0(
  "Risk difference: P=", format_p_value(fall_rd$p_value),
  "    Risk ratio: P=", format_p_value(fall_rr$p_value)
)
fall_annotation_y <- max(fall_risks$confidence_upper, na.rm = TRUE) + 0.025

figure_s5 <- ggplot2::ggplot(
  fall_risks,
  ggplot2::aes(x = strategy, y = estimate, colour = strategy)
) +
  ggplot2::geom_errorbar(
    ggplot2::aes(ymin = confidence_lower, ymax = confidence_upper),
    width = 0.12, linewidth = 0.70
  ) +
  ggplot2::geom_point(size = 3.0) +
  ggplot2::annotate(
    "text", x = 1.5, y = fall_annotation_y,
    label = fall_p_label, family = font_family, size = 3.2
  ) +
  ggplot2::scale_colour_manual(values = c(Continue = blue, Discontinue = orange)) +
  ggplot2::scale_y_continuous(
    labels = function(x) sprintf("%.0f%%", 100 * x),
    limits = c(NA, fall_annotation_y + 0.025),
    expand = ggplot2::expansion(mult = c(0.08, 0.02))
  ) +
  ggplot2::labs(x = NULL, y = "Standardized 3-year risk (95% CI)") +
  theme_jaha_supplement() +
  ggplot2::theme(legend.position = "none")

save_supplement_plot(
  figure_s5, "FigureS5_hrs_death_or_fall",
  width = 6.4, height = 4.5, tiff_dpi = 600
)

