# Stage 05: multiple imputation, stabilized treatment/censoring weights, and
# balance diagnostics. This stage deliberately estimates no treatment effect.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)

required_packages <- c("yaml", "data.table", "mice", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  install_text <- paste0(
    "install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')"
  )
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: ", install_text,
    call. = FALSE
  )
}

config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
model_config <- tte_read_yaml_utf8(
  file.path(project_root, "config_r", "primary_weight_model.yml")
)
input_dir <- file.path(
  project_root, config$output_root, "stage04_structural_followup", "private_do_not_share"
)
output_dir <- file.path(project_root, config$output_root, "stage05_weighting")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
continuous_covariates <- unlist(model_config$continuous_covariates, use.names = FALSE)
categorical_covariates <- unlist(model_config$categorical_covariates, use.names = FALSE)
primary_covariates <- c(continuous_covariates, categorical_covariates)
spline_covariates <- unlist(model_config$spline_covariates, use.names = FALSE)
m_number <- as.integer(model_config$imputations)
max_iterations <- as.integer(model_config$iterations)
probability_floor <- as.numeric(model_config$probability_floor)
lower_quantile <- as.numeric(model_config$weight_lower_quantile)
upper_quantile <- as.numeric(model_config$weight_upper_quantile)
minimum_retention_probability <- as.numeric(
  model_config$minimum_acceptable_retention_probability
)

clamp_probability <- function(x) {
  pmax(probability_floor, pmin(1 - probability_floor, x))
}

safe_quantile <- function(x, probability) {
  value <- suppressWarnings(as.numeric(x))
  value <- value[is.finite(value)]
  if (!length(value)) return(NA_real_)
  as.numeric(stats::quantile(value, probability, names = FALSE, type = 2L))
}

effective_sample_size <- function(weight) {
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

weighted_mean <- function(x, weight) {
  valid <- !is.na(x) & is.finite(weight) & weight > 0
  if (!any(valid)) return(NA_real_)
  sum(weight[valid] * x[valid]) / sum(weight[valid])
}

weighted_variance <- function(x, weight) {
  valid <- !is.na(x) & is.finite(weight) & weight > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean(x[valid], weight[valid])
  sum(weight[valid] * (x[valid] - center)^2) / sum(weight[valid])
}

numeric_smd <- function(x, treatment, weight) {
  valid <- is.finite(suppressWarnings(as.numeric(x))) &
    treatment %in% c(0L, 1L) & is.finite(weight) & weight > 0
  x <- suppressWarnings(as.numeric(x))[valid]
  treatment <- treatment[valid]
  w <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  mean0 <- weighted_mean(x[treatment == 0L], w[treatment == 0L])
  mean1 <- weighted_mean(x[treatment == 1L], w[treatment == 1L])
  var0 <- weighted_variance(x[treatment == 0L], w[treatment == 0L])
  var1 <- weighted_variance(x[treatment == 1L], w[treatment == 1L])
  denominator <- sqrt((var0 + var1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (mean1 - mean0) / denominator
}

level_smd <- function(x, treatment, weight, level_value) {
  valid <- !is.na(x) & treatment %in% c(0L, 1L) & is.finite(weight) & weight > 0
  x <- as.character(x[valid])
  treatment <- treatment[valid]
  w <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  indicator <- as.numeric(x == level_value)
  p0 <- weighted_mean(indicator[treatment == 0L], w[treatment == 0L])
  p1 <- weighted_mean(indicator[treatment == 1L], w[treatment == 1L])
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

calculate_balance <- function(
  data, weight_name, sample_name, imputation, cohort_name,
  variables, categorical_variables
) {
  treatment <- as.integer(data$treatment)
  weight <- suppressWarnings(as.numeric(data[[weight_name]]))
  rows <- list()
  row_index <- 0L
  for (variable_name in variables) {
    x <- data[[variable_name]]
    if (variable_name %in% categorical_variables) {
      levels_present <- sort(unique(as.character(x[!is.na(x)])))
      for (level_value in levels_present) {
        row_index <- row_index + 1L
        rows[[row_index]] <- data.frame(
          cohort = cohort_name,
          imputation = imputation,
          balance_sample = sample_name,
          variable = variable_name,
          level = level_value,
          standardized_difference = level_smd(x, treatment, weight, level_value),
          stringsAsFactors = FALSE
        )
      }
    } else {
      row_index <- row_index + 1L
      rows[[row_index]] <- data.frame(
        cohort = cohort_name,
        imputation = imputation,
        balance_sample = sample_name,
        variable = variable_name,
        level = "",
        standardized_difference = numeric_smd(x, treatment, weight),
        stringsAsFactors = FALSE
      )
    }
  }
  result <- data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)
  result[, absolute_standardized_difference := abs(standardized_difference)]
  result
}

fit_binary_model <- function(formula, data, model_name, cohort_name, imputation) {
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::glm(
      formula = formula,
      data = data,
      family = stats::binomial(),
      control = stats::glm.control(maxit = 100, epsilon = 1e-8)
    ),
    warning = function(warning_condition) {
      warning_messages <<- c(warning_messages, conditionMessage(warning_condition))
      invokeRestart("muffleWarning")
    }
  )
  diagnostics <- data.table::data.table(
    cohort = cohort_name,
    imputation = imputation,
    model = model_name,
    converged = isTRUE(fit$converged),
    iterations = fit$iter,
    coefficient_n = length(stats::coef(fit)),
    aliased_coefficient_n = sum(is.na(stats::coef(fit))),
    warning_n = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    separation_or_convergence_warning = any(grepl(
      "did not converge|fitted probabilities numerically 0 or 1 occurred|algorithm stopped",
      warning_messages,
      ignore.case = TRUE
    ))
  )
  list(fit = fit, diagnostics = diagnostics)
}

model_term <- function(variable_name) {
  if (variable_name %in% spline_covariates) {
    paste0("splines::ns(", variable_name, ", df = 3)")
  } else {
    variable_name
  }
}

sample_flow_parts <- list()
missingness_parts <- list()
country_support_parts <- list()
mi_log_parts <- list()
model_diagnostic_parts <- list()
support_parts <- list()
weight_summary_parts <- list()
ess_parts <- list()
balance_parts <- list()
extreme_parts <- list()
plot_data_parts <- list()
model_specification_parts <- list()

for (cohort_index in seq_along(cohorts)) {
  cohort_name <- cohorts[[cohort_index]]
  input_path <- file.path(
    input_dir,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  if (!file.exists(input_path)) stop("Missing validated trials: ", input_path, call. = FALSE)
  trials <- data.table::as.data.table(readRDS(input_path))

  required_columns <- c(
    "person_id", "trial_id", "sequence", "treatment", "primary_event",
    "strict_event", "death_adl_decline", "L_survey_weight_final",
    "FI_pre_treatment", primary_covariates
  )
  if (cohort_name == "SHARE") required_columns <- c(required_columns, "B_country")
  missing_columns <- setdiff(required_columns, names(trials))
  if (length(missing_columns)) {
    stop(cohort_name, " is missing model variables: ", paste(missing_columns, collapse = ", "), call. = FALSE)
  }

  initial_n <- nrow(trials)
  valid_weight <- is.finite(suppressWarnings(as.numeric(trials$L_survey_weight_final))) &
    suppressWarnings(as.numeric(trials$L_survey_weight_final)) > 0
  trials <- trials[valid_weight]
  trials[, analysis_row_id := seq_len(.N)]
  trials[, outcome_observed := as.integer(!is.na(primary_event))]
  trials[, primary_event_aux := factor(
    ifelse(is.na(primary_event), "outcome_missing", paste0("event_", primary_event))
  )]
  trials[, sequence := factor(sequence)]
  if (cohort_name == "SHARE") {
    country_value <- as.character(trials$B_country)
    country_value[is.na(country_value) | !nzchar(country_value)] <- "UNKNOWN"
    trials[, B_country := factor(country_value)]
  }
  for (variable_name in categorical_covariates) {
    trials[, (variable_name) := factor(get(variable_name))]
  }
  for (variable_name in continuous_covariates) {
    trials[, (variable_name) := suppressWarnings(as.numeric(get(variable_name)))]
  }

  sample_flow_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    initial_person_trials = initial_n,
    excluded_nonpositive_or_missing_survey_weight = initial_n - nrow(trials),
    analysis_person_trials = nrow(trials),
    unique_persons = data.table::uniqueN(trials$person_id),
    continue_trials = sum(trials$treatment == 0L),
    discontinue_trials = sum(trials$treatment == 1L),
    observed_primary_outcomes = sum(trials$outcome_observed == 1L),
    primary_events = sum(trials$primary_event == 1L, na.rm = TRUE)
  )

  for (variable_name in primary_covariates) {
    missingness_parts[[paste(cohort_name, variable_name, sep = "_")]] <- trials[, .(
      person_trials = .N,
      missing_n = sum(is.na(get(variable_name))),
      missing_fraction = mean(is.na(get(variable_name)))
    ), by = treatment][, `:=`(cohort = cohort_name, variable = variable_name)]
  }

  if (cohort_name == "SHARE") {
    country_only <- trials[, .(
      person_trials = .N,
      unique_persons = data.table::uniqueN(person_id),
      observed_outcomes = sum(outcome_observed == 1L),
      primary_events = sum(primary_event == 1L, na.rm = TRUE)
    ), by = .(B_country, treatment)][, support_level := "country"]
    country_sequence <- trials[, .(
      person_trials = .N,
      unique_persons = data.table::uniqueN(person_id),
      observed_outcomes = sum(outcome_observed == 1L),
      primary_events = sum(primary_event == 1L, na.rm = TRUE)
    ), by = .(B_country, sequence, treatment)][, support_level := "country_sequence"]
    country_support_parts[[cohort_name]] <- data.table::rbindlist(
      list(country_only, country_sequence), use.names = TRUE, fill = TRUE
    )
  } else {
    country_support_parts[[cohort_name]] <- trials[, .(
      person_trials = .N,
      unique_persons = data.table::uniqueN(person_id),
      observed_outcomes = sum(outcome_observed == 1L),
      primary_events = sum(primary_event == 1L, na.rm = TRUE)
    ), by = .(sequence, treatment)][, `:=`(
      B_country = "United States", support_level = "country_sequence"
    )]
  }

  fixed_terms <- unlist(model_config$always_adjust[[cohort_name]], use.names = FALSE)
  mi_variables <- unique(c(
    primary_covariates, "treatment", "outcome_observed", "primary_event_aux", fixed_terms
  ))
  imputation_data <- as.data.frame(trials[, ..mi_variables])

  initialization <- mice::mice(
    imputation_data, m = 1L, maxit = 0L, printFlag = FALSE,
    remove.constant = TRUE, remove.collinear = TRUE
  )
  method <- initialization$method
  predictor_matrix <- initialization$predictorMatrix
  method[] <- ""
  for (variable_name in primary_covariates) {
    if (!anyNA(imputation_data[[variable_name]])) next
    if (variable_name %in% categorical_covariates) {
      observed_levels <- nlevels(droplevels(imputation_data[[variable_name]]))
      if (observed_levels < 2L) {
        stop(
          cohort_name, ": cannot impute ", variable_name,
          " because fewer than two observed levels remain.",
          call. = FALSE
        )
      }
      method[[variable_name]] <- if (observed_levels == 2L) "logreg" else "polyreg"
    } else {
      if (!any(is.finite(imputation_data[[variable_name]]), na.rm = TRUE)) {
        stop(cohort_name, ": cannot impute all-missing variable ", variable_name, call. = FALSE)
      }
      method[[variable_name]] <- "pmm"
    }
  }
  # Preserve exclusions identified by the zero-iteration MICE setup (for example,
  # constant or exactly collinear predictors) instead of silently reintroducing them.
  diag(predictor_matrix) <- 0L
  predictor_matrix[method == "", ] <- 0L
  # primary_event_aux already encodes both event status and whether the outcome
  # was missing. Keeping outcome_observed as a second imputation predictor makes
  # the two exactly redundant and produces one logged collinearity event for
  # every variable, chain, and iteration.
  if ("outcome_observed" %in% colnames(predictor_matrix)) {
    predictor_matrix[, "outcome_observed"] <- 0L
  }

  seed_value <- as.integer(config$seed) + cohort_index * 1000L
  message("Running ", m_number, " imputations for ", cohort_name, " ...")
  mids <- mice::mice(
    imputation_data,
    m = m_number,
    maxit = max_iterations,
    method = method,
    predictorMatrix = predictor_matrix,
    seed = seed_value,
    printFlag = TRUE,
    remove.constant = TRUE,
    remove.collinear = TRUE
  )
  saveRDS(mids, file.path(private_dir, paste0(tolower(cohort_name), "_mids_PRIVATE.rds")), version = 3L)

  if (!is.null(mids$loggedEvents) && nrow(mids$loggedEvents)) {
    log_table <- data.table::as.data.table(mids$loggedEvents)
    log_table[, cohort := cohort_name]
    mi_log_parts[[cohort_name]] <- log_table
  }

  imputed_variables <- names(mids$method)[nzchar(mids$method)]
  trace_mean <- data.table::as.data.table(as.table(mids$chainMean))
  data.table::setnames(trace_mean, c("variable", "iteration", "chain", "value"))
  trace_mean[, statistic := "mean"]
  trace_sd <- data.table::as.data.table(as.table(mids$chainVar))
  data.table::setnames(trace_sd, c("variable", "iteration", "chain", "value"))
  trace_sd[, value := sqrt(pmax(value, 0))]
  trace_sd[, statistic := "sd"]
  trace_data <- data.table::rbindlist(
    list(trace_mean, trace_sd), use.names = TRUE, fill = TRUE
  )
  trace_data <- trace_data[
    variable %in% imputed_variables & is.finite(value)
  ]
  trace_data[, iteration := as.integer(as.character(iteration))]
  trace_data[, chain := factor(chain)]
  trace_data[, variable := factor(variable, levels = imputed_variables)]
  trace_plot <- ggplot2::ggplot(
    trace_data,
    ggplot2::aes(x = iteration, y = value, group = chain, colour = chain)
  ) +
    ggplot2::geom_line(linewidth = 0.35, alpha = 0.70) +
    ggplot2::facet_grid(variable ~ statistic, scales = "free_y") +
    ggplot2::scale_x_continuous(breaks = seq_len(max_iterations)) +
    ggplot2::labs(
      x = "Iteration", y = NULL,
      title = paste0(cohort_name, " MICE chain traces"),
      subtitle = "All imputed variables; each line is one imputed dataset"
    ) +
    ggplot2::theme_minimal(base_size = 10) +
    ggplot2::theme(legend.position = "none")
  trace_height <- max(6, 1.35 * length(imputed_variables))
  ggplot2::ggsave(
    file.path(output_dir, paste0("05_mice_convergence_", tolower(cohort_name), ".png")),
    trace_plot, width = 12, height = trace_height, dpi = 220, limitsize = FALSE
  )
  ggplot2::ggsave(
    file.path(output_dir, paste0("05_mice_convergence_", tolower(cohort_name), ".pdf")),
    trace_plot, width = 12, height = trace_height, limitsize = FALSE
  )

  full_terms <- c(vapply(primary_covariates, model_term, character(1L)), fixed_terms)
  numerator_terms <- fixed_terms
  treatment_denominator_formula <- stats::as.formula(
    paste("treatment ~", paste(full_terms, collapse = " + "))
  )
  treatment_numerator_formula <- stats::as.formula(
    paste("treatment ~", paste(numerator_terms, collapse = " + "))
  )
  censor_denominator_formula <- stats::as.formula(
    paste("outcome_observed ~ treatment +", paste(full_terms, collapse = " + "))
  )
  censor_numerator_formula <- stats::as.formula(
    paste("outcome_observed ~ treatment +", paste(numerator_terms, collapse = " + "))
  )
  model_specification_parts[[cohort_name]] <- data.table::data.table(
    cohort = cohort_name,
    model = c(
      "treatment_denominator", "treatment_numerator",
      "censoring_denominator", "censoring_numerator"
    ),
    formula = c(
      paste(deparse(treatment_denominator_formula), collapse = " "),
      paste(deparse(treatment_numerator_formula), collapse = " "),
      paste(deparse(censor_denominator_formula), collapse = " "),
      paste(deparse(censor_numerator_formula), collapse = " ")
    )
  )

  diagnostic_covariates <- unique(c(primary_covariates, fixed_terms))
  diagnostic_categorical <- unique(c(categorical_covariates, fixed_terms))

  completed_weighted <- vector("list", m_number)
  base_fields <- trials[, .(
    analysis_row_id, person_id, trial_id, primary_event, strict_event,
    death_adl_decline, L_survey_weight_final
  )]

  for (imputation_index in seq_len(m_number)) {
    completed <- data.table::as.data.table(mice::complete(mids, action = imputation_index))
    completed <- cbind(base_fields, completed)
    completed[, treatment := as.integer(treatment)]
    completed[, outcome_observed := as.integer(outcome_observed)]
    residual_missing <- vapply(
      primary_covariates,
      function(variable_name) anyNA(completed[[variable_name]]),
      logical(1L)
    )
    if (any(residual_missing)) {
      stop(
        cohort_name, " imputation ", imputation_index,
        " retains missing primary covariates: ",
        paste(names(residual_missing)[residual_missing], collapse = ", "),
        call. = FALSE
      )
    }

    treatment_denominator <- fit_binary_model(
      treatment_denominator_formula, completed, "treatment_denominator",
      cohort_name, imputation_index
    )
    treatment_numerator <- fit_binary_model(
      treatment_numerator_formula, completed, "treatment_numerator",
      cohort_name, imputation_index
    )
    censor_denominator <- fit_binary_model(
      censor_denominator_formula, completed, "censor_denominator",
      cohort_name, imputation_index
    )
    censor_numerator <- fit_binary_model(
      censor_numerator_formula, completed, "censor_numerator",
      cohort_name, imputation_index
    )
    model_diagnostic_parts[[paste(cohort_name, imputation_index, sep = "_")]] <-
      data.table::rbindlist(list(
        treatment_denominator$diagnostics, treatment_numerator$diagnostics,
        censor_denominator$diagnostics, censor_numerator$diagnostics
      ), use.names = TRUE, fill = TRUE)

    completed[, propensity_score := clamp_probability(stats::predict(
      treatment_denominator$fit, newdata = completed, type = "response"
    ))]
    completed[, numerator_treatment_probability := clamp_probability(stats::predict(
      treatment_numerator$fit, newdata = completed, type = "response"
    ))]
    completed[, retention_probability := clamp_probability(stats::predict(
      censor_denominator$fit, newdata = completed, type = "response"
    ))]
    completed[, numerator_retention_probability := clamp_probability(stats::predict(
      censor_numerator$fit, newdata = completed, type = "response"
    ))]

    completed[, treatment_weight := ifelse(
      treatment == 1L,
      numerator_treatment_probability / propensity_score,
      (1 - numerator_treatment_probability) / (1 - propensity_score)
    )]
    # IPCW is defined only for records whose primary outcome is observed; records
    # with R = 0 are not used in the weighted outcome analysis.
    completed[, censoring_weight := ifelse(
      outcome_observed == 1L,
      numerator_retention_probability / retention_probability,
      NA_real_
    )]

    survey_strata <- if (cohort_name == "SHARE") c("sequence", "B_country") else "sequence"
    completed[, survey_weight_scaled := {
      value <- suppressWarnings(as.numeric(L_survey_weight_final))
      value / mean(value, na.rm = TRUE)
    }, by = survey_strata]

    completed[, treatment_analysis_weight_raw := survey_weight_scaled * treatment_weight]
    treatment_lower <- safe_quantile(completed$treatment_analysis_weight_raw, lower_quantile)
    treatment_upper <- safe_quantile(completed$treatment_analysis_weight_raw, upper_quantile)
    completed[, treatment_analysis_weight := pmax(
      treatment_lower, pmin(treatment_upper, treatment_analysis_weight_raw)
    )]

    completed[, total_weight_raw := ifelse(
      outcome_observed == 1L,
      survey_weight_scaled * treatment_weight * censoring_weight,
      NA_real_
    )]
    total_lower <- safe_quantile(completed$total_weight_raw, lower_quantile)
    total_upper <- safe_quantile(completed$total_weight_raw, upper_quantile)
    completed[, total_weight := ifelse(
      outcome_observed == 1L,
      pmax(total_lower, pmin(total_upper, total_weight_raw)),
      NA_real_
    )]

    arm0 <- completed[treatment == 0L, propensity_score]
    arm1 <- completed[treatment == 1L, propensity_score]
    support_lower <- max(min(arm0), min(arm1))
    support_upper <- min(max(arm0), max(arm1))
    support_fraction <- mean(
      completed$propensity_score >= support_lower &
        completed$propensity_score <= support_upper
    )
    support_parts[[paste(cohort_name, imputation_index, sep = "_")]] <- data.table::data.table(
      cohort = cohort_name,
      imputation = imputation_index,
      support_lower = support_lower,
      support_upper = support_upper,
      common_support_fraction = support_fraction,
      minimum_propensity_score = min(completed$propensity_score),
      maximum_propensity_score = max(completed$propensity_score),
      minimum_retention_probability = min(completed$retention_probability),
      maximum_retention_probability = max(completed$retention_probability),
      fraction_retention_probability_below_0_05 = mean(
        completed$retention_probability < 0.05
      ),
      any_retention_probability_below_0_01 = any(
        completed$retention_probability < minimum_retention_probability
      )
    )

    weight_summary_parts[[paste(cohort_name, imputation_index, sep = "_")]] <- completed[
      outcome_observed == 1L,
      .(
        observed_outcomes = .N,
        raw_weight_minimum = min(total_weight_raw),
        raw_weight_p01 = safe_quantile(total_weight_raw, 0.01),
        raw_weight_median = safe_quantile(total_weight_raw, 0.50),
        raw_weight_p99 = safe_quantile(total_weight_raw, 0.99),
        raw_weight_maximum = max(total_weight_raw),
        truncated_weight_minimum = min(total_weight),
        truncated_weight_median = safe_quantile(total_weight, 0.50),
        truncated_weight_maximum = max(total_weight)
      ),
      by = treatment
    ][, `:=`(cohort = cohort_name, imputation = imputation_index)]

    ess_parts[[paste(cohort_name, imputation_index, sep = "_")]] <- data.table::rbindlist(list(
      completed[outcome_observed == 1L, .(
        treatment = NA_integer_,
        effective_sample_size = effective_sample_size(total_weight)
      )],
      completed[outcome_observed == 1L, .(
        effective_sample_size = effective_sample_size(total_weight)
      ), by = treatment]
    ), use.names = TRUE, fill = TRUE)[, `:=`(
      cohort = cohort_name, imputation = imputation_index
    )]

    all_unweighted <- data.table::copy(completed)
    all_unweighted[, unit_weight := 1]
    balance_parts[[paste(cohort_name, imputation_index, "unweighted_all", sep = "_")]] <-
      calculate_balance(
        all_unweighted, "unit_weight", "eligible_unweighted",
        imputation_index, cohort_name, diagnostic_covariates, diagnostic_categorical
      )
    balance_parts[[paste(cohort_name, imputation_index, "treatment", sep = "_")]] <-
      calculate_balance(
        completed, "treatment_analysis_weight", "after_treatment_weight",
        imputation_index, cohort_name, diagnostic_covariates, diagnostic_categorical
      )
    observed_completed <- completed[outcome_observed == 1L]
    observed_completed[, unit_weight := 1]
    balance_parts[[paste(cohort_name, imputation_index, "observed_unweighted", sep = "_")]] <-
      calculate_balance(
        observed_completed, "unit_weight", "observed_unweighted",
        imputation_index, cohort_name, diagnostic_covariates, diagnostic_categorical
      )
    balance_parts[[paste(cohort_name, imputation_index, "total", sep = "_")]] <-
      calculate_balance(
        observed_completed, "total_weight", "after_total_weight",
        imputation_index, cohort_name, diagnostic_covariates, diagnostic_categorical
      )

    extreme_parts[[paste(cohort_name, imputation_index, sep = "_")]] <- completed[
      outcome_observed == 1L
    ][order(-total_weight_raw)][seq_len(min(.N, 10L)), .(
      cohort = cohort_name,
      imputation = imputation_index,
      analysis_row_id,
      treatment,
      sequence,
      propensity_score,
      retention_probability,
      treatment_weight,
      censoring_weight,
      survey_weight_scaled,
      total_weight_raw,
      total_weight
    )]

    completed[, cohort := cohort_name]
    completed[, imputation := imputation_index]
    completed_weighted[[imputation_index]] <- completed
    if (imputation_index == 1L) {
      plot_data_parts[[cohort_name]] <- completed[, .(
        cohort, treatment, propensity_score, total_weight_raw, total_weight,
        outcome_observed
      )]
    }
  }
  saveRDS(
    completed_weighted,
    file.path(private_dir, paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")),
    version = 3L
  )
}

sample_flow <- data.table::rbindlist(sample_flow_parts, use.names = TRUE, fill = TRUE)
missingness <- data.table::rbindlist(missingness_parts, use.names = TRUE, fill = TRUE)
data.table::setcolorder(
  missingness,
  c("cohort", "treatment", "variable", "person_trials", "missing_n", "missing_fraction")
)
country_support <- data.table::rbindlist(country_support_parts, use.names = TRUE, fill = TRUE)
mi_log <- if (length(mi_log_parts)) {
  data.table::rbindlist(mi_log_parts, use.names = TRUE, fill = TRUE)
} else {
  data.table::data.table(cohort = character(), message = character())
}
model_diagnostics <- data.table::rbindlist(model_diagnostic_parts, use.names = TRUE, fill = TRUE)
model_specification <- data.table::rbindlist(
  model_specification_parts, use.names = TRUE, fill = TRUE
)
support <- data.table::rbindlist(support_parts, use.names = TRUE, fill = TRUE)
weight_summary <- data.table::rbindlist(weight_summary_parts, use.names = TRUE, fill = TRUE)
ess <- data.table::rbindlist(ess_parts, use.names = TRUE, fill = TRUE)
balance <- data.table::rbindlist(balance_parts, use.names = TRUE, fill = TRUE)
balance[, balance_role := ifelse(
  variable %in% primary_covariates,
  "confounder_gate",
  "design_stratum_report_only"
)]
extreme_weights <- data.table::rbindlist(extreme_parts, use.names = TRUE, fill = TRUE)
plot_data <- data.table::rbindlist(plot_data_parts, use.names = TRUE, fill = TRUE)

balance_summary <- balance[, .(
  mean_standardized_difference = mean(standardized_difference, na.rm = TRUE),
  mean_absolute_standardized_difference = mean(absolute_standardized_difference, na.rm = TRUE),
  maximum_absolute_standardized_difference_across_imputations = max(
    absolute_standardized_difference, na.rm = TRUE
  )
), by = .(cohort, balance_sample, balance_role, variable, level)]

gate_balance <- balance[
  balance_sample == "after_total_weight" & balance_role == "confounder_gate",
  .(
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE)
), by = cohort]
gate_support <- support[, .(
  minimum_common_support_fraction = min(common_support_fraction)
), by = cohort]
gate_ess <- ess[!is.na(treatment), .(
  minimum_arm_effective_sample_size = min(effective_sample_size)
), by = cohort]
gate_models <- model_diagnostics[, .(
  all_models_converged = all(converged),
  total_model_warnings = sum(warning_n),
  maximum_aliased_coefficients = max(aliased_coefficient_n),
  any_separation_or_convergence_warning = any(separation_or_convergence_warning)
), by = cohort]
gate_retention <- support[, .(
  maximum_fraction_retention_below_0_05 = max(
    fraction_retention_probability_below_0_05
  ),
  any_retention_probability_below_0_01 = any(
    any_retention_probability_below_0_01
  )
), by = cohort]
weighting_gate <- Reduce(
  function(x, y) merge(x, y, by = "cohort", all = TRUE, sort = FALSE),
  list(gate_balance, gate_support, gate_ess, gate_models, gate_retention)
)
weighting_gate[, `:=`(
  passes_balance = maximum_absolute_smd <
    as.numeric(config$data_gates$maximum_absolute_standardized_difference),
  passes_common_support = minimum_common_support_fraction >=
    as.numeric(config$data_gates$minimum_common_support_fraction),
  passes_effective_sample_size = minimum_arm_effective_sample_size >=
    as.numeric(config$data_gates$minimum_weighted_effective_sample_size),
  passes_model_identifiability = all_models_converged &
    maximum_aliased_coefficients == 0L &
    !any_separation_or_convergence_warning,
  passes_retention_positivity =
    maximum_fraction_retention_below_0_05 <=
      as.numeric(model_config$maximum_fraction_retention_below_0_05) &
    !any_retention_probability_below_0_01
)]
weighting_gate[, ready_for_effect_estimation := passes_balance &
  passes_common_support & passes_effective_sample_size &
  passes_model_identifiability & passes_retention_positivity]

tte_write_csv(sample_flow, file.path(output_dir, "05_analysis_sample_flow.csv"))
tte_write_csv(missingness, file.path(output_dir, "05_preimputation_missingness.csv"))
tte_write_csv(country_support, file.path(output_dir, "05_country_treatment_support.csv"))
tte_write_csv(mi_log, file.path(output_dir, "05_mice_logged_events.csv"))
tte_write_csv(model_diagnostics, file.path(output_dir, "05_model_diagnostics.csv"))
tte_write_csv(model_specification, file.path(output_dir, "05_model_specification.csv"))
tte_write_csv(support, file.path(output_dir, "05_common_support.csv"))
tte_write_csv(weight_summary, file.path(output_dir, "05_weight_distribution.csv"))
tte_write_csv(ess, file.path(output_dir, "05_effective_sample_size.csv"))
tte_write_csv(balance, file.path(output_dir, "05_balance_all_imputations.csv"))
tte_write_csv(balance_summary, file.path(output_dir, "05_balance_summary.csv"))
tte_write_csv(extreme_weights, file.path(output_dir, "05_extreme_weights_deidentified.csv"))
tte_write_csv(weighting_gate, file.path(output_dir, "05_weighting_gate.csv"))

propensity_plot <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(x = propensity_score, colour = factor(treatment), fill = factor(treatment))
) +
  ggplot2::geom_density(alpha = 0.18, linewidth = 0.7) +
  ggplot2::facet_wrap(~cohort, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c("0" = "#2468A2", "1" = "#C14953")) +
  ggplot2::scale_fill_manual(values = c("0" = "#2468A2", "1" = "#C14953")) +
  ggplot2::labs(
    x = "Propensity score", y = "Density", colour = "Treatment",
    fill = "Treatment", title = "Propensity-score overlap (imputation 1)",
    subtitle = "0 = continue; 1 = discontinue"
  ) +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave(
  file.path(output_dir, "05_propensity_overlap.png"), propensity_plot,
  width = 9, height = 5.5, dpi = 300
)
ggplot2::ggsave(
  file.path(output_dir, "05_propensity_overlap.pdf"), propensity_plot,
  width = 9, height = 5.5
)

weight_plot_data <- plot_data[outcome_observed == 1L & is.finite(total_weight_raw)]
weight_plot <- ggplot2::ggplot(
  weight_plot_data,
  ggplot2::aes(x = log10(total_weight_raw), fill = factor(treatment))
) +
  ggplot2::geom_histogram(bins = 50, alpha = 0.55, position = "identity") +
  ggplot2::facet_wrap(~cohort, scales = "free_y") +
  ggplot2::scale_fill_manual(values = c("0" = "#2468A2", "1" = "#C14953")) +
  ggplot2::labs(
    x = "log10(raw total weight)", y = "Person-trials", fill = "Treatment",
    title = "Raw combined-weight distribution (imputation 1)"
  ) +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave(
  file.path(output_dir, "05_weight_distribution.png"), weight_plot,
  width = 9, height = 5.5, dpi = 300
)
ggplot2::ggsave(
  file.path(output_dir, "05_weight_distribution.pdf"), weight_plot,
  width = 9, height = 5.5
)

love_data <- balance_summary[
  balance_sample %in% c("observed_unweighted", "after_total_weight")
]
love_data[, display_name := ifelse(nzchar(level), paste0(variable, ":", level), variable)]
love_data <- love_data[, .(
  mean_abs_smd = mean(mean_absolute_standardized_difference, na.rm = TRUE)
), by = .(cohort, balance_sample, display_name)]
love_plot <- ggplot2::ggplot(
  love_data,
  ggplot2::aes(x = mean_abs_smd, y = stats::reorder(display_name, mean_abs_smd), shape = balance_sample)
) +
  ggplot2::geom_point(size = 2.1) +
  ggplot2::geom_vline(xintercept = 0.10, linetype = 2, colour = "#C14953") +
  ggplot2::facet_wrap(~cohort, scales = "free_y") +
  ggplot2::labs(
    x = "Mean absolute standardized difference", y = NULL, shape = "Sample",
    title = "Covariate balance before and after total weighting"
  ) +
  ggplot2::theme_minimal(base_size = 10)
ggplot2::ggsave(
  file.path(output_dir, "05_love_plot.png"), love_plot,
  width = 11, height = 11, dpi = 300, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "05_love_plot.pdf"), love_plot,
  width = 11, height = 11, limitsize = FALSE
)

summary_lines <- c(
  "Stage 05: multiple imputation and weighting diagnostics",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  paste0("Imputations per cohort: ", m_number),
  paste0("Cohorts passing every weighting gate: ", sum(weighting_gate$ready_for_effect_estimation),
         " of ", nrow(weighting_gate)),
  "",
  "No treatment effect was estimated in this stage.",
  "Proceed to Stage 06 only if balance, overlap, ESS, and convergence gates pass."
)
writeLines(summary_lines, file.path(output_dir, "05_stage_summary.txt"), useBytes = TRUE)
capture.output(sessionInfo(), file = file.path(output_dir, "05_session_info.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
