# Stage 08b: refit treatment/censoring weights and estimate the primary effect
# in landmark-age >=75 and >=80 target populations.

options(stringsAsFactors = FALSE)
project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_stage06_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_weighting_sensitivity_helpers.R"), encoding = "UTF-8", local = TRUE)

required_packages <- c("yaml", "data.table", "ggplot2", "splines")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically.", call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
weight_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "primary_weight_model.yml"))
age_config_path <- file.path(project_root, "config_r", "age_threshold_sensitivity.yml")
age_config <- tte_read_yaml_utf8(age_config_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_private <- file.path(
  project_root, analysis_config$output_root,
  "stage05_weighting", "private_do_not_share"
)
stage06_path <- file.path(
  project_root, analysis_config$output_root,
  "stage06_primary_effects", "06_primary_effects_pooled.csv"
)
output_dir <- file.path(
  project_root, analysis_config$output_root, "stage08b_age_sensitivity"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
age_thresholds <- as.numeric(unlist(age_config$thresholds, use.names = FALSE))
target_years <- as.numeric(age_config$target_risk_years)
lower_quantile <- as.numeric(age_config$weight_lower_quantile)
upper_quantile <- as.numeric(age_config$weight_upper_quantile)
probability_floor <- as.numeric(age_config$probability_floor)
continuous_covariates <- unlist(weight_config$continuous_covariates, use.names = FALSE)
categorical_covariates <- unlist(weight_config$categorical_covariates, use.names = FALSE)
spline_covariates <- unlist(weight_config$spline_covariates, use.names = FALSE)
primary_covariates <- c(continuous_covariates, categorical_covariates)

model_term <- function(variable_name) {
  if (variable_name %in% spline_covariates) {
    paste0("splines::ns(", variable_name, ", df = 3)")
  } else {
    variable_name
  }
}

effect_parts <- list()
weight_model_parts <- list()
outcome_model_parts <- list()
balance_parts <- list()
ess_parts <- list()
support_parts <- list()
sample_parts <- list()
join_parts <- list()

for (cohort_name in cohorts) {
  source_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(source_path) || !file.exists(stage05_path)) {
    stop("Missing Stage 08b input for ", cohort_name, call. = FALSE)
  }
  source_trials <- data.table::as.data.table(readRDS(source_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate source key.", call. = FALSE)
  }
  source_fields <- source_trials[, .(
    join_key,
    L_age = suppressWarnings(as.numeric(L_age)),
    followup_time_years = suppressWarnings(as.numeric(followup_time_years))
  )]
  completed_list <- readRDS(stage05_path)
  if (!is.list(completed_list) || length(completed_list) != 20L) {
    stop(cohort_name, ": Stage 05 must contain 20 datasets.", call. = FALSE)
  }

  fixed_terms <- unlist(weight_config$always_adjust[[cohort_name]], use.names = FALSE)
  full_terms <- c(vapply(primary_covariates, model_term, character(1L)), fixed_terms)
  treatment_denominator_formula <- stats::as.formula(
    paste("treatment ~", paste(full_terms, collapse = " + "))
  )
  treatment_numerator_formula <- stats::as.formula(
    paste("treatment ~", paste(fixed_terms, collapse = " + "))
  )
  censor_denominator_formula <- stats::as.formula(
    paste("outcome_observed ~ treatment +", paste(full_terms, collapse = " + "))
  )
  censor_numerator_formula <- stats::as.formula(
    paste("outcome_observed ~ treatment +", paste(fixed_terms, collapse = " + "))
  )
  outcome_formula_text <- paste0(
    "outcome_value ~ treatment + ", paste(fixed_terms, collapse = " + "),
    " + offset(log(followup_time_years))"
  )
  outcome_formula <- stats::as.formula(outcome_formula_text)
  diagnostic_variables <- unique(c(primary_covariates, fixed_terms))
  diagnostic_categorical <- unique(c(categorical_covariates, fixed_terms))
  survey_strata <- if (cohort_name == "SHARE") {
    c("sequence", "B_country")
  } else {
    "sequence"
  }

  for (imputation_index in seq_along(completed_list)) {
    base_completed <- data.table::as.data.table(
      data.table::copy(completed_list[[imputation_index]])
    )
    base_completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    source_index <- match(base_completed$join_key, source_fields$join_key)
    exact_join <- !anyNA(source_index) &&
      nrow(base_completed) == nrow(source_fields) &&
      !anyDuplicated(base_completed$join_key)
    if (!exact_join) {
      stop(
        cohort_name, ": Stage 04/05 join failed in imputation ",
        imputation_index, call. = FALSE
      )
    }
    base_completed[, L_age := source_fields$L_age[source_index]]
    base_completed[, followup_time_years :=
      source_fields$followup_time_years[source_index]]
    base_completed[, treatment := suppressWarnings(
      as.integer(as.character(treatment))
    )]
    base_completed[, outcome_observed := suppressWarnings(
      as.integer(outcome_observed)
    )]
    base_completed[, outcome_value := suppressWarnings(
      as.integer(primary_event)
    )]
    base_completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      base_completed[, B_country := droplevels(factor(B_country))]
    }

    for (age_threshold in age_thresholds) {
      analysis_name <- paste0("age_", age_threshold, "plus")
      completed <- data.table::copy(base_completed[L_age >= age_threshold])
      completed[, sequence := droplevels(factor(sequence))]
      if (cohort_name == "SHARE") {
        completed[, B_country := droplevels(factor(B_country))]
      }
      for (variable_name in categorical_covariates) {
        completed[, (variable_name) := droplevels(factor(get(variable_name)))]
      }
      if (!nrow(completed) || data.table::uniqueN(completed$treatment) != 2L) {
        stop(cohort_name, "/", analysis_name, ": both arms required.", call. = FALSE)
      }
      completed[, survey_weight_scaled := {
        value <- suppressWarnings(as.numeric(L_survey_weight_final))
        value / mean(value, na.rm = TRUE)
      }, by = survey_strata]

      treatment_denominator <- tte_sensitivity_fit_binary(
        treatment_denominator_formula, completed, "treatment_denominator",
        cohort_name, analysis_name, imputation_index
      )
      treatment_numerator <- tte_sensitivity_fit_binary(
        treatment_numerator_formula, completed, "treatment_numerator",
        cohort_name, analysis_name, imputation_index
      )
      censor_denominator <- tte_sensitivity_fit_binary(
        censor_denominator_formula, completed, "censoring_denominator",
        cohort_name, analysis_name, imputation_index
      )
      censor_numerator <- tte_sensitivity_fit_binary(
        censor_numerator_formula, completed, "censoring_numerator",
        cohort_name, analysis_name, imputation_index
      )
      weight_model_parts[[paste(
        cohort_name, analysis_name, imputation_index, sep = "_"
      )]] <- data.table::rbindlist(list(
        treatment_denominator$diagnostics,
        treatment_numerator$diagnostics,
        censor_denominator$diagnostics,
        censor_numerator$diagnostics
      ), use.names = TRUE, fill = TRUE)
      all_fits <- list(
        treatment_denominator$fit, treatment_numerator$fit,
        censor_denominator$fit, censor_numerator$fit
      )
      if (any(vapply(all_fits, function(fit) {
        !isTRUE(fit$converged) || anyNA(stats::coef(fit))
      }, logical(1L)))) {
        stop(
          cohort_name, "/", analysis_name,
          ": a weighting model was not identifiable.", call. = FALSE
        )
      }

      completed[, propensity_score := tte_sensitivity_clamp_probability(
        stats::predict(treatment_denominator$fit, newdata = completed, type = "response"),
        probability_floor
      )]
      completed[, numerator_treatment_probability :=
        tte_sensitivity_clamp_probability(
          stats::predict(treatment_numerator$fit, newdata = completed, type = "response"),
          probability_floor
        )]
      completed[, retention_probability := tte_sensitivity_clamp_probability(
        stats::predict(censor_denominator$fit, newdata = completed, type = "response"),
        probability_floor
      )]
      completed[, numerator_retention_probability :=
        tte_sensitivity_clamp_probability(
          stats::predict(censor_numerator$fit, newdata = completed, type = "response"),
          probability_floor
        )]
      completed[, treatment_weight := ifelse(
        treatment == 1L,
        numerator_treatment_probability / propensity_score,
        (1 - numerator_treatment_probability) / (1 - propensity_score)
      )]
      completed[, censoring_weight := ifelse(
        outcome_observed == 1L,
        numerator_retention_probability / retention_probability,
        NA_real_
      )]
      completed[, total_weight_raw := ifelse(
        outcome_observed == 1L,
        survey_weight_scaled * treatment_weight * censoring_weight,
        NA_real_
      )]
      weight_lower <- tte_sensitivity_quantile(
        completed$total_weight_raw, lower_quantile
      )
      weight_upper <- tte_sensitivity_quantile(
        completed$total_weight_raw, upper_quantile
      )
      completed[, total_weight := ifelse(
        outcome_observed == 1L,
        pmax(weight_lower, pmin(weight_upper, total_weight_raw)),
        NA_real_
      )]

      arm0 <- completed[treatment == 0L, propensity_score]
      arm1 <- completed[treatment == 1L, propensity_score]
      support_lower <- max(min(arm0), min(arm1))
      support_upper <- min(max(arm0), max(arm1))
      support_fraction <- mean(
        completed$propensity_score >= support_lower &
          completed$propensity_score <= support_upper
      )
      support_parts[[paste(
        cohort_name, analysis_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        analysis = analysis_name,
        age_threshold = age_threshold,
        imputation = imputation_index,
        support_lower = support_lower,
        support_upper = support_upper,
        common_support_fraction = support_fraction
      )

      observed <- completed[
        outcome_observed == 1L & !is.na(outcome_value) &
          is.finite(total_weight) & total_weight > 0
      ]
      observed[, model_weight := total_weight / mean(total_weight)]
      balance_parts[[paste(
        cohort_name, analysis_name, imputation_index, sep = "_"
      )]] <- tte_sensitivity_balance(
        observed, "total_weight", diagnostic_variables,
        diagnostic_categorical
      )[, `:=`(
        cohort = cohort_name,
        analysis = analysis_name,
        age_threshold = age_threshold,
        imputation = imputation_index
      )]
      ess_parts[[paste(
        cohort_name, analysis_name, imputation_index, sep = "_"
      )]] <- observed[, .(
        effective_sample_size = tte_sensitivity_ess(total_weight)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        analysis = analysis_name,
        age_threshold = age_threshold,
        imputation = imputation_index
      )]

      warning_messages <- character()
      fit <- withCallingHandlers(
        stats::glm(
          formula = outcome_formula,
          data = observed,
          family = stats::quasibinomial(link = "cloglog"),
          weights = model_weight,
          na.action = stats::na.fail,
          control = stats::glm.control(maxit = 100, epsilon = 1e-9)
        ),
        warning = function(warning_condition) {
          warning_messages <<- c(warning_messages, conditionMessage(warning_condition))
          invokeRestart("muffleWarning")
        }
      )
      if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
        stop(cohort_name, "/", analysis_name, ": outcome model failed.", call. = FALSE)
      }
      robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
      standardized <- tte_standardized_cloglog_effects(
        fit, robust$vcov, completed, completed$survey_weight_scaled,
        target_years
      )
      variance_continue <- standardized$risk_covariance[1L, 1L]
      variance_discontinue <- standardized$risk_covariance[2L, 2L]
      effect_key <- paste(
        cohort_name, analysis_name, imputation_index, sep = "_"
      )
      effect_parts[[effect_key]] <- data.table::data.table(
        cohort = cohort_name,
        analysis = analysis_name,
        age_threshold = age_threshold,
        imputation = imputation_index,
        risk_continue = standardized$risk_continue,
        logit_risk_continue = tte_logit(standardized$risk_continue),
        variance_logit_risk_continue = variance_continue /
          (standardized$risk_continue * (1 - standardized$risk_continue))^2,
        risk_discontinue = standardized$risk_discontinue,
        logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
        variance_logit_risk_discontinue = variance_discontinue /
          (standardized$risk_discontinue * (1 - standardized$risk_discontinue))^2,
        risk_difference = standardized$risk_difference,
        variance_risk_difference = standardized$variance_risk_difference,
        log_risk_ratio = standardized$log_risk_ratio,
        variance_log_risk_ratio = standardized$variance_log_risk_ratio
      )
      outcome_model_parts[[effect_key]] <- data.table::data.table(
        cohort = cohort_name,
        analysis = analysis_name,
        age_threshold = age_threshold,
        imputation = imputation_index,
        converged = isTRUE(fit$converged),
        aliased_coefficient_n = sum(is.na(stats::coef(fit))),
        warning_n = length(unique(warning_messages)),
        warnings = paste(unique(warning_messages), collapse = " | "),
        observations = nrow(observed),
        unique_person_clusters = robust$clusters,
        coefficient_n = length(stats::coef(fit)),
        events = sum(observed$outcome_value == 1L)
      )
      if (imputation_index == 1L) {
        sample_parts[[paste(cohort_name, analysis_name, sep = "_")]] <-
          completed[, .(
            person_trials = .N,
            unique_persons = data.table::uniqueN(person_id),
            observed_outcomes = sum(outcome_observed == 1L),
            events = sum(outcome_value == 1L, na.rm = TRUE)
          ), by = treatment][, `:=`(
            cohort = cohort_name,
            analysis = analysis_name,
            age_threshold = age_threshold
          )]
      }
      join_parts[[effect_key]] <- data.table::data.table(
        cohort = cohort_name,
        analysis = analysis_name,
        imputation = imputation_index,
        exact_join = exact_join
      )
    }
  }
}

effects <- data.table::rbindlist(effect_parts, use.names = TRUE, fill = TRUE)
weight_models <- data.table::rbindlist(weight_model_parts, use.names = TRUE, fill = TRUE)
outcome_models <- data.table::rbindlist(outcome_model_parts, use.names = TRUE, fill = TRUE)
balance <- data.table::rbindlist(balance_parts, use.names = TRUE, fill = TRUE)
ess <- data.table::rbindlist(ess_parts, use.names = TRUE, fill = TRUE)
support <- data.table::rbindlist(support_parts, use.names = TRUE, fill = TRUE)
sample_description <- data.table::rbindlist(sample_parts, use.names = TRUE, fill = TRUE)
join_checks <- data.table::rbindlist(join_parts, use.names = TRUE, fill = TRUE)

balance_gate <- balance[, .(
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE),
  largest_imbalance = paste0(
    variable[which.max(absolute_standardized_difference)],
    ifelse(level[which.max(absolute_standardized_difference)] == "", "",
           paste0("=", level[which.max(absolute_standardized_difference)]))
  )
), by = .(cohort, analysis, age_threshold)]
ess_gate <- ess[, .(
  minimum_arm_effective_sample_size = min(effective_sample_size)
), by = .(cohort, analysis, age_threshold)]
support_gate <- support[, .(
  minimum_common_support_fraction = min(common_support_fraction)
), by = .(cohort, analysis, age_threshold)]
model_gate <- data.table::rbindlist(list(
  weight_models[, .(
    converged, aliased_coefficient_n, warning_n
  ), by = .(cohort, analysis, imputation)],
  outcome_models[, .(
    cohort, analysis, imputation, converged,
    aliased_coefficient_n, warning_n
  )]
), use.names = TRUE, fill = TRUE)[, .(
  all_models_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0L),
  any_warning = any(warning_n > 0L)
), by = .(cohort, analysis)]
model_gate <- merge(
  model_gate,
  unique(effects[, .(cohort, analysis, age_threshold)]),
  by = c("cohort", "analysis"), all.x = TRUE
)
sample_gate <- sample_description[, .(
  smaller_arm_person_trials = min(person_trials),
  smaller_arm_events = min(events),
  total_events = sum(events)
), by = .(cohort, analysis, age_threshold)]
gate <- Reduce(
  function(x, y) merge(
    x, y, by = c("cohort", "analysis", "age_threshold"), all = TRUE
  ),
  list(sample_gate, balance_gate, ess_gate, support_gate, model_gate)
)
thresholds <- age_config$gates
gate[, pass_sample := smaller_arm_person_trials >= as.numeric(
  thresholds$minimum_smaller_arm_person_trials
) & smaller_arm_events >= as.numeric(
  thresholds$minimum_events_each_arm
) & total_events >= as.numeric(thresholds$minimum_total_events)]
gate[, pass_balance := maximum_absolute_smd < as.numeric(
  thresholds$maximum_absolute_standardized_difference
)]
gate[, pass_ess := minimum_arm_effective_sample_size >= as.numeric(
  thresholds$minimum_effective_sample_size_each_arm
)]
gate[, pass_support := minimum_common_support_fraction >= as.numeric(
  thresholds$minimum_common_support_fraction
)]
gate[, pass_models := all_models_converged & !any_alias & !any_warning]
gate[, ready_for_effect_interpretation :=
  pass_sample & pass_balance & pass_ess & pass_support & pass_models]

pooled_parts <- list()
for (i in seq_len(nrow(gate))) {
  gate_row <- gate[i]
  if (!isTRUE(gate_row$ready_for_effect_interpretation)) next
  point <- effects[
    cohort == gate_row$cohort & analysis == gate_row$analysis
  ]
  diagnostics <- outcome_models[
    cohort == gate_row$cohort & analysis == gate_row$analysis
  ]
  df_complete <- min(diagnostics$unique_person_clusters) -
    max(diagnostics$coefficient_n)
  pools <- list(
    risk_continue = tte_pool_scalar(
      point$logit_risk_continue, point$variance_logit_risk_continue,
      df_complete
    ),
    risk_discontinue = tte_pool_scalar(
      point$logit_risk_discontinue, point$variance_logit_risk_discontinue,
      df_complete
    ),
    risk_difference = tte_pool_scalar(
      point$risk_difference, point$variance_risk_difference,
      df_complete, null = 0
    ),
    risk_ratio = tte_pool_scalar(
      point$log_risk_ratio, point$variance_log_risk_ratio,
      df_complete, null = 0
    )
  )
  transformers <- list(
    risk_continue = tte_expit,
    risk_discontinue = tte_expit,
    risk_difference = identity,
    risk_ratio = exp
  )
  for (measure_name in names(pools)) {
    pool <- pools[[measure_name]]
    transform <- transformers[[measure_name]]
    pooled_parts[[paste(
      gate_row$cohort, gate_row$analysis, measure_name, sep = "_"
    )]] <- data.table::data.table(
      cohort = gate_row$cohort,
      outcome = as.character(age_config$outcome$name),
      outcome_label = as.character(age_config$outcome$label),
      analysis = gate_row$analysis,
      age_threshold = gate_row$age_threshold,
      measure = measure_name,
      estimate = transform(pool$estimate),
      confidence_lower = transform(pool$lower),
      confidence_upper = transform(pool$upper),
      p_value = if (measure_name %in%
        c("risk_difference", "risk_ratio")) pool$p_value else NA_real_
    )
  }
}
pooled <- data.table::rbindlist(pooled_parts, use.names = TRUE, fill = TRUE)
if (nrow(pooled)) {
  pooled[, estimate_per_1000 := ifelse(
    measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
    estimate * 1000, NA_real_
  )]
  pooled[, confidence_lower_per_1000 := ifelse(
    measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
    confidence_lower * 1000, NA_real_
  )]
  pooled[, confidence_upper_per_1000 := ifelse(
    measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
    confidence_upper * 1000, NA_real_
  )]
}

tte_write_csv(sample_description, file.path(output_dir, "08b_sample_and_events.csv"))
tte_write_csv(gate, file.path(output_dir, "08b_age_weighting_gate.csv"))
tte_write_csv(pooled, file.path(output_dir, "08b_age_effects_pooled.csv"))
tte_write_csv(effects, file.path(output_dir, "08b_age_effects_by_imputation.csv"))
tte_write_csv(balance_gate, file.path(output_dir, "08b_balance_summary.csv"))
tte_write_csv(ess, file.path(output_dir, "08b_effective_sample_size.csv"))
tte_write_csv(support, file.path(output_dir, "08b_common_support.csv"))
tte_write_csv(weight_models, file.path(output_dir, "08b_weight_model_diagnostics.csv"))
tte_write_csv(outcome_models, file.path(output_dir, "08b_outcome_model_diagnostics.csv"))
tte_write_csv(join_checks, file.path(output_dir, "08b_join_checks.csv"))
writeLines(
  readLines(age_config_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "08b_frozen_age_threshold_sensitivity.yml"),
  useBytes = TRUE
)
saveRDS(
  list(effects = effects, pooled = pooled, gate = gate, config = age_config),
  file.path(private_dir, "stage08b_age_sensitivity_PRIVATE.rds"),
  version = 3L
)

plot_data <- if (nrow(pooled)) pooled[measure == "risk_difference"] else data.table::data.table()
if (file.exists(stage06_path)) {
  primary <- data.table::as.data.table(tte_read_csv_utf8(stage06_path))[
    measure == "risk_difference"
  ][, .(
    cohort,
    analysis = "age_70plus_primary",
    age_threshold = 70,
    estimate, confidence_lower, confidence_upper
  )]
  plot_data <- data.table::rbindlist(list(
    primary,
    plot_data[, .(
      cohort, analysis, age_threshold,
      estimate, confidence_lower, confidence_upper
    )]
  ), use.names = TRUE, fill = TRUE)
}
if (nrow(plot_data)) {
  plot_data[, age_label := paste0("Age >=", age_threshold)]
  age_plot <- ggplot2::ggplot(
    plot_data,
    ggplot2::aes(
      x = estimate * 1000, y = age_label,
      xmin = confidence_lower * 1000,
      xmax = confidence_upper * 1000,
      colour = cohort
    )
  ) +
    ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey45") +
    ggplot2::geom_errorbar(
      orientation = "y", width = 0.12,
      position = ggplot2::position_dodge(width = 0.45)
    ) +
    ggplot2::geom_point(
      size = 2.2,
      position = ggplot2::position_dodge(width = 0.45)
    ) +
    ggplot2::scale_colour_manual(values = c(
      "HRS" = "#2463A8", "SHARE" = "#C44E52"
    )) +
    ggplot2::labs(
      x = "3-year risk difference per 1,000",
      y = NULL, colour = "Cohort",
      title = "Primary effect across landmark-age thresholds"
    ) +
    ggplot2::theme_minimal(base_size = 10) +
    ggplot2::theme(legend.position = "bottom")
  ggplot2::ggsave(
    file.path(output_dir, "08b_age_effect_plot.png"),
    age_plot, width = 9, height = 5.5, dpi = 220
  )
  ggplot2::ggsave(
    file.path(output_dir, "08b_age_effect_plot.pdf"),
    age_plot, width = 9, height = 5.5
  )
} else {
  stop("No age-restricted analysis passed all gates.", call. = FALSE)
}

gate_lines <- vapply(seq_len(nrow(gate)), function(i) {
  row <- gate[i]
  paste0(
    row$cohort, "/age>=", row$age_threshold,
    ": smaller-arm trials=", row$smaller_arm_person_trials,
    ", smaller-arm events=", row$smaller_arm_events,
    ", max |SMD|=", sprintf("%.3f", row$maximum_absolute_smd),
    ", min ESS=", sprintf("%.1f", row$minimum_arm_effective_sample_size),
    ", support=", sprintf("%.3f", row$minimum_common_support_fraction),
    ", ready=", row$ready_for_effect_interpretation
  )
}, character(1L))
effect_rows <- pooled[measure == "risk_difference"]
effect_lines <- if (nrow(effect_rows)) vapply(seq_len(nrow(effect_rows)), function(i) {
  rd <- effect_rows[i]
  rr <- pooled[
    cohort == rd$cohort & analysis == rd$analysis & measure == "risk_ratio"
  ]
  paste0(
    rd$cohort, "/age>=", rd$age_threshold,
    ": RD=", sprintf("%.1f", rd$estimate_per_1000),
    " per 1,000 (95% CI ",
    sprintf("%.1f", rd$confidence_lower_per_1000), " to ",
    sprintf("%.1f", rd$confidence_upper_per_1000),
    "); RR=", sprintf("%.3f", rr$estimate),
    " (95% CI ", sprintf("%.3f", rr$confidence_lower), " to ",
    sprintf("%.3f", rr$confidence_upper), ")."
  )
}, character(1L)) else "No age-restricted effect passed every gate."
summary_lines <- c(
  "Stage 08b: landmark-age threshold sensitivity analysis",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Treatment and censoring models were refitted within age >=75 and >=80 populations.",
  "No threshold was interpreted unless all frozen sample, balance, overlap, ESS, and model gates passed.",
  "", "Diagnostic gates:", gate_lines,
  "", "Interpretable effects:", effect_lines,
  "",
  "These are nested target populations and are not formal treatment-by-age interaction tests."
)
writeLines(summary_lines, file.path(output_dir, "08b_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "08b_session_info.txt"), useBytes = TRUE)
message(paste(summary_lines, collapse = "\n"))
message("Stage 08b completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
