# Run from the project root. Reads aggregate diagnostics only.
suppressPackageStartupMessages(library(data.table))

read_output <- function(path) fread(file.path("outputs_r", path))
stage05 <- read_output("stage05_weighting/05_balance_summary.csv")
table1 <- read_output("revision_r1/Table1_baseline_characteristics.csv")
compare <- rbindlist(list(
  stage05[cohort == "HRS" & variable == "B_current_smoking" & level == "1",
          .(cohort, characteristic = "Current smoking", balance_sample,
            mean_absolute_standardized_difference)],
  stage05[cohort == "SHARE" & variable == "FI_pre_treatment",
          .(cohort, characteristic = "Frailty index", balance_sample,
            mean_absolute_standardized_difference)]
))
stage_values <- dcast(compare, cohort + characteristic ~ balance_sample,
                     value.var = "mean_absolute_standardized_difference")
checks <- merge(stage_values, table1, by.x = c("cohort", "characteristic"),
                by.y = c("Cohort", "Characteristic"))
stopifnot(nrow(checks) == 2L,
          all(round(checks$eligible_unweighted, 3) == as.numeric(checks$`SMD before`)),
          all(round(checks$after_treatment_weight, 3) == as.numeric(checks$`SMD after`)))

gate <- read_output("stage05_weighting/05_weighting_gate.csv")
main <- stage05[balance_sample == "after_total_weight" & balance_role == "confounder_gate",
                .SD[which.max(maximum_absolute_standardized_difference_across_imputations)], by = cohort]
stopifnot(isTRUE(all.equal(
  main$maximum_absolute_standardized_difference_across_imputations,
  gate$maximum_absolute_smd[match(main$cohort, gate$cohort)]
)), all(gate$passes_balance))

alt <- read_output("stage08a_alternative_weights/08a_weighting_gate.csv")[
  ready_for_effect_interpretation == FALSE]
age <- read_output("stage08b_age_sensitivity/08b_age_weighting_gate.csv")[
  ready_for_effect_interpretation == FALSE]
prior <- read_output("stage08c_prior_visit_only/08c_weighting_gate.csv")[
  ready_for_effect_interpretation == FALSE]
stopifnot(!any(c(alt$pass_balance, age$pass_balance, prior$pass_balance)))
corrected_dir <- "revision_r1/deterioration_corrected/stage07e_restricted_weights"
restricted <- read_output(file.path(corrected_dir, "07e_weighting_gate.csv"))[
  ready_for_restricted_effect_estimation == FALSE]
restricted_balance <- read_output(file.path(corrected_dir, "07e_balance_all_imputations.csv"))[
  balance_sample == "after_restricted_total_weight" &
    (variable_group == "primary_covariate" |
      (variable_group == "prognosis_change" & minimum_arm_observed_fraction >= 0.80))
]
restricted_max <- restricted_balance[, .SD[which.max(absolute_standardized_difference)],
                                     by = .(cohort, restriction, outcome, variable_group)]
restricted_max <- dcast(restricted_max[, .(
  cohort, restriction, outcome, variable_group,
  feature = paste0(variable, ifelse(!is.na(level) & nzchar(level), paste0("=", level), "")),
  max_smd = absolute_standardized_difference
)], cohort + restriction + outcome ~ variable_group, value.var = c("feature", "max_smd"))
restricted <- merge(restricted, restricted_max, by = c("cohort", "restriction", "outcome"))
stopifnot(all(!restricted$pass_primary_balance | !restricted$pass_change_balance),
          isTRUE(all.equal(restricted$max_smd_primary_covariate,
                           restricted$maximum_absolute_primary_covariate_smd)),
          isTRUE(all.equal(restricted$max_smd_prognosis_change,
                           restricted$maximum_absolute_change_variable_smd)))

primary_label <- "Cardiovascular disease or death"
outcome_labels <- c(primary_event = primary_label, strict_event = "MI, stroke, or death",
                    death_component = "All-cause death")
scheme_labels <- c(iptw_2.5_97.5 = "2.5th/97.5th percentile truncation",
                   iptw_5_95 = "5th/95th percentile truncation")
restriction_labels <- c(exclude_multiple_deterioration_markers = "Exclude >=2 deterioration markers",
                        exclude_severe_deterioration = "Exclude any severe deterioration marker")
feature_labels <- c("sequence=HRS_14_15_16" = "HRS Waves 14-15-16 sequence",
                    "B_country=23" = "Belgium (country indicator)",
                    "B_country=11" = "Austria (country indicator)",
                    "fi_worsening_005" = "Frailty-index increase of >=0.05",
                    "B_self_rated_health=2" = "Self-rated health (category 2)",
                    "self_rated_health_worsened" = "Worsening self-rated health",
                    "marked_bmi_loss" = "BMI decrease of >=2 kg/m2",
                    "multiple_deterioration_markers" = "At least two deterioration markers")
failed <- rbindlist(list(
  alt[, .(analysis = scheme_labels[scheme], cohort, outcome = primary_label,
          feature = largest_imbalance, max_smd = maximum_absolute_smd,
          smd_display = sprintf("%.3f", maximum_absolute_smd),
          ess = minimum_arm_effective_sample_size, additional = "")],
  age[, .(analysis = paste0("Age >=", age_threshold, " years"), cohort, outcome = primary_label,
          feature = largest_imbalance, max_smd = maximum_absolute_smd,
          smd_display = sprintf("%.3f", maximum_absolute_smd),
          ess = minimum_arm_effective_sample_size, additional = "")],
  prior[, .(analysis = "Preceding-visit covariates", cohort, outcome = primary_label,
            feature = largest_imbalance, max_smd = maximum_absolute_smd,
            smd_display = sprintf("%.3f", maximum_absolute_smd),
            ess = minimum_arm_effective_sample_size, additional = "")],
  restricted[, .(analysis = restriction_labels[restriction], cohort, outcome = outcome_labels[outcome],
                 feature = ifelse(max_smd_prognosis_change > max_smd_primary_covariate,
                                  feature_prognosis_change, feature_primary_covariate),
                 max_smd = pmax(max_smd_primary_covariate, max_smd_prognosis_change),
                 smd_display = sprintf("%.3f covariates / %.3f change", max_smd_primary_covariate,
                                       max_smd_prognosis_change),
                 ess = minimum_arm_effective_sample_size,
                 additional = ifelse(pass_total_events, "", sprintf("%d total events (<100)", total_events)))]
))
stopifnot(nrow(failed) == nrow(alt) + nrow(age) + nrow(prior) + nrow(restricted),
          all(failed$max_smd >= 0.10))
unknown_labels <- setdiff(failed$feature, names(feature_labels))
if (length(unknown_labels)) stop("Missing labels for: ", paste(unknown_labels, collapse = ", "))

out <- c(
  "# Reconciliation of the balance diagnostics", "",
  "## Reviewer examples", "",
  "| Cohort | Characteristic | Table 1 and revised Figure S1, weighted | Original Figure S1, weighted |",
  "|:--|:--|--:|--:|",
  with(checks, sprintf("| %s | %s | %.3f | %.3f |", cohort, characteristic,
                       after_treatment_weight, after_total_weight)), "",
  "Table 1 and revised Figure S1 use the same display values for eligible entries before and after survey and medication-status weighting. The original Figure S1 used combined survey, medication-status, and outcome-observation weights for its weighted points among entries with observed outcomes. The displays use mean absolute standardized mean differences (SMDs) across 20 imputations.",
  "", "## Primary balance criterion", "",
  "The gate used the largest absolute SMD across 20 imputations and the 20 adjustment covariates (including individual levels for categorical covariates) after combined weighting of outcome-observed entries. The maximum was 0.066 for education in HRS and 0.093 for alcohol use in SHARE. Both cohorts passed the <0.10 criterion. Sequence and country were reported separately for the primary balance diagnostic and were included in the balance gate for the alternative-weight, age-restricted, and preceding-visit analyses when applicable.",
  "", "## Supplementary Table S6. Analyses that failed the balance criterion", "",
  "| Analysis | Cohort | Outcome | Largest imbalance | Maximum absolute SMD | Minimum arm ESS | Additional reason |",
  "|:--|:--|:--|:--|--:|--:|:--|",
  with(failed, sprintf("| %s | %s | %s | %s | %s | %.1f | %s |", analysis, cohort, outcome,
                       feature_labels[feature], smd_display, ess, additional)),
  "", "Each row identifies the diagnostic with the largest absolute SMD after the analysis-specific weighting, across all 20 imputations. In the deterioration restrictions, the balance criterion was applied separately to adjustment covariates and health-change indicators. Health-change indicators were assessed when observed in at least 80% of each group. ESS, effective sample size. MI, myocardial infarction."
)
destination <- "outputs_r/revision_r1/R1_balance_diagnostic_reconciliation.md"
writeLines(out, destination)
message("Aggregate balance reconciliation written to ", destination)
