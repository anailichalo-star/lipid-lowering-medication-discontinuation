# Stage 07e: rebuild treatment and outcome-specific censoring weights within
# prognosis-restricted populations. No treatment effect is estimated here.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_stage07e_helpers.R"), encoding = "UTF-8", local = TRUE)
tte_require_packages(c("yaml", "data.table", "ggplot2"))

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
primary_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "primary_weight_model.yml"))
sensitivity_path <- file.path(project_root, "config_r", "reverse_causation_sensitivity.yml")
sensitivity_config <- tte_read_yaml_utf8(sensitivity_path)

output_root <- file.path(project_root, analysis_config$output_root)
stage05_private <- file.path(output_root, "stage05_weighting", "private_do_not_share")
restriction_root <- getOption("tte.restriction_output_root", output_root)
stage07d_dir <- file.path(restriction_root, "stage07d_deterioration_audit")
stage07d_private <- file.path(stage07d_dir, "private_do_not_share")
output_dir <- file.path(restriction_root, "stage07e_restricted_weights")
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
restrictions <- names(sensitivity_config$restrictions)
outcomes <- names(sensitivity_config$outcomes)
continuous_covariates <- unlist(primary_config$continuous_covariates, use.names = FALSE)
categorical_covariates <- unlist(primary_config$categorical_covariates, use.names = FALSE)
primary_covariates <- c(continuous_covariates, categorical_covariates)
spline_covariates <- unlist(primary_config$spline_covariates, use.names = FALSE)
change_continuous <- unlist(
  sensitivity_config$diagnostic_change_variables$continuous, use.names = FALSE
)
change_binary <- unlist(
  sensitivity_config$diagnostic_change_variables$binary, use.names = FALSE
)
change_variables <- c(change_continuous, change_binary)

probability_floor <- as.numeric(sensitivity_config$probability_floor)
lower_quantile <- as.numeric(sensitivity_config$weight_lower_quantile)
upper_quantile <- as.numeric(sensitivity_config$weight_upper_quantile)
minimum_retention_probability <- as.numeric(
  sensitivity_config$minimum_acceptable_retention_probability
)
maximum_low_retention_fraction <- as.numeric(
  sensitivity_config$maximum_fraction_retention_below_0_05
)
minimum_change_observed_fraction <- as.numeric(
  sensitivity_config$minimum_change_variable_observed_fraction
)
gate_config <- sensitivity_config$effect_estimation_gate

flags_path <- file.path(stage07d_private, "stage07d_deterioration_flags_PRIVATE.rds")
if (!file.exists(flags_path)) stop("Missing Stage 07d private flags: ", flags_path, call. = FALSE)
stage07d_gate_path <- file.path(stage07d_dir, "07d_restriction_gate.csv")
if (!file.exists(stage07d_gate_path)) stop("Missing Stage 07d gate: ", stage07d_gate_path, call. = FALSE)

flags_all <- data.table::as.data.table(readRDS(flags_path))
stage07d_gate <- data.table::as.data.table(tte_read_csv_utf8(stage07d_gate_path))

variable_manifest <- data.table::rbindlist(list(
  data.table::data.table(
    variable = continuous_covariates,
    variable_group = "primary_covariate",
    variable_type = "numeric"
  ),
  data.table::data.table(
    variable = categorical_covariates,
    variable_group = "primary_covariate",
    variable_type = "categorical"
  ),
  data.table::data.table(
    variable = change_continuous,
    variable_group = "prognosis_change",
    variable_type = "numeric"
  ),
  data.table::data.table(
    variable = change_binary,
    variable_group = "prognosis_change",
    variable_type = "numeric"
  )
), use.names = TRUE, fill = TRUE)
variable_manifest <- unique(variable_manifest, by = "variable")

restriction_flow_parts <- list()
sample_parts <- list()
sequence_parts <- list()
model_diagnostic_parts <- list()
support_parts <- list()
retention_parts <- list()
weight_parts <- list()
ess_parts <- list()
balance_parts <- list()
propensity_plot_parts <- list()
weight_plot_parts <- list()
join_check_parts <- list()

for (cohort_name in cohorts) {
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(stage05_path)) stop("Missing Stage 05 imputations: ", stage05_path, call. = FALSE)
  imputations <- readRDS(stage05_path)
  if (!is.list(imputations) || length(imputations) != 20L) {
    stop(cohort_name, " does not have exactly 20 Stage 05 imputations.", call. = FALSE)
  }

  cohort_flags <- data.table::copy(flags_all[cohort == cohort_name])
  if (!nrow(cohort_flags) || anyDuplicated(cohort_flags$analysis_row_id)) {
    stop(cohort_name, " has missing or duplicate Stage 07d flag rows.", call. = FALSE)
  }
  required_flags <- c(
    "analysis_row_id", "person_id", "trial_id", "treatment",
    outcomes, change_variables
  )
  missing_flags <- setdiff(required_flags, names(cohort_flags))
  if (length(missing_flags)) {
    stop(cohort_name, " Stage 07d flags lack: ", paste(missing_flags, collapse = ", "), call. = FALSE)
  }

  for (restriction_name in restrictions) {
    restriction_marker <- sensitivity_config$restrictions[[restriction_name]]$marker
    if (!restriction_marker %in% names(cohort_flags)) {
      stop("Unknown restriction marker: ", restriction_marker, call. = FALSE)
    }
    restriction_status <- cohort_flags[[restriction_marker]]
    restriction_flow_parts[[paste(cohort_name, restriction_name, sep = "_")]] <-
      data.table::data.table(
        cohort = cohort_name,
        restriction = restriction_name,
        restriction_marker = restriction_marker,
        original_person_trials = nrow(cohort_flags),
        excluded_marker_positive = sum(restriction_status == 1L, na.rm = TRUE),
        excluded_marker_unknown = sum(is.na(restriction_status)),
        retained_known_marker_negative = sum(restriction_status == 0L, na.rm = TRUE),
        retained_unique_persons = data.table::uniqueN(
          cohort_flags[!is.na(get(restriction_marker)) & get(restriction_marker) == 0L, person_id]
        )
      )

    compact_outcome_weights <- setNames(vector("list", length(outcomes)), outcomes)
    for (outcome_name in outcomes) compact_outcome_weights[[outcome_name]] <- vector("list", 20L)

    for (imputation_index in seq_along(imputations)) {
      completed <- data.table::as.data.table(data.table::copy(imputations[[imputation_index]]))
      required_completed <- c(
        "analysis_row_id", "person_id", "trial_id", "treatment",
        "sequence", "L_survey_weight_final", primary_covariates
      )
      if (cohort_name == "SHARE") required_completed <- c(required_completed, "B_country")
      missing_completed <- setdiff(required_completed, names(completed))
      if (length(missing_completed)) {
        stop(
          cohort_name, " imputation ", imputation_index, " lacks: ",
          paste(missing_completed, collapse = ", "), call. = FALSE
        )
      }
      compact_flag_columns <- unique(c(
        "analysis_row_id", "person_id", "trial_id", "treatment",
        restriction_marker, outcomes, change_variables
      ))
      compact_flags <- cohort_flags[, ..compact_flag_columns]
      overlapping_payload <- intersect(
        c(outcomes, change_variables), names(completed)
      )
      if (length(overlapping_payload)) {
        completed[, (overlapping_payload) := NULL]
      }
      data.table::setnames(
        compact_flags,
        c("person_id", "trial_id", "treatment"),
        c("flag_person_id", "flag_trial_id", "flag_treatment")
      )
      joined <- merge(
        completed, compact_flags,
        by = "analysis_row_id", all.x = TRUE, sort = FALSE
      )
      data.table::setorder(joined, analysis_row_id)
      exact_identity <- nrow(joined) == nrow(completed) &&
        all(as.character(joined$person_id) == as.character(joined$flag_person_id)) &&
        all(as.character(joined$trial_id) == as.character(joined$flag_trial_id)) &&
        all(as.integer(joined$treatment) == as.integer(joined$flag_treatment))
      join_check_parts[[paste(
        cohort_name, restriction_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        restriction = restriction_name,
        imputation = imputation_index,
        stage05_rows = nrow(completed),
        matched_flag_rows = sum(!is.na(joined$flag_person_id)),
        exact_person_trial_treatment_identity = exact_identity
      )
      if (!exact_identity) {
        stop(
          cohort_name, "/", restriction_name, " failed the row identity check in imputation ",
          imputation_index, ".", call. = FALSE
        )
      }

      restricted <- joined[
        !is.na(get(restriction_marker)) & get(restriction_marker) == 0L
      ]
      restricted[, c("flag_person_id", "flag_trial_id", "flag_treatment") := NULL]
      restricted <- drop_unused_factors(restricted)
      restricted[, treatment := suppressWarnings(as.integer(as.character(treatment)))]
      if (!setequal(unique(restricted$treatment), c(0L, 1L))) {
        stop(cohort_name, "/", restriction_name, " lost one treatment arm.", call. = FALSE)
      }
      for (variable_name in continuous_covariates) {
        data.table::set(restricted, j = variable_name, value = plain_numeric(restricted[[variable_name]]))
      }
      for (variable_name in categorical_covariates) {
        data.table::set(restricted, j = variable_name, value = droplevels(factor(restricted[[variable_name]])))
      }
      restricted[, sequence := droplevels(factor(sequence))]
      if (cohort_name == "SHARE") restricted[, B_country := droplevels(factor(B_country))]

      residual_missing <- vapply(
        primary_covariates,
        function(variable_name) anyNA(restricted[[variable_name]]),
        logical(1L)
      )
      if (any(residual_missing)) {
        stop(
          cohort_name, "/", restriction_name, "/imputation ", imputation_index,
          " retains missing primary covariates: ",
          paste(names(residual_missing)[residual_missing], collapse = ", "),
          call. = FALSE
        )
      }

      fixed_candidates <- unlist(primary_config$always_adjust[[cohort_name]], use.names = FALSE)
      usable_primary <- usable_model_variables(restricted, primary_covariates)
      usable_fixed <- usable_model_variables(restricted, fixed_candidates)
      full_terms <- c(
        vapply(usable_primary, model_term_07e, character(1L), spline_covariates = spline_covariates),
        usable_fixed
      )
      numerator_terms <- usable_fixed
      treatment_denominator_formula <- make_formula_07e("treatment", full_terms)
      treatment_numerator_formula <- make_formula_07e("treatment", numerator_terms)

      treatment_denominator <- fit_binary_model_07e(
        treatment_denominator_formula, restricted, "treatment",
        "treatment_denominator", cohort_name, restriction_name,
        "all_outcomes", imputation_index
      )
      treatment_numerator <- fit_binary_model_07e(
        treatment_numerator_formula, restricted, "treatment",
        "treatment_numerator", cohort_name, restriction_name,
        "all_outcomes", imputation_index
      )
      restricted[, restricted_propensity_score := clamp_probability(
        stats::predict(treatment_denominator$fit, newdata = restricted, type = "response"),
        probability_floor
      )]
      restricted[, restricted_treatment_numerator_probability := clamp_probability(
        stats::predict(treatment_numerator$fit, newdata = restricted, type = "response"),
        probability_floor
      )]
      restricted[, restricted_treatment_weight := ifelse(
        treatment == 1L,
        restricted_treatment_numerator_probability / restricted_propensity_score,
        (1 - restricted_treatment_numerator_probability) / (1 - restricted_propensity_score)
      )]

      survey_strata <- if (cohort_name == "SHARE") c("sequence", "B_country") else "sequence"
      restricted[, restricted_survey_weight_scaled := {
        value <- plain_numeric(L_survey_weight_final)
        value / mean(value, na.rm = TRUE)
      }, by = survey_strata]
      restricted[, restricted_treatment_analysis_weight_raw :=
        restricted_survey_weight_scaled * restricted_treatment_weight]
      treatment_lower <- safe_quantile(
        restricted$restricted_treatment_analysis_weight_raw, lower_quantile
      )
      treatment_upper <- safe_quantile(
        restricted$restricted_treatment_analysis_weight_raw, upper_quantile
      )
      restricted[, restricted_treatment_analysis_weight := pmax(
        treatment_lower,
        pmin(treatment_upper, restricted_treatment_analysis_weight_raw)
      )]

      arm0 <- restricted[treatment == 0L, restricted_propensity_score]
      arm1 <- restricted[treatment == 1L, restricted_propensity_score]
      support_lower <- max(min(arm0), min(arm1))
      support_upper <- min(max(arm0), max(arm1))
      common_support_fraction <- mean(
        restricted$restricted_propensity_score >= support_lower &
          restricted$restricted_propensity_score <= support_upper
      )
      support_parts[[paste(
        cohort_name, restriction_name, imputation_index, sep = "_"
      )]] <- data.table::data.table(
        cohort = cohort_name,
        restriction = restriction_name,
        imputation = imputation_index,
        support_lower = support_lower,
        support_upper = support_upper,
        common_support_fraction = common_support_fraction,
        minimum_propensity_score = min(restricted$restricted_propensity_score),
        maximum_propensity_score = max(restricted$restricted_propensity_score)
      )
      if (imputation_index == 1L) {
        propensity_plot_parts[[paste(cohort_name, restriction_name, sep = "_")]] <-
          restricted[, .(
            cohort = cohort_name,
            restriction = restriction_name,
            treatment_label = ifelse(treatment == 1L, "Discontinue", "Continue"),
            propensity_score = restricted_propensity_score
          )]
      }

      for (outcome_name in outcomes) {
        restricted[, outcome_value := suppressWarnings(as.integer(get(outcome_name)))]
        restricted[, outcome_observed_specific := as.integer(!is.na(outcome_value))]
        censor_denominator_formula <- make_formula_07e(
          "outcome_observed_specific", c("treatment", full_terms)
        )
        censor_numerator_formula <- make_formula_07e(
          "outcome_observed_specific", c("treatment", numerator_terms)
        )
        censor_denominator <- fit_binary_model_07e(
          censor_denominator_formula, restricted, "censoring",
          "censoring_denominator", cohort_name, restriction_name,
          outcome_name, imputation_index
        )
        censor_numerator <- fit_binary_model_07e(
          censor_numerator_formula, restricted, "censoring",
          "censoring_numerator", cohort_name, restriction_name,
          outcome_name, imputation_index
        )
        treatment_diagnostics_for_outcome <- data.table::rbindlist(list(
          data.table::copy(treatment_denominator$diagnostics),
          data.table::copy(treatment_numerator$diagnostics)
        ), use.names = TRUE, fill = TRUE)
        treatment_diagnostics_for_outcome[, outcome := outcome_name]
        model_diagnostic_parts[[paste(
          cohort_name, restriction_name, outcome_name,
          imputation_index, "treatment", sep = "_"
        )]] <- treatment_diagnostics_for_outcome
        model_diagnostic_parts[[paste(
          cohort_name, restriction_name, outcome_name,
          imputation_index, "censoring", sep = "_"
        )]] <- data.table::rbindlist(list(
          censor_denominator$diagnostics,
          censor_numerator$diagnostics
        ), use.names = TRUE, fill = TRUE)

        restricted[, retention_probability_specific := clamp_probability(
          stats::predict(censor_denominator$fit, newdata = restricted, type = "response"),
          probability_floor
        )]
        restricted[, numerator_retention_probability_specific := clamp_probability(
          stats::predict(censor_numerator$fit, newdata = restricted, type = "response"),
          probability_floor
        )]
        restricted[, censoring_weight_specific := ifelse(
          outcome_observed_specific == 1L,
          numerator_retention_probability_specific / retention_probability_specific,
          NA_real_
        )]
        restricted[, total_weight_specific_raw := ifelse(
          outcome_observed_specific == 1L,
          restricted_survey_weight_scaled * restricted_treatment_weight *
            censoring_weight_specific,
          NA_real_
        )]
        weight_lower <- safe_quantile(restricted$total_weight_specific_raw, lower_quantile)
        weight_upper <- safe_quantile(restricted$total_weight_specific_raw, upper_quantile)
        if (!is.finite(weight_lower) || !is.finite(weight_upper) ||
            weight_lower <= 0 || weight_upper < weight_lower) {
          stop(
            cohort_name, "/", restriction_name, "/", outcome_name,
            " has invalid truncation bounds in imputation ", imputation_index,
            ".", call. = FALSE
          )
        }
        restricted[, total_weight_specific := ifelse(
          outcome_observed_specific == 1L,
          pmax(weight_lower, pmin(weight_upper, total_weight_specific_raw)),
          NA_real_
        )]

        if (imputation_index == 1L) {
          sample_parts[[paste(cohort_name, restriction_name, outcome_name, sep = "_")]] <-
            restricted[, .(
              eligible_person_trials = .N,
              unique_persons = data.table::uniqueN(person_id),
              observed_person_trials = sum(!is.na(outcome_value)),
              observation_fraction = mean(!is.na(outcome_value)),
              events = sum(outcome_value == 1L, na.rm = TRUE),
              non_events = sum(outcome_value == 0L, na.rm = TRUE)
            ), by = treatment][, `:=`(
              cohort = cohort_name,
              restriction = restriction_name,
              outcome = outcome_name,
              treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
            )]
          sequence_parts[[paste(cohort_name, restriction_name, outcome_name, sep = "_")]] <-
            restricted[, .(
              eligible_person_trials = .N,
              observed_person_trials = sum(!is.na(outcome_value)),
              observation_fraction = mean(!is.na(outcome_value)),
              events = sum(outcome_value == 1L, na.rm = TRUE)
            ), by = .(sequence, treatment)][, `:=`(
              cohort = cohort_name,
              restriction = restriction_name,
              outcome = outcome_name,
              treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
            )]
        }

        retention_parts[[paste(
          cohort_name, restriction_name, outcome_name, imputation_index, sep = "_"
        )]] <- data.table::data.table(
          cohort = cohort_name,
          restriction = restriction_name,
          outcome = outcome_name,
          imputation = imputation_index,
          minimum_retention_probability = min(restricted$retention_probability_specific),
          maximum_retention_probability = max(restricted$retention_probability_specific),
          fraction_retention_probability_below_0_05 = mean(
            restricted$retention_probability_specific < 0.05
          ),
          any_retention_probability_below_0_01 = any(
            restricted$retention_probability_specific < minimum_retention_probability
          )
        )

        observed <- restricted[outcome_observed_specific == 1L]
        if (!nrow(observed) || !setequal(unique(observed$treatment), c(0L, 1L)) ||
            any(!is.finite(observed$total_weight_specific)) ||
            any(observed$total_weight_specific <= 0)) {
          stop(
            cohort_name, "/", restriction_name, "/", outcome_name,
            " has an invalid weighted outcome sample in imputation ",
            imputation_index, ".", call. = FALSE
          )
        }
        observed[, unit_weight := 1]
        weight_parts[[paste(
          cohort_name, restriction_name, outcome_name, imputation_index, sep = "_"
        )]] <- observed[, .(
          observed_person_trials = .N,
          raw_weight_minimum = min(total_weight_specific_raw),
          raw_weight_p01 = safe_quantile(total_weight_specific_raw, 0.01),
          raw_weight_median = safe_quantile(total_weight_specific_raw, 0.50),
          raw_weight_p99 = safe_quantile(total_weight_specific_raw, 0.99),
          raw_weight_maximum = max(total_weight_specific_raw),
          truncated_weight_minimum = min(total_weight_specific),
          truncated_weight_median = safe_quantile(total_weight_specific, 0.50),
          truncated_weight_maximum = max(total_weight_specific)
        ), by = treatment][, `:=`(
          cohort = cohort_name,
          restriction = restriction_name,
          outcome = outcome_name,
          imputation = imputation_index,
          treatment_label = ifelse(treatment == 1L, "discontinue", "continue")
        )]
        ess_parts[[paste(
          cohort_name, restriction_name, outcome_name, imputation_index, sep = "_"
        )]] <- observed[, .(
          effective_sample_size = effective_sample_size(total_weight_specific)
        ), by = treatment][, `:=`(
          cohort = cohort_name,
          restriction = restriction_name,
          outcome = outcome_name,
          imputation = imputation_index
        )]
        balance_parts[[paste(
          cohort_name, restriction_name, outcome_name, imputation_index,
          "unweighted", sep = "_"
        )]] <- calculate_balance_07e(
          observed, "unit_weight", "outcome_observed_unweighted",
          cohort_name, restriction_name, outcome_name, imputation_index,
          variable_manifest
        )
        balance_parts[[paste(
          cohort_name, restriction_name, outcome_name, imputation_index,
          "weighted", sep = "_"
        )]] <- calculate_balance_07e(
          observed, "total_weight_specific", "after_restricted_total_weight",
          cohort_name, restriction_name, outcome_name, imputation_index,
          variable_manifest
        )
        if (imputation_index == 1L) {
          weight_plot_parts[[paste(
            cohort_name, restriction_name, outcome_name, sep = "_"
          )]] <- observed[, .(
            cohort = cohort_name,
            restriction = restriction_name,
            outcome = outcome_name,
            treatment_label = ifelse(treatment == 1L, "Discontinue", "Continue"),
            total_weight_specific
          )]
        }
        compact_outcome_weights[[outcome_name]][[imputation_index]] <- restricted[, .(
          analysis_row_id,
          person_id,
          trial_id,
          treatment,
          sequence,
          B_country = if ("B_country" %in% names(restricted)) as.character(B_country) else NA_character_,
          outcome_value,
          outcome_observed_specific,
          restricted_propensity_score,
          restricted_treatment_weight,
          restricted_survey_weight_scaled,
          retention_probability_specific,
          censoring_weight_specific,
          total_weight_specific_raw,
          total_weight_specific
        )]
      }
    }

    for (outcome_name in outcomes) {
      saveRDS(
        compact_outcome_weights[[outcome_name]],
        file.path(
          private_dir,
          paste0(
            tolower(cohort_name), "_", restriction_name, "_",
            outcome_name, "_weights_PRIVATE.rds"
          )
        ),
        version = 3L
      )
    }
  }
}

restriction_flow <- data.table::rbindlist(restriction_flow_parts, use.names = TRUE, fill = TRUE)
sample_counts <- data.table::rbindlist(sample_parts, use.names = TRUE, fill = TRUE)
sequence_counts <- data.table::rbindlist(sequence_parts, use.names = TRUE, fill = TRUE)
model_diagnostics <- data.table::rbindlist(model_diagnostic_parts, use.names = TRUE, fill = TRUE)
support <- data.table::rbindlist(support_parts, use.names = TRUE, fill = TRUE)
retention <- data.table::rbindlist(retention_parts, use.names = TRUE, fill = TRUE)
weight_distribution <- data.table::rbindlist(weight_parts, use.names = TRUE, fill = TRUE)
ess <- data.table::rbindlist(ess_parts, use.names = TRUE, fill = TRUE)
balance <- data.table::rbindlist(balance_parts, use.names = TRUE, fill = TRUE)
join_checks <- data.table::rbindlist(join_check_parts, use.names = TRUE, fill = TRUE)
propensity_plot_data <- data.table::rbindlist(propensity_plot_parts, use.names = TRUE, fill = TRUE)
weight_plot_data <- data.table::rbindlist(weight_plot_parts, use.names = TRUE, fill = TRUE)

balance_summary <- balance[, .(
  imputations = data.table::uniqueN(imputation),
  minimum_observed_fraction = min(minimum_arm_observed_fraction, na.rm = TRUE),
  mean_standardized_difference = mean(standardized_difference, na.rm = TRUE),
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE)
), by = .(
  cohort, restriction, outcome, balance_sample,
  variable_group, variable, level
)]

event_gate <- sample_counts[, .(
  both_arms_present = data.table::uniqueN(treatment) == 2L,
  smaller_arm_observed_person_trials = min(observed_person_trials),
  smaller_arm_events = min(events),
  total_events = sum(events)
), by = .(cohort, restriction, outcome)]
primary_balance_gate <- balance[
  balance_sample == "after_restricted_total_weight" &
    variable_group == "primary_covariate",
  .(maximum_absolute_primary_covariate_smd = max(
    absolute_standardized_difference, na.rm = TRUE
  )),
  by = .(cohort, restriction, outcome)
]
change_balance_gate <- balance[
  balance_sample == "after_restricted_total_weight" &
    variable_group == "prognosis_change" &
    minimum_arm_observed_fraction >= minimum_change_observed_fraction,
  .(maximum_absolute_change_variable_smd = max(
    absolute_standardized_difference, na.rm = TRUE
  )),
  by = .(cohort, restriction, outcome)
]
ess_gate <- ess[, .(
  minimum_arm_effective_sample_size = min(effective_sample_size)
), by = .(cohort, restriction, outcome)]
support_gate <- support[, .(
  minimum_common_support_fraction = min(common_support_fraction)
), by = .(cohort, restriction)]
model_gate <- model_diagnostics[, .(
  all_models_converged = all(converged),
  total_model_warnings = sum(warning_n),
  maximum_aliased_coefficients = max(aliased_coefficient_n),
  any_separation_or_convergence_warning = any(separation_or_convergence_warning)
), by = .(cohort, restriction, outcome)]
retention_gate <- retention[, .(
  minimum_retention_probability = min(minimum_retention_probability),
  maximum_fraction_retention_below_0_05 = max(
    fraction_retention_probability_below_0_05
  ),
  any_retention_probability_below_0_01 = any(any_retention_probability_below_0_01)
), by = .(cohort, restriction, outcome)]

gate <- Reduce(function(left, right) merge(
  left, right,
  by = intersect(names(left), names(right)), all = TRUE, sort = FALSE
), list(
  event_gate, primary_balance_gate, change_balance_gate,
  ess_gate, support_gate, model_gate, retention_gate
))
gate[, pass_smaller_arm_n := smaller_arm_observed_person_trials >=
  as.numeric(gate_config$minimum_smaller_arm_person_trials)]
gate[, pass_smaller_arm_events := smaller_arm_events >=
  as.numeric(gate_config$minimum_smaller_arm_events)]
gate[, pass_total_events := total_events >= as.numeric(gate_config$minimum_total_events)]
gate[, pass_primary_balance := maximum_absolute_primary_covariate_smd <
  as.numeric(gate_config$maximum_absolute_primary_covariate_smd)]
gate[, pass_change_balance := maximum_absolute_change_variable_smd <
  as.numeric(gate_config$maximum_absolute_change_variable_smd)]
gate[, pass_effective_sample_size := minimum_arm_effective_sample_size >=
  as.numeric(gate_config$minimum_arm_effective_sample_size)]
gate[, pass_common_support := minimum_common_support_fraction >=
  as.numeric(gate_config$minimum_common_support_fraction)]
gate[, pass_model_identifiability := all_models_converged &
  total_model_warnings == 0L & maximum_aliased_coefficients == 0L &
  !any_separation_or_convergence_warning]
gate[, pass_retention_positivity :=
  maximum_fraction_retention_below_0_05 <= maximum_low_retention_fraction &
  !any_retention_probability_below_0_01]
gate[, ready_for_restricted_effect_estimation :=
  both_arms_present & pass_smaller_arm_n & pass_smaller_arm_events &
  pass_total_events & pass_primary_balance & pass_change_balance &
  pass_effective_sample_size & pass_common_support &
  pass_model_identifiability & pass_retention_positivity]

if (any(!join_checks$exact_person_trial_treatment_identity) ||
    any(join_checks$matched_flag_rows != join_checks$stage05_rows)) {
  stop("At least one Stage 05-to-Stage 07d join check failed.", call. = FALSE)
}

data.table::setorder(restriction_flow, cohort, restriction)
data.table::setorder(sample_counts, cohort, restriction, outcome, treatment)
data.table::setorder(sequence_counts, cohort, restriction, sequence, outcome, treatment)
data.table::setorder(model_diagnostics, cohort, restriction, outcome, imputation, model_group, model)
data.table::setorder(support, cohort, restriction, imputation)
data.table::setorder(retention, cohort, restriction, outcome, imputation)
data.table::setorder(weight_distribution, cohort, restriction, outcome, imputation, treatment)
data.table::setorder(ess, cohort, restriction, outcome, imputation, treatment)
data.table::setorder(balance, cohort, restriction, outcome, balance_sample, variable_group, variable, level, imputation)
data.table::setorder(balance_summary, cohort, restriction, outcome, balance_sample, variable_group, variable, level)
data.table::setorder(gate, cohort, restriction, outcome)

tte_write_csv(restriction_flow, file.path(output_dir, "07e_restriction_flow.csv"))
tte_write_csv(sample_counts, file.path(output_dir, "07e_analysis_sample.csv"))
tte_write_csv(sequence_counts, file.path(output_dir, "07e_sequence_arm_counts.csv"))
tte_write_csv(model_diagnostics, file.path(output_dir, "07e_model_diagnostics.csv"))
tte_write_csv(support, file.path(output_dir, "07e_common_support.csv"))
tte_write_csv(retention, file.path(output_dir, "07e_retention_diagnostics.csv"))
tte_write_csv(weight_distribution, file.path(output_dir, "07e_weight_distribution.csv"))
tte_write_csv(ess, file.path(output_dir, "07e_effective_sample_size.csv"))
tte_write_csv(balance, file.path(output_dir, "07e_balance_all_imputations.csv"))
tte_write_csv(balance_summary, file.path(output_dir, "07e_balance_summary.csv"))
tte_write_csv(join_checks, file.path(output_dir, "07e_join_checks.csv"))
tte_write_csv(gate, file.path(output_dir, "07e_weighting_gate.csv"))
writeLines(
  readLines(sensitivity_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "07e_frozen_sensitivity_weight_model.yml"),
  useBytes = TRUE
)

balance_plot_data <- balance_summary[
  balance_sample == "after_restricted_total_weight" &
    is.finite(maximum_absolute_smd)
]
balance_plot_data[, display_variable := ifelse(
  is.na(level) | level == "", variable, paste0(variable, "=", level)
)]
balance_plot <- ggplot2::ggplot(
  balance_plot_data,
  ggplot2::aes(
    x = maximum_absolute_smd,
    y = stats::reorder(display_variable, maximum_absolute_smd),
    colour = variable_group,
    shape = variable_group
  )
) +
  ggplot2::geom_vline(xintercept = 0.10, linetype = 2, colour = "#B2182B") +
  ggplot2::geom_point(size = 1.6, alpha = 0.85) +
  ggplot2::facet_grid(
    cohort + restriction ~ outcome,
    scales = "free_y", space = "free_y"
  ) +
  ggplot2::labs(
    x = "Maximum absolute standardized difference across imputations",
    y = NULL,
    colour = NULL,
    shape = NULL,
    title = "Balance after restriction-specific treatment and censoring weights"
  ) +
  ggplot2::theme_minimal(base_size = 8.5) +
  ggplot2::theme(
    legend.position = "bottom",
    axis.text.y = ggplot2::element_text(size = 5.8)
  )

propensity_plot <- ggplot2::ggplot(
  propensity_plot_data,
  ggplot2::aes(x = propensity_score, colour = treatment_label, fill = treatment_label)
) +
  ggplot2::geom_density(alpha = 0.15, linewidth = 0.55) +
  ggplot2::facet_grid(cohort ~ restriction, scales = "free_y") +
  ggplot2::scale_colour_manual(values = c("Continue" = "#2463A8", "Discontinue" = "#C44E52")) +
  ggplot2::scale_fill_manual(values = c("Continue" = "#2463A8", "Discontinue" = "#C44E52")) +
  ggplot2::labs(
    x = "Restriction-specific propensity score",
    y = "Density",
    colour = NULL,
    fill = NULL,
    title = "Propensity-score overlap in restricted populations",
    subtitle = "First imputed dataset"
  ) +
  ggplot2::theme_minimal(base_size = 10) +
  ggplot2::theme(legend.position = "bottom")

weight_plot <- ggplot2::ggplot(
  weight_plot_data,
  ggplot2::aes(x = treatment_label, y = total_weight_specific, fill = treatment_label)
) +
  ggplot2::geom_boxplot(outlier.shape = NA, width = 0.65) +
  ggplot2::scale_y_log10() +
  ggplot2::facet_grid(cohort + restriction ~ outcome, scales = "free_y") +
  ggplot2::scale_fill_manual(values = c("Continue" = "#2463A8", "Discontinue" = "#C44E52")) +
  ggplot2::labs(
    x = NULL,
    y = "Truncated total weight (log scale)",
    fill = NULL,
    title = "Restricted outcome-specific weight distributions",
    subtitle = "First imputed dataset"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(legend.position = "bottom")

ggplot2::ggsave(
  file.path(output_dir, "07e_balance_plot.png"), balance_plot,
  width = 14, height = 18, dpi = 240, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "07e_balance_plot.pdf"), balance_plot,
  width = 14, height = 18, limitsize = FALSE
)
ggplot2::ggsave(
  file.path(output_dir, "07e_propensity_overlap.png"), propensity_plot,
  width = 11, height = 7, dpi = 240
)
ggplot2::ggsave(
  file.path(output_dir, "07e_propensity_overlap.pdf"), propensity_plot,
  width = 11, height = 7
)
ggplot2::ggsave(
  file.path(output_dir, "07e_weight_distribution.png"), weight_plot,
  width = 12, height = 10, dpi = 240
)
ggplot2::ggsave(
  file.path(output_dir, "07e_weight_distribution.pdf"), weight_plot,
  width = 12, height = 10
)

gate_lines <- apply(gate, 1L, function(row) paste0(
  row[["cohort"]], "/", row[["restriction"]], "/", row[["outcome"]],
  ": primary max |SMD|=", sprintf("%.3f", as.numeric(row[["maximum_absolute_primary_covariate_smd"]])),
  ", change max |SMD|=", sprintf("%.3f", as.numeric(row[["maximum_absolute_change_variable_smd"]])),
  ", min arm ESS=", sprintf("%.1f", as.numeric(row[["minimum_arm_effective_sample_size"]])),
  ", support=", sprintf("%.3f", as.numeric(row[["minimum_common_support_fraction"]])),
  ", smaller-arm events=", row[["smaller_arm_events"]],
  ", total events=", row[["total_events"]],
  ", ready=", row[["ready_for_restricted_effect_estimation"]]
))
summary_lines <- c(
  "Stage 07e: restriction-specific weighting diagnostics",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Restrictions: exclude >=2 deterioration markers; exclude any objective severe deterioration.",
  "Outcomes: broad CVD/death, strict MI/stroke/death, and all-cause death.",
  "The 20 frozen Stage 05 completed covariate datasets were reused.",
  "Treatment and outcome-observation models were refitted within every restricted population.",
  "Survey weights were renormalized and combined weights were truncated at the 1st/99th percentiles.",
  "Unknown restriction status was excluded rather than classified as no deterioration.",
  "Both primary covariate balance and observed prognosis-change balance were required to pass.",
  "No treatment effect was estimated in this stage.",
  "",
  gate_lines,
  "",
  "Proceed to Stage 07f only for cohort/restriction/outcome combinations with ready=TRUE."
)
writeLines(summary_lines, file.path(output_dir, "07e_stage_summary.txt"), useBytes = TRUE)
writeLines(
  capture.output(utils::sessionInfo()),
  file.path(output_dir, "07e_session_info.txt"),
  useBytes = TRUE
)
message(paste(summary_lines, collapse = "\n"))
message("Stage 07e completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
