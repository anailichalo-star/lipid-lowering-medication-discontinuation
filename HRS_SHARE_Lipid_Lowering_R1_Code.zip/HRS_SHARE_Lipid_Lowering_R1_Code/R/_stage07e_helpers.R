plain_numeric <- function(x) suppressWarnings(as.numeric(x))

as_logical_value <- function(x) {
  tolower(trimws(as.character(x))) %in% c("true", "t", "1", "yes")
}

clamp_probability <- function(x, probability_floor) {
  pmax(probability_floor, pmin(1 - probability_floor, x))
}

safe_quantile <- function(x, probability) {
  value <- plain_numeric(x)
  value <- value[is.finite(value)]
  if (!length(value)) return(NA_real_)
  as.numeric(stats::quantile(value, probability, names = FALSE, type = 2L))
}

effective_sample_size <- function(weight) {
  value <- plain_numeric(weight)
  value <- value[is.finite(value) & value > 0]
  if (!length(value)) return(NA_real_)
  sum(value)^2 / sum(value^2)
}

weighted_mean_value <- function(x, weight) {
  value <- plain_numeric(x)
  w <- plain_numeric(weight)
  valid <- is.finite(value) & is.finite(w) & w > 0
  if (!any(valid)) return(NA_real_)
  sum(w[valid] * value[valid]) / sum(w[valid])
}

weighted_variance_value <- function(x, weight) {
  value <- plain_numeric(x)
  w <- plain_numeric(weight)
  valid <- is.finite(value) & is.finite(w) & w > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean_value(value[valid], w[valid])
  sum(w[valid] * (value[valid] - center)^2) / sum(w[valid])
}

numeric_smd <- function(x, treatment, weight) {
  value <- plain_numeric(x)
  trt <- suppressWarnings(as.integer(as.character(treatment)))
  w <- plain_numeric(weight)
  valid <- is.finite(value) & trt %in% c(0L, 1L) & is.finite(w) & w > 0
  value <- value[valid]
  trt <- trt[valid]
  w <- w[valid]
  if (!any(trt == 0L) || !any(trt == 1L)) return(NA_real_)
  mean0 <- weighted_mean_value(value[trt == 0L], w[trt == 0L])
  mean1 <- weighted_mean_value(value[trt == 1L], w[trt == 1L])
  var0 <- weighted_variance_value(value[trt == 0L], w[trt == 0L])
  var1 <- weighted_variance_value(value[trt == 1L], w[trt == 1L])
  denominator <- sqrt((var0 + var1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (mean1 - mean0) / denominator
}

level_smd <- function(x, treatment, weight, level_value) {
  trt <- suppressWarnings(as.integer(as.character(treatment)))
  w <- plain_numeric(weight)
  valid <- !is.na(x) & trt %in% c(0L, 1L) & is.finite(w) & w > 0
  value <- as.character(x[valid])
  trt <- trt[valid]
  w <- w[valid]
  if (!any(trt == 0L) || !any(trt == 1L)) return(NA_real_)
  indicator <- as.numeric(value == level_value)
  p0 <- weighted_mean_value(indicator[trt == 0L], w[trt == 0L])
  p1 <- weighted_mean_value(indicator[trt == 1L], w[trt == 1L])
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

minimum_arm_observed_fraction <- function(x, treatment) {
  trt <- suppressWarnings(as.integer(as.character(treatment)))
  fractions <- vapply(c(0L, 1L), function(arm) {
    selector <- trt == arm
    if (!any(selector)) return(NA_real_)
    mean(!is.na(x[selector]))
  }, numeric(1L))
  if (anyNA(fractions)) return(NA_real_)
  min(fractions)
}

calculate_balance_07e <- function(
  data, weight_name, balance_sample, cohort_name, restriction_name,
  outcome_name, imputation_index, variable_manifest
) {
  trt <- data$treatment
  weight <- data[[weight_name]]
  rows <- list()
  row_index <- 0L
  for (manifest_index in seq_len(nrow(variable_manifest))) {
    variable_name <- variable_manifest$variable[[manifest_index]]
    variable_group <- variable_manifest$variable_group[[manifest_index]]
    variable_type <- variable_manifest$variable_type[[manifest_index]]
    x <- data[[variable_name]]
    observed_fraction <- minimum_arm_observed_fraction(x, trt)
    if (identical(variable_type, "categorical")) {
      levels_present <- sort(unique(as.character(x[!is.na(x)])))
      if (!length(levels_present)) levels_present <- ""
      for (level_value in levels_present) {
        row_index <- row_index + 1L
        smd <- if (identical(level_value, "")) NA_real_ else
          level_smd(x, trt, weight, level_value)
        rows[[row_index]] <- data.table::data.table(
          cohort = cohort_name,
          restriction = restriction_name,
          outcome = outcome_name,
          imputation = imputation_index,
          balance_sample = balance_sample,
          variable_group = variable_group,
          variable = variable_name,
          level = level_value,
          minimum_arm_observed_fraction = observed_fraction,
          standardized_difference = smd
        )
      }
    } else {
      row_index <- row_index + 1L
      rows[[row_index]] <- data.table::data.table(
        cohort = cohort_name,
        restriction = restriction_name,
        outcome = outcome_name,
        imputation = imputation_index,
        balance_sample = balance_sample,
        variable_group = variable_group,
        variable = variable_name,
        level = "",
        minimum_arm_observed_fraction = observed_fraction,
        standardized_difference = numeric_smd(x, trt, weight)
      )
    }
  }
  result <- data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)
  result[, absolute_standardized_difference := abs(standardized_difference)]
  result
}

drop_unused_factors <- function(data) {
  for (variable_name in names(data)) {
    if (is.factor(data[[variable_name]])) {
      data.table::set(
        data, j = variable_name,
        value = droplevels(data[[variable_name]])
      )
    }
  }
  data
}

usable_model_variables <- function(data, variables) {
  variables[vapply(variables, function(variable_name) {
    value <- data[[variable_name]]
    if (is.factor(value) || is.character(value)) {
      data.table::uniqueN(as.character(value[!is.na(value)])) >= 2L
    } else {
      numeric_value <- plain_numeric(value)
      length(unique(numeric_value[is.finite(numeric_value)])) >= 2L
    }
  }, logical(1L))]
}

model_term_07e <- function(variable_name, spline_covariates) {
  if (variable_name %in% spline_covariates) {
    paste0("splines::ns(", variable_name, ", df = 3)")
  } else {
    variable_name
  }
}

make_formula_07e <- function(response, terms) {
  if (!length(terms)) return(stats::as.formula(paste(response, "~ 1")))
  stats::as.formula(paste(response, "~", paste(terms, collapse = " + ")))
}

fit_binary_model_07e <- function(
  formula, data, model_group, model_name, cohort_name, restriction_name,
  outcome_name, imputation_index
) {
  warning_messages <- character()
  fit <- withCallingHandlers(
    stats::glm(
      formula = formula,
      data = data,
      family = stats::binomial(),
      na.action = stats::na.fail,
      control = stats::glm.control(maxit = 100, epsilon = 1e-8)
    ),
    warning = function(warning_condition) {
      warning_messages <<- c(warning_messages, conditionMessage(warning_condition))
      invokeRestart("muffleWarning")
    }
  )
  diagnostics <- data.table::data.table(
    cohort = cohort_name,
    restriction = restriction_name,
    outcome = outcome_name,
    imputation = imputation_index,
    model_group = model_group,
    model = model_name,
    formula = paste(deparse(formula), collapse = " "),
    converged = isTRUE(fit$converged),
    iterations = fit$iter,
    coefficient_n = length(stats::coef(fit)),
    aliased_coefficient_n = sum(is.na(stats::coef(fit))),
    warning_n = length(unique(warning_messages)),
    warnings = paste(unique(warning_messages), collapse = " | "),
    separation_or_convergence_warning = any(grepl(
      "did not converge|fitted probabilities numerically 0 or 1 occurred|algorithm stopped",
      warning_messages, ignore.case = TRUE
    ))
  )
  list(fit = fit, diagnostics = diagnostics)
}
