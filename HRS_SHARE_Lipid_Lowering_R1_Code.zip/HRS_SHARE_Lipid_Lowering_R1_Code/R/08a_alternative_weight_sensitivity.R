# Stage 08a: alternative truncation and overlap-weight sensitivity analysis
# for the broad cardiovascular disease/all-cause death outcome.

options(stringsAsFactors = FALSE)

project_root <- normalizePath(".", winslash = "/", mustWork = TRUE)
source(file.path(project_root, "R", "_stage1_helpers.R"), encoding = "UTF-8", local = TRUE)
source(file.path(project_root, "R", "_stage06_helpers.R"), encoding = "UTF-8", local = TRUE)

required_packages <- c("yaml", "data.table", "ggplot2")
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1L), quietly = TRUE)
]
if (length(missing_packages)) {
  stop(
    "Missing required packages: ", paste(missing_packages, collapse = ", "),
    ". No package was installed automatically. Run: install.packages(c(",
    paste(sprintf("'%s'", missing_packages), collapse = ", "),
    "), repos = 'https://cloud.r-project.org')", call. = FALSE
  )
}

analysis_config <- tte_read_yaml_utf8(file.path(project_root, "config_r", "analysis.yml"))
weight_model <- tte_read_yaml_utf8(file.path(project_root, "config_r", "primary_weight_model.yml"))
sensitivity_path <- file.path(project_root, "config_r", "alternative_weight_sensitivity.yml")
sensitivity_config <- tte_read_yaml_utf8(sensitivity_path)

stage04_private <- file.path(
  project_root, analysis_config$output_root,
  "stage04_structural_followup", "private_do_not_share"
)
stage05_private <- file.path(
  project_root, analysis_config$output_root,
  "stage05_weighting", "private_do_not_share"
)
stage06_path <- file.path(
  project_root, analysis_config$output_root,
  "stage06_primary_effects", "06_primary_effects_pooled.csv"
)
output_dir <- file.path(
  project_root, analysis_config$output_root,
  "stage08a_alternative_weights"
)
private_dir <- file.path(output_dir, "private_do_not_share")
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(private_dir, recursive = TRUE, showWarnings = FALSE)

cohorts <- c("HRS", "SHARE")
target_years <- as.numeric(sensitivity_config$target_risk_years)
outcome_name <- as.character(sensitivity_config$outcome$name)
outcome_label <- as.character(sensitivity_config$outcome$label)
continuous_covariates <- unlist(weight_model$continuous_covariates, use.names = FALSE)
categorical_covariates <- unlist(weight_model$categorical_covariates, use.names = FALSE)

safe_quantile <- function(x, probability) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  as.numeric(stats::quantile(x, probability, names = FALSE, type = 2L))
}

effective_sample_size <- function(weight) {
  weight <- suppressWarnings(as.numeric(weight))
  weight <- weight[is.finite(weight) & weight > 0]
  if (!length(weight)) return(NA_real_)
  sum(weight)^2 / sum(weight^2)
}

weighted_mean_safe <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (!any(valid)) return(NA_real_)
  sum(x[valid] * weight[valid]) / sum(weight[valid])
}

weighted_variance_safe <- function(x, weight) {
  x <- suppressWarnings(as.numeric(x))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & is.finite(weight) & weight > 0
  if (sum(valid) < 2L) return(NA_real_)
  center <- weighted_mean_safe(x[valid], weight[valid])
  sum(weight[valid] * (x[valid] - center)^2) / sum(weight[valid])
}

numeric_smd <- function(x, treatment, weight) {
  x <- suppressWarnings(as.numeric(x))
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- is.finite(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- x[valid]
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  m0 <- weighted_mean_safe(x[treatment == 0L], weight[treatment == 0L])
  m1 <- weighted_mean_safe(x[treatment == 1L], weight[treatment == 1L])
  v0 <- weighted_variance_safe(x[treatment == 0L], weight[treatment == 0L])
  v1 <- weighted_variance_safe(x[treatment == 1L], weight[treatment == 1L])
  denominator <- sqrt((v0 + v1) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (m1 - m0) / denominator
}

level_smd <- function(x, treatment, weight, level_value) {
  treatment <- suppressWarnings(as.integer(as.character(treatment)))
  weight <- suppressWarnings(as.numeric(weight))
  valid <- !is.na(x) & treatment %in% c(0L, 1L) &
    is.finite(weight) & weight > 0
  x <- as.character(x[valid])
  treatment <- treatment[valid]
  weight <- weight[valid]
  if (!any(treatment == 0L) || !any(treatment == 1L)) return(NA_real_)
  indicator <- as.numeric(x == level_value)
  p0 <- weighted_mean_safe(indicator[treatment == 0L], weight[treatment == 0L])
  p1 <- weighted_mean_safe(indicator[treatment == 1L], weight[treatment == 1L])
  denominator <- sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2)
  if (!is.finite(denominator) || denominator == 0) return(0)
  (p1 - p0) / denominator
}

calculate_balance <- function(data, variables, categorical_variables) {
  rows <- list()
  row_index <- 0L
  for (variable_name in variables) {
    x <- data[[variable_name]]
    if (variable_name %in% categorical_variables) {
      present_levels <- sort(unique(as.character(x[!is.na(x)])))
      for (level_value in present_levels) {
        row_index <- row_index + 1L
        rows[[row_index]] <- data.table::data.table(
          variable = variable_name,
          level = level_value,
          standardized_difference = level_smd(
            x, data$treatment, data$sensitivity_weight, level_value
          )
        )
      }
    } else {
      row_index <- row_index + 1L
      rows[[row_index]] <- data.table::data.table(
        variable = variable_name,
        level = "",
        standardized_difference = numeric_smd(
          x, data$treatment, data$sensitivity_weight
        )
      )
    }
  }
  result <- data.table::rbindlist(rows, use.names = TRUE, fill = TRUE)
  result[, absolute_standardized_difference := abs(standardized_difference)]
  result
}

effect_parts <- list()
model_parts <- list()
balance_parts <- list()
ess_parts <- list()
weight_parts <- list()
join_parts <- list()

for (cohort_name in cohorts) {
  source_path <- file.path(
    stage04_private,
    paste0(tolower(cohort_name), "_structural_validated_trials_PRIVATE.rds")
  )
  stage05_path <- file.path(
    stage05_private,
    paste0(tolower(cohort_name), "_weighted_imputations_PRIVATE.rds")
  )
  if (!file.exists(source_path) || !file.exists(stage05_path)) {
    stop("Missing Stage 08a input for ", cohort_name, call. = FALSE)
  }
  source_trials <- data.table::as.data.table(readRDS(source_path))
  source_trials <- source_trials[
    is.finite(suppressWarnings(as.numeric(L_survey_weight_final))) &
      suppressWarnings(as.numeric(L_survey_weight_final)) > 0
  ]
  source_trials[, join_key := paste(
    as.character(person_id), as.character(trial_id), sep = "\r"
  )]
  if (anyDuplicated(source_trials$join_key)) {
    stop(cohort_name, ": duplicate source person-trial key.", call. = FALSE)
  }
  source_fields <- source_trials[, .(
    join_key,
    followup_time_years = suppressWarnings(as.numeric(followup_time_years))
  )]
  completed_list <- readRDS(stage05_path)
  if (!is.list(completed_list) || length(completed_list) != 20L) {
    stop(cohort_name, ": Stage 05 must contain 20 datasets.", call. = FALSE)
  }

  fixed_terms <- unlist(
    sensitivity_config$design_adjustment[[cohort_name]], use.names = FALSE
  )
  diagnostic_variables <- unique(c(
    continuous_covariates, categorical_covariates, fixed_terms
  ))
  diagnostic_categorical <- unique(c(categorical_covariates, fixed_terms))
  formula_text <- paste0(
    "outcome_value ~ treatment + ",
    paste(fixed_terms, collapse = " + "),
    " + offset(log(followup_time_years))"
  )
  outcome_formula <- stats::as.formula(formula_text)

  for (imputation_index in seq_along(completed_list)) {
    base_completed <- data.table::as.data.table(
      data.table::copy(completed_list[[imputation_index]])
    )
    required <- c(
      "person_id", "trial_id", "treatment", "primary_event",
      "outcome_observed", "total_weight_raw", "survey_weight_scaled",
      "propensity_score", "censoring_weight", diagnostic_variables
    )
    missing_required <- setdiff(required, names(base_completed))
    if (length(missing_required)) {
      stop(
        cohort_name, " Stage 05 lacks: ",
        paste(missing_required, collapse = ", "), call. = FALSE
      )
    }
    base_completed[, join_key := paste(
      as.character(person_id), as.character(trial_id), sep = "\r"
    )]
    source_index <- match(base_completed$join_key, source_fields$join_key)
    exact_join <- !anyNA(source_index) &&
      nrow(base_completed) == nrow(source_fields)
    if (!exact_join || anyDuplicated(base_completed$join_key)) {
      stop(
        cohort_name, ": source join failed in imputation ",
        imputation_index, call. = FALSE
      )
    }
    base_completed[, followup_time_years :=
      source_fields$followup_time_years[source_index]]
    base_completed[, treatment := suppressWarnings(
      as.integer(as.character(treatment))
    )]
    base_completed[, outcome_value := suppressWarnings(
      as.integer(primary_event)
    )]
    base_completed[, outcome_observed_specific := suppressWarnings(
      as.integer(outcome_observed)
    )]
    base_completed[, sequence := droplevels(factor(sequence))]
    if (cohort_name == "SHARE") {
      base_completed[, B_country := droplevels(factor(B_country))]
    }

    for (scheme_name in names(sensitivity_config$schemes)) {
      scheme <- sensitivity_config$schemes[[scheme_name]]
      scheme_type <- as.character(scheme$type)
      completed <- data.table::copy(base_completed)
      if (scheme_type == "ate_iptw") {
        completed[, sensitivity_weight_raw := suppressWarnings(
          as.numeric(total_weight_raw)
        )]
        completed[, standardization_weight := suppressWarnings(
          as.numeric(survey_weight_scaled)
        )]
      } else if (scheme_type == "overlap") {
        completed[, overlap_treatment_weight := ifelse(
          treatment == 1L, 1 - propensity_score, propensity_score
        )]
        completed[, sensitivity_weight_raw := ifelse(
          outcome_observed_specific == 1L,
          survey_weight_scaled * overlap_treatment_weight * censoring_weight,
          NA_real_
        )]
        completed[, standardization_weight :=
          survey_weight_scaled * propensity_score * (1 - propensity_score)]
      } else {
        stop("Unsupported sensitivity weight type: ", scheme_type, call. = FALSE)
      }
      lower <- safe_quantile(
        completed$sensitivity_weight_raw, as.numeric(scheme$lower_quantile)
      )
      upper <- safe_quantile(
        completed$sensitivity_weight_raw, as.numeric(scheme$upper_quantile)
      )
      if (!is.finite(lower) || !is.finite(upper) || lower <= 0 || upper < lower) {
        stop("Invalid sensitivity weight bounds.", call. = FALSE)
      }
      completed[, sensitivity_weight := ifelse(
        outcome_observed_specific == 1L,
        pmax(lower, pmin(upper, sensitivity_weight_raw)),
        NA_real_
      )]
      observed <- completed[
        outcome_observed_specific == 1L & !is.na(outcome_value) &
          is.finite(sensitivity_weight) & sensitivity_weight > 0
      ]
      if (!nrow(observed) || data.table::uniqueN(observed$treatment) != 2L) {
        stop("Both outcome-observed treatment arms are required.", call. = FALSE)
      }
      observed[, model_weight := sensitivity_weight / mean(sensitivity_weight)]

      balance_key <- paste(
        cohort_name, scheme_name, imputation_index, sep = "_"
      )
      balance_parts[[balance_key]] <- calculate_balance(
        observed, diagnostic_variables, diagnostic_categorical
      )[, `:=`(
        cohort = cohort_name,
        scheme = scheme_name,
        imputation = imputation_index
      )]
      ess_parts[[balance_key]] <- observed[, .(
        effective_sample_size = effective_sample_size(sensitivity_weight)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        scheme = scheme_name,
        imputation = imputation_index
      )]
      weight_parts[[balance_key]] <- observed[, .(
        raw_minimum = min(sensitivity_weight_raw),
        raw_median = stats::median(sensitivity_weight_raw),
        raw_maximum = max(sensitivity_weight_raw),
        truncated_minimum = min(sensitivity_weight),
        truncated_median = stats::median(sensitivity_weight),
        truncated_maximum = max(sensitivity_weight)
      ), by = treatment][, `:=`(
        cohort = cohort_name,
        scheme = scheme_name,
        imputation = imputation_index,
        lower_bound = lower,
        upper_bound = upper
      )]

      warning_messages <- character()
      fit <- withCallingHandlers(
        stats::glm(
          formula = outcome_formula,
          data = observed,
          family = stats::quasibinomial(link = "cloglog"),
          weights = model_weight,
          na.action = stats::na.fail,
          control = stats::glm.control(maxit = 100, epsilon = 1e-9)
        ),
        warning = function(warning_condition) {
          warning_messages <<- c(
            warning_messages, conditionMessage(warning_condition)
          )
          invokeRestart("muffleWarning")
        }
      )
      if (!isTRUE(fit$converged) || anyNA(stats::coef(fit))) {
        stop(
          cohort_name, "/", scheme_name,
          ": outcome model failed in imputation ", imputation_index,
          call. = FALSE
        )
      }
      robust <- tte_cluster_vcov_glm(fit, as.character(observed$person_id))
      standardized <- tte_standardized_cloglog_effects(
        fit = fit,
        robust_vcov = robust$vcov,
        target_data = completed,
        standardization_weight = completed$standardization_weight,
        target_years = target_years
      )
      variance_continue <- standardized$risk_covariance[1L, 1L]
      variance_discontinue <- standardized$risk_covariance[2L, 2L]
      effect_parts[[balance_key]] <- data.table::data.table(
        cohort = cohort_name,
        scheme = scheme_name,
        scheme_label = as.character(scheme$label),
        estimand = ifelse(scheme_type == "overlap", "ATO", "ATE"),
        imputation = imputation_index,
        risk_continue = standardized$risk_continue,
        logit_risk_continue = tte_logit(standardized$risk_continue),
        variance_logit_risk_continue = variance_continue /
          (standardized$risk_continue * (1 - standardized$risk_continue))^2,
        risk_discontinue = standardized$risk_discontinue,
        logit_risk_discontinue = tte_logit(standardized$risk_discontinue),
        variance_logit_risk_discontinue = variance_discontinue /
          (standardized$risk_discontinue *
             (1 - standardized$risk_discontinue))^2,
        risk_difference = standardized$risk_difference,
        variance_risk_difference = standardized$variance_risk_difference,
        log_risk_ratio = standardized$log_risk_ratio,
        variance_log_risk_ratio = standardized$variance_log_risk_ratio
      )
      model_parts[[balance_key]] <- data.table::data.table(
        cohort = cohort_name,
        scheme = scheme_name,
        imputation = imputation_index,
        formula = formula_text,
        converged = isTRUE(fit$converged),
        aliased_coefficient_n = sum(is.na(stats::coef(fit))),
        warning_n = length(unique(warning_messages)),
        warnings = paste(unique(warning_messages), collapse = " | "),
        observations = nrow(observed),
        unique_person_clusters = robust$clusters,
        coefficient_n = length(stats::coef(fit)),
        events = sum(observed$outcome_value == 1L)
      )
      join_parts[[balance_key]] <- data.table::data.table(
        cohort = cohort_name,
        scheme = scheme_name,
        imputation = imputation_index,
        completed_rows = nrow(completed),
        source_rows = nrow(source_fields),
        exact_join = exact_join
      )
    }
  }
}

effects <- data.table::rbindlist(effect_parts, use.names = TRUE, fill = TRUE)
models <- data.table::rbindlist(model_parts, use.names = TRUE, fill = TRUE)
balance <- data.table::rbindlist(balance_parts, use.names = TRUE, fill = TRUE)
ess <- data.table::rbindlist(ess_parts, use.names = TRUE, fill = TRUE)
weights <- data.table::rbindlist(weight_parts, use.names = TRUE, fill = TRUE)
joins <- data.table::rbindlist(join_parts, use.names = TRUE, fill = TRUE)

balance_summary <- balance[, .(
  mean_absolute_smd = mean(absolute_standardized_difference, na.rm = TRUE),
  maximum_absolute_smd = max(absolute_standardized_difference, na.rm = TRUE),
  largest_imbalance = paste0(
    variable[which.max(absolute_standardized_difference)],
    ifelse(level[which.max(absolute_standardized_difference)] == "", "",
           paste0("=", level[which.max(absolute_standardized_difference)]))
  )
), by = .(cohort, scheme)]
ess_summary <- ess[, .(
  minimum_arm_effective_sample_size = min(effective_sample_size)
), by = .(cohort, scheme)]
model_summary <- models[, .(
  all_converged = all(converged),
  any_alias = any(aliased_coefficient_n > 0L),
  any_warning = any(warning_n > 0L),
  observations = unique(observations)[1L],
  events = unique(events)[1L]
), by = .(cohort, scheme)]

gate <- Reduce(
  function(x, y) merge(x, y, by = c("cohort", "scheme"), all = TRUE),
  list(balance_summary, ess_summary, model_summary)
)
gate_thresholds <- sensitivity_config$gates
gate[, pass_balance := maximum_absolute_smd < as.numeric(
  gate_thresholds$maximum_absolute_standardized_difference
)]
gate[, pass_ess := minimum_arm_effective_sample_size >= as.numeric(
  gate_thresholds$minimum_effective_sample_size_each_arm
)]
gate[, pass_models := all_converged & !any_alias & !any_warning]
gate[, ready_for_effect_interpretation := pass_balance & pass_ess & pass_models]

pooled_parts <- list()
pooling_parts <- list()
for (cohort_name in cohorts) {
  for (scheme_name in names(sensitivity_config$schemes)) {
    if (!isTRUE(gate[
      cohort == cohort_name & scheme == scheme_name,
      ready_for_effect_interpretation
    ])) next
    point <- effects[cohort == cohort_name & scheme == scheme_name]
    diagnostics <- models[cohort == cohort_name & scheme == scheme_name]
    df_complete <- min(diagnostics$unique_person_clusters) -
      max(diagnostics$coefficient_n)
    pools <- list(
      risk_continue = tte_pool_scalar(
        point$logit_risk_continue, point$variance_logit_risk_continue,
        df_complete = df_complete
      ),
      risk_discontinue = tte_pool_scalar(
        point$logit_risk_discontinue, point$variance_logit_risk_discontinue,
        df_complete = df_complete
      ),
      risk_difference = tte_pool_scalar(
        point$risk_difference, point$variance_risk_difference,
        df_complete = df_complete, null = 0
      ),
      risk_ratio = tte_pool_scalar(
        point$log_risk_ratio, point$variance_log_risk_ratio,
        df_complete = df_complete, null = 0
      )
    )
    transformers <- list(
      risk_continue = tte_expit,
      risk_discontinue = tte_expit,
      risk_difference = identity,
      risk_ratio = exp
    )
    for (measure_name in names(pools)) {
      pool <- pools[[measure_name]]
      transform <- transformers[[measure_name]]
      key <- paste(cohort_name, scheme_name, measure_name, sep = "_")
      pooled_parts[[key]] <- data.table::data.table(
        cohort = cohort_name,
        outcome = outcome_name,
        outcome_label = outcome_label,
        scheme = scheme_name,
        scheme_label = unique(point$scheme_label),
        estimand = unique(point$estimand),
        measure = measure_name,
        estimate = transform(pool$estimate),
        confidence_lower = transform(pool$lower),
        confidence_upper = transform(pool$upper),
        p_value = if (measure_name %in%
          c("risk_difference", "risk_ratio")) pool$p_value else NA_real_
      )
      pooling_parts[[key]] <- data.table::data.table(
        cohort = cohort_name,
        scheme = scheme_name,
        measure = measure_name,
        degrees_freedom = pool$degrees_freedom,
        within_variance = pool$within_variance,
        between_variance = pool$between_variance,
        total_variance = pool$total_variance,
        fraction_missing_information = pool$fraction_missing_information
      )
    }
  }
}
pooled <- data.table::rbindlist(pooled_parts, use.names = TRUE, fill = TRUE)
pooling <- data.table::rbindlist(pooling_parts, use.names = TRUE, fill = TRUE)
if (!nrow(pooled)) {
  stop("No alternative-weight scheme passed every diagnostic gate.", call. = FALSE)
}
pooled[, estimate_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  estimate * 1000, NA_real_
)]
pooled[, confidence_lower_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_lower * 1000, NA_real_
)]
pooled[, confidence_upper_per_1000 := ifelse(
  measure %in% c("risk_continue", "risk_discontinue", "risk_difference"),
  confidence_upper * 1000, NA_real_
)]

tte_write_csv(effects, file.path(output_dir, "08a_effects_by_imputation.csv"))
tte_write_csv(pooled, file.path(output_dir, "08a_effects_pooled.csv"))
tte_write_csv(pooling, file.path(output_dir, "08a_pooling_diagnostics.csv"))
tte_write_csv(balance_summary, file.path(output_dir, "08a_balance_summary.csv"))
tte_write_csv(ess, file.path(output_dir, "08a_effective_sample_size.csv"))
tte_write_csv(weights, file.path(output_dir, "08a_weight_summary.csv"))
tte_write_csv(models, file.path(output_dir, "08a_model_diagnostics.csv"))
tte_write_csv(gate, file.path(output_dir, "08a_weighting_gate.csv"))
tte_write_csv(joins, file.path(output_dir, "08a_join_checks.csv"))
writeLines(
  readLines(sensitivity_path, encoding = "UTF-8", warn = FALSE),
  file.path(output_dir, "08a_frozen_alternative_weight_sensitivity.yml"),
  useBytes = TRUE
)
saveRDS(
  list(effects = effects, pooled = pooled, gate = gate, config = sensitivity_config),
  file.path(private_dir, "stage08a_alternative_weight_effects_PRIVATE.rds"),
  version = 3L
)

plot_data <- pooled[measure == "risk_difference"]
if (file.exists(stage06_path)) {
  primary <- data.table::as.data.table(tte_read_csv_utf8(stage06_path))[
    measure == "risk_difference"
  ]
  primary <- primary[, .(
    cohort,
    scheme = "primary_iptw_1_99",
    scheme_label = "Primary IPTW/IPCW 1st/99th truncation",
    estimand = "ATE",
    estimate, confidence_lower, confidence_upper
  )]
  plot_data <- data.table::rbindlist(
    list(primary, plot_data[, .(
      cohort, scheme, scheme_label, estimand,
      estimate, confidence_lower, confidence_upper
    )]),
    use.names = TRUE, fill = TRUE
  )
}
plot_data[, display_label := paste0(scheme_label, " [", estimand, "]")]
sensitivity_plot <- ggplot2::ggplot(
  plot_data,
  ggplot2::aes(
    x = estimate * 1000, y = display_label,
    xmin = confidence_lower * 1000,
    xmax = confidence_upper * 1000,
    colour = cohort
  )
) +
  ggplot2::geom_vline(xintercept = 0, linetype = 2, colour = "grey45") +
  ggplot2::geom_errorbar(
    orientation = "y", width = 0.12,
    position = ggplot2::position_dodge(width = 0.45)
  ) +
  ggplot2::geom_point(
    size = 2.2,
    position = ggplot2::position_dodge(width = 0.45)
  ) +
  ggplot2::scale_colour_manual(values = c(
    "HRS" = "#2463A8", "SHARE" = "#C44E52"
  )) +
  ggplot2::labs(
    x = "3-year risk difference per 1,000",
    y = NULL, colour = "Cohort",
    title = "Primary outcome across alternative weighting specifications",
    subtitle = "Positive values indicate higher risk under observed discontinuation"
  ) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(legend.position = "bottom")
ggplot2::ggsave(
  file.path(output_dir, "08a_alternative_weight_effect_plot.png"),
  sensitivity_plot, width = 12, height = 6.5, dpi = 220
)
ggplot2::ggsave(
  file.path(output_dir, "08a_alternative_weight_effect_plot.pdf"),
  sensitivity_plot, width = 12, height = 6.5
)

gate_lines <- vapply(seq_len(nrow(gate)), function(i) {
  row <- gate[i]
  paste0(
    row$cohort, "/", row$scheme,
    ": max |SMD|=", sprintf("%.3f", row$maximum_absolute_smd),
    ", min arm ESS=", sprintf("%.1f", row$minimum_arm_effective_sample_size),
    ", ready=", row$ready_for_effect_interpretation
  )
}, character(1L))
effect_lines <- vapply(
  seq_len(nrow(pooled[measure == "risk_difference"])),
  function(i) {
    rd <- pooled[measure == "risk_difference"][i]
    rr <- pooled[
      cohort == rd$cohort & scheme == rd$scheme & measure == "risk_ratio"
    ]
    paste0(
      rd$cohort, "/", rd$scheme, " [", rd$estimand, "]",
      ": RD=", sprintf("%.1f", rd$estimate_per_1000),
      " per 1,000 (95% CI ",
      sprintf("%.1f", rd$confidence_lower_per_1000), " to ",
      sprintf("%.1f", rd$confidence_upper_per_1000),
      "); RR=", sprintf("%.3f", rr$estimate),
      " (95% CI ", sprintf("%.3f", rr$confidence_lower), " to ",
      sprintf("%.3f", rr$confidence_upper), ")."
    )
  },
  character(1L)
)
summary_lines <- c(
  "Stage 08a: alternative weighting sensitivity analysis",
  paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  "Outcome: broad cardiovascular disease or all-cause death.",
  "The two alternative IPTW truncations retain the primary ATE target.",
  "Overlap weighting targets the clinical-equipoise population (ATO).",
  "",
  "Diagnostic gates:", gate_lines,
  "",
  "Effects from schemes passing every gate:", effect_lines,
  "",
  "ATE and ATO estimates are displayed together for robustness but are not the same estimand.",
  "Do not interpret the exposure as statin-specific or clinician-directed deprescribing."
)
writeLines(summary_lines, file.path(output_dir, "08a_stage_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "08a_session_info.txt"), useBytes = TRUE)
message(paste(summary_lines, collapse = "\n"))
message("Stage 08a completed: ", normalizePath(output_dir, winslash = "/", mustWork = TRUE))
